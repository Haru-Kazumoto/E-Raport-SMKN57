<?php
$useJS=2;
include_once 'conf.php';
$det="transaksi-kas";
secureuser("admin,sa,mankeu,ksr");
$nmTabel=$oNamaTb->gl;
$nmTabelAlias='h';
$nmCaptionTabel="Data Transaksi";
$nmFieldID='id';
$configFrmInput="width:1000,title: \'Input Transaksi\'";

//$isTest=true;
cekVar("jtrans,id");
if ($jtrans==''){
	if ($id!='') {
		$jtrans=carifield("select jtrans from $nmTabel where id='$id'");
		
	} else {
		$jtrans=$_SESSION['jtranskas'];
	}
}

$kdAwal=$jtrans.$defKdBranch;
$jenisju=$nmCaptionTabel;

$evt="evalTransJU($rnd);";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
//$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
$defOrderDT="[1, 'desc']";
$sqTabel="select * from (
select xh.*,b.branch,p.nama as namapeg,pm.nama as nmpemasok,ast.nama_asset,

if(xh.stat=0,'Normal',if(xh.stat=1,'Belum ACC',if(xh.stat=2,'Sudah ACC',
if(xh.stat=3,'Tidak ACC','-')))) as vstat,

ca.account_name as akunkas
from ((((".$oNamaTb->gl." xh left join tbpbranch b on xh.kdbranch=b.kdbranch)
left join ".$oNamaTb->akun." ca on xh.kdprkkas=ca.account_code)
 left join tbppegawai p on xh.idpegawai=p.id)
 left join tbppembantu pm on xh.kdpembantu=pm.id)
 left join tbpasset ast on xh.kdasset=ast.id
 
 order by tgl desc,id desc
) as  h ";

if (op("itb,del,hp")) {
	//jika status sudah diacc g bisa diubah
	if (isset($aid)) {
		extractRecord("select stat from ".$oNamaTb->gl." where id='$aid'" );
		if ($stat>=2) {
			$pes="Transaksi sudah terlock";
			if (op("del,hp"))
				echo $pes.", data tidak bisa dihapus";
			else
				echo um412_falr($pes);
			exit;
		} 
	}
} //tanpa else

if (op("del")) {
	cekVar("aid");
	$aids=explode(",",$aid);
	$s="";
	foreach ($aids as $xid) {
		$notrans=carifield("select notrans from ".$oNamaTb->gl." where id='$xid'");
		$s.="delete from ".$oNamaTb->gld." where  notrans='$notrans' ;"; 
		$s.="delete from ".$oNamaTb->gl." where  notrans='$notrans' ;"; 
	}
	//echo $s;
	querysql($s);
	echo "";
	exit;
}elseif (op("preview")) {
	setvar("op","view");
	setvar("custom","kuitansi");
	setvar("op2","preview");
}

 

include $um_path."input-std0.php";
 
$showTbView=false;
if ($jtrans=="KM") {
	$pmpb="Penerimaan";
	//$posKas="D";
	$sFldDCap="Aksi,Kategori Penerimaan,xxDebet,RP,xxju";
	$btsAkun=40025;
} 
elseif ($jtrans=="KK") {
	$pmpb="Pengeluaran";
	//$posKas="K";
	$sFldDCap="Aksi,Kategori Pengeluaran,RP,xxKredit,xxju";
	$addTbOpr=" 
	<span  class='btn btn-primary btn-mini btn-sm' 
	onclick=\"tbOpr('view|&op=view&custom=kuitansi','$det|$det',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Kuitansi</span> 
	";
	$btsAkun=60025;
} else {
	exit;
}

$_SESSION['jtranskas']=$jtrans;

$nmCaptionTabel="$pmpb Kas";		


$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

if ((usertype("sa"))||($defKdBranch=="")) {
	$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|branch|30|C|H1-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}

$i++; $sAllField.="#17|jenisju|Jenis Transaksi|40|0|1|0|30|C|H1-0|0|1";
$gDefField[$i]=$jenisju;
$i++; $sAllField.="#17|jtrans|jtrans|40|0|1|0|30|C|S-0|1|1";
$gDefField[$i]=$jtrans;
/*
$i++; $sAllField.="#17|jenisju|Jenis Transaksi|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select jtrans as jenisju,jtrans from tbpjtrans order by jtrans asc','jenisju','GTInputJU($rnd)');";

*///$gGroupInput[$i]='Data Transaksi';
			
			
$i++; $sAllField.="#4|notrans|No. Transaksi|40|1|1|1|30|C|S-0|1|1";
if ($isAddItb) {
	$gDefField[$i]=getNewNotrans($kdAwal);
}
$i++; $sAllField.="#1|tgl|Tanggal|40|1|1|1|30|C|D-0|1|1";
$gDefField[$i]=date($formatTgl);

$i++; $sAllField.="#1|kdprkkas|Akun Kas|40|1|1|akunkas|30|C|S-1|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprkkas',0,11100,'','','evalTransJU($rnd)');";
$gDefField[$i]=$defKdPrkKasM;
$tPosDetail=$i;

$i++; $sAllField.="#13|jlhuang|Total $pmpb|12|3|1|1|7|C|N-0|1|1";

/*
$i++; $sAllField.="#12|kdpembantu|Nama Supplier|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama from tbppembantu where jpembantu=\'PM\' order by nama asc','kdpembantu');";
$i++; $sAllField.="#17|idpegawai|Nama Pegawai|40|1|1|0|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama from tbppegawai order by nama asc','idpegawai');";
*/

$i++; $sAllField.="#3|catatan|Catatan|75|1|1|1|30|C|T-2|1|1";
$gFieldView[$i]="=getKetTransJU({id},-{catatan}-);";

$i++; $sAllField.="#11|stat|STAT|7|0|0|vstat|21|C|S-0|1|1";
$i++; $sAllField.="#30|netto|Aksi|40|0|0|1|30|C|S-0|1|1";
$gFieldView[$i]="=tbAksiTrans('$jtrans');";
 
/*

$i++; $sAllField.="#17|kdasset|Nama Asset|40|1|1|nama_asset|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama_asset from tbpasset order by nama_asset asc','kdasset');";
$i++; $sAllField.="#14|carabayar|CARABAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|jlhbonus|JLHBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|kdasset|KDASSET|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#18|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|ref|REF|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|kdprkkas|KDPRKKAS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|noac|NOAC|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|nobg|NOBG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
*/

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="tgl;".$oNamaTb->gld.".tgl"; 

/*
$aCssRow=array(
	array("data[3]=='0'",'bg-red'),
	array("data[4]=='0'",'func',"$(row).css('color','red')"),
	array("data[5]=='0'",'css','color','red'),
	array("unmaskRp(data[4])>0",'func',"  $(row).find('td:eq(4)').css('color', 'red');"),
);

*/


//menambah fungsiWarna stat
$aCssRow=array(
	array("data[8]!='0'",'bg-light-green'),
); 


$jInputD=1;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD=$oNamaTb->gld;
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="xxaksi,kdprk,xxjlhd,xxjlhk,jlhuang";
//$sFldDCap="Akun,Debet,Kredit,ju,Aksi";

$sFldDIgnoreIfBlank="kdprk";//diabaikan jika kosong
$sLebarFldD="110,220,110,110,110";
$sClassFldD=",,N,N,N,,,,,,,,,,,,,,,"; 
$sAlignFldD=",,C,C,C,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian";
$jlhDefRowAdd=2;//minimal 2, karena baris 1 disembunyikan
//$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td><td align=right>rp(#jlhD2#)</td>";
$showOprD=false;
//$gFieldInputD[1]="=isiComboAcc('d_kdprk_$rnd"."_#no#|d_kdprk[]',0,$btsAkun);";
//$gFieldInputD[1]="=isiComboAcc('d_kdprk_$rnd"."_#no#|d_kdprk[]',0);";
$gFieldInputD[1]="=isiComboAcc('d_kdprk_$rnd"."_#no#|d_kdprk[]',0,$btsAkun);";
$gFieldViewD[1]="nmprk"; 

$gFuncFldD[2]=$gFuncFldD[3]=$gFuncFldD[4]="$evt";

$gFieldInputD[0]="=
'<a href=# onclick=\"$'.'(\'#d_kdprk_#rnd#_#no#\').val(0);
$'.'(\'#d_xxjlhd_#rnd#_#no#\').val(0);
$'.'(\'#d_xxjlhk_#rnd#_#no#\').val(0);
$'.'(\'#d_jlhuang_#rnd#_#no#\').val(0);
$'.'(\'#trdet_#rnd#_#no#\').hide();
$evt;\" class=\"btn btn-danger btn-sm\"> <i class=\"fa fa-trash\"></i> </a>'
;";	
//fungsi yang akan ditambahkan saat tekan addrow
$addfD="$('#d_kdprk_#rnd#_#no#').combobox();";

for ($i=4;$i<=20;$i++) {
	$gFuncFld[$i]="$evt";
}

if (op("itb")) addfbe("$evt");


/*
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/

 $sqTabelD="select d.*,d.kdprk as d_kdprk,
 mm.account_name as nmprk,
 if(d.jlhuang>=0,d.jlhuang,0) as xxjlhd,
 if(d.jlhuang<0,abs(d.jlhuang),0) as xxjlhk  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
left join ".$oNamaTb->akun." mm on d.kdprk=mm.account_code
where $nmTabelAlias.$nmFieldID='#id#' order by d.id asc
";
//echo $sqTabelD;
//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Transaksi';//caption tombol import
$sFieldCSV=strtolower('id,tgl,ref,catatan,notrans,opr,kdprkkas,jtrans,noac,nobg,tgljt,stat,kdpembantu,jlhuang,carabayar,jlhbonus,kdasset,jenisju,modified_date,kdbranch');
$sFieldCaptionCSV= strtolower('ID,TGL,REF,CATATAN,NOTRANS,OPR,KDPRKKAS,JTRANS,NOAC,NOBG,TGLJT,STAT,KDPEMBANTU,JLHUANG,CARABAYAR,JLHBONUS,KDASSET,JENISJU,MODIFIED_DATE,KDBRANCH');
$nfCSV='import_Data_Transaksi.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";

 
 
include $um_path."input-std.php";

if (op("tb,ed")) {
	//update kas
	//status transaksi: 0 normal tanpa acc, 1:perlu acc,2:sudah acc
	mysql_query2("delete from ".$oNamaTb->gld." where  notrans='$notrans' and  jlhuang=0 "); 
	if (($jlhuang>$limAccPengeluaran) &&($jtrans=='KK')) {
		extractRecord("select id as idnotif,stat as statacc from tbpnotif where notrans='$notrans'",1,1,1);
		if ($idnotif=="") {		
			$sq="INSERT INTO `tbpnotif` ( detnotif,opnotif,`notrans`, `dariuid`, `kpdsjab`) 
			   VALUES ('$det','preview','$notrans',  '$userid',  'MANKEU');";
			echo $sq;
			mysql_query($sq);
			$sq="update  ".$oNamaTb->gl." set stat=1 where notrans='$notrans'";
			mysql_query($sq);
		} else {
			if ($statacc=='1') {
				//jika diacc, maka lock
				mysql_query("update ".$oNamaTb->gl." set stat=2 where notrans='$notrans' ");
			} else {
				mysql_query("update ".$oNamaTb->gl." set stat=1 where notrans='$notrans' ");
				
			}
			echo "stat : $stat";
		}
		
		echo "Silahkan tunggu ACC dari manejer keuangan";
		
	}

	
} 