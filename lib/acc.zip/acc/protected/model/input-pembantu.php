
<?php
$useJS=2;
include_once 'conf.php';
$det="pembantu";
$nmTabel='tbppembantu';
$nmTabelAlias='pb';
$nmCaptionTabel="Data Pembantu";
$nmFieldID='id';
//$isTest=$debugMode;
cekVar("xjp");
if ($xjp!="") 
	$_SESSION["xjp"]=$xjp;
elseif(isset($_SESSION["xjp"]))
	$xjp=$_SESSION["xjp"];

if ($xjp!='') {
	addFilterTb("jpembantu='$xjp'");
	$nmCaptionTabel=($xjp=="PM"?"Data Supplier":"Data Customer");
}

if (op("getAlamatPB")) {
	cekVar("id");
	echo getPembantu($id," concat(alamat,' ',kota,' ',provinsi)");
	exit;
}


$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=true;
$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:1000,title: \'Input $nmCaptionTabel\'";

//$isTest=true; 
if ($xjp=="PL") {
	$capsa="Piutang";
} else {
	$capsa="Hutang";
	
}
$sqTabel="select * from (
select xpl.*,br.branch,
if(jpembantu='PM','Pemasok',if(jpembantu='PL','Pelanggan',jpembantu)) as xjpembantu
	from tbppembantu xpl
 left join tbpbranch br on xpl.kdbranch=br.kdbranch
) as  pb
 "; 

include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="	0|id|ID|11|0|0|0|0|C|I-4,U|0|0";

/*
$i++; $sAllField.="#19|jpembantu|JPEMBANTU|10|1|1|0|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('Pemasok;PM,Pelanggan;PL','jpembantu');";
$gDefField[$i]=$xjp;
*/
addSave('jpembantu',$xjp);
$i++; $sAllField.="#1|nama|Nama Perusahaan|35|1|1|1|100|C|S-3|1|1";
$i++; $sAllField.="#2|alamat|Alamat|70|1|1|1|130|C|S-0|1|1";
$i++; $sAllField.="#4|kota|Kota|20|1|1|1|30|C|S-1|1|1";
$i++; $sAllField.="#6|telp|Telepon|15|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|cp|Nama Kontak|30|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|hp|HP|20|1|1|1|20|C|S-1|1|1";
$i++; $sAllField.="#9|fax|Fax|20|1|1|0|20|C|S-0|1|1";

$gGroupInput[$i+1]='Saldo Awal';
$i++; $sAllField.="#26|tglsawal|Tgl. Saldo|12|1|1|1|7|C|D-0|1|1";

$gDefField[$i]=$tglsekarang;
$i++; $sAllField.="#26|sawal|Saldo Awal $capsa|9|1|1|1|7|C|C-0|1|1";

$i++; $sAllField.="#9|norek|Informasi Bank|40|1|1|0|30|C|T-0|1|1";
$i++; $sAllField.="#9|vuserid|User ID|20|1|1|0|30|C|U-1|1|1";
$gDefField[$i]="=genUID('tbppembantu','vuserid',8)";
$i++; $sAllField.="#26|vpass|Password|15|1|1|0|7|C|P-1|1|1";
$gDefField[$i]="12345678";
if ((usertype("sa"))||($defKdBranch=="")) {
	//$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|cabang|30|C|H1-0|1|1";
	$i++; $sAllField.="#47|kdbranch|CABANG|1|1|1|branch|30|C|S-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=isiCbBranch('kdbranch');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}

 

$i++; $sAllField.="#28|xrista|Ristan|40|0|0|1|30|C|S-0|1|1";
$gFieldView[$i]="=getSaldoHP({id},true);";
 
/*
//$i++; $sAllField.="#3|alamat2|ALAMAT2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|email|EMAIL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|provinsi|PROVINSI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|fax|FAX|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|npwp|NPWP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#14|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#15|www|WWW|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#16|fb|FB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|twitter|TWITTER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|pinbb|PINBB|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#20|kdwil|KDWIL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#21|creditlimit|CREDITLIMIT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#22|defppn|DEFPPN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#23|kdpj|KDPJ|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#24|jpembantu2|JPEMBANTU2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#25|deposit|DEPOSIT|7|1|1|1|7|C|S-0|1|1";

$i++; $sAllField.="#27|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#28|kdbranch|KDBRANCH|40|1|1|1|30|C|S-0|1|1";
*/

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="nama;tbppembantu.nama"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','pelanggan|pelanggan',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Pelaggan';//caption tombol import
$sFieldCSV=strtolower('id,nama,alamat,alamat2,kota,provinsi,telp,fax,cp,hp,email,term,npwp,catatan,inactive,www,fb,twitter,pinbb,jpembantu,kdwil,creditlimit,defppn,kdpj,jpembantu2,deposit,sawal,modified_date,kdbranch');
$sFieldCaptionCSV= strtolower('ID,NAMA,ALAMAT,ALAMAT2,KOTA,PROVINSI,TELP,FAX,CP,HP,EMAIL,TERM,NPWP,CATATAN,INACTIVE,WWW,FB,TWITTER,PINBB,JPEMBANTU,KDWIL,CREDITLIMIT,DEFPPN,KDPJ,JPEMBANTU2,DEPOSIT,SAWAL,MODIFIED_DATE,KDBRANCH');
//$nfCSV='import_Data_Pelaggan.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";

//memasukkan ristan ke tabel beli
if (op("tb,ed,hp")){
	updateSaldoAwalPB();
}
	

?>