<?php
$useJS=2;
include_once 'conf.php';
secureuser("admin,sa");
$det="lokasi";
$nmTabel='tbplokasi';
$nmTabelAlias='h';
$nmCaptionTabel="Data Lokasi/Gudang";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:700,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";
$isTest=$debugMode; 

$sqTabel="select * from (
select xh.*,b.branch from tbplokasi xh left join tbpbranch b on xh.kdbranch=b.kdbranch )
as h
 "; 


if (op("cblokasi,listlokasi")) {
	cekvar("kdbranch,stat");
	echo isiCbLokasi("kdlokasi","cbBrgByLokasi($rnd)",$kdbranch);
	exit;
	}

if (!usertype("sa")) {
	if ($defKdBranch!='') {
		addFilterTb("kdbranch='$defKdBranch'");
		addsave("kdbranch",$defKdBranch);
	}
}
include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|$isSA|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Lokasi/Gudang';
			
$i++; $sAllField.="#1|lokasi|Lokasi|40|1|1|1|30|C|S-0|1|1";
//$i++; $sAllField.="#2|alamat|ALAMAT|40|1|1|1|30|C|S-0|1|1";
//$i++; $sAllField.="#3|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
if (($defKdBranch=='')||(usertype("sa"))) {
	$i++; $sAllField.="#4|kdbranch|Cabang|40|1|1|branch|30|C|S-1|1|1";
	$gFieldInput[$i]="=um412_isicombo5('select kdbranch,branch from tbpbranch','kdbranch');";
}
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="lokasi;tbplokasi.lokasi"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','lokasi|lokasi',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Lokasi/Gudang';//caption tombol import
$sFieldCSV=strtolower('id,lokasi,alamat,modified_date,kdbranch');
$sFieldCaptionCSV= strtolower('ID,LOKASI,ALAMAT,MODIFIED_DATE,KDBRANCH');
//$nfCSV='import_Data_Lokasi/Gudang.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
