<?php
$useJS=2;
include_once 'conf.php';
$det="pembelian";
$nmTabel='tbpbeli';
$nmTabelAlias='h';
$nmCaptionTabel="Data Pembelian";
$nmFieldID='id';

//$isTest=$debugMode;
cekVar("jtrans");
include $lib_app_path."protected/model/input-$det-op.php";

$jtrans="PB";
$nmCaptionTabel="Pembelian";
$capPb="Pemasok";
$jenisPb="PM";
$kdAwal="PB".$defKdBranch;

addFilterTb("jtrans='$jtrans'");

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
$defOrderDT="[1, 'desc']";
$configFrmInput="width:1200,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";


$sqTabel="select * from (
select xh.*,
xh.netto-xh.paidtoday-xh.paidafter-xh.retur as kurangbayar,
br.branch as cabang,pb.nama as namapb,
pb.telp as telppb,pb.alamat as alamatpb,
pg.nama as namapj,l.lokasi
 from (((tbpbeli xh
left join tbppembantu pb on xh.kdpembantu=pb.id)
left join tbpbranch br on xh.kdbranch=br.kdbranch)
left join tbppegawai pg on xh.kdpj=pg.id)
left join tbplokasi l on xh.kdlokasi=l.id
) as  h ";
include $um_path."input-std0.php";
 
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

$i++; $sAllField.="#1|notrans|NOTRANS|20|1|1|1|30|C|H1-0|1|1";
if ($isAddItb) {
	$gDefField[$i]=getNewNoTrans($kdAwal,"tbpbeli",5);
	//setvar("op","ed");
}

if ((usertype("sa"))||($defKdBranch=="")) {
	$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|cabang|30|C|H1-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=isiCbBranch('kdbranch','cbLokasiByBranch($rnd)');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}


$i++; $sAllField.="#7|tgl|TGL|10|1|1|1|30|C|D-1|1|1";
$gDefField[$i]=date($formatTgl);

$i++; $sAllField.="#14|kdpembantu|$capPb|7|1|1|namapb|7|C|H1-1|1|1";
$gFieldInput[$i]= "=showListPembantu('$jenisPb','getSaldoHP($rnd)');";
$gAddField[$i]="='<span class=tsaldohp id=tsaldohp_$rnd > Saldo Hutang/Piutang : '.getSaldoHP('{kdpembantu}').'</span>';";

	$i++; $sAllField.="#21|kdlokasi|Lokasi|7|1|1|lokasi|7|C|H1-1|1|1";
	$gDefField[$i]=$defKdLokasi;
	$gFieldInput[$i]="=isiCbLokasi('kdlokasi');";
/*
if ((usertype("sa"))||($defKdLokasi==0)) {
	$i++; $sAllField.="#21|kdlokasi|Lokasi|7|1|1|lokasi|7|C|H1-1|1|1";
	$gDefField[$i]=$defKdLokasi;
	$gFieldInput[$i]="=isiCbLokasi('kdlokasi');";
} else {
	$i++; $sAllField.="#21|kdlokasi|Lokasi|7|2|0|lokasi|7|C|H1-0|1|1";
	$gDefField[$i]=$defKdLokasi;
	addsave("kdlokasi",$defKdLokasi,"tb");
}
*/
 
//$i++; $sAllField.="#46|alamatkirim|ALAMAT PENGIRIMAN|40|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#30|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$tPosDetail=$i;
$i++; $sAllField.="#10|brutto|SUB TOTAL|13|3|1|0|7|C|N,1|1|1";
$i++; $sAllField.="#44|byangkut|BY.ANGKUT |13|1|1|0|7|C|N-0,0|1|1";
//$i++; $sAllField.="#44|bytimbang|BY.TIMBANG |13|1|1|0|7|C|C,0|1|1";
//$i++; $sAllField.="#44|bykuli|BY.KULI |13|1|1|0|7|C|C,0|1|1";
$i++; $sAllField.="#13|netto|Total Transaksi|13|3|1|1|7|C|N,1|1|1|0";
$i++; $sAllField.="#13|retur|Retur|13|0|0|1|7|C|N-0,1|1|1|0";
$i++; $sAllField.="#17|paidtoday|Pembayaran Tunai|13|1|1|0|7|C|N-0,0|1|1|0";
//$gAddField[$i]="='Akun Pembayaran '.isiListCBKas('kdprkkas','','KM');";	

$i++; $sAllField.="#16|kdprkkas|Akun Kas/Bank|40|1|1|0|30|C|N-0|1|1";
if (op("itb")) {
	if ($isAddItb) $kdprkkas=$defKdPrkKasK;
	$gFieldInput[$i]="=isiComboAcc('kdprkkas',0,11100,'','$kdprkkas');";
}

$i++; $sAllField.="#17|kurangbayar|Terhutang|13|3|0|1|7|C|N,0|1|1|0";
//$i++; $sAllField.="#30|catatan|Catatan|40|1|1|1|30|C|T,0|1|1";

if (usertype("sa")) {
	$i++; $sAllField.="#25|kdpj|PJ|7|1|1|kdpj namapj|7|C|S-0|1|1";
	$gFieldInput[$i]="=um412_isicombo6('select id,nama from tbppegawai','kdpj');";	
	$gDefField[$i]=$vidusr;
} else {
	//$i++; $sAllField.="#25|kdpj|PJ|7|0|0|kdpj namapj|7|C|S-0|1|1";
	addSave("kdpj",$vidusr,"tb");//controller
}

for ($i=$tPosDetail;$i<=20;$i++) {
	$gFuncFld[$i]="evalTransBeli($rnd);";
}

/*
$i++; $sAllField.="#2|jtrans|JTRANS|0|0|1|0|30|C|S-0|1|1";
$gDefField[$i]="SL";
$i++; $sAllField.="#6|tglentri|TGLENTRI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|nofaktur|NOFAKTUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|nopo|NO. PO|12|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|stat|STAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|disc|DISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#12|discp|DISCP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|carabayar|CARA BAYAR|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('Tunai,Kredit','carabayar');";
$i++; $sAllField.="#18|paidafter|PAIDAFTER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#45|pdeposit|PENGAMBILAN DEPOSIT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#33|byangkut|BYANGKUT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|expedisi|EXPEDISI|40|1|1|1|30|C|S-0|1|1";


$i++; $sAllField.="#19|kdbayar|KDBAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|retur|RETUR|7|1|1|1|7|C|S-0|1|1";

$i++; $sAllField.="#34|disc2|DISC2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#35|disctot|DISCTOT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#43|bal|BAL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|berat|BERAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|statexpedisi|STATEXPEDISI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#39|tglkirim|TGLKIRIM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#40|tglsampai|TGLSAMPAI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#41|noresi|NORESI|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#26|dccharge|DCCHARGE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#27|bayar|BAYAR|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#28|kembalian|KEMBALIAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#29|dcref|DCREF|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#22|kdlokasi2|KDLOKASI2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#31|donasi|DONASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|margin|MARGIN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#42|idproject|IDPROJECT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#23|ppn|PPN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#24|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#48|idkonsolidasi|IDKONSOLIDASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#49|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

*/
//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="notrans;tbpbeli.notrans"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','penjualan|penjualan',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=gl','$det',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> 
";

$jInputD=3;
$sSzFldD ="4,18,4,7,4,7,7";//ukuran input
$detCari="barang"; 
$opcari="carib";
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbpbelid';
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="kdbrg,xxnmbarang,jlh_terima,sat,hrg,disc,subtot";
$sFldDCap="Kode,Deskripsi,Jumlah,Satuan,Harga,xx,Subtotal";
$funcEvalD=$adf="evalTransBeli($rnd)";
$sFuncFldD="$adf,,$adf,,$adf,,,,,,,,,";
$sLebarFldD="20,65,20,20,20,0,20";
$sClassFldD=",,CX,,N,CX,N,,,,,,,,,,,";
$sAlignFldD=",r,r,r,r,r,,,,,,,,,,,,";
$sAllowEditFldD="0,0,,0,,,0,,,,,,,,,,,,";
 
$nmCaptionTabelD="Detail Pembelian";

$addParamDetCari="&kdlokasi='+$('#kdlokasi_$rnd').val()+'";
$footTbD="
<div class='coldet coldet-0'>
	<div class='tisicoldet' id=jlhitemfix_$rnd>&nbsp;</div>
</div >
<div class='coldet coldet-1'>
	<div class='tisicoldet' > </div>
</div >
<div class='coldet coldet-2'>
	<div class='tisicoldet' >Jumlah</div>
</div>
<div class='coldet coldet-3'>
	<div class='tjlhd tisicoldet' id=tjlhnetto_$rnd>i</div>
</div>
<div class='coldet coldet-4 right'>
	<div class='tisicoldet ' ></div>
</div>

<div class='coldet coldet-5'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-6'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-7'>
	<div class='tjlhd tisicoldet' id=tbrutto_$rnd></div>
</div>

<div class='coldet coldet-8'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
";

$showOprD=false;

$idxAksi=0;
if (($op=='itb')) {
/*
	//$defKdPrkKasK=getKdPrkKas("K");
	if ($idxAksi==0) {
		$sFldD="xxaksi,$sFldD";
		$sFldDCap="Aksi,$sFldDCap";
		$sLebarFldD="10,$sLebarFldD";
		$sClassFldD=",$sClassFldD";
		//$idxplg++;
		//$idxsales++;
	} else {
		$sFldD.=",xxAksi";
		$sFldDCap.=",Aksi";
	}
	//'<a href=# onclick=\"bukaAjaxD(\'#tid#\',\'content1.php?det=piutang&op=pilih&newrnd=$rnd&idpembantu=\',\'width:1240\')\"class=\"btn btn-primary btn-sm\"> + </a>'.
	
	$gFieldInputD[$idxAksi]="=
	'<a href=# onclick=\"$'.'(\'#d_hrg_#rnd#_#no#\').val(0);$'.'(\'#d_jlh_terima_#rnd#_#no#\').val(0);$'.'(\'#trdet_#rnd#_#no#\').xhide();evalTransBeli($rnd);\"class=\"btn btn-danger btn-sm\"> - </a>'
	;";
	
*/
} elseif ($op=='view') {
	//$gFieldViewD[4]="0";
	//$gFieldViewD[5]="0";
	
}
/*
$gFieldInputD[1]="=um412_isicombo5('select kdbrg,nmbarang from tbpbarang order by nmbarang ','d_kdbrg_$rnd"."_#no#;d_kdbrg[]','','','','#def#','cekKdBrgTransBeli($rnd,#no#);' );";
$gFieldViewD[1]="nmbarang";

$gFieldInputD[2]="<input id=d_nmbrg2_#rnd#_#no# size=6 onkeyup='evalJlhTransBeli($rnd,#no#);'>";
*/
for ($i=3;$i<=6;$i++) {
	$gFuncFldD[$i]="evalJlhTransBeli($rnd,#no#);";
}
	


$sqTabelD="select d.*,b.nmbarang,b.satuan  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where $nmTabelAlias.$nmFieldID='#id#' 
";

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Pembelian';//caption tombol import
$sFieldCSV=strtolower('id,notrans,jtrans,nofaktur,stat,nopo,tglentri,tgl,tgljt,opr,brutto,disc,discp,netto,kdpembantu,term,carabayar,paidtoday,paidafter,kdbayar,retur,kdlokasi,kdlokasi2,ppn,jenis,kdpj,dccharge,bayar,kembalian,dcref,catatan,donasi,margin,byangkut,disc2,disctot,berat,expedisi,statexpedisi,tglkirim,tglsampai,noresi,idproject,bal,byangkutest,pdeposit,alamatkirim,kdbranch,idkonsolidasi,modified_date');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,JTRANS,NOFAKTUR,STAT,NOPO,TGLENTRI,TGL,TGLJT,OPR,BRUTTO,DISC,DISCP,NETTO,KDPEMBANTU,TERM,CARABAYAR,PAIDTODAY,PAIDAFTER,KDBAYAR,RETUR,KDLOKASI,KDLOKASI2,PPN,JENIS,KDPJ,DCCHARGE,BAYAR,KEMBALIAN,DCREF,CATATAN,DONASI,MARGIN,BYANGKUT,DISC2,DISCTOT,BERAT,EXPEDISI,STATEXPEDISI,TGLKIRIM,TGLSAMPAI,NORESI,IDPROJECT,BAL,BYANGKUTEST,PDEPOSIT,ALAMATKIRIM,KDBRANCH,IDKONSOLIDASI,MODIFIED_DATE');
//$nfCSV='import_Data_Penjualan.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";

//cek data detail awal
if ($op=='itb') {
	$addfbe="
	evalTransBeli($rnd,1);
	";
}elseif (($op=="ed")||($op=="tb")){
	querysql("update tbpbelid set cek=0  where notrans='$notrans' ");
	addsave("jtrans",$jtrans);
	//addsave("kdprkkas",$defKdPrkKasK,'tb');
	addsaveD("cek",1);
} elseif(op("hp,del")) {
	updateGLAndStockTransBeli($aid,$op);
}

$addTbSimpan=array(
array('Simpan dan Cetak','op=view&aid=#id#')
);


include $um_path."input-std.php";
//cek data detail akhir
if (op("tb,ed")){
	$kdlokasi= carifield("select kdlokasi from tbpbeli where notrans='$notrans' ");
	$skdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans' ");
	mysql_query2("delete from tbpbelid where  notrans='$notrans' and (jlh_terima=0 or cek=0) ");
	updateDefHrg($skdbrg,$kdlokasi,$jtrans);
	updateStockTrans($skdbrg,$kdlokasi,$jtrans);
	updateGLTransBeli($notrans);
}
?>
