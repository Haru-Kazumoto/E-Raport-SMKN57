<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="absensipeg";
$nmTabel='tbppegawai_absensi';
$nmTabelAlias='ab';
$nmCaptionTabel="Absensi Pegawai";
$nmFieldID='id';
$pathUpload=$toroot."upload/absensipeg/";

cekvar("op");
if ($op=="") {
	
	$scd="";
	$aw=hitungSkala([1,4,6,4]);
	for ($i=1;$i<=4;$i++) {
		$wi=$aw[$i-1];
		$scd.="
		.coldet-$i {
			width: $wi%;
		}
		";
	}
	
	echo "
	<div class='row rowabsensi'>
		<div class='colabsensi colabsensi1 col-sm-3'>
			<div class='isiabsensi isiabsensi1'>
			Tanggal
			<div id=dp></div>
			<input type=hidden name=tgl1 id=tgl1 class='dp'>
			</div>
		</div>
		<div class='colabsensi colabsensi2 col-sm-9'>
			<div class='isiabsensi isiabsensi2'>
			<div id=tcari_$rnd>tempat</div>
			</div>
		</div>
	</div>
	<style>
	.rowabsensi {
		margin:10px;
		display:block;
		background:#fff;
	}
	.colabsensi {
		display:table-cell;
	}
	.colabsensi1 {
		background:#ccc;
	}
	.colabsensi2 {
		
	}
	
	.isiabsensi {
		margin:20px;
		
	}
	
	.rowdet {
		height:30px;
	}
	
	.odd .coldet {
		background:#f9f9f9;
	}
	
	.coldet {
		float:left;
	}
	$scd 
	</style>
	
	";
	echo fbe("

	$('#dp').datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat:'dd/mm/yy',
		altField : '#tgl1',
		onSelect : function(){
			url='index.php?det=absensipeg&op=show&&xtgl='+$(this).val();
			bukaAjax('tcari_$rnd',url);
		}
	})
	");
} elseif (op("show")) {
	cekvar('xtgl');
	$tglabs=tgltosql($xtgl);
	$judul= "Absensi Tanggal ".tglIndo2($tglabs)."<br>";
	
	$addsy="";
	if ((usertype("sa"))||($defKdBranch=="")) {
	} else {
		$addsy.="and kdbranch='$defKdBranch'";
	}
	
	$isi="";

	$isi.="
		<div class='rowdet'>
			<div class='coldet coldet-1'><div id='tisicoldet'>No</div></div>
			<div class='coldet coldet-2'><div id='tisicoldet'>Nama</div></div>
			<div class='coldet coldet-3'><div id='tisicoldet'>Absensi</div></div>
			<div class='coldet coldet-4'><div id='tisicoldet'>Catatan</div></div>
		</div>
			";
	$sq="select id,nama from tbppegawai where 1 $addsy ";
	
	
	$i=0;
	$dt=$db->query($sq)->fetch();
	foreach($dt as $r) {
		$troe=($i%2==0?"even":"odd");
		extractRecord("select kehadiran,ket from tbppegawai_absensi where idpegawai='$r[id]' and tglabsensi='$tglabs'");
		$sia=um412_isicombo5("R:Hadir;H,Sakit;S,Ijin;I,Alpha;A","kehadiran_$i|kehadiran[]","","","Pilih",$kehadiran);
		$sib="<input type=text id=ket_$i name='ket[]' value='$ket'>";
		$isi.="
		<input type=hidden name=idpeg[] value='$r[id]'>
		<div class='$troe rowdet'>
			<div class='coldet coldet-1'><div id='tisicoldet'>$r[id]</div></div>
			<div class='coldet coldet-2'><div id='tisicoldet'>$r[nama]</div></div>
			<div class='coldet coldet-3'><div id='tisicoldet'>$sia</div></div>
			<div class='coldet coldet-4'><div id='tisicoldet'>$sib</div></div>
		</div>
		";
		$i++;
	}
	
	
	$frm=new htmlForm;
	$frm->nmForm="frm1";
	$frm->nmValidasi="$det";
	$frm->rnd=$rnd;	
	$frm->nfAction="index.php?contentOnly=1&useJS=2";
	$frm->useAjaxSubmit=true;//default
	$frm->hideFormAfterSubmit=false;
	$frm->tresult="tanggaran";
	$frm->tHideTesult=false;;
	$frm->awalForm();
	$frm->addHiddenField([["op","edit"],["det",$det],['xtgl',$xtgl]]);
	$frm->addFbe("resizeInputTb();");
	/*
	$frm->rowForm("rnama","Nama Lengkap","text|60|5|CF|fa-user");
	$frm->rowForm("tahun","Tahun","text|10|5");
	$frm->rowForm("bulan~".isiComboBulan("bulan"),"Bulan","text|30|5");
	$frm->rowForm("txtmateri2","Teks","TA3");
	$frm->rowForm("nfmgambar","File tambahan Materi (Gambar)","file|I|0|image/*|Pilih File Gambar|multiple","",$rab);
	$frm->addTxtBody("<input type=submit class='btn btn-sm btn-primary' value='OK'>",$isi=" ");
	//$frm->addHiddenField("det",$det);
	*/
	$frm->addTxtBody("<div class='tbdet3'>$isi</div>");
	$frm->addTxtBody("<input type=submit class='btn btn-sm btn-primary' value='Simpan'>",$isi=" ");
	$frm->akhirForm();
	$form1= $frm->show();
	$t='';
	$t.=tpboxInput($form1,$judul);
	$t.="<section class='content' id='tanggaran'></section>";


	echo $t;
	
} elseif (op("edit")) {
	//echo "simpan....$xtgl";
	$tglabs=tgltosql($xtgl);
	cekvar("idpeg");
	$aidpeg=$_REQUEST['idpeg'];
	$akehadiran=$_REQUEST['kehadiran'];
	$aket=$_REQUEST['ket'];
	$ssq="";
	$i=0;
	foreach($aidpeg as $idpeg) {
		$kehadiran=$akehadiran[$i];
		$ket=$aket[$i];
		$c=carifield("select id  from tbppegawai_absensi where idpegawai='$idpeg' and tglabsensi='$tglabs'");
		if ($c=="") {
			$ssq.="insert into tbppegawai_absensi(idpegawai,tglabsensi,kehadiran,ket) values('$idpeg','$tglabs','$kehadiran','$ket');";
		} else {
			$ssq.="update tbppegawai_absensi set kehadiran='$kehadiran',ket='$ket' where id='$c';";
			
		}
		$i++;
	}
	
	if ($ssq!='') {
		//echo $ssq;
		querysql($ssq);
		echo "Penyimpanan berhasil";
	} else {
		echo "Tidak ada data yang disimpan";
	}
	
	
}
