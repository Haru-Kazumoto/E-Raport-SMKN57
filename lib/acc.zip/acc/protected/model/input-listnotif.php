<?php
//secureUser('admin,sa,Super Admin');
$det="listnotif";
$nmTabel='tbpnotif';
$nmTabelAlias='n';
$nmCaptionTabel="List Notifikasi";
$nmFieldID='id';
$pathUpload=$toroot."upload/listnotif/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=false;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=false;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";


$isTest=false; 

$sqTabel="select * from (
	select xn.*,g.id as idtrans,
if(xn.stat='2','ACC',xn.stat) as vstat
	from 
	tbpnotif xn left join $oNamaTb->gl g on xn.notrans=g.notrans
) as  n ";

if (op("approve")) {
	if ($detnotif=='transaksi-kas') {
		$tb= $oNamaTb->gl;
		$ssq="update tbpnotif set stat='2' where id='$id';";
		$ssq.="update $tb set stat='2' where id='$idtrans'";
		querysql($ssq);
		echo um412_falr("ACC berhasil","success");
		setRefreshTb($detnotif);
		
	}
	exit;
	
}

include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah='sarwono'");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}
*/

addFilterTb("kpdsjab like '%$userType%'");

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='List Notifikasi';
			
$i++; $sAllField.="#1|notrans|NO.TRANS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|tglnotif|TGL. NOTIF|40|1|1|1|30|C|dt-0|1|1";
$i++; $sAllField.="#3|info|INFO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|dariuid|DARI|40|1|1|1|30|C|S-0|1|1";
//$i++; $sAllField.="#5|kpduid|KPDUID|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|kpdsjab|KPDSJAB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|stat|STATUS|40|1|1|vstat|30|C|S-0|1|1";
$i++; $sAllField.="#7|aksi|AKSI|40|0|0|1|30|C|S-0|1|1";
$gFieldView[$i]="=tbAksiNotif({id});";

//$i++; $sAllField.="#8|statuid|STATUID|40|1|1|1|30|C|S-0|1|1";
//$i++; $sAllField.="#9|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

/*
$gPathUpload[$i]=."upload/listnotif/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('listnotif','idperusahaan|nama_perusahaa',121691,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='
A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="notrans;tbpnotif.notrans"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','listnotif|listnotif',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','n.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=0;
$showNoD=true;
//--------------------------detail

$detCari="barang"; 
$funcEvalD=="evalTransBeli(121691)";
$sFuncFldD=",,,,,,,,,,,,";
$opcari="carib2";
$classtb="clistnotif";
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sSzFldD ='4,18,4,4,4,4,7,7';//ukuran input
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian $nmCaptionTabel";
$jlhDefRowAdd=1;
$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");


/*
	//ver 2
	$sJenisFldD=',,,,,,i,,i,,,,,,,,,,,,,';
	$gFieldInputD=$gFieldViewD;
	$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
	$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_121691_#no#|d_idsales[]','','','','#def#' );";
*/

/*
$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

/*
$gFieldViewD[2]="nmpelanggan";
$gFieldViewD[$idxsales]="nmsales";

$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
		array('nmbarang','kdbrg-nmbarang|like','Kode/Nama Brg. : #inp#'),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import List Notifikasi';//caption tombol import
$sFieldCSV=strtolower('id,notrans,tglnotif,info,dariuid,kpduid,kpdsjab,stat,statuid,modified_date');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,TGLNOTIF,INFO,DARIUID,KPDUID,KPDSJAB,STAT,STATUID,MODIFIED_DATE');
$nfCSV='import_List_Notifikasi.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
//catatan2
$tPosDetail=10;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="
Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>