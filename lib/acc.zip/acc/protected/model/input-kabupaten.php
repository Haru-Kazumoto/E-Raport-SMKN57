
<?php
$useJS=2;
include_once 'conf.php';

$det="kabupaten";
$nmTabel='tbkabupaten';
$nmTabelAlias='kb';
$nmCaptionTabel="kabupaten";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$showFrmCari=true;
$showTbHapus=true;
$showTbView=true;
$showTbUbah=true;
$showTbPrint=true;
$showTbTambah=true; 
$showExportDB=false; 
$showTbUnduh=false;
$showTbUnggah=false;
$configFrmInput="width:700,title: \'Input Data\'";


$isTest=false; 

$sqTabel="select * from (
select xkb.*, provinsi,
concat('KB',right(concat('000000',xkb.id),6)) as vuserid
from tbkabupaten xkb left join tbprovinsi pr on xkb.idprovinsi=pr.id
) as kb
 ";
//$sqTabel="select * from (xkb.* from tbkabupaten xkb) as  kb ";


include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Kabupaten';
			
$i++; $sAllField.="#1|kabupaten|KABUPATEN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|idprovinsi|PROVINSI|7|1|1|provinsi|7|C|S-0|1|1";

$gFieldInput[$i]="$"."inp=um412_isicombo5('select id,provinsi from tbprovinsi   order by provinsi ','idprovinsi');";
$isiComboFilterTabel="kabupaten;tbkabupaten.kabupaten"; 

$i++; $sAllField.="#1|cp|KONTAK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|hp|HP|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#1|vuserid|USER ID|40|0|0|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|vpass|PASSWORD|40|1|1|0|30|C|P-0|1|1";

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','kabupaten|kabupaten',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Kabupaten';//caption tombol import
$sFieldCSV=strtolower('id,kabupaten,idprovinsi');
$sFieldCaptionCSV= strtolower('ID,KABUPATEN,IDPROVINSI');
$nfCSV='import_Kabupaten.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
