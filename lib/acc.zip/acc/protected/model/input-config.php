<?php
//$useJS=2;
//include_once 'conf.php';
//var_dump($_REQUEST);
secureUser('admin,sa,Super Admin');
$det="config";
$nmTabel='tbconfig';
$nmTabelAlias='c';
$nmCaptionTabel="Konfigurasi";
$nmFieldID='id';
$pathUpload=$tohost."content/img/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=false;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=true;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";
//$isTest=$debugMode; 

$sqTabel="select * from (
select xc.* from tbconfig xc
) as  c ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah=''");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Konfigurasi';
			
$i++; $sAllField.="#2|namapsh|NAMAPSH|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|alamat|ALAMAT|70|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#4|alamat2|ALAMAT2|70|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#5|alamat3|ALAMAT3|70|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#6|alamat4|ALAMAT4|70|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#11|kota|KOTA|30|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|telp|TELP|25|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|fax|FAX|20|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#9|email|EMAIL|30|1|1|0|30|C|S-0|1|1";
/*
$i++; $sAllField.="#12|cp|CP|40|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#13|hp|HP|40|1|1|0|30|C|S-0|1|1";
*/
$i++; $sAllField.="#31|defkdbranch|Def. Cabang|40|1|1|0|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch order by branch','defkdbranch')";

$i++; $sAllField.="#42|defkdlokasi|Def. Gudang|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6(\"select l.id,concat(lokasi,'-',branch) from tbplokasi l left join tbpbranch b on l.kdbranch=b.kdbranch order by lokasi\",'defkdlokasi')";
$i++; $sAllField.="#43|nflogo|File Logo Besar|40|1|1|0|30|C|F-0,I|1|1";
$i++; $sAllField.="#43|nflogo2|File Logo Kecil|40|1|1|0|30|C|F-0,I|1|1";

/*
$i++; $sAllField.="#14|verdb|VERDB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|defkdproject|DEFKDPROJECT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#33|tglawal|TGLAWAL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|regid|REGID|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|cos|COS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#39|judulweb|JUDULWEB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#40|deskripsiweb|DESKRIPSIWEB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#41|dbwebver|DBWEBVER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#44|rndjs|RNDJS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#45|umdbver|UMDBVER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#22|mysqlpath|MYSQLPATH|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#23|odbcname|ODBCNAME|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#24|setbeli|SETBELI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#25|setjual|SETJUAL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#26|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#27|tmpfolder|TMPFOLDER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#28|defidpelanggan|DEFIDPELANGGAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#29|dbver|DBVER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#30|toleransi|TOLERANSI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#1|exename|EXENAME|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|sn|SN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|dccharge|DCCHARGE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#16|fldreport|FLDREPORT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|tt_do1|TT_DO1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|tt_do2|TT_DO2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|tt_do1_nama|TT_DO1_NAMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|tt_do2_nama|TT_DO2_NAMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#21|tt_accounting_nama|TT_ACCOUNTING_NAMA|40|1|1|1|30|C|S-0|1|1";

$gPathUpload[$i]=."upload/config/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('config','idperusahaan|nama_perusahaa',485751,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="exename;tbconfig.exename"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','config|config',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','c.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_485751_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Konfigurasi';//caption tombol import
$sFieldCSV=strtolower('id,exename,namapsh,alamat,alamat2,alamat3,alamat4,telp,fax,email,sn,kota,cp,hp,verdb,dccharge,fldreport,tt_do1,tt_do2,tt_do1_nama,tt_do2_nama,tt_accounting_nama,mysqlpath,odbcname,setbeli,setjual,catatan,tmpfolder,defidpelanggan,dbver,toleransi,defkdbranch,defkdproject,tglawal,branch,kdbranch,regid,modified_date,cos,judulweb,deskripsiweb,dbwebver,defkdlokasi,nflogo,rndjs,umdbver');
$sFieldCaptionCSV= strtolower('ID,EXENAME,NAMAPSH,ALAMAT,ALAMAT2,ALAMAT3,ALAMAT4,TELP,FAX,EMAIL,SN,KOTA,CP,HP,VERDB,DCCHARGE,FLDREPORT,TT_DO1,TT_DO2,TT_DO1_NAMA,TT_DO2_NAMA,TT_ACCOUNTING_NAMA,MYSQLPATH,ODBCNAME,SETBELI,SETJUAL,CATATAN,TMPFOLDER,DEFIDPELANGGAN,DBVER,TOLERANSI,DEFKDBRANCH,DEFKDPROJECT,TGLAWAL,BRANCH,KDBRANCH,REGID,MODIFIED_DATE,COS,JUDULWEB,DESKRIPSIWEB,DBWEBVER,DEFKDLOKASI,NFLOGO,RNDJS,UMDBVER');
$nfCSV='import_Konfigurasi.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=46;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
