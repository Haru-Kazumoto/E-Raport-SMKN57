<?php
cekVar("op,op2,ia");

//ia:include active
$sq="select * from ".$oNamaTb->kontrolAkun." ".($ia==1?"":"where aktif=1")." order by id";
$hq=mysql_query2($sq);

if ($op=="") {
	$t="";
	$det="config-acc";
	$idForm="form_$rnd";
	$newop="update";
	$tempat="tedit$rnd";
	$rnd2=$rnd."123";
	

	$t.="
	<div style='max-height:350px;overflow:auto;margin : 0px auto;width:100%;max-width:900px;padding:20px;background:#fff'>
	
	";
	
	$i=0;
	while ($r=mysql_fetch_array($hq)) {
		$cap=($r['ket']==''?$r['name']:$r['ket']);
		$isi=$r['value']." - ".getPrk	($r['value']);
		$isi.=" ( $r[name] ) ";
		$t.= rowITB('-',$cap,$isi,$r["value"] ,$stytr='',$addstylecap='');
		$i++;
	}
	
	$t.="
	</div>
	
	<br>
	<p style='margin-top:5px;text-align:right;margin : 0px auto;width:100%;max-width:900px;'>
	<input type='button' value='Edit' id='tbedit_$rnd' class='button btn btn-primary btn-sm' onclick=\"
	bukaAjax('$tempat','index.php?det=$det&ia=$ia&useJS=2&contentOnly=1&newrnd=$rnd2&op=edit',0,'awalEdit($rnd2)');
	\">

	</p>
	";

	echo "<div class='content' id='$tempat' >";
	echo tpTitlePage("Konfigurasi Akun");
	echo tpBoxInput($t);
	echo "</div>";

} else if ($op=="edit") {
	$t="";
	$det="config-acc";
	$idForm="form_$rnd";
	$newop="update";

	$t.="
	<div id=ts$idForm style='display:none'></div>
	<form id='$idForm' 
	action='index.php?det=$det&useJS=2&contentOnly=1' 
	method='Post' 
	onsubmit=\"ajaxSubmitAllForm('$idForm','ts$idForm','$det','selesaiEdit($rnd)');return false;\" 
	style='padding:0px;margin:0 0 5px 0;'>
	
	<div style='max-height:350px;overflow:auto;margin : 0px auto;width:100%;max-width:900px;padding:20px;background:#fff'>
	<input type=hidden name=ia value='$ia'>
	<input type=hidden name=op value='$newop'>
	<input type=hidden name=opx value='$newop'>
	
	";
	
	$i=0;
	while ($r=mysql_fetch_array($hq)) {
		$cap=($r['ket']==''?$r['name']:$r['ket']);
		$nminput="value_$i";
		$nminput2="aktif_$i";
		eval("
		$"."$nminput='$r[value]';
		$"."$nminput2='$r[aktif]';
		");
		//$isi=isiComboAcc("value$i");
		$isi=um412_isicombo6("select * from (select account_code,concat(account_code,'/',account_code2,'-',account_name) as cap from ".$oNamaTb->akun." 
		where ish=0 ) as ac order by cap ","$nminput,class='combobox' ");
		if ($ia==1) {
			$isi.="<input name=ket_$i id=ket_$i"."_$rnd value='$r[ket]' size=30>";
			$isi.=um412_isiCombo6("Aktif;1,Non Aktif;0","aktif_$i");
		}
		$isi.=" <input name=id_$i id=id_$i"."_$rnd value='$r[id]' type=hidden>";		
		$t.= rowITB($nminput,$cap,$isi,$r["value"] ,$stytr='',$addstylecap='');
		$i++;
	}
	$t.="
	</div>
	
	<br>
	<p style='margin-top:5px;text-align:right;margin : 0px auto;width:100%;max-width:900px;'>
	<input type='submit' value='Simpan' id='tbsimpan_$rnd' class='button btn btn-primary btn-sm' onclick='
	'>

	</p>
	";
	$t.="</form>";
	echo "<div class='content'>";
	echo tpTitlePage("Konfigurasi Akun");
	echo tpBoxInput($t);
	echo "</div>";
	echo fbe("$('.combobox').combobox();");
} elseif ($op=="update") {
	//echo $sq;
	$i=0;
	$t="";
	$ssql="";
	while ($r=mysql_fetch_array($hq)) {
		$adds='';
		$id=$_REQUEST["id_$i"];
		$val=$_REQUEST["value_$i"];
		if ($ia==1) {
			$ket=$_REQUEST["ket_$i"];
			$aktif=$_REQUEST["aktif_$i"];
			$adds.=",ket='$ket',aktif='$aktif'";
		}
		
		$ssql.="update ".$oNamaTb->kontrolAkun." set value='$val' $adds where id='$id';";
		$i++;
	}
	querysql($ssql);
	//echo $ssql;
	//echo $t;
	echo "Update berhasil....";
	exit;
}
?>