<?php
$useJS=2;
include_once 'conf.php';
secureuser("sa");
$det="cabang";
$nmTabel='tbpbranch';
$nmTabelAlias='br';
$nmCaptionTabel="Data Cabang";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:700,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";

//$isTest=true;//$debugMode; 

$sqTabel="select * from (
select xbr.*,sk.namas from tbpbranch xbr left join tb2 sk on xbr.kd=sk.kode)
as br
 ";
$sqTabel="select * from (select xbr.* from tbpbranch xbr) as  br ";


include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Cabang';
			
$i++; $sAllField.="#3|kdbranch|Kode|10|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|branch|Cabang|30|1|1|1|30|C|S-0|1|1";
$gGroupInput[$i+1]='Alamat';
$i++; $sAllField.="#2|alamat|Alamat Baris 1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|alamat2|Alamat Baris 2|40|1|1|1|30|C|S-0|1|1";

$gGroupInput[$i+1]='Default';
$i++; $sAllField.="#7|kdprkkasm|Akun Kas Penerimaan|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=isiListCBKas('kdprkkasm');";
$i++; $sAllField.="#7|kdprkkask|Akun Kas Pengeluaran|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=isiListCBKas('kdprkkask');";
$i++; $sAllField.="#7|kdprkkaskecil|Akun Kas Kecil|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=isiListCBKas('kdprkkaskecil');";
$i++; $sAllField.="#7|kdprkbank|Akun Bank|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=isiListCBKas('kdprkbank');";

$i++; $sAllField.="#7|kdpembantuumum|Pelanggan Umum|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]= "=showListPembantu('PL','','kdpembantuumum');";

$i++; $sAllField.="#7|defkdlokasi|Lokasi/Gudang|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=isiCbLokasi('defkdlokasi');";


//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Cabang';//caption tombol import
$sFieldCSV=strtolower('id,branch,alamat,kdbranch,pwd1,pwd2,modified_date,kdprkkas,kdprkpiutang,kdprkhutang');
$sFieldCaptionCSV= strtolower('ID,BRANCH,ALAMAT,KDBRANCH,PWD1,PWD2,MODIFIED_DATE,KDPRKKAS,KDPRKPIUTANG,KDPRKHUTANG');
//$nfCSV='import_Data_Cabang.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
