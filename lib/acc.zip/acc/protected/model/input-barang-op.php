<?php
if (op("cbbrgstock")) {
	cekvar("kdlokasi");
	echo isiCbBrgStock($kdlokasi);
	exit;
}
elseif ($op=="gethrgjual") {
	cekVar("kdbrg");
	echo carifield("select hrgjual from tbpbarang where kdbrg='$kdbrg'");
	exit;

}elseif (op('mergebrg,ubahkdbrg')) {
	/*
	mergebrg: merger kode barang ke kd barang lain (dalam kasus ada barang dobel kode)
	ubahkode: mengubah kode barang menjadi kode baru
	*/
	cekvar("kdbrg");
	if ($kdbrg=="") {
		cekvar("aid");
		//echo "aid $aid";
		if ($aid=="") exit;
		carifield("select kdbrg from tbpbarang where id='$aid'");
	}
	
	if ($kdbrg=="") exit;
	$kdbrgold=$kdbrg;
	if (op("mergebrg")) {
		
		$capbaru="Kode Barang Tujuan";
		$capdlg="Merger Kode Barang, Kode Barang: $kdbrg";
		
	} else {
		$capbaru="Kode Baru";
		$capdlg="Ubah Kode Barang, Kode Lama: $kdbrg";
		$kdbrgnew=$kdbrg;
	}
	$newop=($op."p");
	//$sq="select kdbrg,kdlokasi,stawal,$sqStAkhir from tbpstock where id='$aid'";
	//extractRecord($sq);
		$frm=new htmlForm;
		$frm->nmForm="frm1";
		$frm->nmValidasi="$det";
		$frm->rnd=$rnd;	
		$frm->nfAction="index.php?contentOnly=1&useJS=2";
		$frm->useAjaxSubmit=true;//default
		$frm->hideFormAfterSubmit=false;
		$frm->tresult="tanggaran";
		$frm->tHideTesult=false;;
		$frm->awalForm();
		$frm->addHiddenField([
		["newrnd","rnd"],
		["op",$newop],
		["det",$det],
		]);
		
		$frm->rowForm("kdbrgold","Kode Lama ","text|10|0|");
		$frm->rowForm("kdbrgnew",$capbaru,"text|10|0|");
		$frm->addTxtBody("
		<input type=submit class='btn btn-sm btn-primary' value='OK'>
		<br>
		<br>
		".um412_falr("
		Note:<br> 
		<br>
Merge kode barang akan mengakibatkan semua data (transaksi, stock semua gudang, dll) 
berhubungan dengan kode yg bersangkutan (kode lama) akan diubah ke kode baru (kode tujuan)<br>
Kode barang lama akan dinonaktifkan.
		<br>
		Setelah memasukkan perubahan data, lakukan refresh untuk melihat hasil di daftar stok. 
		","warning"),$isi=" ");
		
		$frm->fae="tutupDialog2('$idtd');";
		
		$frm->akhirForm();
		$form1= $frm->show();
		$t='';
		$t.=tpboxInput($form1,$capdlg);
		
		$t.="<section class='content' id='tanggaran'></section>";
		echo $t;
	
}
elseif (op('mergebrgp,ubahkdbrgp')) {
	cekvar("kdbrgold,kdbrgnew");
	$ssq='';
	if (op("mergebrgp")) {
		$sq="select kdbrg from tbpbarang where kdbrg='$kdbrgnew'";
		if (carifield($sq)=="" ) {
			echo "Kode tujuan tidak ditemukan di data barang";
			exit;
		}
		$ssq.="
		delete from  tbpstock where  kdbrg='$kdbrgold';
		update tbpbarang set inactive='1' where kdbrg='$kdbrgold';
		";
	} else {
		//ubah kode
		$ssq.="update tbpstock set kdbrg='$kdbrgnew' where kdbrg='$kdbrgold';
		update tbpbarang set kdbrg='$kdbrgnew' where kdbrg='$kdbrgold';
		";
	}
	$ssq.="
		update tbpbelid set kdbrg='$kdbrgnew' where kdbrg='$kdbrgold';
		update tbphrgcustom set kdbrg='$kdbrgnew' where kdbrg='$kdbrgold';
		update tbphrgjual set kdbrg='$kdbrgnew' where kdbrg='$kdbrgold';
		";
		
	//update tbpstock set kdbrg='$kdbrgold*' where kdbrg='$kdbrgold';
	
	querysql($ssq);
	//echo $ssq;
	echo 1;
	exit;	
} elseif (op("cari2,carib,caribb,caribjadi,carib2,caribj,caribj2,caristop")) {	
//carirj:carireturjual
	cekvar("kdlokasi,margin,jtrans,kdpb");
	$capCari="Nama Barang ";
	$syCari=' where 1';
	 $jbb = "j";
     $fldhrg = ($margin == 3? "hrgjual3":($margin == 2? "hrgjual2": "hrgjual"));
	 $kdpembantu = $kdpb;
	 
	 $useCustomHrgJual=false;
	 if (($useCustomHrgJual) && ($kdpembantu!='')) {
		 $hrgj="tbphrgcustom.kdpembantu,if (tbphrgcustom.hrgcustom >0,tbphrgcustom.hrgcustom,tbpbarang.hrgjual) as hrgjual";
		 $addSqFrom=" left join tbphrgcustom  on tbpbarang.kdbrg=tbphrgcustom.kdbrg and tbphrgcustom.kdpembantu='" .$kdpembantu ."' ";
		 $sFldFormatTampil=",,,N,CX,,";
	 } else {
		$hrgj="hrgjual";
		$addSqFrom="";
		$sFldFormatTampil=",,,N,CX,";
	 }
	 
	 if ($kdlokasi!='') {
		$addSqFrom.=" and kdlokasi='$kdlokasi'";
		 
	 }
	//echo "op $op";
	//carib2:hrgjual juga ditampilkan dan diinputkan di pembelian
	if (op("carib,caribb,carib2,caribjadi")) {
		//$fldhrg="tbpbarang.defhrgbeli";		
		$fldhrg="tbpstock.defhrgbeli";		
		$sqBarang = "select tbpstock.kdbrg ,tbpbarang.nmbarang ,tbpbarang.satuan as sat,
		tbpstock.defhrgjual as defhrgj,
		$fldhrg AS hrg,$sqStAkhir  
		from tbpstock   inner join tbpbarang  on tbpstock.kdbrg=tbpbarang.kdbrg $addSqFrom ";
		$fldhasil="kdbrg,nmbarang,sat,hrg";
		
		$sFldTampil = "kdbrg,nmbarang,sat,hrg,defhrgj,stakhir";
		$sFldCapTampil="Kode,Nama Barang,Satuan,Harga Beli,Harga Jual,Stok Akhir";

		if (op("carib2")) { 
			$fldhasil.=",defhrgj";
		}
		elseif (op("caribjadi")) { 
			$syCari.=" and jenis = 'bj'";
		}
		elseif (op("caribb")) { 
			$syCari.=" and (jenis = 'bb' or jenis='bp')";
			$sFldTampil = "kdbrg,nmbarang,sat,hrg,stakhir";
			$sFldCapTampil="Kode,Nama Barang,Satuan,Harga Beli,Stok Akhir";
		
		}
		//echo "func op ---->$op ";
	}elseif (op("caristop")) {
		$sqBarang = "select tbpstock.kdbrg ,tbpbarang.nmbarang , tbpbarang.satuan,
		tbpbarang.defhrgbeli AS hrg,$sqStAkhir0 as stsystem  
		from tbpstock   inner join tbpbarang  on tbpstock.kdbrg=tbpbarang.kdbrg $addSqFrom ";
		$fldhasil="kdbrg,nmbarang,satuan,stsystem,stsystem,hrg";
		$sFldTampil = "kdbrg,nmbarang,satuan,hrg,stsystem";
		$sFldCapTampil="Kode,Nama Barang,Satuan,Harga,Stok Akhir";
	} else {
		//caribj
		$hrgj="tbpstock.defhrgjual";
		echo $sqBarang = "select tbpstock.kdbrg ,tbpbarang.nmbarang ,tbpbarang.satuan,
		tbpbarang.hrgpokok AS hrgbeli, $hrgj as hrg,$sqStAkhir  
		from tbpstock   inner join tbpbarang  on tbpstock.kdbrg=tbpbarang.kdbrg $addSqFrom ";
		$fldhasil="kdbrg,nmbarang,satuan,hrg";
		//kdbrg,nmbarang,satuan,hrg
		$sFldTampil = "kdbrg,nmbarang,satuan,hrg,stakhir";
		$sFldCapTampil="Kode,Nama Barang,Satuan,Harga,Stok Akhir";

	
	}
     $sqUkuran = "170,650,0,100,100,100,100,100,100";
     
	 //(tbpbarang.jbb like '%$jbb%' or isnull(jbb)) and
	$sy = " where  tbpbarang.inactive=0 and tbpstock.kdlokasi='$kdlokasi'";
	$sqcari=$sqBarang;//"select kdbrg,namabrg,satuan,hrgjual,aturanpakai,1 as jlh from tbobat where 1 ";
	$fldcari="tbpstock.kdbrg,nmbarang";
	$addParamCari="&kdlokasi=$kdlokasi";
	include $um_path."frmcari2.php";
	exit;
} elseif (op("carirj,carirb")) {	
//carirj:carireturjual
	
	cekvar("kdlokasi,margin,jtrans,kdpb,ntransb");
	$capCari="Nama Barang ";
	$addSqFrom =""; 
	$sqBarang = "select d.kdbrg ,b.nmbarang ,b.satuan,d.hrg,d.jlh_terima as jlh from tbpbelid d   inner join tbpbarang b on d.kdbrg=b.kdbrg $addSqFrom ";
	$fldhasil="kdbrg,nmbarang,satuan,hrg";
	$sFldTampil = "kdbrg,nmbarang,satuan,hrg,jlh";
	$sFldCapTampil="Kode,Nama Barang,Satuan,Harga,Jumlah";
	$sqUkuran = "170,650,0,100,100,100,100,100,100";
	$sy = " where (d.notrans='$ntransb') ";
	$addParamCari="&ntransb=$ntransb";
	$sqcari=$sqBarang;//"select kdbrg,namabrg,satuan,hrgjual,aturanpakai,1 as jlh from tbobat where 1 ";
	$fldcari="nmbarang";
	include $um_path."frmcari2.php";
	exit;
}
