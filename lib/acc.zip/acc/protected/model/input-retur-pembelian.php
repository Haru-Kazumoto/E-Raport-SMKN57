<?php
$useJS=2;
include_once 'conf.php';
$det="retur-pembelian";
$nmTabel='tbpbeli';
$nmTabelAlias='h';
$nmCaptionTabel="Data Pembelian";
$nmFieldID='id';

$jtrans="PR";
$nmCaptionTabel="Retur Pembelian";
$capPb="Pemasok";
$jenisPb="PM";
$kdAwal="PR".$defKdBranch;
//$isTest=true;
addFilterTb("jtrans='$jtrans'");

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;

$defOrderDT="[1, 'desc']";
$configFrmInput="width:1200,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";


$sqTabel="select * from (
select xh.*,xh2.tgl as tglb,
xh.netto-xh.paidtoday-xh.paidafter-xh.retur as kurangbayar,
br.branch as cabang,pb.nama as namapb,
pb.telp as telppb,pb.alamat as alamatpb,
pg.nama as namapj,l.lokasi
 from (((tbpbeli xh
 left join tbpbeli xh2 on xh.nopo=xh2.notrans 
left join tbppembantu pb on xh.kdpembantu=pb.id)
left join tbpbranch br on xh.kdbranch=br.kdbranch)
left join tbppegawai pg on xh.kdpj=pg.id)
left join tbplokasi l on xh.kdlokasi=l.id
) as  h ";

include $um_path."input-std0.php";
 
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

$i++; $sAllField.="#1|notrans|NOTRANS|20|1|1|1|30|C|H1-0|1|1";
if ($isAddItb) {
	$gDefField[$i]=getNewNoTrans($kdAwal,"tbpbeli",5);
	//setvar("op","ed");
}


if ((usertype("sa"))||($defKdBranch=="")) {
	//$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|cabang|30|C|H1-0|1|1";
	$i++; $sAllField.="#47|kdbranch|CABANG|1|1|1|cabang|30|C|S-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}

if ((usertype("sa"))||($defKdLokasi==0)) {
	$i++; $sAllField.="#21|kdlokasi|Lokasi|7|1|1|lokasi|7|C|S-0|1|1";
	$gDefField[$i]=$kdlokasi=$defKdLokasi;
	$gFieldInput[$i]="=isiCbLokasi('kdlokasi');";
}else {
	addsave("kdlokasi",$defKdLokasi,"tb");
}

$i++; $sAllField.="#7|tgl|TGL|10|1|1|1|30|C|D-0|1|1";
$gDefField[$i]=date($formatTgl);

$i++; $sAllField.="#14|kdpembantu|$capPb|7|1|1|namapb|7|C|H1-0|1|1";
$gFieldInput[$i]="=showListPembantu('$jenisPb',\"cbNopoByPB($rnd,'$jtrans' );\");";

$i++; $sAllField.="#1|nopo|No. Pembelian|12|1|1|1|20|C|H1-0|1|1";
//$gFieldInput[$i]="-";//=um412_isicombo6(\"select notrans,tgl from tbpbeli where jtrans='SL'\",'nopo');";
$i++; $sAllField.="#1|tglb|Tgl. Pembelian|12|0|0|1|20|C|D|1|1";
//$gFieldInput[$i]="-";//=um412_isicombo6(\"select notrans,tgl from tbpbeli where jtrans='SL'\",'nopo');";
//$gFieldInput[$i]="=um412_isicombo6(\"select notrans,tgl from tbpbeli where jtrans='PB'\",'nopo');";

//$i++; $sAllField.="#46|alamatkirim|ALAMAT PENGIRIMAN|40|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#30|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$tPosDetail=$i;
$i++; $sAllField.="#10|brutto|SUB TOTAL|13|3|1|0|7|C|C,1|1|0";
$i++; $sAllField.="#44|byangkut|BY.ANGKUT |13|1|1|0|7|C|N-0,0|1|1";
//$i++; $sAllField.="#44|bytimbang|BY.TIMBANG |13|1|1|0|7|C|C,0|1|1";
//$i++; $sAllField.="#44|bykuli|BY.KULI |13|1|1|0|7|C|C,0|1|1";
$i++; $sAllField.="#13|netto|Total Transaksi|13|3|1|1|7|C|C,1|1|1|0";
//$i++; $sAllField.="#17|paidtoday|Pembayaran Tunai|13|1|1|0|7|C|N-0,0|1|1|0";
//$i++; $sAllField.="#17|kurangbayar|Terhutang|13|3|0|1|7|C|C,0|1|1|0";
//$i++; $sAllField.="#30|catatan|Catatan|40|1|1|1|30|C|T,0|1|1";

if (usertype("sa")) {
	$i++; $sAllField.="#25|kdpj|PJ|7|1|1|kdpj namapj|7|C|S-0|1|1";
	$gFieldInput[$i]="=um412_isicombo6('select id,nama from tbppegawai','kdpj');";	
	$gDefField[$i]=$vidusr;
} else {
	addSave("kdpj",$vidusr,"tb");
}

for ($i=$tPosDetail;$i<=20;$i++) {
	$gFuncFld[$i]="evalTransRBeli($rnd);";
}

/*
$i++; $sAllField.="#2|jtrans|JTRANS|0|0|1|0|30|C|S-0|1|1";
$gDefField[$i]="SL";
$i++; $sAllField.="#6|tglentri|TGLENTRI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|nofaktur|NOFAKTUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|nopo|NO. PO|12|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|stat|STAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|disc|DISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#12|discp|DISCP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|carabayar|CARA BAYAR|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('Tunai,Kredit','carabayar');";
$i++; $sAllField.="#18|paidafter|PAIDAFTER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#45|pdeposit|PENGAMBILAN DEPOSIT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#33|byangkut|BYANGKUT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|expedisi|EXPEDISI|40|1|1|1|30|C|S-0|1|1";


$i++; $sAllField.="#19|kdbayar|KDBAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|retur|RETUR|7|1|1|1|7|C|S-0|1|1";

$i++; $sAllField.="#34|disc2|DISC2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#35|disctot|DISCTOT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#43|bal|BAL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|berat|BERAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|statexpedisi|STATEXPEDISI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#39|tglkirim|TGLKIRIM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#40|tglsampai|TGLSAMPAI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#41|noresi|NORESI|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#26|dccharge|DCCHARGE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#27|bayar|BAYAR|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#28|kembalian|KEMBALIAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#29|dcref|DCREF|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#22|kdlokasi2|KDLOKASI2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#31|donasi|DONASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|margin|MARGIN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#42|idproject|IDPROJECT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#23|ppn|PPN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#24|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#48|idkonsolidasi|IDKONSOLIDASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#49|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

*/
//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="notrans;tbpbeli.notrans"; 

$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=gl','retur-pembelian',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> ";

 
 
$jInputD=3;
$sSzFldD ="4,20,4,4,7,7";//ukuran input
$sJenisFldD=",,,,,,i,,i,,,,,,,,,,,,,";
$detCari="barang"; 
$fldCari="kdbrg,nmbarang,satuan,hrg";
$funcEvalD=$adf="evalTransRBeli($rnd)";
$sFuncFldD="$adf,$adf,$adf,$adf,,,,,,,,,";

$opcari="carirb";//carireturjual
$addParamDetCari="&kdlokasi='+$('#kdlokasi_$rnd').val()+'&ntransb='+$('#nopo_$rnd').val()+'";


$useInputD=true;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbpbelid';
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="kdbrg,xxnmbarang,jlh_terima,hrg,disc,subtot";
$sFldDCap="Kode,Deskripsi,Jumlah,Harga,xx,Subtotal";
$sLebarFldD="20,80,20,20,0,20";
$sClassFldD=",,CX,N,CX,N,,,,,,,,,,,";
$sAlignFldD=",r,r,r,r,r,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";

$nmCaptionTabelD="Detail Retur Pembelian`";

$footTbD="
<div class='coldet coldet-1'>
	<div class='tisicoldet' id=jlhitemfix_$rnd>&nbsp;</div>
</div >
<div class='coldet coldet-2'>
	<div class='tisicoldet' >Jumlah</div>
</div>
<div class='coldet coldet-3'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-4'>
	<div class='tjlhd tisicoldet' id=tjlhnetto_$rnd>i</div>
</div>

<div class='coldet coldet-5'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-6'>
	<div class='tisicoldet' >&nbsp;</div>
</div><div class='coldet coldet-7'>
	<div class='tjlhd tisicoldet' id=tbrutto_$rnd></div>
</div>

<div class='coldet coldet-8'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
";

/*
$gFieldInputD[1]="=um412_isicombo5('select kdbrg,nmbarang from tbpbarang order by nmbarang ','d_kdbrg_$rnd"."_#no#;d_kdbrg[]','','','','#def#','cekKdBrgTransRBeli($rnd,#no#);' );";
$gFieldViewD[1]="nmbarang";

$gFieldInputD[2]="<input id=d_nmbrg2_#rnd#_#no# size=6 onkeyup='evalJlhTransRBeli($rnd,#no#);'>";
*/
for ($i=3;$i<=6;$i++) {
	$gFuncFldD[$i]="evalJlhTransRBeli($rnd,#no#);";
}
	


//$gFieldInputD[4]="=(#jlh_terima#*(#hrg#-#disc#));";
/*
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";

//

*/

$sqTabelD="select d.*,b.nmbarang,b.satuan  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where $nmTabelAlias.$nmFieldID='#id#' 
";

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Pembelian';//caption tombol import
$sFieldCSV=strtolower('id,notrans,jtrans,nofaktur,stat,nopo,tglentri,tgl,tgljt,opr,brutto,disc,discp,netto,kdpembantu,term,carabayar,paidtoday,paidafter,kdbayar,retur,kdlokasi,kdlokasi2,ppn,jenis,kdpj,dccharge,bayar,kembalian,dcref,catatan,donasi,margin,byangkut,disc2,disctot,berat,expedisi,statexpedisi,tglkirim,tglsampai,noresi,idproject,bal,byangkutest,pdeposit,alamatkirim,kdbranch,idkonsolidasi,modified_date');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,JTRANS,NOFAKTUR,STAT,NOPO,TGLENTRI,TGL,TGLJT,OPR,BRUTTO,DISC,DISCP,NETTO,KDPEMBANTU,TERM,CARABAYAR,PAIDTODAY,PAIDAFTER,KDBAYAR,RETUR,KDLOKASI,KDLOKASI2,PPN,JENIS,KDPJ,DCCHARGE,BAYAR,KEMBALIAN,DCREF,CATATAN,DONASI,MARGIN,BYANGKUT,DISC2,DISCTOT,BERAT,EXPEDISI,STATEXPEDISI,TGLKIRIM,TGLSAMPAI,NORESI,IDPROJECT,BAL,BYANGKUTEST,PDEPOSIT,ALAMATKIRIM,KDBRANCH,IDKONSOLIDASI,MODIFIED_DATE');
//$nfCSV='import_Data_Penjualan.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";

//cek data detail awal
if ($op=='itb') {
	$addfbe="
	evalTransRBeli($rnd,1);
	";
}elseif (($op=="ed")||($op=="tb")){
	querysql("update tbpbelid set cek=0  where notrans='$notrans' ");
	addsave("jtrans",$jtrans);
	addsaveD("cek",1);
} elseif(op("hp,del")) {
	//echo "$op > ";
	$akdb=array();
	$aid=explode(",",$aid);
	foreach($aid as $id) {
		extractRecord("select notrans,nopo from tbpbeli where id='$id'");
		$akdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans' ","array");
		$sq="delete from tbpbelid where  notrans='$notrans'  ";
		mysql_query2($sq);
		foreach($akdbrg as $kdb) {
			updateStockTrans($kdb,$kdlokasi,$jtrans);
		}
		if ($nopo!='') updateJlhRetur($nopo,1);

	}

}

$addTbSimpan=array(
array('Simpan dan Cetak','op=view&aid=#id#')
);
	
include $um_path."input-std.php";
//cek data detail akhir
if (op("tb,ed")){
	//$kdlokasi=0;
	
	//update lokasi sama dengan saat pembelian
	extractRecord("select kdlokasi from tbpbeli where notrans='$nopo'",1,1,1);
	mysql_query2("update tbpbeli set kdlokasi='$kdlokasi' where notrans='$notrans'");
	
	$akdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans' ","array");
	mysql_query2("delete from tbpbelid where  notrans='$notrans' and (jlh_terima=0 or cek=0) ");
	foreach($akdbrg as $kdb) {
		//echo "updateStockTrans($kdb,$kdlokasi,$jtrans);";
		updateStockTrans($kdb,$kdlokasi,$jtrans);
	}
	//update retur
	
	updateJlhRetur($nopo);
	updateGLTransBeli($notrans);
}
?>
