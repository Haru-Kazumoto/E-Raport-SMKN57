<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="pembeliand";
$nmTabel='tbpbelid';
$nmTabelAlias='d';
$nmFieldID='id';
$pathUpload=$toroot."upload/pembeliand/";

cekvar2("jtrans=PB",true);
addFilterTb("jtrans='$jtrans'");

//echo "jtrans $jtrans";
$nmCaptionTabel="Detail Pembelian";


$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=false;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";

$isTest=false; 

$sqTabel="select * from (
select  h.jtrans,h.tgl,b.nmbarang,
xd.* from tbpbelid xd 
left join tbpbeli h on xd.notrans=h.notrans
left join tbpbarang b on xd.kdbrg=b.kdbrg
) as  d ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah='admin'");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Detail Pembelian';
			
$i++; $sAllField.="#1|notrans|NOTRANS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|kdbrg|KDBRG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|nmbarang|NAMA BARANG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|hrg|HRG|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#4|hpp|HPP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#5|disc|DISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#6|discp|DISCP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#7|subtot|SUBTOT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#8|cek|CEK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#9|jlh_pesan|JLH_PESAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|jlh_terima|JLH_TERIMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|jlh_retur|JLH_RETUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|kdbayar|KDBAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|cbonus|CBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#14|paid|PAID|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#15|idbelid|IDBELID|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|gulung|GULUNG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|catatan1|CATATAN1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|nmbrg2|NMBRG2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|adacatatan|ADACATATAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#20|jlh_cetak|JLH_CETAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#21|dk|DK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#22|jlh_terpenuhi|JLH_TERPENUHI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#23|jlh_brutto|JLH_BRUTTO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#24|jlh_tarra|JLH_TARRA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#25|idkonsolidasi|IDKONSOLIDASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#26|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#27|hppinves|HPPINVES|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#28|hrgjinves|HRGJINVES|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#29|defhrgj|DEFHRGJ|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#30|jlhpkg|JLHPKG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#31|jlhppkg|JLHPPKG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|jenisd|JENISD|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#33|statterpakai|STATTERPAKAI|7|1|1|1|7|C|S-0|1|1";

/*
$gPathUpload[$i]=."upload/pembeliand/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('pembeliand','idperusahaan|nama_perusahaa',736059,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="notrans;tbpbelid.notrans"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','pembeliand|pembeliand',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/



$aFilterTb=array(
		//array('tingkat','d.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
		//array('kdlokasi','kdlokasi','Lokasi :  '.isicbLokasi('xkdlokasi','#url#')),
		array('nmbarang','kdbrg-nmbarang|like','Kode/Nama Brg. : #inp#'),
);
/*

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_736059_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Detail Pembelian';//caption tombol import
$sFieldCSV=strtolower('id,notrans,kdbrg,hrg,hpp,disc,discp,subtot,cek,jlh_pesan,jlh_terima,jlh_retur,kdbayar,cbonus,paid,idbelid,gulung,catatan1,nmbrg2,adacatatan,jlh_cetak,dk,jlh_terpenuhi,jlh_brutto,jlh_tarra,idkonsolidasi,modified_date,hppinves,hrgjinves,defhrgj,jlhpkg,jlhppkg,jenisd,statterpakai');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,KDBRG,HRG,HPP,DISC,DISCP,SUBTOT,CEK,JLH_PESAN,JLH_TERIMA,JLH_RETUR,KDBAYAR,CBONUS,PAID,IDBELID,GULUNG,CATATAN1,NMBRG2,ADACATATAN,JLH_CETAK,DK,JLH_TERPENUHI,JLH_BRUTTO,JLH_TARRA,IDKONSOLIDASI,MODIFIED_DATE,HPPINVES,HRGJINVES,DEFHRGJ,JLHPKG,JLHPPKG,JENISD,STATTERPAKAI');
$nfCSV='import_Detail_Pembelian.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=34;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
