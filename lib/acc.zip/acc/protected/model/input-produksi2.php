<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="produksi2";
$nmTabel='tbpproduksi2';
$nmTabelAlias='p';
$nmCaptionTabel="Produksi";
$nmFieldID='id';
$pathUpload=$toroot."upload/produksi2/";
$kdAwal="PU".$defKdBranch;

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";
//$isTest=true;

if (op("listproduksi")) {
	cekvar("kdbranch,stat");
	echo showListProduksi('kdproduksi',$kdbranch,$stat,"cbLokasiByProduksi($rnd);");
	//echo isiCbpro("kdlokasi","cbBrgByLokasi($rnd)",$kdbranch);
	exit;
}elseif (op("finish")) {
	cekvar("kdproduksi");
	$totbb=getByProduksi($kdproduksi,'BB',0);
	$totbj=getByProduksi($kdproduksi,'BJ',0);
	$bal=$totbb-$totbj;
	$tglstat=date('Y-m-d H:i:s');
	
	$sq="update tbpproduksi2 set totbb='$totbb',totbj='$totbj',ballance='$bal',psstat=100,tglstat='$tglstat' where kdproduksi='$kdproduksi'";
	mysql_query($sq);
	//update gl
	$kdPrkPersediaanBDP = getACC("default_inventory_act_bdp");
	$kdPrkBalProduksi = getACC("penyeimbang_by_produksi");
	
	
	//PRODUKSI2
	$jtrans="PU";
	$notrans=$kdproduksi; 
	extractRecord("select ballance,tglstat,tglentry,tglselesai,catatan from tbpproduksi2 where kdproduksi='$kdproduksi'"); 
	$tgl=sqltotgl($tglstat);
	
	//$tgl=sqltotgl($tglentry);
	updateGLTrans ($notrans, $catatan, $kdPrkBalProduksi, $ballance , $jtrans, $tgl, 0);	 			
	updateGLTransD($notrans, $catatan, $kdPrkBalProduksi, $ballance*-1,0,"");
	updateGLTransD($notrans, $catatan, $kdPrkPersediaanBDP, $ballance*1,1,"");
	echo um412_falr("Finish...","success");
	
}



$sqTabel="select * from (

select xp.*,jp.jenis,0 as totbbproduksi,
if(psstat<100,concat(psstat,'%'),'Selesai') as xstat 
from tbpproduksi2 xp left join tbpproduksij jp on xp.kdjp=jp.kdjp
) as  p ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah='admin'");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Produksi';
			
$i++; $sAllField.="#1|kdproduksi|KD. PRODUKSI|12|1|1|1|30|C|S-0|1|1";
if ($isAdd) {
	$gDefField[$i]=getNewNoTrans($kdAwal,"tbpproduksi2",5);
	//setvar("op","ed");
}
$i++; $sAllField.="#1|kdjp|Jenis Produksi|12|1|1|jenis|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select kdjp,jenis from tbpproduksij','kdjp');";

$i++; $sAllField.="#1|kdbranch|Branch|12|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";


$i++; $sAllField.="#2|tglmulai|TGL. MULAI|40|1|1|1|30|C|D-0|1|1";
	$gDefField[$i]=$tglsekarang;
$i++; $sAllField.="#3|tglselesai|TGL. SELESAI|40|1|1|1|30|C|D-0|1|1";
//$i++; $sAllField.="#4|volume|VOLUME|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|totbb|TOTAL BB|40|3|0|1|30|C|N-0|1|1";
//$gFieldView[$i]="=getByProduksi(-{kdproduksi}-,'BB',1);";
$i++; $sAllField.="#3|totbj|TOTAL BJ|40|3|0|1|30|C|N-0|1|1";
//$gFieldView[$i]="=getByProduksi(-{kdproduksi}-,'BJ',1);";
$i++; $sAllField.="#3|ballance|BALLANCE|40|3|0|1|30|C|N-0|1|1";
//$gFieldView[$i]="=getByProduksi(-{kdproduksi}-,'bal',1);";
$i++; $sAllField.="#3|xstat|STATUS|40|3|0|1|30|C|S-0|1|1";

$i++; $sAllField.="#5|catatan|CATATAN|40|1|1|1|30|C|T-0|1|1";
$i++; $sAllField.="#5|aksi|Aksi|20|0|0|1|30|C|T-0|1|1";
$gFieldView[$i]="=tbAksiProduksi({id});";

//$i++; $sAllField.="#6|tglentry|TGLENTRY|40|1|1|1|30|C|S-0|1|1";

/*
$gPathUpload[$i]=."upload/produksi2/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('produksi2','idperusahaan|nama_perusahaa',650502,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="noproduksi;tbpproduksi2.noproduksi"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','produksi2|produksi2',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','p.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_650502_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

if (userType("admin,sa,acc")) {
	$addTbOpr=" 
	<span  class='btn btn-warning btn-mini btn-sm' 
	onclick=\"tbOpr('view|&op=view&custom=gl','$det',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> 
	";
}

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Produksi';//caption tombol import
$sFieldCSV=strtolower('id,noproduksi,tglmulai,tglselesai,volume,catatan,tglentry');
$sFieldCaptionCSV= strtolower('ID,NOPRODUKSI,TGLMULAI,TGLSELESAI,VOLUME,CATATAN,TGLENTRY');
$nfCSV='import_Produksi.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=7;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
