<?php
if (op("tb,ed,hp")){
	//updatehpp
	$ssq="";
	//echo showTA($arrdd);
	//evaluasi hpp  
	$spes="";
	$i=0;
	foreach($arrdd as $r) {
		$idbj=$r['idbj'];
		$kdbrg=$r['kdbrg'];
		$hpplama=$r['hpplama'];
		$jlhlama=$r['jlhlama'];
		$jlhdibutuhkan=$r['jlhbaru'];		
		$stakhir=$r['stakhir'];	
		$sta=$stakhir+$jlhlama;
		$sisa=($sta-$jlhdibutuhkan); 		
		$hpp=cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans,$idbj, $hpplama, $jlhlama,1 );
		$r['hppbaru']=$hpp;
		
		if ($r['mark']==0)	
			$ssq.="delete from  tbpbelid  where kdbrg='$kdbrg' and notrans='$notrans' and id='$idbj';";
		else	
			$ssq.="update tbpbelid set hpp='$hpp' where kdbrg='$kdbrg' and notrans='$notrans' and id='$idbj';";
		$i++;
	}
	
	
	foreach($arrdd as $r) {
		$kdbrg=$r["kdbrg"];
		$hpp=$r["hppbaru"];
		$mark=$r["mark"];
	}
	//echo "<br><br>update hpp----------> ".$ssq;
	if ($isTest) {
		echo $loghpp;
		echo "<br>update hpp :".$ssq;
	}	
	querysql ($ssq);
	$kdlokasi= carifield("select kdlokasi from tbpbeli where notrans='$notrans' ");

	$skdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans'");
	
	//delete from tbpbelid where  notrans='$notrans' and (jlh_terima=0 or cek=0);
	
	$sqdel="
	delete from tbpbelid_terpakai where  notrans='$notrans' and jlh<=0 ;
	";
	querysql($sqdel);
	
	if ($isTest) echo "<br>hapus: $sqdel <br>Kode barang : $skdbrg >>>>";
	updateStockTrans($skdbrg,$kdlokasi,$jtrans);	
    updateGLTransBeli($notrans,$jtrans);
	
}
