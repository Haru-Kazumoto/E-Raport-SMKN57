<?php
$useJS=2;
include_once 'conf.php';

$det="barang";
$nmTabel='tbpbarang';
$nmTabelAlias='b';
$nmCaptionTabel="Data Barang/Produk";
$nmFieldID='id';
$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=usertype("sa,admin");
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=usertype("sa"); 
$showTbFilter=usertype("sa");

$showTbUnduh=usertype("sa");
$showTbUnggah=usertype("sa");
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:900,title: \'Input Data\'";

include $lib_app_path."protected/model/input-$det-op.php";

 $sqTabel="
select * from (
select xb.*,pb.nama as nmpemasok,
bj.jbarang,prk.account_name as nmprk,
'' as aksi from 
tbpbarang xb left join tbpbarangj bj on xb.jenis=bj.kdjbarang
left join tbppembantu pb on xb.kdpemasok=pb.id  
left join ".$oNamaTb->akun." prk on xb.kdprk=prk.account_code) as  b 
";

include $um_path."input-std0.php";

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Barang/Produk';
			
$i++; $sAllField.="#1|kdbrg|Kode Barang |40|1|1|1|20|C|S-0|1|1";
$gDefField[$i]="=getNewNoTrans3('$kdAwalBrg','tbpbarang','kdbrg',$digitKdBrg,'');";

$i++; $sAllField.="#2|nmbarang|Nama Barang|40|1|1|1|200|C|S,5|1|1";
$i++; $sAllField.="#8|jenis|Kategori|40|1|1|jbarang|100|C|S,1|1|1";
$gFieldInput[$i]="=um412_isicombo5('select kdjbarang,jbarang from tbpbarangj','jenis');";

$i++; $sAllField.="#8|jenisb|Jenis Barang|40|1|1|1|30|C|S,1|1|1";
$gFieldInput[$i]="=um412_isicombo5('R:Bahan Baku;BB,Barang Dalam Proses;BDP,Barang Jadi;BJ,Bahan Pembantu;BP','jenisb');";
$gDefField[$i]="BJ";
$i++; $sAllField.="#8|jbb|JBB|40|1|1|1|30|C|S,1|1|1";
$gFieldInput[$i]="=um412_isicombo5('C:Beli;B,Jual;J,Produksi;P','jbb');";

$i++; $sAllField.="#4|kdpemasok|Pemasok|7|1|1|nmpemasok|37|C|S-0|1|1";
$gFieldInput[$i]="=showListPembantu('PM');";

/*
$i++; $sAllField.="#16|jlhisi|Jumlah KG Perpak|7|1|1|1|7|C|N,0|1|1";
$gDefField[$i]="1";
*/

$i++; $sAllField.="#24|satuan|Satuan|40|1|1|1|30|C|S-0,5|1|1";
$gDefField[$i]="Kg";

$i++; $sAllField.="#9|defhrgbeli|Harga Beli Awal|7|1|1|1|7|C|N-0,0|1|1";
$i++; $sAllField.="#16|hrgjual|Harga Jual|7|1|1|1|7|C|N-0,0|1|1";
/*
$i++; $sAllField.="#22|kdprk|Akun Persediaan|7|1|1|nmprk|7|C|S-1|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprk',0,13000);";
*/

$i++; $sAllField.="#31|aksi|Aksi|40|0|0|1|30|C|S-0|1|1";
$gFieldView[$i]="=tbAksiBrg('{id}');";

/*

$i++; $sAllField.="#3|nmbarangx|NMBARANGX|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#5|kdmerk|KDMERK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|kdbrgpms|KDBRGPMS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|reorder|REORDER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#10|realhrgbeli|REALHRGBELI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#11|ppn|PPN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#12|labaps|LABAPS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|labarp|LABARP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#14|pembulatan|PEMBULATAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#15|defdisc|DEFDISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#17|labarp2|LABARP2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#18|labarp3|LABARP3|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#19|hrgjual2|HRGJUAL2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#20|hrgjual3|HRGJUAL3|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#21|cbonus|CBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#23|kdprkpajak|KDPRKPAJAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#25|warna|WARNA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#26|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#27|ukuran|UKURAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#28|kemasan|KEMASAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#29|kdgbrg|KDGBRG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#30|isheader|ISHEADER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#32|ae|AE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#33|jlhbuild|JLHBUILD|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#34|hrgpokok|HRGPOKOK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#35|ime|IME|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|cat1|CAT1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|cat2|CAT2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#31|jbb|JBB|40|1|1|1|30|C|S-0|1|1";
*/

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="kdbrg;tbpbarang.kdbrg"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','barang|barang',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

$aFilterTb=array(
		array('nmbarang','kdbrg-nmbarang|like','Kode/Nama Brg. : #inp#'),
		array('jenis','jenis','Kategori :'.um412_isicombo6("select kdjbarang,jbarang from tbpbarangj",'xjenis',"#url#")),
//		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);


/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Barang/Produk';//caption tombol import
$sFieldCSV=strtolower('id,kdbrg,nmbarang,jenisb,kdpemasok,kdmerk,kdbrgpms,reorder,jenis,defhrgbeli,realhrgbeli,ppn,labaps,labarp,pembulatan,defdisc,hrgjual,labarp2,labarp3,hrgjual2,hrgjual3,cbonus,kdprk,kdprkpajak,satuan,warna,inactive,ukuran,kemasan,kdgbrg,isheader,jbb,ae,jlhbuild,hrgpokok,ime,cat1,cat2');
$sFieldCaptionCSV= strtoupper('ID,KDBRG,NMBARANG,jenisb,KDPEMASOK,KDMERK,KDBRGPMS,REORDER,JENIS,DEFHRGBELI,REALHRGBELI,PPN,LABAPS,LABARP,PEMBULATAN,DEFDISC,HRGJUAL,LABARP2,LABARP3,HRGJUAL2,HRGJUAL3,CBONUS,KDPRK,KDPRKPAJAK,SATUAN,WARNA,INACTIVE,UKURAN,KEMASAN,KDGBRG,ISHEADER,JBB,AE,JLHBUILD,HRGPOKOK,IME,CAT1,CAT2');
$nfCSV='import_Data_Barang/Produk.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
 
include $um_path."input-std.php";

if (op("tb,ed")) {
	$ssq="update tbpstock set defhrgbeli='".unmaskRp($defhrgbeli)."' where kdbrg='$kdbrg' and defhrgbeli=0;";
	$ssq.="update tbpstock set defhrgjual='".unmaskRp($hrgjual)."' where kdbrg='$kdbrg' and defhrgjual=0;";
	echo $ssq;
	querysql($ssq);
}
?>
