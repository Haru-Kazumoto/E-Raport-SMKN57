<?php
cekVar("ja"); 

include_once $lib_app_path."protected/controller/controller.php";
if ($ja=="") {
	$url="index.php?det=$det&ja=ag";
	$tout="tout2_$rnd";
	$bcrumb1="bcr$rnd";
 
	echo "
	<div style='padding:10px' id='$bcrumb1' >
	 <div class='col-12'>
		Cabang: ".um412_isiCombo6("select kdbranch,branch from tbpbranch order by branch","kdbranch","gantiSales($rnd)")."
		Sales : 
		<span id=tsales_$rnd>".um412_isiCombo6("select distinct(kdpj),nama from tbpbeli h left join tbppegawai p on h.kdpj=p.id where kdpj>0 order by nama","kdpj","")."
		</span>
		Periode :".um412_isiCombo6("Hari Ini,Bulan Ini,Tahun Ini,Custom","periode","gantiPeriode($rnd)")."
		<span id='ttglp_$rnd' style='display:none'>
		Tanggal : <input type=text size=10 class=inputtgl name=tgl1 id=tgl1_$rnd value='$tglsekarang' > SD
		 <input type=text size=10 class=inputtgl name=tgl2 id=tgl2_$rnd value='$tglsekarang' > 
		 </span>
		
		Pemasok : 
		<span id=tpms_$rnd>".um412_isiCombo6("select id,concat(nama,'-',kota) from tbppembantu  where jpembantu='PM' order by nama","kdpms","")."
		</span>
		<br>
		Pelanggan : 
		<span id=tplg_$rnd>".um412_isiCombo6("select id,concat(nama,'-',kota) from tbppembantu where jpembantu='PL' order by nama","kdpembantu","")."
		</span>
		<span id='tkdbrg_$rnd' style='display:nonex'>
			Nama Barang  : ".um412_isicombo6("select kdbrg,nmbarang from tbpbarang b where 1=1 $addSqComboBrg","kdbrg","")."
		</span>
	<a class='btn btn-success btn-sm' onclick=\"printDiv('$tout');\">Cetak</a>
 		</div>
	";	
	
	$amn1=array(
		array("Omset Penjualan Semua Plg","omset&fokus=omset"),
		array("Omset Penjualan Semua Plg (Jlh Brg)","omset&fokus=jlh"),
		array("Omset Penjualan Berdasar Pemasok","omsetpms&fokus=omset"),
		array("Omset Penjualan Berdasar Pemasok (Jlh Brg)","omsetpms&fokus=jlh"),
		array("Peringkat Penjualan Semua Plg","peringkat&fokus=omset"),
		array("Peringkat Penjualan Semua Plg (Jlh Brg)","peringkat&fokus=jlh"),
	);
	$amn2=array(
		array("Omset Penjualan Barang","omsetbrg&fokus=omset"),
		array("Omset Penjualan Barang (Jlh Brg)","omsetbrg&fokus=jlh"),
		array("Trend Omset Penjualan Bulanan Per-Plg","tpjplg&fokus=omset"),
		array("Trend Omset Penjualan Bulanan Per-Plg (Jlh Brg)","tpjplg&fokus=brg"),
		array("Trend Nilai Penjualan Bulanan Persales","tpjsales"),
		array("Trend Omset Penjualan Bulanan","tpj&fokus=omset"),
		array("Trend Omset Penjualan Bulanan(Jlh Brg) ","tpj&fokus=jlh"),
		
	);
	
	$urltgl="tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+'";
	$urlkdbrg="kdbrg='+$('#kdbrg_$rnd').val()+'";
	//$urlkdbrg="";
	$urlkdbranch="kdbranch='+$('#kdbranch_$rnd').val()+'";
	$urlkdbranch.="&kdpj='+$('#kdpj_$rnd').val()+'";
	$urlkdbranch.="&kdpembantu='+$('#kdpembantu_$rnd').val()+'";
	$urlkdbranch.="&kdpms='+$('#kdpms_$rnd').val()+'";
	
	?>
	<div class='col-sm-5' style='float:left'>
		<!--div class=subtitleform2>Analisa Global</div-->
		<ul>
		<?php
		$rndx=$rnd.rand(123,444);
		foreach($amn1 as $mn) {
			echo "	<li><a href=# onclick=\"bukaAjax('$tout','$url&$urlkdbrg&$urlkdbranch&jreport=$mn[1]&$urltgl&newrnd=$rndx',0,'awalEdit($rndx)');return false\"
						title='$mn[1]' >$mn[0]</a></li>";
		}
		?>
		</ul> 
	</div>
	<div class='col-sm-7'>
		<!--div class=subtitleform2>Analisa Perbarang</div-->
		<?php
		
		?>
		<ul>
		<?php
		foreach($amn2 as $mn) {
			echo "	<li><a href=# onclick=\"bukaAjax('$tout','$url&jreport=$mn[1]&$urltgl&$urlkdbrg&$urlkdbranch&newrnd=$rndx',0,'awalEdit($rndx)');return false;\"
			title='$mn[1]' >$mn[0]</a></li>";
		}
		?>
			
		</ul>
		 
	</div>
	
	<?php
	
	$addf="
		$(document).ready(function(){
			$('.inputtgl').datepicker();
			$('#kdbrg_$rnd').combobox();
		});";
		
	$urlku="'index.php?det=analisis2&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+''";
	//<a class='btn btn-primary btn-sm onclick=\"bukaAjax('$tout','index.php?det=analisis2',0,'awalEdit($rnd)');return false;\">Tampil</a>
	echo "
 		<script>
		";
		?>
		
		function gantiSales(rnd){
			kdbranch=$("#kdbranch_"+rnd).val();
			bukaAjax("tsales_"+rnd,"filtercombo.php?op=sales&kdbranch="+kdbranch+"&newrnd="+rnd+"&func=gantiSales2("+rnd+")");
			gantiSales2(rnd);
		}
		function gantiSales2(rnd){
			kdbranch=$("#kdbranch_"+rnd).val();
			kdpj=$("#kdpj_"+rnd).val();
			bukaAjax("tplg_"+rnd,"filtercombo.php?op=plg&kdbranch="+kdbranch+"&kdpj="+kdpj+"&newrnd="+rnd);
		}
		
		<?php echo "
		$addf</script>
		
		<div id=$tout class='tout' style='background:#ccc;padding:30px 50px'></div>";
		
		
	
} else {

	include $lib_app_path."protected/view/manalisa/analisa-penjualan2.php";
}
?>