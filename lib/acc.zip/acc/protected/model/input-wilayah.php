
<?php
$useJS=2;
include_once 'conf.php';
 
//default
$det="wilayah";
$nmTabel='tbwilayah';
$nmTabelAlias='w';
$nmCaptionTabel="Kelurahan";
$nmFieldID='id';

$tbsql="";
$thisFile=$nfref="index.php?ref=wilayah&det=wilayah&useJS=2&contentOnly=1";//&valid=1

//$sqTabel="select w.*,sk.namas from tbwilayah w left join tb2 sk on w.kd=sk.kode ";
$sqTabel="select w.* from tbwilayah w ";

include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Wilayah';
			
$i++; $sAllField.="#1|wilayah|KELURAHAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|kecamatan|KECAMATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";

$isiComboFilterTabel="wilayah;tbwilayah.wilayah"; 
$identitasRec='rctbwilayah'; 
$configFrmInput='width:600'; 
$folderModul='mwilayah'; 
$nfReport="$folderModul/showtable.php"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('','restitusi|dokumenreimburse',$rnd,$rndInput,'$configFrmInput');\" value='Upload Dokumen' /><i class='icon-recycle'></i> Upload Dokumen</span> ";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Wilayah';//caption tombol import
$sFieldCSV=strtolower('id,wilayah,catatan,kecamatan');
$sFieldCaptionCSV= strtolower('ID,WILAYAH,CATATAN,KECAMATAN');
$nfCSV='import_lumpsump.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$showFrmCari=true;
$showTbHapus=true;
$showTbView=true;
$showTbUbah=true;
$showTbPrint=true;
$showTbTambah=true; 
$showExportDB=false; 
$isTest=false; 
$showTbUnduh=false;
$showTbUnggah=false;


//include "$folderModul/custom-wilayah.php"; 

include $um_path."input-std.php";
?>
