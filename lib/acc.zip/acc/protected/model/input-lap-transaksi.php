<?php
 
cekVar("jlap,media,op");

$subjd="";
$addjdl="";
$addInp="";
$sytingkat=" where 1=1 ";
if ($jlap=="") $jlap="transaksi";
   
if ($op=='') {
	$deftgl1=awalBulan(); 
	$deftgl2=akhirBulan(); 
	if (isset($_SESSION['tgllap1'])) $deftgl1=$_SESSION['tgllap1'];
	if (isset($_SESSION['tgllap2'])) $deftgl2=$_SESSION['tgllap2'];


	$url="
	'index.php?det=$det&op=lapbb&jlap=$jlap&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()
	+'&jenisju='+$('#jenisju_$rnd').val()
	+'&kdasset='+$('#kdasset_$rnd').val()
	+'&kdpembantu='+$('#kdpembantu_$rnd').val()
	+'&jform='+$('#jform_$rnd').val()
	+'&kdpegawai='+$('#kdpegawai_$rnd').val()+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()
	";
	$urlxls="$url+'&media=xls&contentOnly=1&showMenu=0'";
		
	$tbpdf="";
	$addSy="";
	if ($jlap=='cashflow') {
		$addSy=" where account_type=25 ";
	}
	$addInp="";
	if ($useBranch) 
		$addInp.="Cabang : ".um412_isicombo5('select kdbranch,branch from tbpbranch order by branch asc','kdbranch');
	else
		$addInp.="<input type=hidden id=kdbranch_$rnd value=''>";
	
	
		//$tbpdf="<a class='btn btn-warning btn-sm' onclick=\"w=window.open($url+'&media=pdf&useJS=2&contentOnly=1');\">PDF</a>";
	//$addInp=" Akun : ".um412_isicombo5("select account_code,account_name from ".$oNamaTb->akun."  $addSy order by account_name",'kdprk');
	$addInp.=" Jenis Transaksi : ".um412_isicombo5("select jtrans from tbpjtrans order by jtrans",'jenisju');
	$addInp.=" Pegawai : ".um412_isicombo5("select id,nama from tbppegawai order by nama asc",'kdpegawai');
	$addInp.=" Asset : ".um412_isicombo5("select id,nama_asset from tbpasset order by nama_asset asc",'kdasset');
	$addInp.=" Plg/Pms : ".um412_isicombo5("select id,nama  from tbppembantu order by nama  asc",'kdpembantu');
	
	echo "
	<div class=breadcrumb2>	
	<div style='margin-bottom:5px'>
	Tampilan : ".um412_isicombo6("List;list,Jurnal Umum;ju",'jform','list')."
	$addInp
	</div> Tanggal : <span id=ttgl1_$rnd><input name=tgl1 id=tgl1_$rnd value='$deftgl1' class=tgl size=11 ></span> 
		sd  <span id=ttgl2_$rnd><input name=tgl2 id=tgl2_$rnd value='$deftgl2' class=tgl  size=11 ></span> 
		
	<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout');\">Cetak</a>
		<a class='btn btn-warning btn-sm' onclick=\"bukaJendela($urlxls);\">XLS</a>
	</div>
		<span id=tdialog style='display:none'></span>
	<div id='tout'></div>
	 
	";	
	
		?>
	<script>
	 
	$(document).ready(function() {
		$("#jenisju_<?=$rnd?>").combobox();
		$("#kdasset_<?=$rnd?>").combobox();
		$("#kdpembantu_<?=$rnd?>").combobox();
		 $(".tgl").datepicker();
	});
	 </script>
	<?php
	exit ;
}  

$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;
include $lib_app_path."protected/view/lap/lap-transaksi.php"; 

?>