<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="mjab";
$nmTabel='tbppegawai_mjab';
$nmTabelAlias='j';
$nmCaptionTabel="Jabatan";
$nmFieldID='id';
$pathUpload=$toroot."upload/jab/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";


$isTest=false; 

$sqTabel="select * from (
select xj.*,d.departemen,
if(isuser=1,'Ya','Tidak') as xisuser
 from tbppegawai_mjab xj
left join tbppegawai_mdept d on xj.kddept=d.kode

) as  j ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah=''");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Jabatan';
			
$i++; $sAllField.="#1|kode|Kode|6|1|1|1|30|C|U-3|1|1";
$i++; $sAllField.="#2|jabatan|Jabatan|30|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|gapok|Gaji Pokok|10|1|1|1|30|C|N0-0|1|1";
$i++; $sAllField.="#4|kddept|Departemen|40|1|1|departemen|30|C|S-0|1|1";
$gFieldInput[$i]="=isiCbDepartemen('kddept');";
$i++; $sAllField.="#4|isuser|Pengguna System|10|1|0|xisuser|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('R:Ya;1,Tidak;0','isuser');";
//$i++; $sAllField.="#4|role|Role System|10|1|0|xisuser|30|C|S-0|1|1";


/*
$gPathUpload[$i]=."upload/jab/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('jab','idperusahaan|nama_perusahaa',382321,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="kode;tbppegawai_mjab.kode"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','jab|jab',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','j.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_382321_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Jabatan';//caption tombol import
$sFieldCSV=strtolower('id,kode,jabatan,gapok,kddept');
$sFieldCaptionCSV= strtolower('ID,KODE,JABATAN,GAPOK,KDDEPT');
$nfCSV='import_Jabatan.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=5;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
