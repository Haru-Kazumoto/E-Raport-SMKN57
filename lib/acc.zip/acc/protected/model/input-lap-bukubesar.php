<?php
 cekVar("jlap,media,op");

$subjd="";
$addjdl="";
$addInp="";
$sytingkat=" where 1=1 ";
if ($jlap=="") {
	$jlap="bukubesar";
	if (userType("kasir,admin")) {
		$jlap="cashflow";
		
	}
}
//if ($jlap=="") $jlap="bukubesar";
if (!isset($jenisacc)) $jenisacc="";


   
if ($op=='') { 
	
	$url="
	'index.php?det=$det&op=lapbb&jlap=$jlap&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()+'&kdpembantu='+$('#kdpembantu_$rnd').val()+'&kdprk='+$('#kdprk_$rnd').val()+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+'&jform='+$('#jform_$rnd').val()
	";
	$urlxls="$url+'&media=xls&contentOnly=1&showMenu=0'";
	$tbpdf="";
	$addSy=$addInp="";
	$jenisacc=0;
	if ($jlap=='cashflow') {
		$jenisacc=11100;//header kas dan bank	
	} 
	
	$sty1=$sty2="";
	if ($jlap=='bukuhutang') {
		$sty1="display:none"; 
		
	} else if ($jlap=='bukupiutang') {
		$sty1="display:none"; 
		
	} else {
		$sty2="display:none"; 
		
	}
	if ($useBranch) {
		if (usertype("sa")) {
			$addInp.="<span style='$sty1'>Cabang : ".um412_isicombo5('select kdbranch,branch from tbpbranch order by branch asc','kdbranch')."</span> ";
		} else {
			$addInp.="<span style='$sty1'><input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";

		}
	} else
		$addInp.="<span style='$sty1'><input type=hidden name=kdbranch id=kdbranch_$rnd value=''>";
	
	if ($jlap=="cashflow") {
		if ((usertype("kasir")) &&($jlap=="cashflow")) {
			$addInp.="<input type=hidden name=kdprk id=kdprk_$rnd value='$defKdPrkKas'>";
		} else {
			$addInp.="Akun : ".isiComboAcc("kdprk",0,$jenisacc,$defKdBranch);
		}		
	} else {
		$addInp.="Akun : ".isiComboAcc("kdprk",0,$jenisacc);
	}
	
	
	//$addInp.="ut ".usertype("kasir,admin")."/$jlap";
	
	$addInp.="<span style='$sty2'> Nama Pemasok/Pelanggan : ".um412_isicombo5("select id,nama,kota from tbppembantu  order by nama",'kdpembantu')."</span>";
		//$tbpdf="<a class='btn btn-warning btn-sm' onclick=\"w=window.open($url+'&media=pdf&useJS=2&contentOnly=1');\">PDF</a>";
	//Bentuk: ".um412_isicombo5("Lengkap,Tanpa Ref",'jform','','','','Tanpa Ref')."
	$addInp.="<input type=hidden name=jform id=jform_$rnd value='Lengkap'>";

	
	echo "
	<div class=breadcrumb2>
		$addInp
		Tanggal : <span id=ttgl1_$rnd><input name=tgl1 id=tgl1_$rnd value='$deftgl1' class=D size=11 ></span> 
		sd  <span id=ttgl2_$rnd><input name=tgl2 id=tgl2_$rnd value='$deftgl2' class=D  size=11 ></span> 
		<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbpdf 
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout');\">Cetak</a>
		<a class='btn btn-warning btn-sm' onclick=\"bukaJendela($urlxls);\">XLS</a>
		
	</div>
	<span id=tdialog style='display:none'></span>
	<div id='tout'></div>
 
	";	
	
	 $addf="
	$(document).ready(function(){
		//$('#kdprk_$rnd').combobox();
		$('#kdbrg_$rnd').combobox();
		$('#kdpembantu_$rnd').combobox();
		$('.custom-combobox-input').css('max-width','200px');
		$('.custom-combobox-input').css('width','auto');
		maskAllMoney();
	});
	
	";
	
	echo fbe($addf);
	exit ;
}  

cekVar("jform");
if ($jform=="Tanpa Ref")
	include $lib_app_path."protected/view/lap/lap-bukubesar-tanparef.php"; 
else
	include $lib_app_path."protected/view/lap/lap-bukubesar.php"; 


?>