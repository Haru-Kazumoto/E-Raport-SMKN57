<?php
$useJS=2;
include_once 'conf.php';

$det="anak";
$nmTabel='tbanak';
$nmTabelAlias='a';
$nmCaptionTabel="anak";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
$defOrderDT="[0, 'asc']";
$configFrmInput="width:700,title: \'Input Data\'";


$isTest=false; 

$sqTabel=" 
	select * from (
	select xa.*,py.posyandu,
	concat(floor( DATEDIFF(curdate(), tgllahir)/365),' tahun') AS umur,
	if(tgllahir<date_add(curdate(),interval -365*5 day),'Lulus Balita',if(tgllahir<date_add(curdate(),interval -365*2 day),'Balita','Bayi'
	)) as jenis from (((((tbanak xa left join tbposyandu py  on xa.idpos=py.id )
	left join tbkelurahan kl on py.idkelurahan=kl.id)
	 left join tbkecamatan kc on kl.idkecamatan=kc.id)
	 left join tbkabupaten kb on kc.idkabupaten=kb.id)
	 left join tbprovinsi pr on kb.idprovinsi=pr.id )
	 ) as a
 "; 
//$isTest=true;
cekVar("jenis");
//$isTest=true; 
if ($jenis=="") { $jenis="bayi" ; }

addfiltertb(" jenis='$jenis'");
include "filtertb.php";

	
include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Anak';
			
$i++; $sAllField.="#1|tgldaftar|TGL. DAFTAR|40|1|1|1|30|C|D-0|1|1";
$i++; $sAllField.="#2|namaanak|NAMA ANAK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|namaibu|NAMA IBU|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|namaayah|NAMA AYAH|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|tgllahir|TGL. LAHIR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|jk|JK|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="$"."inp=um412_isicombo5('R:Laki-laki;L,Perempuan;P','jk');";

$i++; $sAllField.="#7|kms|KMS|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="$"."inp=um412_isicombo5('R:Ada,Tidak','kms');";

$i++; $sAllField.="#8|idpos|POSYANDU|7|1|1|posyandu|7|C|S-0|1|1";
$gFieldInput[$i]="$"."inp=um412_isicombo5('select id,posyandu from tbposyandu p order by posyandu','idpos');";
$i++; $sAllField.="#8|jenis|KATEGORI|0|0|0|1|7|C|S-0|1|1";
$i++; $sAllField.="#8|umur|UMUR|0|0|0|1|7|C|S-0|1|1";

$i++; $sAllField.="#9|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="tgldaftar;tbanak.tgldaftar"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','anak|anak',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Anak';//caption tombol import
$sFieldCSV=strtolower('id,tgldaftar,namaanak,namaibu,namaayah,tgllahir,jk,kms,idpos,catatan');
$sFieldCaptionCSV= strtolower('ID,TGLDAFTAR,NAMAANAK,NAMAIBU,NAMAAYAH,TGLLAHIR,JK,KMS,IDPOS,CATATAN');
$nfCSV='import_Data_Anak.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
