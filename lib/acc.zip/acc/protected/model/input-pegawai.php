<?php
$useJS=2;
include_once 'conf.php';

$det="pegawai";
$nmTabel='tbppegawai';
$nmTabelAlias='pg';
$nmCaptionTabel="Pegawai";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:1200,title: \'Input Data\'";
//$isTest=$debugMode; 

$sqTabel="select * from (
select xpg.*,br.branch,
concat(j.jabatan,'(',kdjab,')') as jabatan from tbppegawai xpg
 
 left join tbpbranch br  on xpg.kdbranch=br.kdbranch
 left join tbppegawai_mjab j on xpg.kdjab=j.kode 
 )
as pg
 ";


include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Pegawai';
			
$i++; $sAllField.="#1|nama|Nama Pegawai|30|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#21|kdjab|JABATAN|40|1|1|jabatan|60|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select kode,jabatan from tbppegawai_mjab','kdjab');";

$i++; $sAllField.="#10|hp|HP|20|1|1|1|20|C|S-0|1|1";
$i++; $sAllField.="#11|email|EMAIL|30|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#2|vuserid|USER ID|40|1|1|1|20|C|S-3|1|1";
$i++; $sAllField.="#3|vpass|PASSWORD|40|1|1|0|30|C|P-3|1|1";

/*
$i++; $sAllField.="#4|alamat|ALAMAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|kota|KOTA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|provinsi|PROVINSI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|telp|TELP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|fax|FAX|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|cp|CP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|npwp|NPWP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#14|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|www|WWW|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|fb|FB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|twitter|TWITTER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|pinbb|PINBB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|grade|GRADE|40|1|1|1|30|C|S-0|1|1";
*/

if ((usertype("sa"))||($defKdBranch=="")) {
	$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|branch|30|C|H1-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}
/*
$i++; $sAllField.="#23|g_pokok|G_POKOK|15|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#22|t_jabatan|T_JABATAN|15|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#24|t_makan|T_MAKAN|15|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#25|t_transport|T_TRANSPORT|15|1|1|1|7|C|C-0|1|1";
*/

/*

$i++; $sAllField.="#26|g_lembur|G_LEMBUR|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#27|g_insentif|G_INSENTIF|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#28|g_satuan|G_SATUAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#29|tgl_terima|TGL_TERIMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#30|NIK|NIK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#31|Alias|ALIAS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|Cabang|CABANG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#33|statkar|STATKAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#34|masakontrak|MASAKONTRAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#35|hakakses|HAKAKSES|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|pin|PIN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|rekno|REKNO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|rekname|REKNAME|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#39|bonus|BONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#40|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#42|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";

*/


//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="nama;tbppegawai.nama"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','pegawai|pegawai',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Pegawai';//caption tombol import
$sFieldCSV=strtolower('id,nama,divisi,subdivisi,alamat,kota,provinsi,telp,fax,cp,hp,email,term,npwp,catatan,inactive,www,fb,twitter,pinbb,grade,jabatan,t_jabatan,g_pokok,t_makan,t_transport,g_lembur,g_insentif,g_satuan,tgl_terima,NIK,Alias,Cabang,statkar,masakontrak,hakakses,pin,rekno,rekname,bonus,modified_date,kdbranch,jenis');
$sFieldCaptionCSV= strtolower('ID,NAMA,DIVISI,SUBDIVISI,ALAMAT,KOTA,PROVINSI,TELP,FAX,CP,HP,EMAIL,TERM,NPWP,CATATAN,INACTIVE,WWW,FB,TWITTER,PINBB,GRADE,JABATAN,T_JABATAN,G_POKOK,T_MAKAN,T_TRANSPORT,G_LEMBUR,G_INSENTIF,G_SATUAN,TGL_TERIMA,NIK,ALIAS,CABANG,STATKAR,MASAKONTRAK,HAKAKSES,PIN,REKNO,REKNAME,BONUS,MODIFIED_DATE,KDBRANCH,JENIS');
$nfCSV='import_Data_Pegawai.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
