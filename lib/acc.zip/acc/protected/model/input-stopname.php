<?php
$useJS=2;
include_once 'conf.php';
$det="stopname";
$nmTabel='tbpbeli';
$nmTabelAlias='h';
$nmCaptionTabel="Data Stok Opname";
$nmFieldID='id';

$jtrans="PA";
$kdAwal="PA".$defKdBranch;

addFilterTb("jtrans='$jtrans'");
//$isTest=$debugMode;
$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
$defOrderDT="[1, 'desc']";
$configFrmInput="width:1200,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";


$sqTabel="select * from (
select xh.*,
xh.netto-xh.paidtoday-xh.paidafter-xh.retur as kurangbayar,
br.branch as cabang,pb.nama as namapb,
pb.telp as telppb,pb.alamat as alamatpb,
pg.nama as namapj,l.lokasi
 from (((tbpbeli xh
left join tbppembantu pb on xh.kdpembantu=pb.id)
left join tbpbranch br on xh.kdbranch=br.kdbranch)
left join tbppegawai pg on xh.kdpj=pg.id)
left join tbplokasi l on xh.kdlokasi=l.id
) as  h ";
include $um_path."input-std0.php";
 
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

$i++; $sAllField.="#1|notrans|NOTRANS|20|1|1|1|30|C|H1-0|1|1";
if ($isAddItb) {
	$gDefField[$i]=getNewNoTrans($kdAwal,"tbpbeli",5);
	//setvar("op","ed");
}

if ((usertype("sa"))||($defKdBranch=="")) {
	$i++; $sAllField.="#47|kdbranch|CABANG|4|1|1|cabang|30|C|H1-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";
} else {
	addsave("kdbranch",$defKdBranch,"tb");
}


$i++; $sAllField.="#7|tgl|TGL|10|1|1|1|30|C|D-1|1|1";
$gDefField[$i]=date($formatTgl);

if ((usertype("sa"))||($defKdLokasi==0)) {
	$i++; $sAllField.="#21|kdlokasi|Lokasi|7|1|1|lokasi|7|C|H1-0|1|1";
	$gDefField[$i]=$defKdLokasi;
	$gFieldInput[$i]="=isiCbLokasi('kdlokasi');";
} else {
	addsave("kdlokasi",$defKdLokasi,"tb");
}
 
//$i++; $sAllField.="#46|alamatkirim|ALAMAT PENGIRIMAN|40|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#30|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$tPosDetail=$i;
$i++; $sAllField.="#10|brutto|SUB TOTAL|13|3|1|0|7|C|N,1|1|1";
//$i++; $sAllField.="#44|bytimbang|BY.TIMBANG |13|1|1|0|7|C|C,0|1|1";
//$i++; $sAllField.="#44|bykuli|BY.KULI |13|1|1|0|7|C|C,0|1|1";
//$i++; $sAllField.="#13|netto|Total Transaksi|13|3|1|1|7|C|N,1|1|1|0";

if (usertype("sa")) {
	$i++; $sAllField.="#25|kdpj|PJ|7|1|1|kdpj namapj|7|C|S-0|1|1";
	$gFieldInput[$i]="=um412_isicombo6('select id,nama from tbppegawai','kdpj');";	
	$gDefField[$i]=$vidusr;
} else {
	//$i++; $sAllField.="#25|kdpj|PJ|7|0|0|kdpj namapj|7|C|S-0|1|1";
	addSave("kdpj",$vidusr,"tb");//controller
}

for ($i=$tPosDetail;$i<=20;$i++) {
	$gFuncFld[$i]="evalTransSTO($rnd);";
}


$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=gl','stopname',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> ";

$jInputD=3;
$sSzFldD ="4,20,4,4,4,4,7,7";//ukuran input
$sJenisFldD=",,,,,,,,";
$detCari="barang"; 
$fldCari="kdbrg,nmbarang,satuan,stsystem,stfisik,hrg";
$funcEvalD=$adf="evalTransSTO($rnd)";
$opcari="caristop";

$useInputD=true;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbpbelid';
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="kdbrg,xxnmbarang,xxsatuan,stsystem,stfisik,jlh_terima,hrg,subtot";
$sFldDCap="Kode,Deskripsi,Satuan,Stock Akhir,Stock Fisik,Perbedaan,Harga,Subtotal";
$sLebarFldD="20,60,15,15,15,15,20,20";
//$sLebarFldD="20,80,10,11,12,13,21,22";
$sClassFldD=",,,C2,C2,C2,N,C2,,,";
$sFuncFldD=",,,$adf,$adf,$adf,$adf,";

$sAlignFldD=",,,r,r,r,r,r,,,,,,,,,,,,";
$sAllowEditFldD="0,0,0,0,,0,0,,,,,,,,,,,,";
 
$nmCaptionTabelD="Detail Stok";

$addParamDetCari="&kdlokasi='+$('#kdlokasi_$rnd').val()+'";
$footTbD="
<div class='coldet coldet-1'>
	<div class='tisicoldet' id=jlhitemfix_$rnd>&nbsp;</div>
</div >
<div class='coldet coldet-2'>
	<div class='tisicoldet' >Jumlah</div>
</div>
<div class='coldet coldet-3'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-4'>
	<div class='tjlhd tisicoldet' id=tjlhnetto_$rnd>i</div>
</div>
<div class='coldet coldet-5'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-6'>
	<div class='tjlhd tisicoldet' id=tbrutto_$rnd></div>
</div>
<div class='coldet coldet-7'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-8' style='display:none'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-9'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
";

$showOprD=false;

$idxAksi=0;
if (($op=='itb')) {
/*
	//$defKdPrkKasK=getKdPrkKas("K");
	if ($idxAksi==0) {
		$sFldD="xxaksi,$sFldD";
		$sFldDCap="Aksi,$sFldDCap";
		$sLebarFldD="10,$sLebarFldD";
		$sClassFldD=",$sClassFldD";
		//$idxplg++;
		//$idxsales++;
	} else {
		$sFldD.=",xxAksi";
		$sFldDCap.=",Aksi";
	}
	//'<a href=# onclick=\"bukaAjaxD(\'#tid#\',\'content1.php?det=piutang&op=pilih&newrnd=$rnd&idpembantu=\',\'width:1240\')\"class=\"btn btn-primary btn-sm\"> + </a>'.
	
	$gFieldInputD[$idxAksi]="=
	'<a href=# onclick=\"$'.'(\'#d_hrg_#rnd#_#no#\').val(0);$'.'(\'#d_jlh_terima_#rnd#_#no#\').val(0);$'.'(\'#trdet_#rnd#_#no#\').xhide();evalTransSTO($rnd);\"class=\"btn btn-danger btn-sm\"> - </a>'
	;";
	
*/
} elseif ($op=='view') {
	//$gFieldViewD[4]="0";
	//$gFieldViewD[5]="0";
	
}
/*
$gFieldInputD[1]="=um412_isicombo5('select kdbrg,nmbarang from tbpbarang order by nmbarang ','d_kdbrg_$rnd"."_#no#;d_kdbrg[]','','','','#def#','cekKdBrgtransSTO($rnd,#no#);' );";
$gFieldViewD[1]="nmbarang";

$gFieldInputD[2]="<input id=d_nmbrg2_#rnd#_#no# size=6 onkeyup='evalJlhtransSTO($rnd,#no#);'>";
*/
for ($i=3;$i<=6;$i++) {
	$gFuncFldD[$i]="evalJlhtransSTO($rnd,#no#);";
}
	


$sqTabelD="select d.*,b.nmbarang,b.satuan  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where $nmTabelAlias.$nmFieldID='#id#' 
";

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Pembelian';//caption tombol import
$sFieldCSV=strtolower('id,notrans,jtrans,nofaktur,stat,nopo,tglentri,tgl,tgljt,opr,brutto,disc,discp,netto,kdpembantu,term,carabayar,paidtoday,paidafter,kdbayar,retur,kdlokasi,kdlokasi2,ppn,jenis,kdpj,dccharge,bayar,kembalian,dcref,catatan,donasi,margin,byangkut,disc2,disctot,berat,expedisi,statexpedisi,tglkirim,tglsampai,noresi,idproject,bal,byangkutest,pdeposit,alamatkirim,kdbranch,idkonsolidasi,modified_date');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,JTRANS,NOFAKTUR,STAT,NOPO,TGLENTRI,TGL,TGLJT,OPR,BRUTTO,DISC,DISCP,NETTO,KDPEMBANTU,TERM,CARABAYAR,PAIDTODAY,PAIDAFTER,KDBAYAR,RETUR,KDLOKASI,KDLOKASI2,PPN,JENIS,KDPJ,DCCHARGE,BAYAR,KEMBALIAN,DCREF,CATATAN,DONASI,MARGIN,BYANGKUT,DISC2,DISCTOT,BERAT,EXPEDISI,STATEXPEDISI,TGLKIRIM,TGLSAMPAI,NORESI,IDPROJECT,BAL,BYANGKUTEST,PDEPOSIT,ALAMATKIRIM,KDBRANCH,IDKONSOLIDASI,MODIFIED_DATE');
//$nfCSV='import_Data_Penjualan.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";

//cek data detail awal
if ($op=='itb') {
	$addfbe="
	evalTransSTO($rnd);
	";
}elseif (($op=="ed")||($op=="tb")){
	querysql("update tbpbelid set cek=0  where notrans='$notrans' ");
	addsave("jtrans",$jtrans);
	addsave("kdprkkas",$defKdPrkKasK,'tb');
	addsave("netto",$brutto);
	addsaveD("cek",1);
} elseif(op("hp,del")) {
	updateGLAndStockTransBeli($aid,$op);
}

$addTbSimpan=array(
array('Simpan dan Cetak','op=view&aid=#id#')
);


include $um_path."input-std.php";
//cek data detail akhir
if (op("tb,ed")){
	$kdlokasi= carifield("select kdlokasi from tbpbeli where notrans='$notrans' ");
	$akdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans' ","array");
	mysql_query2("delete from tbpbelid where  notrans='$notrans' and (jlh_terima=0 or cek=0) ");
	foreach($akdbrg as $kdb) {
		//echo "updateStockTrans($kdb,$kdlokasi,$jtrans);";
		updateStockTrans($kdb,$kdlokasi,$jtrans);
	}
   updateGLtransBeli($notrans);
}
?>
