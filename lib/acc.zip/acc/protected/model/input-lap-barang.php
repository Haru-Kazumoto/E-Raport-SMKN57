<?php

cekVar("jlap,media,op");

$subjd="";
$addjdl="";
$addInp="";
$sytingkat=" where 1=1 ";
if ($jlap=="") $jlap="nstock";

$stj="display:none";
if ($op=='') { 	
	$url="
	'index.php?det=$det&jlap='+$('#jlap_$rnd').val()+'&op=lap&newrnd=$rnd&kdlokasi='+$('#kdlokasi_$rnd').val()+'&kdbranch='+$('#kdbranch_$rnd').val()+'&bentuk='+$('#bentuk_$rnd').val()+'&kdbrg='+$('#kdbrg_$rnd').val()+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()
	";
	$tbpdf="";
	$addSy="";
 
	$addInp="";
	if ($useBranch) {
		if (usertype("sa"))
			$addInp.="Cabang : ".um412_isicombo6('select kdbranch,branch from tbpbranch order by branch asc','kdbranch',"cbLokasiByBranch($rnd)");
		else	
			$addInp.="<input type=hidden id=kdbranch_$rnd value='$defKdBranch'>";
			//$addInp.="Cabang : ".um412_isicombo6('select kdbranch,branch from tbpbranch order by branch asc','kdbranch',"cbLokasiByBranch($rnd)");
		
	
	}
	else
		$addInp.="<input type=hidden id=kdbranch_$rnd value=''>";
	
	$sjlap="Kartu Stock;kstock,Kartu Stock+Harga;kstock2,Nilai Stock;nstock";
	if (!$isOnline)
		$sjlap="Kartu Stock+Deskripsi;kstock3,$sjlap";
	$addInp.="Jenis Laporan : ".um412_isiCombo6("$sjlap",'jlap',"cekInpLapStock('jlap',$rnd);");
	$addInp.="Lokasi : <span id=tkdlokasi_$rnd>".isiCbLokasi('kdlokasi','')."</span>";
	//gantiCbBrgStock()
	$addInp.="Nama Barang : <span id=tkdbrg_$rnd>".isiCbBrg()."</span>";
	
	$tgl1=awalBulan();
	$tgl2=akhirBulan();
	$addInp.="
		<span id='tperiode_$rnd'>
		Periode :".isiCbPeriodeLap()."
		<span id='ttglp_$rnd' style='display:none'>
		Tanggal : <input type=text size=10 class=D name=tgl1 id=tgl1_$rnd value='$tgl1'> SD
		<input type=text size=10 class=D name=tgl2 id=tgl2_$rnd  value='$tgl2'> 
		</span>
		</span>
	";
	
	echo "
	<div class=breadcrumb2>	
	$addInp
		 <a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout');\">Cetak</a>
	</div>
	<div id='tout'></div>
	 
	";	
	echo fbe("$('#kdbrg_$rnd').combobox();"); 
	exit ;
}  

//echo $jlap;
if ($jlap=="kstock") {
	$judulLap="KARTU STOCK";
	$nfLap=$lib_app_path."protected/view/lap/kartu-stock.php"; 
}
elseif ($jlap=="kstock2") {
	$judulLap="KARTU STOCK";
	$nfLap=$lib_app_path."protected/view/lap/kartu-stock+hrg.php"; 
}
elseif ($jlap=="kstock3") {
	$judulLap="KARTU STOCK";
	$nfLap=$lib_app_path."protected/view/lap/kartu-stock+kronologi.php"; 
}
elseif ($jlap=="nstock") {
	$judulLap="NILAI STOCK AKHIR";
	$nfLap=$lib_app_path."protected/view/lap/nilai-stock-akhir.php"; 
}
//echo "$jlap";
include $nfLap;


?>