<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="mca";
$nmTabel=$oNamaTb->kontrolAkun;
$nmTabelAlias='acc';
$nmCaptionTabel="Akun Kontrol";
$nmFieldID='id';
$pathUpload=$toroot."upload/mca/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=usertype("admin,sa")?true:false;
$ae=usertype("admin,sa")?1:2;

$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";

if (op("updateca")) {
	
	updateCA(true);
}
//$isTest=true; 

$sqTabel="select * from (
select xac.*,prk.account_name,'' as kdacc from ".$oNamaTb->kontrolAkun." xac
left join ".$oNamaTb->akun." prk on xac.value=prk.account_code
) as  acc ";


include $um_path."input-std0.php";


$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Akun Kontrol';
			
$i++; $sAllField.="#1|name|NAME|40|1|1|1|30|C|S-0|1|$ae";
$i++; $sAllField.="#2|ket|KET|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|kdacc|AKUN|7|1|0|account_name|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select account_code,account_name from ".$oNamaTb->akun." where ish=0','kdacc');";
addfbe("$('#kdacc_$rnd').combobox();","itb");

$i++; $sAllField.="#3|aktif|AKTIF|7|1|1|0|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('Aktif;1,Non Aktif;0','aktif');";

addSave("value",$kdacc);
/*
$i++; $sAllField.="#4|category|CATEGORY|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|type|TYPE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|length|LENGTH|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#8|aw|AW|7|1|1|1|7|C|S-0|1|1";
*/
/*
$i++; $sAllField.="#9|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

$gPathUpload[$i]=."upload/mca/";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('mca','idperusahaan|nama_perusahaa',561017,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="name;".$oNamaTb->kontrolAkun.".name"; 

/*
*/
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('updateca|&op=updateca','mca|mca',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' />Update CA</span> ";

$aFilterTb=array(
		array('aktif','aktif','Tingkat :  '.um412_isicombo6("Aktif;1,Non Aktif;0",'xaktif',"#url#"),'1'),
);

/*


$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_561017_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Akun Kontrol';//caption tombol import
$sFieldCSV=strtolower('id,name,ket,aktif,category,type,length,value,aw,modified_date');
$sFieldCaptionCSV= strtolower('ID,NAME,KET,AKTIF,CATEGORY,TYPE,LENGTH,VALUE,AW,MODIFIED_DATE');
$nfCSV='import_Akun_Kontrol.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=10;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/

