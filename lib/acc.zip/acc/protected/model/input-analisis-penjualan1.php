<?php 
/*
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();

$i=0;
for ($i=0;$i<=$jrange-1;$i++) {
	$armin[]=$armax[$i+1]+1;
	$arjudul[$i]="$armin[$i] - $armax[$i]";
}
*/
cekVar("ida,media,kdbrg,jenis,jur,mapel");

$subjd="";
$addjdl="";
$addInp="";
$syjenis=" where 1=1 ";

include_once $lib_app_path."protected/controller/controller.php";

cekVar("p,jtrans");

if ($p=='') {
	?>
	<script>
	//cekJenisLap($rnd)
	 
	 
	 function gantiCbb(rnd) {
		kdbranch=$("#kdbranch_"+rnd).val();
		$("#tpbt_"+rnd).hide();
		bukaAjax("tpbt_"+rnd,"filtercombo.php?op=plg&kdbranch="+kdbranch+"&newrnd="+rnd,rnd," $('#tpbt_"+rnd+"').show();$('#kdpembantu_"+rnd+"').combobox();");
	 	$("#tsales_"+rnd).hide();
		bukaAjax("tsales_"+rnd,"filtercombo.php?op=sales&kdbranch="+kdbranch+"&newrnd="+rnd,rnd," $('#tsales_"+rnd+"').show();");
		//$("kdpj_"+rnd).comboBox();
	 }
	 
	 
	 function gantiProvinsi(rnd){
		provinsi=$("#provinsi_"+rnd).val();
		if (provinsi=='')
			$("#tplg_"+rnd).show();
		else
			$("#tplg_"+rnd).hide();
		
	 }
	 function gantiWil(rnd){
		wil=$("#kdwil_"+rnd).val();
		if (wil=='')
			$("#tplg_"+rnd).show();
		else
			$("#tplg_"+rnd).hide();
		
	 }
	 
	 </script>
	 <?php
	 
}

if (!isset($addSqComboBrg)) $addSqComboBrg='';
	
if (($p=="")) {
	
	//+'&provinsi='+$('#provinsi_$rnd').val()
	
	
	$url="
	'index.php?det=$det&ida=$ida&jt=T&p=1&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()
	+'&bentuk='+$('#bentuk_$rnd').val()
	+'&kdpj='+$('#kdpj_$rnd').val()
	+'&kdwil='+$('#kdwil_$rnd').val()
	+'&kdpembantu='+$('#kdpembantu_$rnd').val()
	+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()
	+'&kdjbarang='+$('#kdjbarang_$rnd').val()
	+'&kdbrg='+$('#kdbrg_$rnd').val()
	+'&jtrans='+$('#jtrans_$rnd').val()
	+'&challsize='+$('#challsize_$rnd').attr('checked')
	";
	//+'&jt2='+$('#jt2_$rnd').val()
	
	$tbpdf="";
	$addInp.="<div style='margin-bottom:7px'>";
	
	if ($useBranch) {
		
		if ($defKdBranch=='') {
			$addInp.=" Cabang  : ".  um412_isicombo6("select kdbranch,branch from tbpbranch order by branch","kdbranch","gantiCbb($rnd)");
		} else {
			$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";
			$tbpdf="";
		}
	} else {
		$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";

	}
	//Percabang-Persales;persales,
	//$addInp.=" Provinsi : ".um412_isicombo6("select distinct(provinsi) from tbppembantu order by provinsi","provinsi","gantiProvinsi($rnd)");
	if ($useWilayah)
		$addInp.=" Wilayah  : ".um412_isicombo6("select kdwil from tbpwilayah order by kdwil ","kdwil","gantiWil($rnd)");
	else
		$addInp.=" <input type=hidden name=kdwil id=kdwil_$rnd value=''>";
		
	$addInp.=" Jenis :".um412_isicombo6("Penjualan Umum;SL,Penjualan Eceran;JE,Semua Penjualan;SL/JE,Retur Penjualan;SR","jtrans")."</span></span>";
	//$addInp.=" Tampilan :".um412_isicombo6("Pertransaksi,Perbarang","jt2")."</span></span>";
	
	$sJenisLap="Pertransaksi;pertrans,Pertransaksi-LR;pertranslr,Perbarang-Pertransaksi;perbrg,Perbarang-Pertransaksi-LR;perbrglr"
	.",Rekap Perbarang;rekapbrg"
	.",Rekap Perbarang Perpelanggan;rekapbrg-plg"
	.",Rekap Perjenis-Barang;rekapjbrg"
	.",Rekap Perjenis-Barang Perpelanggan;rekapjbrg-plg"
	.",Rekap Perpelanggan Perbarang;rekapplg-brg"
	.",Rekap Perpelanggan Perjenis-Barang;rekapplg-jbrg";
	$addInp.=" Jenis Lap :".um412_isiCombo6($sJenisLap,"bentuk","cekJenisLapJual($rnd)");
	
	$addInp.=" <span id=tplg_$rnd>Nama Pelanggan  : <span id=tpbt_$rnd>".isiComboPembantu("kdpembantu","PL")."</span></span>";
	
	if ($useMarketing)
		$addInp.=" Nama Marketing  : <span id=tsales_$rnd> ".um412_isicombo6("select id,nama from tbppegawai order by nama","kdpj","")."</span>";
	else
		$addInp.=" <input type=hidden name=kdpj id=kdpj_$rnd value=''>";
	
	$addInp.="</div>";
	$addInp.="<span id=tfbrg_$rnd>";
		$addInp.="Jenis Brg : ".um412_isicombo6("select kdjbarang,jbarang from tbpbarangj","kdjbarang","cbBrgByKdJBrg($rnd)");
		$addInp.=" <span id=tnb_$rnd>Nama Brg : ".um412_isicombo6("select kdbrg,nmbarang from tbpbarang b where 1=1 $addSqComboBrg","kdbrg","")."</span>";
		//$addInp.="<input type=checkbox id=challsize_$rnd > All Size </span>";
	$addInp.="</span >";//tfbrg
	
	//$addInp.="Nama Barang  2: <input name='xnmbrg' size=10 id=xnmbrg >";
	
	$tgl1=awalBulan();
	$tgl2=akhirBulan();
	$addInp.="
		Periode :".um412_isiCombo6("Hari Ini,Kemarin,Minggu Ini,Bulan Ini,Tahun Ini,Custom","periode","gantiPeriode($rnd)")."
		<span id='ttglp_$rnd' style='display:none'>
			Tanggal : <input type=text size=10 class=D name=tgl1 id=tgl1_$rnd value='$tgl1' > SD
			<input type=text size=10 class=D name=tgl2 id=tgl2_$rnd value='$tgl2'> 
		</span>
	";
	
	
	 
	$addInp.="<input type=hidden name=jt id=jt_$rnd value='T'>";//jenis tampilan:Tabel/Grafik
	
	$addf="
	$('.inputtgl').datepicker();
	$(document).ready(function(){
		$('#kdbrg_$rnd').combobox();
		$('#kdpembantu_$rnd').combobox();
		maskAllMoney();	
	});
	
	";
	
	$tbxls="<a class='btn btn-warning btn-sm' onclick=\"bukaJendela($url+'&media=xls');\">XLS</a>
		";
//	$tbxls="		<a class='btn btn-warning btn-sm' onclick=\"xlsDiv('tout_$rnd');\">XLS</a>";
if ($isOnline )$tbxls="";
	echo "
	<div class=breadcrumb2>
		$addInp
		<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout_$rnd',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbxls
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout_$rnd');\">Cetak</a>
		".fbe($addf)."
	</div>
	<div id='tout_$rnd' class=tout ></div>
	";	
	exit;

} 
$t="";
//if (($ida==0)||($ida==1)) {
	$useHtmlTable =false;	
	//$sq="select kdbrg,nmbarang,sum(jlh_terima) from tbpbelid d left join tbpbeli h on d.notrans=h.notrans where $sy ";
	cekVar("bentuk");
	$path=$lib_app_path."protected/view/manalisa/";
	include_once $lib_app_path."protected/controller/app-func-acc-lap.php";
	
	cekvar('jtrans');
	if ($jtrans=="") $jtrans="SL/JE";
	
	$jdtrans=($jtrans=="SR"?"RETUR PENJUALAN":($jtrans=="SL"?"PENJUALAN UMUM":($jtrans=="JE"?"PENJUALAN ECERAN":"PENJUALAN UMUM & ECERAN")));
	$judul="DATA $jdtrans ";
	$jdhupi="PIUTANG";
	$judul2="";
	$sy="";
	$sy.=addSyLapSL($jtrans);	
	$sy.=addSyKdPlg();
	if (($bentuk=='pertrans')||($bentuk=="")){
		$useHtmlTable =true;	
		$orientation="l";
		$xnf="analisis-penjualan-pertrans";
		$judul="DATA $jdtrans PERTRANSAKSI";
	
		$aLap=[
			['NO','NO',30,'C','N',false],
			['notrans','NO. TRANS',90,'C','',false],
			['tgl','TANGGAL',90,'C','D',false],
			['namaplg','PELANGGAN',255,'L','',false],
			['brutto','BRUTTO',90,'C','N',true],
			//['tdisc','DISC',90,'C','N',true],
			['netto','NETTO',90,'C','N',true],
			['paidtoday','TUNAI',90,'C','N',true],
			['paidafter','PELUNASAN',90,'C','N',true],
			['retur','RETUR',90,'C','N',true],
			['hupi',$jdhupi,90,'C','N',true],
			['catatan','CATATAN',90,'C','N',false],
		];
		$sqLap=genSqLapTrans("pertrans");
	}elseif ($bentuk=='pertranslr'){
		$useHtmlTable =true;	
		$orientation="l";
		$sqLap=genSqLapTrans("trans-lr");
		$xnf="analisis-penjualan-pertrans-lr";
		$judul="DATA $jdtrans PERTRANSAKSI (LABA-RUGI)";

		$aLap=[
			['NO','NO',30,'C','N',false],
			['notrans','NO. TRANS',90,'C','',false],
			['tgl','TANGGAL',90,'C','D',false],
			['namaplg','PELANGGAN',255,'L','',false],
			['netto','NETTO',90,'C','N',true],
			['jhpp','HPP',90,'C','N',true],
			['lr','HPP',90,'C','N',true],
		];
		$sqLap=genSqLapTrans("pertrans-lr");

	} elseif ($bentuk=='perbrg'){
		$useHtmlTable =true;
		$judul="DATA $jdtrans DETAIL PERBARANG";
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf="analisis-penjualan-perbarang";
		$aLap=[
			['NO','NO',30,'C','N',false],
			['notrans','NO. TRANS',90,'C','',false],
			['tgl','TANGGAL',90,'C','D2',false],
			//['namaplg','PELANGGAN',330,'L','',false],
			['kdbrg','KODE',90,'C','',false],
			['nmbarang','NAMA BRG.',255,'L','',false],
			//['tdisc','DISC',90,'C','N',true],
			['jlh_terima','JUMLAH',60,'C','CX2',true],
			//['jlh_retur','RETUR',90,'C','CX',true],
			['hrg','HARGA',90,'C','N',true],
		//	['hpp','HPP',90,'C','CX',true],
			['subtot','SUB TOTAL',90,'C','N',true],
			//['jhpp','TOT.HPP',90,'C','N',true],
		//	['jlaba','LABA-RUGI',90,'C','N',true],
		];
		$sqLap=genSqLapTrans("perbrg-lr");

	} elseif ($bentuk=='perbrglr'){
		$useHtmlTable =true;	
		$orientation="l";
		$sy.=addSyKdBrg();
		$xnf="analisis-penjualan-perbarang-lr";
		$judul="DATA $jdtrans DETAIL PERBARANG (LABA-RUGI)";

		$aLap=[
			['NO','NO',30,'C','N',false],
			['notrans','NO. TRANS',90,'C','',false],
			['tgl','TANGGAL',90,'C','D2',false],
			['namaplg','PELANGGAN',230,'L','',false],
			['kdbrg','KODE',90,'C','',false],
			['nmbarang','NAMA BRG.',255,'C','',false],
			//['tdisc','DISC',90,'C','N',true],
			['jlh_terima','JUMLAH',60,'C','CX',true],
			//['jlh_retur','RETUR',90,'C','CX',true],
			['hrg','HARGA',90,'C','N',true],
			['hpp','HPP',90,'C','CX',true],
			['subtot','SUB TOTAL',90,'C','N',true],
			['jhpp','TOT.HPP',90,'C','N',true],
			['jlaba','LABA-RUGI',90,'C','N',true],
		];
		$sqLap=genSqLapTrans("perbrg-lr");

		
	} elseif ($bentuk=='rekapjbrg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perjenis-barang";
	} elseif ($bentuk=='rekapjbrg-plg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perjenis-barang-perpelanggan";
	} elseif ($bentuk=='rekapplg-jbrg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perpelanggan-perjenis-barang";
	} elseif ($bentuk=='persales'){
		$orientation="p";
		$xnf= "analisis-penjualan-percabang-persales";
		//tanpa kdbrg
	} elseif ($bentuk=='rekapbrg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perbarang";
	} elseif ($bentuk=='rekapbrg-plg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perbarang-perpelanggan";
	} elseif ($bentuk=='rekapplg-brg'){
		$orientation="p";
		$sy.=addSyKdBrg();
		$xnf= "analisis-penjualan-rekap-perpelanggan-perbarang";
	}
	//echo "000>".$xnf;
	$nf=$path.$xnf.($useMarketing?"(mk)":"").".php";
	if ($orientation=='p') {
		$clspage="page";	
		$maxbr=30;
	} else{ 
		$clspage="page-landscape";
		$maxbr=14;
	}
	


	if ($useHtmlTable) {
		$aw=array();
		$sFld=$sJudul=$sWidth=$sAlign=$sFormat=$sColJlh="";
		$i=0;
		foreach($aLap as $xlap) {
			$aw[]=$xlap[2];
			$sFld.=($i==0?"":",").$xlap[0];
			$sJudul.=($i==0?"":",").$xlap[1];
			$sWidth.=($i==0?"":",").$xlap[2];
			$sAlign.=($i==0?"":",").$xlap[3];
			$sFormat.=($i==0?"":",").$xlap[4];
			if ($xlap[5]) $sColJlh.=($sColJlh==''?"":",").($i);
			$i++;
		}
		$aw=hitungskala($aw);
		$jlhFld=count($aw);
		$ajlh= array_fill(0, $jlhFld-1, 0);
		
		
		//kop
		$useHtmlTable=true;
			 
		$ax=array(80,480,100);
		$kop="
			<table border='0' width='100%' style='width:100%'  >
				<tr>
					<td align='center' valign='midle' style='font-size:16px;width:$ax[1]%' >
						<b>
						$judul
						</b>
					 
							
					</td> 
			</tr>
		 </table>
		 <br>
		 
		 <table width='100%' style='margin-bottom:24px' >
			$subjd
			</table>
			
		  ";
		if ($media!='') $kop.="<br><br>";


		$tb=new htmlTable();
		$tb->sJudul=$sJudul;
		$tb->sFld=$sFld;
		$tb->sWidth=$sWidth;
		$tb->tbStyle="print";
		$tb->sql=$sqLap;
		$tb->sAlign=$sAlign;
		$tb->showNo=false;
		//$tb->configFld[3]="F,2000,D,1,upload/tugas/"; //konfig file kolom 3 karena ada no	
		//$tb->colContent[4])="carifield();";
		$tb->sFormat=$sFormat;		
		$tb->showNo=true;
		if ($media!='xls') {
			$tb->usePagination=true;
			$tb->clsPage=$clspage;
			$tb->brPerPage=$maxbr;
			$tb->brPerPage2=$maxbr+2;
		}
		$tb->addJudul=$kop;//tambahan judul
		$tb->addJudul2="";//tambahan judul halaman 2 dst
		$tb->sColJlh=$sColJlh;	//kolom yg akan dijumlah
		echo $xnf;

		$isi=$tb->show();
		$t.=$isi;
	} else {
		echo $xnf;
		include $nf;
		$t.="
			$kop
			$jdl
			$isi
			</table>
			";
		
	}		
	
	cekVar('jt',1,1);
	$result="";
	if ($media!='xls') {
		$result.= "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
		$result.="
			<style>
			.page,
			.page-landscape, {			
				padding:2.5cm ;			
			}
			.page,
			.page td,
			.page-landscape,
			.page-landscape td {
				font-size:11px;
				line-height:23px;
			}
			</style>
			
			";
	}
	
	if ($jt=='T') {
		if ($media!='xls'){
			if (!$useHtmlTable) 
				$result.="	<div class='$clspage'>$t</div>";
			else
				$result.=$t;
		}
	} elseif ($jt=='G') {	
		if ($media==''){		
			$result.= "
			<div class='page-landscape' style='padding:20px'>
				<div id='chartdiv' style='width: 100%; height: 600px;'></div>
				<div style='margin-left:30px;display:none'>
					<input type='radio' checked='true' name='group' id='rb1' onclick='setDepth()'>2D
					<input type='radio' name='group' id='rb2' onclick='setDepth()'>3D
				</div>
			</div>";
		}
		/*
		$result.= "
		<div id='tfbe$rnd'  style='display:none'>
		$scriptdata		
		function setDepth() {
			if (document.getElementById('rb1').checked) {
				chart.depth3D = 0;
				chart.angle = 0;
			} else {
				chart.depth3D = 25;
				chart.angle = 30;
			}
			chart.validateNow();
		}
		</div>
		";
		*/ 
	} 
	
	if ($media=='pdf') {
		$html=$result;
		$html=str_replace('"','`',$html);
		$html=str_replace("'",'"',$html);		
		include $um_path."print2pdf.php";
	} else  if ($media=='xls') {
		$nfXls=str_replace("php","xls",pathinfo(__file__,PATHINFO_FILENAME));
		header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
		header("Content-Disposition: attachment; filename=$nfXls");  //File name extension was wrong
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false);
		echo $t;
		exit;
	} else {
		echo $result;
	}
?>