<?php
$useJS=2;
include_once 'conf.php';

$det="jtrans";
$nmTabel='tbpjtrans';
$nmTabelAlias='j';
$nmCaptionTabel="jtrans";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:900,title: \'Input Data\'";
$isTest=false; 

 
$sqTabel="select * from (
select xj.*,p1.account_name as akun1,p2.account_name as akun2,p3.account_name as akun3 
from ((tbpjtrans xj left join ".$oNamaTb->akun." p1 on xj.kdprk1=p1.account_code)
left join ".$oNamaTb->akun." p2 on xj.kdprk2=p2.account_code)
left join ".$oNamaTb->akun." p3 on xj.kdprk3=p3.account_code
) as  j ";



include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Jenis Transaksi';
$i++; $sAllField.="#4|grp|Kategori|7|1|1|1|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('Pemasukan,Pengeluaran,Lain-lain','grp','GTInputJTrans($rnd);');";
$gFuncFld[$i]="GTInputJTrans($rnd);";
$i++; $sAllField.="#1|jtrans|Jenis Transaksi|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|kdprk1|Akun 1|7|1|1|akun1|7|C|S-0|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprk1',1);";
$i++; $sAllField.="#3|kdprk2|Akun 2|7|1|1|akun2|7|C|S-0|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprk2',1);";
/*			
$i++; $sAllField.="#3|kdprk3|Akun 3|7|1|1|akun3|7|C|S-0|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprk3',1);";
*/
if ($op=='itb') {
	//addfbe("GTInputJTrans($rnd);");
}

//$i++; $sAllField.="#2|kdjtrans|KDJTRANS|40|1|1|1|30|C|S-0|1|1";
//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="jtrans;tbjtrans.jtrans"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','jtrans|jtrans',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Jenis Transaksi';//caption tombol import
$sFieldCSV=strtolower('id,jtrans,kdjtrans,kdprkd,kdprkk');
$sFieldCaptionCSV= strtolower('ID,JTRANS,KDJTRANS,KDPRKD,KDPRKK');
$nfCSV='import_Data_Jenis_Transaksi.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
