<?php
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();

cekvar("jtrans");
$i=0;
for ($i=0;$i<=$jrange-1;$i++) {
	$armin[]=$armax[$i+1]+1;
	$arjudul[$i]="$armin[$i] - $armax[$i]";
}

cekVar("ida,media,kdbrg,jenis,jur,mapel");

$subjd="";
$addjdl="";
$addInp="";
$syjenis=" where 1=1 ";

include_once $lib_app_path."protected/controller/controller.php";

cekVar("p");

if ($p=='') {
	if ($jtrans!='') {
		if (strstr("PB",$jtrans)!='') {
			$jPembantu="PM";
			$capPb="Pemasok";
		} else {
			$jPembantu="PL";
			$capPb="Pelanggan";
			
			
		}
	}
	
	?>
	<script>
 
	  function gantiJTampilan(rnd) {
		bentuk=$("#bentuk_"+rnd).val();
	 
		if (bentuk=='pertrans') {
			$("#tsp_"+rnd).show();

		} else {
			$("#tsp_"+rnd).val("");
			$("#tsp_"+rnd).hide();

		}
	}
	 
	 </script>
	 <?php
	 
}

if (($p=="")) {
	$tgl1=awalBulan();
	$tgl2=akhirBulan();
	$addf='';
	$url="
	'index.php?det=$det&ida=$ida&jt=T&p=1&newrnd=$rnd&jtrans=$jtrans&kdbranch='+$('#kdbranch_$rnd').val()
	+'&bentuk='+$('#bentuk_$rnd').val()
	+'&kdpj='+$('#kdpj_$rnd').val()
	+'&kdpembantu='+$('#kdpembantu_$rnd').val()
	+'&statby='+$('#statby_$rnd').val()
	+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+'&kdbrg='+$('#kdbrg_$rnd').val()
	";
	$tbpdf="";
	$tbxls="<a class='btn btn-warning btn-sm' onclick=\"bukaAjax('tout_$rnd',$url+'&media=xls',0,'awalEdit($rnd)');\">XLS</a>";
	$tbxls="";
	
	if ($useBranch) {
		if (strtolower($userType)=='sa') {
			$addInp.=" Cabang  : ".  um412_isicombo6("select kdbranch,branch from tbpbranch order by branch","kdbranch","gantiCbb($rnd)");
		} else {
			$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";
			//$kdbrg=$userid;
			$tbpdf="";
		}
	}
	$bentuk="pertrans";	
	$addInp.="<div style='margin-bottom:7px'>";
	$addInp.=" Jenis Tampilan :".um412_isiCombo6("Pertransaksi;pertrans,Detail Perbarang;perbrg,Rekap Perbarang;rekapbrg","bentuk","gantiJTampilan($rnd)");
	if ($jtrans=="PG") {
		$addInp.="
		<input type=hidden name=kdpembantu id=kdpembantu_$rnd value=''>
		<input type=hidden name=statby id=statby_$rnd value=''>
		";
		//produksi
	} else { 
		$addf.="$('#kdpembantu_$rnd').combobox();";
		$addInp.=" Nama $capPb  : <span id=tpbt_$rnd>".isiComboPembantu("kdpembantu",$jPembantu)."</span>";
		$addInp.="<span id=tsp_$rnd> Status Pelunasan : ".um412_isicombo6("Semua,Lunas,Belum Lunas","statby")."</span>";
		//$addInp.=" Nama Marketing  : <span id=tsales_$rnd>".um412_isicombo6("select id,nama from tbppegawai order by nama","kdpj","")."</span>";
	}
	$addInp.="</div>";
	
	$addInp.="<div style='margin-bottom:7px'>";
	$addInp.="Nama Barang  : ".um412_isicombo6("select kdbrg,nmbarang from tbpbarang b where 1=1 $addSqComboBrg","kdbrg","");
	$addInp.="
		Periode :".um412_isiCombo6("Hari Ini,Minggu Ini,Bulan Ini,Tahun Ini,Custom","periode","gantiPeriode($rnd)")."
		<span id='ttglp_$rnd' style='display:none'>
		Tanggal : <input type=text size=10 class=D name=tgl1 id=tgl1_$rnd value='$tgl1' > SD
		<input type=text size=10 class=D name=tgl2 id=tgl2_$rnd value='$tgl2'> 
		</span>
	";
	
	$addInp.="
			<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout_$rnd',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbxls
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout_$rnd');\">Cetak</a>
	";
	$addInp.="</div>";
	
	 
	$addInp.="<input type=hidden name=jt id=jt_$rnd value='T'>";//jenis tampilan:Tabel/Grafik	
	echo "
	<div class=breadcrumb2>
		$addInp
	</div>
	<div id='tout_$rnd' class=tout ></div>
	";	
	
	$addf.="
		$('#kdbrg_$rnd').combobox();
		$('.custom-combobox-input').css('width','auto');
		maskAllMoney();	
	";
	
	$addf="
	$(document).ready(function(){
		$addf
	});
	";
	echo fbe($addf);
	
	exit;

} 
$t="";
if (($ida==0)||($ida==1)) {
	 		
	$sy="";
	$an="pembelian";
	if ($jtrans=="PG") $an="packing";
	//$sq="select kdbrg,nmbarang,sum(jlh_terima) from tbpbelid d left join tbpbeli h on d.notrans=h.notrans where $sy ";
	cekVar("bentuk");
	if (($bentuk=='pertrans')||($bentuk=="")){
		$orientation="l";
		$nf=$lib_app_path."protected/view/manalisa/analisis-$an-pertrans.php";
		
	} elseif ($bentuk=='perbrg'){
		$orientation="l";
		$nf= $lib_app_path."protected/view/manalisa/analisis-$an-perbarang.php";
	} elseif ($bentuk=='rekapbrg'){
		$orientation="p";
		$nf= cekFileViewLocal("manalisa/analisis-$an-rekap-perbarang",$include=false);
		
	}
	 
	if ($orientation=='p') {
		$clspage="page";	
		$maxbr=34;
	} else{ 
		$clspage="page-landscape";
		$maxbr=14;
	}
	include $nf;
	$t.= "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
 
	//$t.=$scriptdata;
	cekVar('jt',1,1);
	$result="";
	if ($media!='xls') {
		$result.="
		<style>
		.page,
		.page-landscape,
		{
			
			padding:2.5cm ;
			
			
			}
		.page,
		.page td,
		.page-landscape,
		.page-landscape td {
			font-size:11px
		}
		</style>
		
		";
	}
	if ($jt=='T') {
		if ($media!='xls'){
			
			$result.="	<div class='$clspage'>$t</div>";
		}
	}
	if ($jt=='G') {	
		if ($media==''){		
			$result.= "
			<div class='page-landscape' style='padding:20px'>
				<div id='chartdiv' style='width: 100%; height: 600px;'></div>
				<div style='margin-left:30px;display:none'>
					<input type='radio' checked='true' name='group' id='rb1' onclick='setDepth()'>2D
					<input type='radio' name='group' id='rb2' onclick='setDepth()'>3D
				</div>
			</div>";
		}
		/*
		$result.= "
		<div id='tfbe$rnd'  style='display:none'>
		$scriptdata		
		function setDepth() {
			if (document.getElementById('rb1').checked) {
				chart.depth3D = 0;
				chart.angle = 0;
			} else {
				chart.depth3D = 25;
				chart.angle = 30;
			}
			chart.validateNow();
		}
		</div>
		";
		*/ 
	//	echo "hoho....";
	} 
	
	if ($media=='pdf') {
		$html=$result;
		$html=str_replace('"','`',$html);
		$html=str_replace("'",'"',$html);
		
		include $um_path."print2pdf.php";
	} else 
		echo $result;
	
	}
?>