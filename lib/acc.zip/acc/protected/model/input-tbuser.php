<?php
$useJS=2;
include_once "conf.php";
secureuser("admin,sa");
//default
$det="tbuser";
$nmTabel='tbuser';
$nmTabelAlias='u';
$nmCaptionTabel="User";
$nmFieldID='vuserid';

//$isTest=$debugMode;
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;

//$isTest=true;
if (!isset($sUserType)) {
	$sUserType="Admin;admin,Keuangan;acc,Gudang;gudang,Pembelian;pembelian,Kasir;kasir,Direksi;direksi";
}

if (!usertype("sa")) {
	if ($defKdBranch=="") {
		echo um412_falr("Unauthorized User","warning");
		exit;
	}
	addFilterTb("kdbranch='$defKdBranch'");
	addsave("kdbranch",$defKdBranch,"tb");
} else {
	$sUserType="Superadmin;sa,$sUserType";
}

if ($op=='gen') {
	include $um_path."input-std.php";
	exit;
}


$tbsql="";
$thisFile=$nfref="index.php?ref=$det&det=$det&useJS=2&contentOnly=1";//&valid=1
 
$sqTabel="select * from (
 select uu.*,b.branch,l.lokasi,
 pb.nama as namapb,
 p.nama as namapeg
 from tbuser uu left join tbpbranch b on uu.kdbranch=b.kdbranch
   left join tbplokasi l  on uu.kdlokasi=l.id
   left join tbppegawai p  on uu.idpegawai=p.id
 left join tbppembantu pb on uu.idpembantu=pb.id
 
 ) as u ";
//$isTest=true;
include $um_path."input-std0.php";
$sAllField='';
//$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|4";
//$gGroupInput[$i]='user';
$i=0; $sAllField.="4|vuserid|ID User|12|1|1|1|50|C|H1-4";
$i++; $sAllField.="#1|vusername|Nama User|40|1|1|1|50|C|S-4";
$i++; $sAllField.="#2|vusertype|Tipe|40|1|1|1|50|C|S-2";

$gFieldInput[$i]="$"."inp=um412_isicombo6('$sUserType','vusertype');";
$i++; $sAllField.="#3|vpass|Password|40|1|1|0|50|C|P";
//$i++; $sAllField.="#3|idpembantu|Link Pemasok|10|1|1|namapb|10|C|CB";

$i++; $sAllField.="#3|idpegawai|Link Karyawan|10|1|1|namapeg|10|C|CB";
//$gFieldInput[$i]="=isiComboPembantu('idpembantu','PL');"; 
if ($useBranch) {
	if (usertype("sa")) {
		$i++; $sAllField.="#3|kdbranch|Cabang|40|1|1|branch|50|C|S-0";
		$gFieldInput[$i]="=isiCbBranch('kdbranch','cbLokasiByBranch($rnd)');";
	} else {
		
	}
	$i++; $sAllField.="#3|kdlokasi|Lokasi|40|1|1|lokasi|50|C|S-0";
	$gFieldInput[$i]="=isiCbLokasi();";
}

$i++; $sAllField.="#4|ket|Catatan|40|1|1|1|50|C|4";

$isiComboFilterTabel="username;tbuser.username"; 
$identitasRec='rctbuser'; 
$configFrmInput='width:900'; 
$folderModul='muser'; 
$nfReport="$folderModul/showtable.php"; 

//include "$folderModul/custom-user.php"; 

include $um_path."input-std.php";


//tempat copas


//pencetakan

?>