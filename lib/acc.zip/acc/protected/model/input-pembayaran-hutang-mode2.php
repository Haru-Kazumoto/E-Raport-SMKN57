<?php
$useJS=2;
include_once 'conf.php';

$det="pembayaran-hutang";
$nmTabel='tbpbayar';
$nmTabelAlias='h';
$nmCaptionTabel="Pelunasan Hutang";
$nmFieldID='id';

$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:1000,title: \'Input Data\'";

cekVar("jtrans");
if ($jtrans=="") {
	if (isset(	$_SESSION['jtransbayar'])) 
			$jtrans=$_SESSION['jtransbayar'];
		else
			$jtrans="PH";
} else {
	$_SESSION['jtransbayar']=$jtrans;
}
 
if ($jtrans=="PH") {
	$nmCaptionTabel="Pelunasan Hutang";
	$nmCapPB="Pemasok";
	$jenisPb="PM";
	if (op("itb")) $kdAwal="PH".$defKdBranch;
	$jtransBeli="PB";
	$jkas="KK";
}
elseif ($jtrans=="PP") {
	$nmCaptionTabel="Penerimaan Piutang";
	if (op("itb")) $kdAwal="PI".$defKdBranch;
	$nmCapPB="Pelanggan";
	$jenisPb="PL";
	$jtransBeli="SL";
	$jkas="KM";	
}

addFilterTb("jtrans='$jtrans'");
addParamOpr("jtrans",$jtrans);
//echo "jtrans $jtransBeli ";

$sqTabel="select * from (
select xh.*,pb.nama as namapb,oc.account_name as prkkas 
from (tbpbayar xh left join tbppembantu pb on xh.kdpembantu=pb.id) 
left join ".$oNamaTb->akun." oc on xh.kdprk1=oc.account_code
) as  h ";

include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah='admin'");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Pembayaran Hutang';
			
$i++; $sAllField.="#1|kdbayar|No. Pelunasan|40|1|1|1|30|C|U-1|1|1";
if (op("itb")) {
	$gDefField[$i]= getNewNoTrans2($kdAwal,"tbpbayar",'kdbayar',5);
}
$i++; $sAllField.="#2|tgl|Tanggal|40|1|1|1|30|C|D-0|1|1";
$gDefField[$i]=date($formatTgl);

if (usertype("sa")) {
	//if ($useBranch) {
	$i++; $sAllField.="#20|kdbranch|Cabang|40|1|1|1|30|C|S-0|1|1";
	$gDefField[$i]=$defKdBranch;
	$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch');";
} else {
	addSave("kdbranch",$defKdBranch);
}

$i++; $sAllField.="#4|kdpembantu|$nmCapPB|7|1|1|namapb|7|C|S-1|1|1";
$gFieldInput[$i]= "=showListPembantu('$jenisPb','getSaldoHP($rnd)');";
$gAddField[$i]="='<span class=tsaldohp id=tsaldohp_$rnd > Saldo Hutang/Piutang : '.getSaldoHP('{kdpembantu}').'</span>';";

$i++; $sAllField.="#4|jlhbayar|Jumlah Penerimaan|7|1|1|1|7|C|N-1|1|1";
if ($isAddItb) {	
	$gAddField[$i]="=\"<span id=aa$rnd>
	<a href='#' class='btn btn-info btn-xs btn-mini' 
	onclick=\\\"autoAllocatedPayment($rnd,'$jtrans');return false;\\\"  >Alokasi Otomatis</a></span>\" ";
}

$tPosDetail=$i;

//$i++; $sAllField.="#6|jlhbayar|Jumlah Pembayaran|13|1|1|1|7|C|N-1|1|1";

/*
$i++; $sAllField.="#13|jlhbayar|Jumlah|13|3|1|1|7|C|N,0|1|1";
$gFuncFld[$i]="evalTransPelunasan($rnd);";
*/


$i++; $sAllField.="#15|carabayar|CARA BAYAR|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('R:Cash;C,Transfer;T,Cek/BG;B','carabayar',\"evalFldTrans('$jtrans','carabayar',$rnd,'kdprk1')\");";

$i++; $sAllField.="#9|kdprk1|Akun Kas/Bank|7|1|1|prkkas|7|C|S-1|1|1";
if (op("itb")) {
	if ($isAddItb) $kdprk1=$defKdPrkKasM;
	$gFieldInput[$i]="=isiComboAcc('kdprk1',0,11100,'','$kdprk1');";
}
$i++; $sAllField.="#17|snotrans|NOTRANS|40|0|0|1|30|C|S-0|1|1";
//$i++; $sAllField.="#18|jlhdisc|JLHDISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#3|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";
 
/*

$i++; $sAllField.="#14|stat|STAT|7|1|1|1|7|C|S-0|1|1";$i++; $sAllField.="#10|kdprk2|KDPRK2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#11|noac|NOAC|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|nobg|NOBG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#16|jtrans|JTRANS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|jlhbonus|JLHBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#8|jlhdeposit|JLHDEPOSIT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|kdlokasi|KDLOKASI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#21|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('hutang','idperusahaan|nama_perusahaa',986672,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";

*/
//$isiComboFilterTabel="kdbayar;tbpbayar.kdbayar"; 


if (userType("sa")) {
	$addTbOpr=" 
	<span  class='btn btn-warning btn-mini btn-sm' 
	onclick=\"tbOpr('view|&op=view&custom=gl','$det',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> 
	";
}


 

$useInputD=true;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbpbayard';
$nmTabelDAlias='d';
$fldKeyM='kdbayar';
$fldKeyForeign='kdbayar';
$fldKeyD='id';
$sFldD="notrans,xxTerhutang,discbayar,jlhbayar,xxSisa,catatan";
$sFldDCap="No. Transaksi,xxTerhutang,xxPotongan,Jumlah Pembayaran,xxSisa,Catatan";
$sLebarFldD="70,70,70,100,100,370,220,70";
$sClassFldD=",,,N,,,,,,,,,,,,,,,";
$sAlignFldD=",,,N,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Pembayaran";
$jlhDefRowAdd=1;


//$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' ";

//$gFieldInputD[0]="=um412_isicombo5('select notrans,netto,netto-paidtoday-paidafter as terhutang from tbpbeli where jtrans=\'$jtransBeli\' and (netto-paidtoday-paidafter)>0 order by tgl asc','d_notrans_$rnd"."_#no#;d_notrans[]','notrans','notrans netto terhutang','','#def#' );";
$gFieldInputD[0]="=\"
<input type=text id='d_notrans_#rnd#_#no#'  name='d_notrans[]' value='#def#'>
<a href=# onclick=cariTransTerhutang($rnd,#no#,'$jtransBeli') class='btn btn-info btn-sm' 
style='height: 18px;margin-top: -7px;'>... </a>

\"";

//$gFieldInputD[0]="=buatLinkDafHutang('d_notrans_#rnd#_#no#,d_notrans[]','$jenisPb','$jtransBeli','#def#');";

//$gFieldViewD[0]="nmpelanggan";
/*
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
$gFuncFldD[3]="evalTransPelunasan($rnd);";

if (op("tb,ed")){
	//querysql("update tbpbelid set cek=0  where notrans='$notrans' ");
	addsave("jtrans",$jtrans);
	addsaveD("cek",1);
}


//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Pembayaran Hutang';//caption tombol import
$sFieldCSV=strtolower('id,kdbayar,tgl,catatan,kdpembantu,opr,jlhbayar,jlhbonus,jlhdeposit,kdprk1,kdprk2,noac,tgljt,nobg,stat,carabayar,jtrans,snotrans,jlhdisc,kdlokasi,kdbranch,modified_date');
$sFieldCaptionCSV= strtolower('ID,KDBAYAR,TGL,CATATAN,KDPEMBANTU,OPR,JLHBAYAR,JLHBONUS,JLHDEPOSIT,KDPRK1,KDPRK2,NOAC,TGLJT,NOBG,STAT,CARABAYAR,JTRANS,SNOTRANS,JLHDISC,KDLOKASI,KDBRANCH,MODIFIED_DATE');
$nfCSV='import_Pembayaran_Hutang.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
if (op("del")) {
	$syHapus="  ".changeParamSySql2($aid,"id",$param=",",$oprx="=","or");
	$sq="select kdbayar  from tbpbayar where ".$syHapus ;
	$skdbayar=getstring($sq);
	$sq="select distinct(notrans)  from tbpbayard where ".changeParamSySql2($skdbayar,"kdbayar",$param=",",$oprx="=","or"); ;
	$snotrans=getstring($sq);
}


include $um_path."input-std.php";
 
if (op("tb,ed")) {
	$snotrans=getstring("select notrans from tbpbayard where kdbayar='$kdbayar' ",",");
	mysql_query2("delete from tbpbayard where  kdbayar='$kdbayar' and (jlhbayar=0 or cek=0) ");
	
	
	$snotransbaru=getstring("select notrans from tbpbayard where kdbayar='$kdbayar' ",",");
	$sqn="update tbpbayar set snotrans='$snotransbaru' where id='$id' ;";
	mysql_query2($sqn);
	
	updatePelunasan($snotrans.",".$snotransbaru,$jtrans);
	//update jlhbayar di tabel beli
	$skdbayar=$kdbayar;
	updateGlTransPelunasan($skdbayar);	

} elseif (op("del")) {
	
	$sq="delete from tbpbayard where ".changeParamSySql2($skdbayar,"kdbayar",$param=",",$oprx="=","or");
	mysql_query2($sq);	
	updatePelunasan($snotrans,$jtrans);	
	
	//echo "jtrans $jtrans notrans $skdbayar >>>>";
	updateGlTransPelunasan($skdbayar);	
}

