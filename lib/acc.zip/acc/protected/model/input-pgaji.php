<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="pgaji";
$nmTabel='tbppegawai_gaji';
$nmTabelAlias='g';
$nmCaptionTabel="Penggajian";
$nmFieldID='id';
$pathUpload=$toroot."upload/pgaji/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";


$isTest=false; 

$sqTabel="select * from (
select xg.* from tbppegawai_gaji xg
) as  g ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah=''");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Penggajian';
			
$i++; $sAllField.="#1|tgl|TGL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|idpegawai|IDPEGAWAI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#3|bulan|BULAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|tahun|TAHUN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#5|jmasuk|JMASUK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|jabsen1|JABSEN1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|jabsen2|JABSEN2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|bonus|BONUS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|cicilan|CICILAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|notrans|NOTRANS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|j_lembur|J_LEMBUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|s_lembur|S_LEMBUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|g_borongan|G_BORONGAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#14|j_borongan|J_BORONGAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|s_borongan|S_BORONGAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#16|nama|NAMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|divisi|DIVISI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|subdivisi|SUBDIVISI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|alamat|ALAMAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|kota|KOTA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#21|provinsi|PROVINSI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#22|telp|TELP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#23|fax|FAX|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#24|cp|CP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#25|hp|HP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#26|email|EMAIL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#27|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#28|npwp|NPWP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#29|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#30|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#31|www|WWW|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|fb|FB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#33|twitter|TWITTER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#34|pinbb|PINBB|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#35|grade|GRADE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|jabatan|JABATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|t_jabatan|T_JABATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|g_pokok|G_POKOK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#39|t_makan|T_MAKAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#40|t_transport|T_TRANSPORT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#41|g_lembur|G_LEMBUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#42|g_insentif|G_INSENTIF|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#43|g_satuan|G_SATUAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#44|tgl_terima|TGL_TERIMA|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#45|NIK|NIK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#46|Alias|ALIAS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#47|Cabang|CABANG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#48|statkar|STATKAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#49|masakontrak|MASAKONTRAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#50|hakakses|HAKAKSES|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#51|pin|PIN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#52|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#53|nokuit|NOKUIT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#54|brutto|BRUTTO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#55|totpotongan|TOTPOTONGAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#56|netto|NETTO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#57|jgaji|JGAJI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#58|editgaji|EDITGAJI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#59|jdispensasi|JDISPENSASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#60|jdispensasi2|JDISPENSASI2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#61|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#62|kdbranch|KDBRANCH|40|1|1|1|30|C|S-0|1|1";

/*
$gPathUpload[$i]=."upload/pgaji/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('pgaji','idperusahaan|nama_perusahaa',491992,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="tgl;tbppegawai_gaji.tgl"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','pgaji|pgaji',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','g.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_491992_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Penggajian';//caption tombol import
$sFieldCSV=strtolower('id,tgl,idpegawai,bulan,tahun,jmasuk,jabsen1,jabsen2,bonus,cicilan,notrans,j_lembur,s_lembur,g_borongan,j_borongan,s_borongan,nama,divisi,subdivisi,alamat,kota,provinsi,telp,fax,cp,hp,email,term,npwp,catatan,inactive,www,fb,twitter,pinbb,grade,jabatan,t_jabatan,g_pokok,t_makan,t_transport,g_lembur,g_insentif,g_satuan,tgl_terima,NIK,Alias,Cabang,statkar,masakontrak,hakakses,pin,jenis,nokuit,brutto,totpotongan,netto,jgaji,editgaji,jdispensasi,jdispensasi2,modified_date,kdbranch');
$sFieldCaptionCSV= strtolower('ID,TGL,IDPEGAWAI,BULAN,TAHUN,JMASUK,JABSEN1,JABSEN2,BONUS,CICILAN,NOTRANS,J_LEMBUR,S_LEMBUR,G_BORONGAN,J_BORONGAN,S_BORONGAN,NAMA,DIVISI,SUBDIVISI,ALAMAT,KOTA,PROVINSI,TELP,FAX,CP,HP,EMAIL,TERM,NPWP,CATATAN,INACTIVE,WWW,FB,TWITTER,PINBB,GRADE,JABATAN,T_JABATAN,G_POKOK,T_MAKAN,T_TRANSPORT,G_LEMBUR,G_INSENTIF,G_SATUAN,TGL_TERIMA,NIK,ALIAS,CABANG,STATKAR,MASAKONTRAK,HAKAKSES,PIN,JENIS,NOKUIT,BRUTTO,TOTPOTONGAN,NETTO,JGAJI,EDITGAJI,JDISPENSASI,JDISPENSASI2,MODIFIED_DATE,KDBRANCH');
$nfCSV='import_Penggajian.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=63;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
