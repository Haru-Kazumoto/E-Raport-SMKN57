<?php
//$useJS=2;
//include_once 'conf.php';
secureUser('admin,sa,Super Admin');

$det="mcuti";
$nmTabel='tbppegawai_mcuti';
$nmTabelAlias='ct';
$nmCaptionTabel="jenis Cuti";
$nmFieldID='id';
$pathUpload=$toroot."upload/mcuti/";

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:wMax-100,title: \'$nmCaptionTabel\'";


$isTest=false; 

$sqTabel="select * from (
select xct.* from tbppegawai_mcuti xct
) as  ct ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah=''");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='jenis Cuti';
			
$i++; $sAllField.="#1|deskripsi|DESKRIPSI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|jlhhari|JLHHARI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#3|ispaid|ISPAID|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#4|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";

/*
$gPathUpload[$i]=."upload/mcuti/";
$gFieldInput[$i]="=um412_isicombo6('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gAddField[$i]="<input type=hidden name='kd_$rnd'><a class='btn btn-primary btn-sm' onclick=\"getDokter();return false\">show</a>";
$gFieldLink[$i]="guru,id,kdguru";//det,fldkey,fldkeyval

$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('mcuti','idperusahaan|nama_perusahaa',922275,this.value);";

$gStrView[$i]= carifield("select concat (id,' - ',namabrg) from tbpenjualanb where id='$idpenjualanb' ");
addCekDuplicate('bulan,tahun,idpegawai');
if (1==2) {
	addcek.='<br>A TIDAK BOLEH SAMA DENGAN B';
}
//contoh untuk input hidden dan hanya menampilkan string tertentu (H2)
$i++; $sAllField.="#1|idpenjualanb|NAMA BARANG|7|1|1|namabrg|57|C|H2,0|1|1";
$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="deskripsi;tbppegawai_mcuti.deskripsi"; 

/*
$addTbOpr1=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','mcuti|mcuti',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/


/*

$aFilterTb=array(
		array('tingkat','ct.tingkat|like','Tingkat :  '.um412_isicombo6("$sTingkat",'xtingkat',"#url#"),'defXI'),
);

$useInputD=false;
$showNoD=true;
//--------------------------detail

$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";
$jlhDefRowAdd=1;


$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;

$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo6('select id,nama from tbppegawai','d_idsales_922275_#no#|d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";


$aFilterTb=array(
		array('kdkelas','kdkelas','Kelas :  '.um412_isicombo6("select kdkelas from tbkelas order by kdkelas",'xkdkelas',"#url#").""),
		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import jenis Cuti';//caption tombol import
$sFieldCSV=strtolower('id,deskripsi,jlhhari,ispaid,catatan');
$sFieldCaptionCSV= strtolower('ID,DESKRIPSI,JLHHARI,ISPAID,CATATAN');
$nfCSV='import_jenis_Cuti.csv';
/*
$sFieldCsvAdd=',kdsekolah';
$sFieldCsvAddValue=",'$defKdSekolah'";
$syImport="
	carifield(\"select kdkelas  from tbkelas where kdsekolah='$defKdSekolah' and kdkelas='-#kdkelas#-' \")!='';
	carifield(\"select nisn  from tbsiswa where kdsekolah='$defKdSekolah' and nisn='-#nisn#-' \")=='';
	
	";
$addTxtInfoExim="<li>Pastikan nomor id peserta unique. nomor id yang sama akan dianggap sebagai update</li>";
*/
include $um_path."input-std.php";


/*
catatan2

$tPosDetail=5;//untuk menentukan posisi tabel detail setelah field apa

if ($opcek==1) {//untuk menambah validasi
	$s=unmaskrp($byangkut)-unmaskrp($byangkuttunai);
	if ($s<0) $addCek.="<br>Bon Supir tidak boleh melebihi biaya angkut....";
}
*/


?>
