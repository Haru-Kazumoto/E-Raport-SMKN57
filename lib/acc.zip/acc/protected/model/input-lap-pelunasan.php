<?php
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();

$i=0;
for ($i=0;$i<=$jrange-1;$i++) {
	$armin[]=$armax[$i+1]+1;
	$arjudul[$i]="$armin[$i] - $armax[$i]";
}

cekVar("ida,media,jtrans,jenis");

if ($jtrans=="PH") {
	$capPb="Supplier";
	$jpb="PM";
	$jd2="Hutang";
	$jd="Pelunasan Hutang";
	
} else {
	$capPb="Customer";
	$jpb="PL";
	$jd2="Piutang";
	$jd="Penerimaan Piutang";
	
}

$subjd="";
$addjdl="";
$addInp="";
$syjenis=" where 1=1 ";

include_once $lib_app_path."protected/controller/controller.php";

cekVar("p");

if (($p=="")) {
	
	$url="
	'index.php?det=$det&ida=$ida&jt=T&jtrans=$jtrans&p=1&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()
	+'&kdpembantu='+$('#kdpembantu_$rnd').val()
+'&bentuk='+$('#bentuk_$rnd').val()
	+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+'&kdbrg='+$('#kdbrg_$rnd').val()
	";
	$tbpdf="";
	$addInp.="<div style='margin-bottom:7px'>";
	
	if ($useBranch) {
		
		if ($defKdBranch=='') {
			$addInp.=" Cabang  : ".  um412_isicombo6("select kdbranch,branch from tbpbranch order by branch","kdbranch","gantiCbb($rnd)");
		} else {
			$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";
			$tbpdf="";
		}
	} else {
		$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";

	}
	//$kdbrg=$userid;
	$tbpdf="";

	$bentuk="uppertrans";
	$sJenisLap="$jd2;uppertrans,$jd Pertransaksi;pertrans,Rekap $jd2 Per$capPb;uprekap";
	$addInp.="Laporan :".um412_isiCombo6($sJenisLap,"bentuk","cekJenisLap($rnd)");

/*
//	$addInp.=" Jenis Tampilan :".um412_isiCombo6("Pertransaksi;pertrans,Percabang-Persales;persales,Detail Perbarang;perbrg,Rekap Perbarang;rekapbrg","bentuk");
	$addInp.="<span id=tsp_$rnd> Status Pelunasan : ".um412_isicombo6("Semua,Lunas,Belum Lunas","statby")."</span>";
	//$addInp.=" Nama Marketing  : <span id=tsales_$rnd>".um412_isicombo6("select id,nama from tbppegawai order by nama","kdpj","")."</span>";
	
	$addInp.="</div>";$addInp.="Nama Barang  : ".um412_isicombo6("select kdbrg,nmbarang from tbpbarang b where 1=1 $addSqComboBrg","kdbrg","");
	$addInp.=" Jenis Tampilan :".um412_isiCombo6("Pertransaksi;pertrans,Detail;detail","bentuk","gantiJTampilan($rnd)");
	
*/
	$addInp.=" <input type=hidden name=bentuk id=bentuk_$rnd value='pertrans'>";	
	$addInp.=" $capPb  : <span id=tpbt_$rnd>".isiComboPembantu("kdpembantu",$jpb)."</span>";
	
	
	$tgl1=awalBulan();
	$tgl2=akhirBulan();
	$periode="Bulan Ini";
	$addInp.="
		Periode :".um412_isiCombo6("Hari Ini,Minggu Ini,Bulan Ini,Tahun Ini,Custom","periode","gantiPeriode($rnd)")."
		<span id='ttglp_$rnd' style='display:none'>
			Tanggal : <input type=text size=10 class=D name=tgl1 id=tgl1_$rnd value='$tgl1' > SD
			<input type=text size=10 class=D name=tgl2 id=tgl2_$rnd value='$tgl2'> 
		</span>
	";
	
	 
	$addInp.="<input type=hidden name=jt id=jt_$rnd value='T'>";//jenis tampilan:Tabel/Grafik
	
	$addf="
	$('.inputtgl').datepicker();
	$(document).ready(function(){ 
		$('#kdpembantu_$rnd').combobox();
		$('.custom-combobox-input').css('width','auto');
	
		maskAllMoney();	
	});
	
	";
	
	$tbxls="<a class='btn btn-warning btn-sm' onclick=\"bukaAjax('tout_$rnd',$url+'&media=xls',0,'awalEdit($rnd)');\">XLS</a>
		";
	$tbxls="";
	echo "
	<div class=breadcrumb2>
		$addInp
		<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout_$rnd',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbxls
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout_$rnd');\">Cetak</a>
		<script>$addf</script>
	</div>
	<div id='tout_$rnd' class=tout ></div>
	";	
	exit;

} 
$t="";

$sy="";
//$sq="select kdbrg,nmbarang,sum(jlh_terima) from tbpbelid d left join tbpbeli h on d.notrans=h.notrans where $sy ";
cekVar("bentuk");
include_once $lib_app_path."protected/controller/app-func-acc-lap.php";
$path=$lib_app_path."protected/view/lap/";

if (($bentuk=='pertrans')||($bentuk=="")){
	$orientation="l";
	$xnf="lap-pelunasan-pertrans";
} else if ($bentuk=='uppertrans'){
	$orientation="l";
	$path=$lib_app_path."protected/view/manalisa/";	
	$xnf="analisis-utang-pertrans";
} else if ($bentuk=='uprekap'){
	$orientation="p";
	$path=$lib_app_path."protected/view/manalisa/";	
	$xnf="analisis-utang-persupplier";
} else {
	$orientation="l";
	$xnf= "lap-pelunasan-detail";
} 

$nf=$path.$xnf.($useMarketing?"(mk)":"").".php";
	 
if ($orientation=='p') {
	$clspage="page";	
	$maxbr=34;
} else{ 
	$clspage="page-landscape";
	$maxbr=14;
}
include $nf;
 
$t.= "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";

//$t.=$scriptdata;
cekVar('jt',1,1);
$result="";
if ($media!='xls') {
	$result.="
	<style>
	.page,
	.page-landscape,
	{
		
		padding:2.5cm ;
		
		
		}
	.page,
	.page td,
	.page-landscape,
	.page-landscape td {
		font-size:11px
	}
	</style>
	
	";
}
 
if ($jt=='T') {
	if ($media!='xls'){
		
		$result.="	<div class='$clspage'>$t</div>";
	}
}
if ($jt=='G') {	
	if ($media==''){		
		$result.= "
		<div class='page-landscape' style='padding:20px'>
			<div id='chartdiv' style='width: 100%; height: 600px;'></div>
			<div style='margin-left:30px;display:none'>
				<input type='radio' checked='true' name='group' id='rb1' onclick='setDepth()'>2D
				<input type='radio' name='group' id='rb2' onclick='setDepth()'>3D
			</div>
		</div>";
	}
	/*
	$result.= "
	<div id='tfbe$rnd'  style='display:none'>
	$scriptdata		
	function setDepth() {
		if (document.getElementById('rb1').checked) {
			chart.depth3D = 0;
			chart.angle = 0;
		} else {
			chart.depth3D = 25;
			chart.angle = 30;
		}
		chart.validateNow();
	}
	</div>
	";
	*/  
} 
 
if ($media=='pdf') {
	$html=$result;
	$html=str_replace('"','`',$html);
	$html=str_replace("'",'"',$html);
	
	include $um_path."print2pdf.php";
} else 
	echo $result;

?>