<?php

if ($op=='itb') {

} elseif(op("hp,del")) {
	updateGLAndStockTransBeli($aid,$op);
	
}
elseif (op('tb,ed')){
	//$skdbrgLama=getstring("select kdbrg from tbpbelid where notrans='$notrans'");
	//querysql("update tbpbelid set cek=0  where notrans='$notrans' ");
	
	//hapus data terpakai
	//querysql("delete from tbpbelid_terpakai where notrans='$notrans' ");
	
	addsave("jtrans",$jtrans);
	addsaveD("cek",1);
	//addsave("kdprkkas",$kpk);
	$br=unmaskrp($brutto);
	$by=unmaskrp($bayar);
	
	$paidtoday=$by>=$br?$br:$by;
	if ($jtrans=="JE") {
		addsave("paidtoday",$paidtoday);
		addsave("netto",$br);
	}
	elseif ($jtrans=="BB") {
		addsave("netto",$br);
	}
//	echo "bayar $bayar brutto $brutto paidtoday $paidtoday";
	//perbaikan hpp
	$sq="select * from tbpbelid where notrans='$notrans'";
	$olddt=$db->query($sq)->fetch();
	$arr=array();
	foreach($olddt as $r) {
		$idbj=$r['id'];
		$kdbrg=$r['kdbrg'];
		$hpp=unmaskRp($r['hpp']);
		$jlh=unmaskRp($r['jlh_terima']);
		$hrg=unmaskRp($r['hrg']);
		$arr[]=[
		'idbj'=>$idbj,
		'kdbrg'=>$kdbrg,
		'jlhlama'=>$jlh,
		'hpplama'=>$hpp,
		'hrglama'=>$hrg,
		'jlhbaru'=>0,
		'hppbaru'=>0,
		'hrgbaru'=>0,
		'stakhir'=>getStockAkhir($kdbrg,$kdlokasi),
		'mark'=>0,
		];
	}
	//ganti hpp
	$aidbj=$_REQUEST['d_id'];
	$akdbrg=$_REQUEST['d_kdbrg'];
	$ajlh=$_REQUEST['d_jlh_terima'];
	$ahrg=$_REQUEST['d_hrg'];
	$i=0;    
	foreach($aidbj as $idbj) {
		//cari di array data lama
		$kdbrg=$akdbrg[$i];
		$jlhbaru=unmaskRp($ajlh[$i]);		
		$hrgbaru=unmaskRp($ahrg[$i]);
		$stakhir=getStockAkhir($kdbrg,$kdlokasi,$notrans);
		if ($idbj*1>0) {
			$k=array_search($idbj,array_column($arr,'idbj'));
			
			if ($isTest) {
				//echo "<br>kd $kdbrg $jlhbaru k $k";
			} //sort($arr);


		//if ( is_int($k)) {
			//echo "ketemu....";	
			$newln=$arr[$k];
			$newln['kdbrg']=$kdbrg;
			$newln['jlhbaru']=$jlhbaru;
			$newln['hrgbaru']=$hrgbaru;
			$newln['stakhir']=$stakhir;
			$newln['mark']=1;
			$arr[$k]=$newln;
		} else {
			if ($jlhbaru==0) {
	
			} else {			
				if ($opcek!=1) {
					$sqi="insert into tbpbelid(notrans,kdbrg,jlh_terima,hrg,cek) 
					values('$notrans','$kdbrg','$jlhbaru','$hrgbaru',1)";
					if ($isTest) echo "<br>ini in > $sqi <br>";
					$idbj=mysql_query2($sqi);
				} else 
					$idbj=0;
				//$idbj=mysql_insert_id();
				$aidbj[$i]=$idbj;
				//echo "id baru : $idbj >";
				$newln=[
					'idbj'=>$idbj,
					'kdbrg'=>$kdbrg,
					'jlhlama'=>0,
					'hpplama'=>0,
					'hrglama'=>0,
					'jlhbaru'=>$jlhbaru,
					'hppbaru'=>0,
					'hrgbaru'=>$hrgbaru,
					'stakhir'=>$stakhir,
					'mark'=>1,	
				];
				$arr[]=$newln;
			}
			//sort($arr);
		}
		$i++;
	}
	
	$arrdd=$arr;
	//if ($isTest) showTa($arrdd);
	$_REQUEST['d_id']=$aidbj;
	
	//cek stok
	$spes="";
	$i=0;
	$lokasi=getLokasi($kdlokasi);
	foreach($arrdd as $r) {
		$idbj=$r['idbj'];
		$kdbrg=$r['kdbrg'];
		$hpplama=$r['hpplama'];
		$jlhlama=$r['jlhlama'];
		$jlhdibutuhkan=$r['jlhbaru'];		
		$stakhir=$r['stakhir'];	
		$sisa=($stakhir+$jlhlama-$jlhdibutuhkan); 		
		if ($sisa<0) {
			$spes.="<br>Lokasi:$kdlokasi -$lokasi,  $kdbrg stok tidak mencukupi, Stok Akhir: $stakhir, dibutuhkan:$jlhdibutuhkan, idbj:$idbj ";
		} 
		$arrdd[$i]=$r;
		$i++;
	}
	if ( $spes!='')  {
		echo $spes;exit;
	}
}