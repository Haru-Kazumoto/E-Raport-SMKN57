<?php

if (op("tb,ed")){
	//updatehpp
	$ssq="";
	//echo showTA($arrdd);
	//evaluasi hpp  
	 $loghpp="";
	$spes="";
	$i=0;
	foreach($arrdd as $r) {
		$idbj=$r['idbj'];
		$kdbrg=$r['kdbrg'];
		$hpplama=$r['hpplama'];
		$jlhlama=$r['jlhlama'];
		$jlhdibutuhkan=$r['jlhbaru'];		
		$stakhir=$r['stakhir'];	
		$sta=$stakhir+$jlhlama;
		$dk=$r['dk'];
		$sisa=($sta-$jlhdibutuhkan); 		
		//jika jenis dk=k/out 
		if (($jtrans=='BB') || ($dk=='k')) {
			if ($dk=='k') {
				$jlhlama*=-1;
				$jlhdibutuhkan*=-1;
			}			
			$hpp=cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans,$idbj, $hpplama, $jlhlama,1,
			$updatehppjadihrg=true );
			$r['hppbaru']=$hpp;
			$r['hrg']=$hpp;
		}
		
		if ($r['mark']==0)	
			$ssq.="delete from  tbpbelid  where kdbrg='$kdbrg' and notrans='$notrans' and id='$idbj';";
		else	
			$ssq.="update tbpbelid set hpp='$hpp' where kdbrg='$kdbrg' and notrans='$notrans' and id='$idbj';";
		$i++;
	}
	
	
	foreach($arrdd as $r) {
		$kdbrg=$r["kdbrg"];
		$hpp=$r["hppbaru"];
		$mark=$r["mark"];
	}
	//echo "<br><br>update hpp----------> ".$ssq;
	if ($isTest) {
		echo $loghpp;
		echo "<br>update hpp :".$ssq;
	}	
	querysql ($ssq);
	$kdlokasi= carifield("select kdlokasi from tbpbeli where notrans='$notrans' ");

	$skdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans'");
	
	//delete from tbpbelid where  notrans='$notrans' and (jlh_terima=0 or cek=0);
	
	$sqdel="
	delete from tbpbelid_terpakai where  notrans='$notrans' and jlh<=0 ;
	";
	querysql($sqdel);
	
	//update ballance
	$bal=carifield("select sum(jlh_terima*hrg) from tbpbelid where notrans='$notrans'");
	querysql("update tbpbeli set  ballance='$bal' where notrans='$notrans'");
	
	if ($isTest) echo "<br>hapus: $sqdel <br>Kode barang : $skdbrg >>>>";
	updateStockTrans($skdbrg,$kdlokasi,$jtrans);	
    updateGLTransBeli($notrans,$jtrans);
	
}
