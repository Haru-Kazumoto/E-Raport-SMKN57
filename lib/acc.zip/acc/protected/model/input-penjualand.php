<?php
$useJS=2;
include_once 'conf.php';
//querysql("update tbpbeli set kdbranch='BK' where kdbranch='' or kdbranch='0';");
$det="penjualand";
$nmTabel='tbpbelid';
$nmTabelAlias='pjd';
$nmCaptionTabel="Data Penjualan Detail";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=false;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=true;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:700,title: \'Input Data\'";
$isTest=false; 

$sqTabel="select * from
 (select xpjd.* ,h.kdbranch,br.branch,b.nmbarang,b.kdpemasok,h.tgl,pg.nama as namapeg,pb.nama as namapb 
 from ((((tbpbelid xpjd left join tbpbeli h on xpjd.notrans=h.notrans)
 left join tbpbarang b on xpjd.kdbrg=b.kdbrg)
 left join tbppembantu pb on h.kdpembantu=pb.id)
left join tbppegawai pg on h.kdpj=pg.id)
left join tbpbranch br on h.kdbranch=br.kdbranch
 ) 
 as  pjd ";

include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Penjualan Detail';

$i++; $sAllField.="#1|notrans|NOTRANS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#7|tgl|TGL|40|1|1|1|30|C|D-0|1|1";
$i++; $sAllField.="#2|kdbrg|NAMA BARANG|40|1|1|nmbarang|30|C|S-0|1|1";

$i++; $sAllField.="#11|jlh_terima|JUMLAH|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|hrg|HARGA|7|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#5|disc|DISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#7|subtot|SUBTOTAL|7|1|1|1|9|C|C-0|1|1";

$i++; $sAllField.="#14|kdpembantu|PELANGGAN|7|1|1|namapb|30|C|S-0|1|1";
$i++; $sAllField.="#25|kdpj|NAMA SALES|7|1|1|namapeg|14|C|S-0|1|1";
$i++; $sAllField.="#25|branch|CABANG|7|1|1|1|14|C|S-0|1|1";
//$gFieldView[$i]="=-{kdbranch}-.-{branch}-;";
/*
$i++; $sAllField.="#2|kdbrg|KDBRG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|hpp|HPP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#6|discp|DISCP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#8|cek|CEK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#9|kdlokasi|KDLOKASI|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#10|jlh_pesan|JLH_PESAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|jlh_retur|JLH_RETUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|kdbayar|KDBAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#14|cbonus|CBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#15|paid|PAID|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|idbelid|IDBELID|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#17|gulung|GULUNG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|catatan1|CATATAN1|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#19|nmbrg2|NMBRG2|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|adacatatan|ADACATATAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#21|jlh_cetak|JLH_CETAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#22|dk|DK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#23|jlh_terpenuhi|JLH_TERPENUHI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#24|jlh_brutto|JLH_BRUTTO|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#25|jlh_tarra|JLH_TARRA|40|1|1|1|30|C|S-0|1|1";
*/

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="notrans;tbpbeliD.notrans"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','penjualanD|penjualanD',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Penjualan Detail';//caption tombol import
$sFieldCSV=strtolower('id,notrans,kdbrg,hrg,hpp,disc,discp,subtot,cek,kdlokasi,jlh_pesan,jlh_terima,jlh_retur,kdbayar,cbonus,paid,idbelid,gulung,catatan1,nmbrg2,adacatatan,jlh_cetak,dk,jlh_terpenuhi,jlh_brutto,jlh_tarra');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,KDBRG,HRG,HPP,DISC,DISCP,SUBTOT,CEK,KDLOKASI,JLH_PESAN,JLH_TERIMA,JLH_RETUR,KDBAYAR,CBONUS,PAID,IDBELID,GULUNG,CATATAN1,NMBRG2,ADACATATAN,JLH_CETAK,DK,JLH_TERPENUHI,JLH_BRUTTO,JLH_TARRA');
$nfCSV='import_Data_Penjualan_Detail.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
