<?php
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();

$i=0;
for ($i=0;$i<=$jrange-1;$i++) {
	$armin[]=$armax[$i+1]+1;
	$arjudul[$i]="$armin[$i] - $armax[$i]";
}

cekVar("ida,media,kdbrg,jenis,jur,mapel");

$subjd="";
$addjdl="";
$addInp="";
$syjenis=" where 1=1 ";

include_once $lib_app_path."protected/controller/controller.php";

cekVar("p,jtrans");

if ($p=='') {
	
	?>
	<script>
	 function gantiCombo(rnd) {
		kdbrg=$("#kdbrg_"+rnd).val();
		$("#tjur"+rnd).hide();
		bukaAjax("tjur"+rnd,"filtercombo.php?op=jur1&kdbrg="+kdbrg+"&newrnd="+rnd,rnd," $('#tjur"+rnd+"').show();");
	 }
	 function gantiCbb(rnd) {
		kdbranch=$("#kdbranch_"+rnd).val();
		$("#tpbt_"+rnd).hide();
		bukaAjax("tpbt_"+rnd,"filtercombo.php?op=plg&kdbranch="+kdbranch+"&newrnd="+rnd,rnd," $('#tpbt_"+rnd+"').show();$('#kdpembantu_"+rnd+"').combobox();");
	 	$("#tsales_"+rnd).hide();
		bukaAjax("tsales_"+rnd,"filtercombo.php?op=sales&kdbranch="+kdbranch+"&newrnd="+rnd,rnd," $('#tsales_"+rnd+"').show();");
		
		//$("kdpj_"+rnd).comboBox();
		
	 }
	 
	 </script>
	 <?php
	 
}

if (($p=="")) {
	//+'&kdpj='+$('#kdpj_$rnd').val()
	
	$url="
	'index.php?det=$det&ida=$ida&jt=T&jtrans=$jtrans&p=1&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()
	+'&bentuk='+$('#bentuk_$rnd').val()
	+'&kdpembantu='+$('#kdpembantu_$rnd').val()
	+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()+'&kdbrg='+$('#kdbrg_$rnd').val()
	";
	$tbpdf="";
	//$addInp.="<div style='margin-bottom:7px'>";
	
	if ($useBranch) {
		if (strtolower($userType)=='admin') {
			$addInp.=" Cabang  : ".  um412_isicombo6("select kdbranch,branch from tbpbranch order by branch","kdbranch","gantiCbb($rnd)");
		} else {
			$addInp.= " <input type=hidden name=kdbranch id=kdbranch_$rnd value='$defKdBranch'>";
		}
	}
	//$addInp.=" Jenis Tampilan :".um412_isiCombo6("Pertransaksi;pertrans,Detail Perbarang;perbrg,Rekap Perbarang;rekapbrg","bentuk");
	$addInp.=" 
	<input type=hidden id=bentuk_$rnd value='pertrans'>
	<input type=hidden id=kdbrg_$rnd value=''>
	";
	
	$addInp.=" Nama Pelanggan  : <span id=tpbt_$rnd>".isiComboPembantu("kdpembantu","PL")."</span>";
	//$addInp.=" Nama Marketing  : <span id=tsales_$rnd>".um412_isicombo6("select id,nama from tbppegawai order by nama","kdpj","")."</span>";
	
	//$addInp.="Nama Barang  : ".um412_isicombo6("select kdbrg,nmbarang from tbpbarang b where 1=1 $addSqComboBrg","kdbrg","");
	$addInp.="
		Periode :".um412_isiCombo6("Hari Ini,Minggu Ini,Bulan Ini,Tahun Ini,Custom","periode","gantiPeriode($rnd)")."
		<span id='ttglp_$rnd' style='display:none'>
		Tanggal : <input type=text size=10 class=D name=tgl1 id=tgl1_$rnd > SD
		<input type=text size=10 class=D name=tgl2 id=tgl2_$rnd> 
		</span>
	";
	//$addInp.="</div>";
	
	 
	$addInp.="<input type=hidden name=jt id=jt_$rnd value='T'>";//jenis tampilan:Tabel/Grafik
	
	$addf="
	$(document).ready(function(){
		//$('#kdbrg_$rnd').combobox();
		$('#kdpembantu_$rnd').combobox();
		$('.custom-combobox-input').css('max-width','200px');
		$('.custom-combobox-input').css('width','auto');
		maskAllMoney();
	});
	
	";
	
	$tbxls="<a class='btn btn-warning btn-sm' onclick=\"bukaAjax('tout_$rnd',$url+'&media=xls',0,'awalEdit($rnd)');\">XLS</a>
		";
	$tbxls="";
	echo "
	<div class=breadcrumb2>
		$addInp
		<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout_$rnd',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbxls
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout_$rnd');\">Cetak</a>
		<script>$addf</script>
	</div>
	<div id='tout_$rnd' class=tout ></div>
	";	
	exit;

} 
$t="";
if (($ida==0)||($ida==1)) {
	 		
	$sy="";
	//$sq="select kdbrg,nmbarang,sum(jlh_terima) from tbpbelid d left join tbpbeli h on d.notrans=h.notrans where $sy ";
	cekVar("bentuk");
	if (($bentuk=='pertrans')||($bentuk=="")){
		$orientation="l";
		$nf=$lib_app_path."protected/view/manalisa/analisis-suratjalan-pertrans.php";
		
	} elseif ($bentuk=='perbrg'){
		$orientation="l";
		$nf= $lib_app_path."protected/view/manalisa/analisis-suratjalan-perbarang.php";

	} elseif ($bentuk=='rekapbrg'){
		$orientation="p";
		$nf= $lib_app_path."protected/view/manalisa/analisis-suratjalan-rekap-perbarang.php";
	}
	 
	if ($orientation=='p') {
		$clspage="page";	
		$maxbr=34;
	} else{ 
		$clspage="page-landscape";
		$maxbr=14;
	}
	include $nf;
	$t.= "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
 
	//$t.=$scriptdata;
	cekVar('jt',1,1);
	$result="";
	if ($media!='xls') {
		$result.="
		<style>
		.page,
		.page-landscape,
		{
			
			padding:2.5cm ;
			
			
			}
		.page,
		.page td,
		.page-landscape,
		.page-landscape td {
			font-size:11px
		}
		</style>
		
		";
	}
	if ($jt=='T') {
		if ($media!='xls'){
			
			$result.="	<div class='$clspage'>$t</div>";
		}
	}
	if ($jt=='G') {	
		if ($media==''){		
			$result.= "
			<div class='page-landscape' style='padding:20px'>
				<div id='chartdiv' style='width: 100%; height: 600px;'></div>
				<div style='margin-left:30px;display:none'>
					<input type='radio' checked='true' name='group' id='rb1' onclick='setDepth()'>2D
					<input type='radio' name='group' id='rb2' onclick='setDepth()'>3D
				</div>
			</div>";
		}
		/*
		$result.= "
		<div id='tfbe$rnd'  style='display:none'>
		$scriptdata		
		function setDepth() {
			if (document.getElementById('rb1').checked) {
				chart.depth3D = 0;
				chart.angle = 0;
			} else {
				chart.depth3D = 25;
				chart.angle = 30;
			}
			chart.validateNow();
		}
		</div>
		";
		*/  
	} 
	
	if ($media=='pdf') {
		$html=$result;
		$html=str_replace('"','`',$html);
		$html=str_replace("'",'"',$html);
		
		include $um_path."print2pdf.php";
	} else 
		echo $result;
	
	}
?>