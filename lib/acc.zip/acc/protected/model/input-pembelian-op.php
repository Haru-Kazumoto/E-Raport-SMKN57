<?php

if (op("listnopo")) {
	cekvar("kdpembantu,jt ");
	$addsy="";
	//and kdlokasi='$kdlokasi' 
	if ($defKdBranch!='') $addsy.=" and kdbranch='$defKdBranch'";

//changeParamSySql2($sArray,$fld="id",$param=",",$oprx="=","or")
	
	$sjtrans=($jt=="PR"?"PB":"SL,JE");
	 $sq="select notrans,concat(tgl,' ',notrans) from tbpbeli 
	where ".changeParamSySql2($sjtrans,"jtrans",$param=",",$oprx="=","or")." and kdpembantu='$kdpembantu' $addsy
	order by tgl,notrans
	";
	echo um412_isicombo6($sq,'nopo',"copyPOItem($rnd,'$jt')");	
	exit;
}
elseif (op("getsaldohp")) {
	cekvar("kdpembantu"); 
	echo getSaldoHP($kdpembantu);
	exit;
}
elseif (op("listitem")) {
	//list item untuk penerimaan po dan retur
	cekvar("notrans,jtrans");
	//$sql="select kdbrg,hrg,jlh_terima from tbpbelid limit 0,4";
	if (($jtrans=="SR") ||($jtrans=="PR")) 
		$sql="select d.kdbrg,b.nmbarang,hrg,jlh_terima from tbpbelid d left join tbpbarang b on d.kdbrg=b.kdbrg where notrans='$notrans'";
	else
		$sql="select kdbrg,hrg,jlh_terima from tbpbelid where notrans='$notrans'";
	
	
	$kdlokasi=carifield("select kdlokasi from tbpbeli where notrans='$notrans'");
	$dt=sqlToArray2($sql,2);
	$h=array();
	$h['kdlokasi']=$kdlokasi;
	$h['data']=$dt;
	echo json_encode($h);
	exit;
} elseif (op("showdethppj")) {
	//list item untuk penerimaan po dan retur
	cekvar("notrans,jtrans");
	//$sql="select kdbrg,hrg,jlh_terima from tbpbelid limit 0,4";
	$sql="select d.kdbrg as Kode_Brg,b.nmbarang as Nama_Brg,
	jlh as Jumlah,d2.hrg as Hrg_Jual,d.hpp as HPP,
	d2.hrg*jlh as subtot,
	d2.hpp*jlh as subtothpp,
	(d2.hrg-d.hpp)*jlh as laba,
	
	idbb as ID_BELIB,idbj AS ID_JUALD,jenisidb as Jenis 
	from  
	(tbpbelid_terpakai d left join tbpbarang b on  d.kdbrg=b.kdbrg)
	left join tbpbelid d2 on d.idbj=d2.id
	
	where d.notrans='$notrans'";
	
	
	$t='';
	$tb=new htmlTable();
	$tb->sql=$sql;
	$tb->showNo=true;
	$tb->sAlign="c,l,r,r,r,r";
	$tb->sFormat=",,CX,CX,CX,cx,";		
	$tb->sColJlh="4,5,6";		
	if (strstr("SL,JE",$jtrans)!='') {
		$tb->sJudul="KODE,DESKRIPSI,JUMLAH,HARGA JUAL,HPP,LABA";
	} else {
		$tb->sJudul="KODE,DESKRIPSI,JUMLAH,HPP,Subtotal";
		$tb->sFld="Kode_Brg,Nama_Brg,Jumlah,HPP,subtothpp";
		$tb->sColJlh="4,5";		
		
		
	}
	
	/*
	$tb->configFld[3]="F,2000,D,1,upload/tugas/"; //konfig file kolom 3 karena ada no	
	$tb->colContent[4])="carifield();";
	*/	
	$tb->showNo=true;
	$tb->usePagination=true;
	$tb->clsPage="page";
	$tb->brPerPage=16;
	$tb->brPerPage2=26;
	$tb->addJudul="<b>Detail HPP<br>Transaksi No.: $notrans </b><br><br>";//tambahan judul
	$tb->addJudul2="";//tambahan judul halaman 2 dst
	$t.=$tb->show();

	echo tpBoxInput($t,'nobread');
	exit;


}
