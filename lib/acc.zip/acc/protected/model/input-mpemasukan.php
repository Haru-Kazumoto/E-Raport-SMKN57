<?php
$useJS=2;
include_once 'conf.php';

$det="mpemasukan";
$nmTabel= $oNamaTb->akun ;
$nmTabelAlias='k';
$nmFieldID='account_code';

$arrAcc=$arrAccPemasukan;
$nmCaptionTabel=$arrAcc[0];
$kdAT=$arrAcc[1];
$rangeKd="$arrAcc[2]-$arrAcc[3]";
//addFilterTb("account_type=$kdAT");
addFilterTb("account_code>=$arrAcc[2] and account_code <$arrAcc[3] and ish=0 ");

if (op("tb")) {
//	addsave("account_type",$kdAT);
}


$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;
$stb2=false;($isOnline?false:true);
$showTbUnduh=$stb2;
$showTbUnggah=$stb2;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:700,title: \'$nmCaptionTabel\'";  
$sqTabel="select * from (
select xprk.*,tp.name as tipe,pi.account_name as accninduk,
if(xprk.ish=1,'H','D') as hd 
from (".$oNamaTb->akun." xprk
left join ".$oNamaTb->tipeAkun." tp on xprk.account_type=tp.id)
left join ".$oNamaTb->akun." pi on xprk.accinduk=pi.account_code
) as k ";

include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|account_code|KODE AKUN|11|1|1|1|10|C|N-$rangeKd,U|1|1";
$i++; $sAllField.="#1|account_name|NAMA AKUN|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#1|accinduk|INDUK PERKIRAAN|40|1|1|accninduk|30|C|N-1|1|1";
$gFieldInput[$i]="=isiComboAcc('accinduk',0,'40001');";
if (op("itb")) $addf.="$('#accinduk_$rnd').combobox();GTInputPrk($rnd);";



//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Akun';//caption tombol import
$sFieldCSV=strtolower('account_code,account_name,account_type,inactive,acc,sawal,modified_date');
$sFieldCaptionCSV= strtolower('ACCOUNT_CODE,ACCOUNT_NAME,ACCOUNT_TYPE,INACTIVE,ACC,SAWAL,MODIFIED_DATE');
$nfCSV='import_Data_Akun.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";

/*
$i++; $sAllField.="#2|account_type|KELOMPOK AKUN|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=isiListCBTipeAkun('account_type')";
$i++; $sAllField.="#4|ish|H/D|7|1|1|hd|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('Header;1,Detail;0','ish','GTInputPrk($rnd)');";

$gFieldView[$i]="=maskRp(getSaldoAkhir(-{account_code}-));";
//$i++; $sAllField.="#5|sawal|SALDO AWAL|40|1|1|1|30|C|C-0|1|1";

//$gFieldView[$i]="=rupiah2(-{sawal}-);";
//$i++; $sAllField.="#5|sakhir|SALDO AKHIR|40|0|0|1|30|C|C-0|1|1";
//$gFieldView[$i]="=rupiah2(getSaldoAkhir(-{account_code}-));";


$i++; $sAllField.="#6|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#4|acc|ACC|7|1|1|1|7|C|S-0|1|1";
if (op("itb")) $addf.="$('#accinduk_$rnd').combobox();GTInputPrk($rnd);";
*/

//if (op("itb")) addfbe("$evt");

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="account_name;".$oNamaTb->akun.".account_name"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','prk|prk',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

