<?php

cekVar("jlap,media,op");

$subjd="";
$addjdl="";
$addInp="";
$sytingkat=" where 1=1 ";
//jlap:neraca,neracasaldo,perubahanmodal,labarugi
if ($jlap=="") $jlap="neraca";

$stytgl1="display:none";
if ($jlap=="neraca") {
	$judulLap="NERACA";
	$nfLap=$lib_app_path."protected/view/lap/lap-neraca.php"; 
} elseif ($jlap=="neracasaldo") {
	$nfLap=$lib_app_path."protected/view/lap/lap-neraca.php"; 
	$judulLap="NERACA SALDO";
} elseif ($jlap=="perubahanmodal") {
	$judulLap="LAPORAN PERUBAHAN MODAL";
	$nfLap=$lib_app_path."protected/view/lap/lap-$jlap.php"; 	
	$stytgl1="";
} elseif ($jlap=="labarugi") {
	$stytgl1="";
	$judulLap="LABA RUGI";
	$nfLap=$lib_app_path."protected/view/lap/lap-$jlap.php"; 
}
  
if ($op=='') {
	$deftgl1=awalBulan(); 
	$deftgl2=akhirBulan(); 	
	if (isset($_SESSION['tgllap1'])) $deftgl1=$_SESSION['tgllap1'];
	if (isset($_SESSION['tgllap2'])) $deftgl2=$_SESSION['tgllap2'];


	$url="
	'index.php?det=$det&op=lapkeu&jlap=$jlap&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()+'&bentuk='+$('#bentuk_$rnd').val()+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()
	";
	$urlxls="$url+'&media=xls&contentOnly=1&showMenu=0'";
	$tbpdf="";
	$tbxls="";
	$addSy="";
 
	$addInp="";
	if ($useBranch) 
		$addInp.="Cabang : ".um412_isicombo5('select kdbranch,branch from tbpbranch order by branch asc','kdbranch');
	else
		$addInp.="<input type=hidden id=kdbranch_$rnd value=''>";
	
	if (strstr($jlap,"neraca")!="") {
		$addInp.="Bentuk ".um412_isicombo5('Detail,Ringkas','bentuk');
	} else $addInp.="<input type=hidden name=bentuk id=bentuk_$rnd>";
	
	echo "
	<div class=breadcrumb2>	
	$addInp
		Tanggal : 
		<span style='$stytgl1'>
		<span id=ttgl1_$rnd><input name=tgl1 id=tgl1_$rnd value='$deftgl1' class=tgl size=11 ></span> 
		sd  </span>
		<span id=ttgl2_$rnd><input name=tgl2 id=tgl2_$rnd value='$deftgl2' class=tgl  size=11 ></span> 
		<a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout',$url,0,'awalEdit($rnd)');\">Tampil</a>
		
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout');\">Cetak</a>
		<a class='btn btn-warning btn-sm' onclick=\"bukaJendela($urlxls);\">XLS</a>
	</div>
	<div id='tout' class='tout'></div>
	 
	";	
	
		?>
	<script>
	 
	$(document).ready(function() {
		$("#jenisju_<?=$rnd?>").combobox();
		 $(".tgl").datepicker();
	});
	 </script>
	<?php
	exit ;
}  



if ($stytgl1!="") $tgl1=$tgl2;
$t="";
$t.=awalLaporan();
$t.=buattbhead($judulLap,$tgl1,$tgl2);

//$t.="<br><br>".um412_falr("Laporan $judulLap dalam proses pembuatan"); 
include $nfLap;

if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
echo "
<div class='page'>
$t
</div>
";

?>