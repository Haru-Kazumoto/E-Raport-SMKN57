
<?php
$useJS=2;
include_once 'conf.php';

$det="provinsi";
$nmTabel='tbprovinsi';
$nmTabelAlias='pr';
$nmCaptionTabel="provinsi";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$showFrmCari=true;
$showTbHapus=true;
$showTbView=true;
$showTbUbah=true;
$showTbPrint=true;
$showTbTambah=true; 
$showExportDB=false; 
$showTbUnduh=false;
$showTbUnggah=false;
$configFrmInput="width:700,title: \'Input Data\'";


$isTest=false; 

$sqTabel=" 
select pr.*,
concat('PV',right(concat('000000',pr.id),6)) as vuserid

 from tbprovinsi pr
 ";
//$sqTabel="select * from (xpr.* from tbprovinsi xpr) as  pr ";


include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Provinsi';
			
$i++; $sAllField.="#1|provinsi|PROVINSI|40|1|1|1|30|C|S-0|1|1";

$isiComboFilterTabel="provinsi;tbprovinsi.provinsi"; 

$i++; $sAllField.="#1|cp|KONTAK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|hp|HP|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|vuserid|USER ID|40|0|0|1|30|C|S-0|1|1";
$i++; $sAllField.="#1|vpass|PASSWORD|40|1|1|0|30|C|P-0|1|1";

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','provinsi|provinsi',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Provinsi';//caption tombol import
$sFieldCSV=strtolower('id,provinsi');
$sFieldCaptionCSV= strtolower('ID,PROVINSI');
$nfCSV='import_Provinsi.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
