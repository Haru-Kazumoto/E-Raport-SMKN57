<?php
$useJS=2;
include_once 'conf.php';

$det="stockbarang";
$nmTabel='tbpstock';
$nmTabelAlias='sb';
$nmCaptionTabel="Data Stock Barang/Produk";
$nmFieldID='id';
//$isTest=$debugMode;
//include_once 'input-stockbarang-opr.php';
cekvar("op");
if (op('hu')) {
	cekvar("id");
	//cari kdbrg dan lokasi
	$sq="select b.kdbrg,s.kdlokasi from tbpbarang b inner join tbpstock s on b.kdbrg=s.kdbrg where s.id='$id'";
	extractRecord($sq);
	updateStockTrans($kdbrg,$kdlokasi);
	echo "Update berhasil, silahkan klik tombol refresh....";
	exit;
}elseif (op('ubahsta')) {
	//ubah stok akhir
	cekvar("aid,id");
	if ($aid=="") $aid=$id;
	if ($aid=="") exit;
	$sq="select kdbrg,kdlokasi,stawal,$sqStAkhir from tbpstock where id='$aid'";
	extractRecord($sq);
		$frm=new htmlForm;
		$frm->nmForm="frm1";
		$frm->nmValidasi="$det";
		$frm->rnd=$rnd;	
		$frm->nfAction="index.php?contentOnly=1&useJS=2";
		$frm->useAjaxSubmit=true;//default
		$frm->hideFormAfterSubmit=false;
		$frm->tresult="tanggaran";
		$frm->tHideTesult=false;;
		$frm->awalForm();
		$frm->addHiddenField([
		["newrnd","rnd"],
		["op","ubahstap"],
		["det",$det],
		["aid",$aid],
		["stawal","$stawal"],
		["stakhirold","$stakhir"]
		]);
		$frm->rowForm("stakhir","Stock Akhir ","text|10|0|");
		$frm->addTxtBody("
		<input type=submit class='btn btn-sm btn-primary' value='OK'>
		<br>
		<br>
		".um412_falr("
		Note:<br> 
		<br>
		Mengubah stock akhir akan merubah stok awal secara otomatis. 
		Sebaiknya mengubah stok akhir ini hanya dilakukan satu kali.<br>
		Jika di lain waktu terjadi perbedaan stok akhir antara syttem dengan fisik, 
		sebaiknya dilakukan transaksi stock opname/penyesuaian stock.
		<br>
		<br>
		Setelah memasukkan perubahan data, lakukan refresh untuk melihat hasil di daftar stok. 
		","warning"),$isi=" ");
		
		$frm->fae="tutupDialog2('$idtd');";
		
		$frm->akhirForm();
		$form1= $frm->show();
		$t='';
		$t.=tpboxInput($form1,"Ubah Stock Akhir, Kode Barang: $kdbrg");
		
		$t.="<section class='content' id='tanggaran'></section>";
		echo $t;
}
elseif (op('ubahstap')) {
	$stakhirold=getStAkhirByID($aid);		
	$beda=$stakhirold-$stakhir;
	//echo "aid $aid stakhirold $stakhirold stakhir $stakhir beda $beda, newstawal=$newstawal ";
	
	$h=mysql_query2("update tbpstock set stawal=stawal-$beda where id='$aid'");
	if (!$h) 
		echo "Update tidak berhasil";
	else
		echo 1;
}
elseif (op('stockopname')) {
	cekvar("id,kdlokasi");
	$kdlokasi*=1;
	if ($kdlokasi==0) {
		echo um412_falr("Pilih lokasi stock terlebih dahulu ","warning");
		exit;
	}
	echo "stock opname $kdlokasi";
	
	$sqT="
	select * from (
	select xsb.kdlokasi,xsb.kdbrg,b.nmbarang,$sqStAkhir,
	l.lokasi
	 from ((tbpstock xsb left join tbpbarang b on xsb.kdbrg=b.kdbrg)
	 left join tbplokasi l on xsb.kdlokasi=l.id)
	 left join tbpbranch br on l.kdbranch=br.kdbranch
	) as  sb where kdlokasi='$kdlokasi' order by nmbarang ";
	echo $sqT;
	
	exit;
}
cekvar("kdlokasi,xkdlokasi,xnmbarang");
//if (!usertype("sa")) {
	if ($xkdlokasi.$kdlokasi=='') {
		cekvar("op3");
		if ($op3=="json") return "";
	}
//}


$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=false;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=true;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=usertype("sa");; 
$showTbFilter=false;

$showTbUnduh=usertype("admin,sa,direksi");
$showTbUnggah=true;//false;
$defOrderDT="[2, 'asc']";
$configFrmInput="width:700,title: \'Input Data\'";
 
$sqTabel="
select * from (
select xsb.*,b.nmbarang,br.branch,b.kdpemasok,
round((stawal+stbeli-strbeli-stjual+strjual+stadjust+stprodm-stprodk+stex+stdistm-stdistk),2) as stakhir,
l.lokasi
 from ((tbpstock xsb left join tbpbarang b on xsb.kdbrg=b.kdbrg)
 left join tbplokasi l on xsb.kdlokasi=l.id)
 left join tbpbranch br on l.kdbranch=br.kdbranch
) as  sb ";

cekvar("xkdlokasi");
if ($xkdlokasi!='') {
	cekExistStockBrg("all",$xkdlokasi);
}


include $um_path."input-std0.php";

if ($opcek==1) {
	if (($hrgawal==0) && ($stawal>0)) {
		$addCek.="<br>Harga Awal harus diisi";
	}
}

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Stock Barang/Produk';
			 
$i++; $sAllField.="#1|kdlokasi|LOKASI|7|1|0|lokasi|7|C|S-0|1|2";
$i++; $sAllField.="#2|kdbrg|KDBRG|40|1|0|1|30|C|S-0|1|2";
$i++; $sAllField.="#2|nmbarang|NAMA BRG|40|1|0|1|30|C|S-0|1|2";
//$i++; $sAllField.="#25|branch|CABANG|7|1|1|1|14|C|S-0|1|1";
$i++; $sAllField.="#3|hrgawal|Hrg. Awal|10|1|1|1|30|C|CX-0|1|1";
//$i++; $sAllField.="#18|defhrgbeli|DEF. HRGBELI|10|3|0|1|30|C|CX-0|1|1";
$i++; $sAllField.="#18|defhrgbeli|DEF. HRGBELI|10|1|1|1|30|C|CX-0|1|1";
$i++; $sAllField.="#18|defhrgjual|DEF. HRGJUAL|10|1|1|1|30|C|CX-0|1|1";
$i++; $sAllField.="#3|stawal|STOK AWAL|10|1|1|1|30|C|CX-0|1|1";
$i++; $sAllField.="#4|stbeli|BELI|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#5|strbeli|R.BELI|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#6|stjual|JUAL|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#7|strjual|R.JUAL|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#11|stprodm|PRODUKSI|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#11|stadjust|ADJ|10|1|0|1|30|C|CX-0|1|2";
$i++; $sAllField.="#18|stakhir|STOK AKHIR|10|1|0|1|30|C|CX-0|1|1";

$i++; $sAllField.="#18|aksi|AKSI|40|0|0|1|30|C|S-0|1|2";
$gFieldView[$i]="=tbAksiStock({id});";
//$gFieldView[$i]="='Menu';";
/*
$i++; $sAllField.="#8|stadjust|STADJUST|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|stpbeli|STPBELI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|reorder|REORDER|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#12|stprodk|STPRODK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|stdistm|STDISTM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#14|stdistk|STDISTK|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|stex|STEX|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#16|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#17|reorderq|REORDERQ|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|stpjual|STPJUAL|40|1|1|1|30|C|S-0|1|1";
*/
//$i++; $sAllField.="#19|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";

//$isiComboFilterTabel="kdlokasi;tbpstock.kdlokasi"; 
$aFilterTb=array(
		array('kdlokasi','kdlokasi','Lokasi :  '.isicbLokasi('xkdlokasi','#url#')),
		array('nmbarang','kdbrg-nmbarang|like','Kode/Nama Brg. : #inp#'),
//		array('jtampil','jtampil|none','Tampilan : '.um412_isicombo6("Global,Detail",'xjtampil',"#url#")),
);

$addTbOpr=" 
<span  class='btn btn-info btn-mini btn-sm' 
onclick=\"tbOpr('stockopname&ps=1&kdlokasi='+$('#xkdlokasi_$rnd').val(),'stockbarang|stockbarang',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' />Stock Opname</span> ";

/*
$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Stock Barang/Produk';//caption tombol import
//$sFieldCSV=strtolower('id,kdlokasi,kdbrg,stawal,stbeli,strbeli,stjual,strjual,stadjust,stpbeli,reorder,stprodm,stprodk,stdistm,stdistk,stex,catatan,reorderq,stpjual,modified_date');
//$sFieldCaptionCSV= strtolower('ID,KoDeLOKASI,KDBRG,STAWAL,STBELI,STRBELI,STJUAL,STRJUAL,STADJUST,STPBELI,REORDER,STPRODM,STPRODK,STDISTM,STDISTK,STEX,CATATAN,REORDERQ,STPJUAL,MODIFIED_DATE');
//$nfCSV='import_Data_Stock_Barang/Produk.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";

if (op("tb,ed")) {
	updateDefHrg($kdbrg,$kdlokasi,"PB");	
}
?>
