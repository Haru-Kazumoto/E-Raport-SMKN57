<?php
//$useJS=2;
//include_once 'conf.php'; 
cekVar("op,op2,kkunci");
if ($op2=="savetmp") {
	cekVar("jtrans,idtd");
	setvar("op","itb");
	unsetvar("id,aid,tkn");
	if (!isset($_REQUEST['d_jlh_terima'])) {
		echo um412_falr("Isi dahulu data yang akan dijadikan template");
		exit;
	}
	$_REQUEST['id']=0;
	$_REQUEST['tkn']='';
	if ($jtrans=='PG') {
		//PACKAGING
		$sfld="kdbrg,nmbarang,jlh_brutto,dk,jlh_terima,sat,hrg";
		$sfldType=",,CX,,N,,N";
		$afld=explode(",",$sfld);
		$afldType=explode(",",$sfldType);
	} elseif (($jtrans=='BB')||($jtrans=='BJ')) {
		$sfld="kdbrg,nmbarang,jlh_terima,sat,hrg";
		$sfldType=",,CX,,N,";
		$afld=explode(",",$sfld);
		$afldType=explode(",",$sfldType);
		
	}  
		foreach($afld as $fld) {
			eval("$"."a$fld=$"."_REQUEST['d_$fld'];");
		}
		$jlh=count($akdbrg);
		 
		$i=0;
		
		$adt[]=$sfld;
		foreach($akdbrg as $kdbrg) {
			$s="";
			$j=0;
			foreach($afld as $fld) {
				if ($j>0) $s.="~";
				if ($afldType[$j]=='C') {
					$ev='$v=unmaskRp($a'.$fld.'[$i]);';
					
				}elseif ($afldType[$j]=='CX') {
					$ev='$v=unmaskRp($a'.$fld.'[$i],0,9000);';
				}elseif ($afldType[$j]=='N') {
					$ev='$v=unmaskRp($a'.$fld.'[$i],0,0);';
					
				} else
					$ev='$v=$a'.$fld.'[$i];';
				echo "<br>$ev";
				eval($ev);
				$s.=$v;
		
				
				$j++;
			}
			eval("$"."adt[]=\"$s\";");
			$i++;
		}
		
		
		$sdt=json_encode($adt);
		//echo $sdt;
		
		$gDefField['isi']=$sdt;
		$gDefField['jtrans']=$jtrans;
		
		include $lib_app_path."protected/model/input-template.php";
		
	
	echo "Penyimpanan Template";
	//exit;
}
elseif ($op2=="usetmp") {
	cekVar("jtrans");
	setvar("op","cari");
	include $lib_app_path."protected/model/input-template.php";
	
	//echo "Pilih Template";
}
elseif ($op=="prkjtrans") {
	cekVar("jtrans");
	 $sq="select concat(kdprk1,',',kdprk2) from tbpjtrans where jtrans='$jtrans' limit 0,1";
	//get value prkjenisju
	echo $h=carifield($sq);
		
}
elseif ($op=="resetacc") {
	echo "reset data accounting.....";
	echo resetacc();
 
}
elseif ($op=="defkas") {
	cekVar("cb,jtrans");
	//c:cash,t:transfer
	if ($jtrans=="JE")
		echo ($cb=='C'?$defKdPrkKasKecil:($cb=='T'?$defKdPrkBank:getACC("debtors_act")));
	elseif ($jtrans=="PP") //piutang
		echo ($cb=='C'?$defKdPrkKasM:($cb=='T'?$defKdPrkBank:$defKdPrkBank));
	elseif ($jtrans=="PH") //piutang
		echo ($cb=='C'?$defKdPrkKasK:($cb=='T'?$defKdPrkBank:$defKdPrkBank));
	
} elseif ($op=="hrgjual") {
	cekVar("kdbrg");
	 $sq="select hrgjual,satuan,jlhisi,nmbarang from tbpbarang where kdbrg='$kdbrg' limit 0,1";
	//get value prkjenisju
	extractRecord($sq);
	echo "$hrgjual,$jlhisi,$nmbarang";
}

elseif ($op=="hrgbeli") {
	cekVar("kdbrg,notrans");
	$sq="select defhrgbeli,satuan,jbb,jlhisi  from tbpbarang where kdbrg='$kdbrg' limit 0,1";
	extractRecord($sq);
	//cari harga beli terakhir
	
	$c=carifield("select hrg from tbpbelid where kdbrg='$kdbrg' order by id desc limit 0,1")*1;
	if ($c>0) $defhrgbbeli=$c;
	
			
	echo "$defhrgbeli,$satuan,$jbb,$jlhisi";
}
elseif ($op=="hrgprod") {
	cekVar("kdbrg,notrans,kdlokasi,jlhdibutuhkan");
	if ($kdlokasi=="undefined") $kdlokasi=$defKdLokasi;
	
	$sq="select defhrgbeli,satuan,jbb,jlhisi  from tbpbarang where kdbrg='$kdbrg' limit 0,1";
	extractRecord($sq);
	/*
	$c=carifield("select hrg from tbpbelid where kdbrg='$kdbrg' order by id desc limit 0,1")*1;
	if ($c>0) $defhrgbbeli=$c;
	*/
	$jtrans="PU";
	$hpplama=0;
	$jlhlama=0;
	$hpp=cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans, $hpplama, $jlhlama,0 );
			
	echo "$hpp,$satuan,$jbb";
}

elseif ($op=="hrgrbeli") {
	cekVar("kdbrg,nopo");
	$sq="select defhrgbeli,satuan,jbb,jlhisi  from tbpbarang where kdbrg='$kdbrg' limit 0,1";
	extractRecord($sq);
	
	//cari harga beli di tabel pembelian
	$c=carifield("select hrg from tbpbelid where kdbrg='$kdbrg' and notrans='$nopo' order by id desc limit 0,1")*1;
	if ($c>0) $defhrgbbeli=$c;
	echo "$defhrgbeli,$satuan,$jbb,$jlhisi";
}
elseif ($op=="caribrg") {
	$capCari="Nama Barang";
	if ($kkunci!='') $capCari.=" ($kkunci)";
	if (!isset($langsungTampil)) 	$langsungTampil=false;
	$sqcari="select kdbrg,nmbarang,satuan,defhrgbeli from tbpbarang where 1 ";
	$fldhasil="kdbrg";
	$fldcari="nmbarang";
	$sFldTampil="kdbrg,nmbarang,satuan,defhrgbeli";
	$addFCari="cekKdBrgTransBeliC($rnd,$no)";
	 
	include_once $um_path."frmcari2.php";
}
elseif ($op=="aap") {
	//autoAllocatedPayment :otomatis mengalokasikan pembayaran hutang/piutang ke transaksi
	//echo "Auto Allocated Payment";
	cekvar("kdpembantu,jtrans");
	$addSy='';
	if ($kdpembantu!='') {
		$addSy.=" and kdpembantu='$kdpembantu' ";
	}
	$sjtrans=($jtrans=="PH"?"PB,AH":"SL,JE,AP");
	$addSy.="and ".changeParamSySql2($sjtrans,$fld="jtrans",$param=",",$oprx="=","or");
	//pb.nama as namapb,netto,paidtoday,paidafter,
	
	$sql="select notrans,netto-paidtoday-paidafter-retur as terhutang  
	from tbpbeli b left join tbppembantu pb on b.kdpembantu=pb.id
	where netto-paidtoday-paidafter-retur >0 $addSy  order by tgl asc,notrans asc";
	$dt=sqlToArray2($sql,2);
	$h=array();
	//$h['kdlokasi']=$kdlokasi;
	$h['data']=$dt;
	echo json_encode($h);exit;
}
elseif ($op=="caritransterhutang") {
	cekVar("jtrans,kdpembantu,notrans,thasil,no,tempat,rndh,txtcari3");
	$capCari="Daftar Transaksi";
	$addSy="";
	$addParamCari="&jtrans=$jtrans";
	$sjtrans=($jtrans=="PH"?"PB":"SL,JE");
	if ($kdpembantu!='') {
		$addSy.=" and kdpembantu='$kdpembantu' ";
		$addParamCari.="&kdpembantu=$kdpembantu";
	}
	if (!isset($langsungTampil)) 	$langsungTampil=true;
	$fldhasil="notrans";
	$fldcari="notrans";
	$sFldCapTampil="No. Transaksi,PB,Total Transaksi,Pembayaran Tunai,Pelunasan,Terhutang";
	$sFldTampil="notrans,namapb,netto,paidtoday,paidafter,terhutang";
	$sFldFormatTampil=",,C,C,C,C,C";
	$sFldFormatTampil=",,N,N,N,N,N";
	$sqcari="select notrans,pb.nama as namapb,netto,paidtoday,paidafter,
	netto-paidtoday-paidafter-retur as terhutang  
	from tbpbeli b left join tbppembantu pb on b.kdpembantu=pb.id
	where ".changeParamSySql2($sjtrans,$fld="jtrans",$param=",",$oprx="=","or")." and netto-paidtoday-paidafter-retur >0 $addSy ";
//$sqgroup="group by b.kdbrg";
	$sqorder="order by notrans desc";
	
	$fldhasil="notrans,terhutang";
	$fldcari="notrans";
	$langsungTampil=true;
	//$addFCari="alert(-{notrans}-);";
	$defFCari="cekNotransTerhutang($rndh,$no,'#fldhasil#')";
	include_once $um_path."frmcari2.php";
}
elseif ($op=="caribrgpaket") {
	cekvar("jharga,kkunci");
	
	$capCari="Nama Barang";
	if ($kkunci!='') $capCari.=" ($kkunci)";
	if (!isset($langsungTampil)) 	$langsungTampil=false;
	
	if ($jharga=="USER") {
			$sFldTampil="kdbrg,nmbarang,hrga,hrg,hrghe";//,hressa
			$sFldCapTampil="KODE,NAMA BARANG,H USER,HJ USER,HEMAT U";
			$sFldFormatTampil=",,C,C,C";			
			$sqcari="select kdbrg,nmbarang,1 as satuan,huserpa as hrg,huser as hrga,(huser-huserpa) as hrghe,hressa  from tbpaket where 1 ";
		}
	else {
		$sFldTampil="kdbrg,nmbarang,hrga,hrg,hrghe,hressa";
		$sFldCapTampil="KODE,NAMA BARANG,H RES,H RES J3.5,HEMAT R,H RES SA";
		$sFldFormatTampil=",,C,C,C,C";
		$sqcari="select kdbrg,nmbarang,1 as satuan,hrespa as hrg,hresmu as hrga,(huser-huserpa) as hrghe,hressa  from tbpaket where 1 ";
	}
	//$sqgroup="group by b.kdbrg";
	$fldhasil="kdbrg";
	$fldcari="nmbarang";
	$langsungTampil=true;
	$addFCari="cekKdBrgPaket($rnd,$no)";
	
	$sy="";
	if ($kkunci!='') $sy.="and ( concat($fldcari,jenis) like '%$kkunci%' or concat($fldcari,jenis) like '%".str_replace(" ","",$kkunci)."%' ) ";
	//echo $sqcari;
	include_once $um_path."frmcari.php";
}
elseif ($op=="hrgjualpaket") {
	cekVar("kdbrg,jpaket");
	if ($jharga=="USER")
		$sq="select kdbrg,nmbarang,1 as satuan,huserpa as hrg,huser as hrga,(huser-huserpa) as hrghe   from tbpaket where kdbrg ='$kdbrg'";
	else
		$sq="select kdbrg,nmbarang,1 as satuan,hressa as hrg,hresmu as hrga,(hressa-hrespa) as hrghe   from tbpaket  where kdbrg ='$kdbrg'";
	//get value prkjenisju
	extractRecord($sq);
	echo "$nmbarang,$hrga,$hrg,$hrghe";
}


?>
