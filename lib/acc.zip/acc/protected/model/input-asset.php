<?php
$useJS=2;
include_once 'conf.php';

$det="asset";
$nmTabel='tbpasset';
$nmTabelAlias='g';
$nmCaptionTabel="asset";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 

$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:1000,title: \'Input Data\'";


$isTest=false; 

$sqTabel="select * from (
select xg.*,
hrgbeli-akumulasi-residu as xnilai,
concat(kdprk,' - ',prk.account_name) as akun,
(hrgbeli-residu)/umur as xpenyusutan
 from tbpasset xg left join ".$oNamaTb->akun." prk on xg.kdprk=prk.account_code
) as  g ";


include $um_path."input-std0.php";

/*
if ($isSekolah) {
	addFilterTb("m.kdsekolah='admin'");
	$kdsekolah=$userid;
	addSaveTb("kdsekolah");
	$addInputNote="kode sekolah secara otomatis akan ditambahkan di field kode mapel";
	cekVar("kdmp");
	if (strstr($kdmp,$kdsekolah."-")=="") {
		setVar("kdmp","$kdsekolah-$kdmp");
	} 
}

*/

$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";
//$gGroupInput[$i]='Data Asset';
			
$i++; $sAllField.="#1|nama_asset|NAMA_ASSET|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|kdprk|AKUN|7|1|1|akun|7|C|S-0|1|1";
$gFieldInput[$i]="=isiComboAcc('kdprk',1,12000);";

$i++; $sAllField.="#6|tglbeli|TGLBELI|40|1|1|1|30|C|D-0|1|1";
$i++; $sAllField.="#7|hrgbeli|HARGA BELI|12|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#14|akumulasi|AK.PENYUSUTAN|12|1|1|1|7|C|C-0|1|1";
$i++; $sAllField.="#16|xnilai|NILAI|12|0|0|1|7|C|C-0|1|1";
$i++; $sAllField.="#16|xpenyusutan|DEPR/BULAN|12|0|0|1|7|C|C-0|1|1";

//$i++; $sAllField.="#8|jlh|JUMLAH|7|1|1|0|7|C|N-0|1|1";
$i++; $sAllField.="#9|umur|UMUR (BULAN)|7|1|1|0|7|C|S-0|1|1";
$i++; $sAllField.="#4|catatan|CATATAN|40|1|1|1|30|C|S-0|1|1";

/*
$i++; $sAllField.="#2|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|residu|RESIDU|7|1|1|0|7|C|S-0|1|1";
$i++; $sAllField.="#19|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#13|inactive|INACTIVE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#5|metode|METODE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|kdprkak|KDPRKAK|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#12|kdprkby|KDPRKBY|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#15|penyusutan|PENYUSUTAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#17|sPenyusutan|SPENYUSUTAN|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#18|tglterakhirpenyusutan|TGLTERAKHIRPENYUSUTAN|40|1|1|1|30|C|S-0|1|1";

$gFieldInput[$i]="=um412_isicombo5('select * from tbsales','idsales');";
$gFieldView[$i]="='Menu';";
$gDefField[$i]=date($formatTgl);
$gFuncFld[$i]="suggestFld('asset','idperusahaan|nama_perusahaa',596031,this.value);";

$addInputAkhir="<div id=thitung_$rnd class='text text-alert'></div>";

*/
//$isiComboFilterTabel="nama_asset;tbpasset.nama_asset"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','asset|asset',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

/*

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbperseksid';
$nmTabelDAlias='d';
$fldKeyM='id';
$fldKeyForeign='idperseksi';
$fldKeyD='id';
$sFldD="deskripsi,jlh";
$sFldDCap="Deskripsi,Jumlah";
$sLebarFldD="220,70";
$sClassFldD=",rp,,,,,,,,,,,,,,,,,";
$sAlignFldD=",r,,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian Biaya";

$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td>";
$showOprD=false;
*/
/*
$gFieldInputD[2]="=um412_isicombo5('select id,nama from tbppembantu order by nama','d_idpembantu[]','','','','#def#' );";
$gFieldViewD[2]="nmpelanggan";
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/
/*
$sqTabelD="select d.*  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
*/

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Asset';//caption tombol import
$sFieldCSV=strtolower('id,nama_asset,jenis,kdprk,catatan,metode,tglbeli,hrgbeli,jlh,umur,residu,kdprkak,kdprkby,inactive,akumulasi,penyusutan,nilai,sPenyusutan,tglterakhirpenyusutan,modified_date');
$sFieldCaptionCSV= strtolower('ID,NAMA_ASSET,JENIS,KDPRK,CATATAN,METODE,TGLBELI,HRGBELI,JLH,UMUR,RESIDU,KDPRKAK,KDPRKBY,INACTIVE,AKUMULASI,PENYUSUTAN,NILAI,SPENYUSUTAN,TGLTERAKHIRPENYUSUTAN,MODIFIED_DATE');
$nfCSV='import_Data_Asset.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
include $um_path."input-std.php";
?>
