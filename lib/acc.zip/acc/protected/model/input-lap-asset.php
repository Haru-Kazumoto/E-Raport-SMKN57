<?php

cekVar("jlap,media,op");

$subjd="";
$addjdl="";
$addInp="";
$sytingkat=" where 1=1 ";
//jlap:neraca,neracasaldo,perubahanmodal,labarugi
if ($jlap=="") $jlap="neraca";

$stj="display:none";

	$judulLap="DAFTAR ASSET";
	$nfLap=$lib_app_path."protected/view/lap/lap-asset.php"; 

if ($op=='') { 	
	$url="
	'index.php?det=$det&op=lapkeu&jlap=$jlap&newrnd=$rnd&kdbranch='+$('#kdbranch_$rnd').val()+'&bentuk='+$('#bentuk_$rnd').val()+'&tgl1='+$('#tgl1_$rnd').val()+'&tgl2='+$('#tgl2_$rnd').val()
	";
	$tbpdf="";
	$addSy="";
 
	$addInp="";
	if ($useBranch) 
		$addInp.="Cabang : ".um412_isicombo5('select kdbranch,branch from tbpbranch order by branch asc','kdbranch');
	else
		$addInp.="<input type=hidden id=kdbranch_$rnd value=''>";
	
	$addInp.="Jenis Asset : ".isiComboAcc('kdprk',0,12000);


	echo "
	<div class=breadcrumb2>	
	$addInp
		 <a class='btn btn-primary btn-sm' onclick=\"bukaAjax('tout',$url,0,'awalEdit($rnd)');\">Tampil</a>
		$tbpdf
		<a class='btn btn-success btn-sm' onclick=\"printDiv('tout');\">Cetak</a>
	</div>
	<div id='tout'></div>
	 
	";	
	
		?>
	<script>
	 
	$(document).ready(function() {
		$("#jenisju_<?=$rnd?>").combobox();
		 $(".tgl").datepicker();
	});
	 </script>
	<?php
	exit ;
}  

$t="";
$t.=awalLaporan();
$t.=buattbhead($judulLap,$tgl1,$tgl2);

//$t.="<br><br>".um412_falr("Laporan $judulLap dalam proses pembuatan"); 
include $nfLap;

echo "
<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >
<div class='page-landscape'>
$t
</div>
";

?>