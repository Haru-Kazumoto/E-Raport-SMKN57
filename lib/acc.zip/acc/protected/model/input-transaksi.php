<?php
$useJS=2;
include_once 'conf.php';

$det="transaksi";
$nmTabel=$oNamaTb->gl;
$nmTabelAlias='h';
$nmCaptionTabel="Data Transaksi";
$nmFieldID='id';

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
$defOrderDT="[3, 'desc']";
$configFrmInput="width:900,title: \'Input Data\'";
$sqTabel="select * from (
select xh.*,b.branch,p.nama as namapeg,pm.nama as nmpemasok,ast.nama_asset
from (((".$oNamaTb->gld." xh left join tbpbranch b on xh.kdbranch=b.kdbranch)
 left join tbppegawai p on xh.idpegawai=p.id)
 left join tbppembantu pm on xh.kdpembantu=pm.id)
 left join tbpasset ast on xh.kdasset=ast.id
 
 order by tgl desc,id desc
 

) as  h ";


if (op("del")) {
	cekVar("aid");
	$aids=explode(",",$aid);
	$s="";
	foreach ($aids as $xid) {
		$notrans=carifield("select notrans from ".$oNamaTb->gld." where id='$xid'");
		$s.="delete from ".$oNamaTb->gltrans." where  notrans='$notrans' ;"; 
		$s.="delete from ".$oNamaTb->gld." where  notrans='$notrans' ;"; 
	}
	//echo $s;
	querysql($s);
	echo "";
	exit;
}
 
//$isTest=true;
include $um_path."input-std0.php";
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

//$i++; $sAllField.="#7|jtrans|Jenis Transasi|40|1|1|1|30|C|S-0|1|1";
if ($useBranch) {
	$i++; $sAllField.="#19|kdbranch|CABANG|40|1|1|branch|30|C|S-0|1|1";
}
$gFieldInput[$i]="=um412_isicombo5('select kdbranch,branch from tbpbranch order by branch asc','kdbranch');";
$i++; $sAllField.="#17|jenisju|Jenis Transaksi|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo6('select jtrans as jenisju,jtrans from tbpjtrans order by jtrans asc','jenisju','GTInputJU($rnd)');";

//$gGroupInput[$i]='Data Transaksi';
			
			
$i++; $sAllField.="#1|tgl|Tanggal|40|1|1|1|30|C|D-0|1|1";
$gDefField[$i]=date($formatTgl);
$i++; $sAllField.="#4|notrans|No. Transaksi|40|1|1|1|30|C|H1-0|0|0";
if ($isAddItb) {
	$gDefField[$i]=getNewNotrans('JU','');
}

$i++; $sAllField.="#3|catatan|Keterangan|75|1|1|1|30|C|T-2|1|1";
$i++; $sAllField.="#13|jlhuang|Nilai Transaksi|12|1|1|1|7|C|C-0|1|1";
$tPosDetail=$i;

$i++; $sAllField.="#12|kdpembantu|Nama Pemasok|7|1|1|nmpemasok|7|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama from tbppembantu where jpembantu=\'PM\' order by nama asc','kdpembantu');";
$i++; $sAllField.="#17|kdasset|Nama Asset|40|1|1|nama_asset|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama_asset from tbpasset order by nama_asset asc','kdasset');";
$i++; $sAllField.="#17|idpegawai|Nama Pegawai|40|1|1|namapeg|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('select id,nama from tbppegawai order by nama asc','idpegawai');";
 
/*
$i++; $sAllField.="#14|carabayar|CARABAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|jlhbonus|JLHBONUS|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|kdasset|KDASSET|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#18|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#2|ref|REF|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#5|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#6|kdprkkas|KDPRKKAS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|noac|NOAC|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|nobg|NOBG|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#10|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|stat|STAT|7|1|1|1|7|C|S-0|1|1";
*/

//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="tgl;".$oNamaTb->gld.".tgl"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','transaksi|transaksi',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

$useInputD=false;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='".$oNamaTb->gltrans."';
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="kdprk,xxjlhd,xxjlhk,jlhuang,xxaksi";
$sFldDCap="Deskripsi,Debet,Kredit,xx,Aksi";
$sLebarFldD="220,110,110,0";
$sClassFldD=",C,C,,,,,,,,,,,,,,,,"; 
$sAlignFldD=",C,C,,,,,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
$nmCaptionTabelD="Rincian";
$jlhDefRowAdd=2;
$footTbD="<td colspan=2>Jumlah</td><td align=right>rp(#jlhD1#)</td><td align=right>rp(#jlhD2#)</td>";
$showOprD=false;
$evt="evalTransJU($rnd);";
$gFieldInputD[0]="=isiComboAcc('d_kdprk_$rnd"."_#no#|d_kdprk[]',0);";
$gFieldViewD[0]="akun"; 
$gFuncFldD[1]=$gFuncFldD[2]="$evt";
$gFieldInputD[4]="=
'<a href=# onclick=\"$'.'(\'#d_kdprk_#rnd#_#no#\').val(0);
$'.'(\'#d_xxjlhd_#rnd#_#no#\').val(0);
$'.'(\'#d_xxjlhk_#rnd#_#no#\').val(0);
$'.'(\'#d_jlhuang_#rnd#_#no#\').val(0);
$'.'(\'#trdet_#rnd#_#no#\').hide();
$evt;\" class=\"btn btn-danger btn-sm\"> - </a>'
;";	
//fungsi yang akan ditambahkan saat tekan addrow
$addfD="$('#d_kdprk_#rnd#_#no#').combobox();";
if (op("itb")) addfbe("$evt");


/*
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";
*/

$sqTabelD="select d.*,d.kdprk as d_kdprk,if(d.jlhuang>=0,d.jlhuang,0) as xxjlhd,if(d.jlhuang<0,abs(d.jlhuang),0) as xxjlhk  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='#id#' 
";
//echo $sqTabelD;
//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data Transaksi';//caption tombol import
$sFieldCSV=strtolower('id,tgl,ref,catatan,notrans,opr,kdprkkas,jtrans,noac,nobg,tgljt,stat,kdpembantu,jlhuang,carabayar,jlhbonus,kdasset,jenisju,modified_date,kdbranch');
$sFieldCaptionCSV= strtolower('ID,TGL,REF,CATATAN,NOTRANS,OPR,KDPRKKAS,JTRANS,NOAC,NOBG,TGLJT,STAT,KDPEMBANTU,JLHUANG,CARABAYAR,JLHBONUS,KDASSET,JENISJU,MODIFIED_DATE,KDBRANCH');
$nfCSV='import_Data_Transaksi.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";
 
include $um_path."input-std.php";

if (op("tb,ed")) {
	mysql_query2("delete from ".$oNamaTb->gltrans." where  notrans='$notrans' and  jlhuang=0 "); 
}

?>