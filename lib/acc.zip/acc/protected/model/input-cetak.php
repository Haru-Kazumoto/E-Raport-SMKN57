<?php
if ($op=='cetakkartu') {
	$judul='Cetak Kartu Ujian';
	$nf="cetak/cetak_kartu.php";
}
elseif ($op=='daftarhadir') {
	$judul='Cetak Daftar Hadir';
	
	$nf="cetak/cetak_daftarhadir.php";
}
elseif ($op=='beritaacara') {
	$judul='Cetak Berita Acara';	
	$nf="cetak/cetak_beritaacara.php";
}
elseif ($op=='nilai') {
	$judul='Cetak Nilai';	
	$nf="cetak/cetak_nilai.php";
}


?>
 <script>
 var op="<?=$op?>";
 function cetakKartu(jenis,media,rnd) {
	 ruang1=$("#ruang1_"+rnd).val();
	 tingkat=$("#tingkat_"+rnd).val();
	 sesi1=$("#sesi1_"+rnd).val();
	 kdsekolah=$("#kdsekolah_"+rnd).val();
	 bukaAjax("tout","<?=$nf?>?media="+media+"&ruang1="+ruang1+"&sesi1="+sesi1+"&kdsekolah="+kdsekolah+"&tingkat="+tingkat);
	 
 }
 
 function gantiCombo(rnd) {
	 
	kdsekolah=$("#kdsekolah_"+rnd).val();
	$("#truang"+rnd).hide();
	 bukaAjax("truang"+rnd,"filtercombo.php?op=ruang1&kdsekolah="+kdsekolah+"&newrnd="+rnd,rnd," $('#truang"+rnd+"').show();");
	$("#tsesi"+rnd).hide();
	 bukaAjax("tsesi"+rnd,"filtercombo.php?op=sesi1&kdsekolah="+kdsekolah+"&newrnd="+rnd,rnd," $('#tsesi"+rnd+"').show();");
	 
	 
 }
 </script>
 <link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
	
<div class="breadcrumb2">
<span align="right" style="margin-right:20px;margin-top:-30px">
<?php
$t="";
$t.=  $judul."&nbsp;&nbsp;&nbsp;&nbsp;";

$sy="";
if ($userid!='admin') {
	$kdsekolah=$userid;
	$sy= " where kdsekolah='$userid'";
	//$showOpr=0;//tampilkan tb opr
}

if ($isSA)
	$t.=" Sekolah : ". um412_isicombo6("select kdsekolah,namasek from tbsekolah ","kdsekolah","gantiCombo($rnd)");
else
	$t.= " <input type=hidden name=kdsekolah id=kdsekolah_$rnd value='$kdsekolah'>";

$t.=" <span id=truangsesi$rnd style='min-width:150px;height:40px;overflow:hide'>&nbsp;";

$t.="Tingkat : <span id=tingkat$rnd>". um412_isicombo5("X,XI,XII","tingkat")."</span> ";
$t.="Ruang : <span id=truang$rnd>". um412_isicombo5("select distinct(ruang) from tbsiswa $sy order by ruang ","ruang1")."</span> ";
$t.="Sesi : <span id=tsesi$rnd>". um412_isicombo5("select distinct(sesi) from tbsiswa $sy order by sesi","sesi1")."</span> ";

$t.="</span>  &nbsp;&nbsp;";
$t.=" <input type=submit class='btn btn-sm btn-mini btn-warning' value='Tampil' onclick=\"cetakKartu('$op','',$rnd);\" > &nbsp;&nbsp; ";
$t.=" <input type=button class='btn btn-sm btn-mini btn-success' value='Cetak'   onclick=\"printDiv('tout',2);\" >   ";

echo $t;
?>
</span>
 </div>
 <div id="tinput_641398"></div>
 <div id="tout" class=tout>
 <?php
 //include $nf;
 ?>
 </div>
