<?php
function addSyLapPB(){
	return addSyLapTrans("PB");	
}

function addSyLapSL($sjtrans){
	return addSyLapTrans($sjtrans);
}

function addSyLapTrans($sjtrans){
	global $useEceran,$kdbranch,$kdpj,$addSqComboBrg,$subjd,$tgl1,$tgl2;
	//global $sy;
	$sjtrans=str_replace("/",",",$sjtrans);
	cekvar("kdbranch,kdpj");
	
	$sykdb="where  ".changeParamSySql2($sjtrans,$fld="h.jtrans",$param=",",$oprx="=","or")." $addSqComboBrg ";
	//$sykdb="where  jtrans='SL' $addSqComboBrg ";
	if ($kdbranch!='') {
		$sykdb.="and  h.kdbranch='$kdbranch' ";	
		$branch=getBranch($kdbranch);
		$subjd.="
			<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
		";
	}
	if ($kdpj!='') {
		$sykdb.="and  h.kdpj='$kdpj' ";			
		$namapeg=getPegawai($kdpj);
		$subjd.="
			<tr><td width='180'>Nama Marketing </td><td >: $namapeg</td></tr>
		";
	}
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sykdb.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sykdb.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl2);
			
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : $xtg </td></tr>
		";
	} 
	return $sykdb;
}

function addSyKdBrg(){
	global $kdbrg,$challsize,$subjd,$kdjbarang,$addSqComboBrg;
	global $sy;
	cekvar("kdbrg,challsize,kdjbarang");
	$sykdb='';
	if ($kdjbarang!='') {
		$sykdb="and  b.jenis='$kdjbarang'  ";
		$subjd.="<tr><td width='180'>Jenis Barang </td><td >: $kdjbarang</td></tr>";
	}else if ($kdbrg!='') {
		$skip=false;
		if ($challsize=='checked') {
			//mencari semua allsize
			$nmbrg=carifield("select nmbarang from tbpbarang where kdbrg='$kdbrg' ");
			$pos=strpos(strtolower($nmbrg),"size");
			if ($pos>0) {
				$skip=true;
				$xnmb=substr($nmbrg,0,$pos);
				$skdb=getstring("select kdbrg from tbpbarang where nmbarang like '$xnmb%'",",");
				$xsy=changeParamSySql2($skdb,$fld="d.kdbrg",$param=",",$oprx="=","or");
				$sykdb="and  $xsy  ";
			}
		}
		
		if (!$skip) {
			$sykdb="and d.kdbrg='$kdbrg' ";
			$xnmb=carifield("select nmbarang  from tbpbarang b where kdbrg='$kdbrg' $addSqComboBrg");
		}
		$subjd.="<tr><td width='180'>Nama Barang </td><td >: $xnmb</td></tr>";
	}
	return $sykdb;
}


function addSyKdPlg(){
	global $kdpembantu,$kdwil,$provinsi,$subjd;
	//global $sy;
	cekvar("kdpembantu,kdwil,provinsi");
	$sykdb='';
	if ($kdwil!='') {
		$sykdb="and  pb.kdwil='$kdwil'  ";
		$subjd.="<tr><td width='180'>Wilayah </td><td >: $kdwil</td></tr>";
	} 
	/*
	else if ($provinsi!='') {
		$sykdb="and  pb.provinsi='$provinsi'  ";
		$subjd.="<tr><td width='180'>Provinsi </td><td >: $provinsi</td></tr>";
	}
	*/
	elseif ($kdpembantu!='') {
		$nmplg=carifield("select nama from tbppembantu where id='$kdpembantu' ");
		$sykdb="and  h.kdpembantu='$kdpembantu'  ";
		$subjd.="<tr><td width='180'>Nama Pelanggan</td><td >: $nmplg</td></tr>";
	}
	return $sykdb;
}

function genSqLapTrans($jenis="pertrans") {
	global $sy,$sqTerhutang;
	$sqGroup=$addSFld=$addSqFrom="";
	$sqOrder="order by tgl asc";
	if (strstr($jenis,"pertrans-lr")!="") {
		$addSFld.="
		,sum(d.hpp*d.jlh_terima) as jhpp
		,sum(d.hrg*d.jlh_terima) as brutto2
		,sum(d.hrg*d.jlh_retur) as retur2
		,netto-sum(d.hpp*d.jlh_terima) as lr
		
		";
		$addSqFrom.="left join tbpbelid d on h.notrans=d.notrans ";
		$sqGroup="group by h.notrans ";
	}
	
	if (strstr($jenis,"perbrg")!="") {
			
			
		$sqLapTrans="select
		br.branch,
		h.kdprkkas,
		h.notrans,
		h.jtrans,
		pb.nama as namaplg,
		h.tgl,
		d.id as idbj,
		d.kdbrg,
		b.nmbarang,
		d.hpp,
		d.hrg,
		d.jlh_terima,
		d.jlh_retur,
		jlh_terima  as jlh,
		 jlh_terima*(d.hrg-d.disc) as subtot,
		 jlh_terima*(d.hpp) as jhpp,
		 jlh_terima*(d.hrg-d.disc-d.hpp) as jlaba 
		from (((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
			left join tbpbranch br on h.kdbranch=br.kdbranch)
			left join tbpbarang b on d.kdbrg=b.kdbrg )
			left join tbppembantu pb on h.kdpembantu=pb.id
			 
		 $sy  
		 $sqGroup
		 $sqOrder ";
		 
	} else {
		$sqLapTrans="select
		br.branch,
		 h.notrans,
		 h.tgl,
		 pb.nama as namaplg,
		 h.brutto,
		 h.netto,
		 h.retur,
		 h.disc,
		 h.disc2,
		 h.disc+h.disc2 as tdisc,
		 h.paidtoday,
		 h.paidafter,
		 $sqTerhutang as hupi,
		 pj.nama as namapj,
		 h.catatan
		 $addSFld
		from tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch
		$addSqFrom
			left join tbppembantu pb on h.kdpembantu=pb.id
			left join tbppegawai pj on h.kdpj=pj.id
		 $sy  
		 $sqGroup
		 $sqOrder ";
	}	 
	//echo  $sqLapTrans;
	return $sqLapTrans;
}

function cekPindahPage($addbr=1){
	global $br,$maxbr,$isi,$clspage,$kop,$media,$pg,$jdlTb;		
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		$kop
		".$jdlTb;
		$br=1;
		$pg++;
	}
	if ($addbr==1) $br++;
}
