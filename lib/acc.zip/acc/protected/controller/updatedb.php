<?php
//program sekolah
$dbwebver=getconfig("dbwebver")*1;
$ssq="";
if ($dbwebver<1) {
	$ssq.="  
	CREATE TABLE `tbh_logclick` (
	  `id` int(11) NOT NULL,
	  `vurl` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `vuid` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `tglclick` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `mark` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `ip` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `ket` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;
	CREATE TABLE `tbh_logh2` (
	  `id` mediumint(9) NOT NULL,
	  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
	  `user` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `ket` text NOT NULL,
	  `created_by` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `modified_by` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `idtrans` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `jenislog` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `ip` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `tb` varchar(30) NOT NULL,
	  `sq` text NOT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=utf8;

	CREATE TABLE `tbh_logip` (
	  `id` int(11) NOT NULL,
	  `ip` varchar(17) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `svuid` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `jlhip` int(5) NOT NULL,
	  `ket` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT '',
	  `mark` varchar(20) NOT NULL DEFAULT '',
	  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;

	ALTER TABLE `tbh_logclick`
	  ADD PRIMARY KEY (`id`);

	ALTER TABLE `tbh_logh2`
	  ADD PRIMARY KEY (`id`);
	ALTER TABLE `tbh_logip`
	  ADD PRIMARY KEY (`id`),
	  ADD UNIQUE KEY `ip` (`ip`);

	ALTER TABLE `tbh_logclick`
	  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

	ALTER TABLE `tbh_logh2`
	  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;
	ALTER TABLE `tbh_logip`
	  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


	ALTER TABLE `tbpjtrans` ADD `grp` VARCHAR(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL AFTER `kdprk3`;
	ALTER TABLE `tbppegawai` ADD `simp_pokok` DECIMAL(15,2) NOT NULL AFTER `vpass`, ADD `simp_wajib` DECIMAL(15,2) NOT NULL AFTER `simp_pokok`, ADD `simp_suka` DECIMAL(15,2) NOT NULL AFTER `simp_wajib`;
	ALTER TABLE `tbppegawai` CHANGE `NIK` `nik` VARCHAR(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL;
	ALTER TABLE `tbconfig` ADD `dbwebver` int(11) NOT NULL;
	
	
	ALTER TABLE `tbplokasi` ADD `kdbranch` INT NOT NULL ;
	
	";
}
if ($dbwebver<2) {
	$ssq.="  
	ALTER TABLE `tbpbeli`  ADD `bykuli` DECIMAL(11,2) NOT NULL DEFAULT '0'   ;
	ALTER TABLE `tbpbeli`  ADD `bytimbang` DECIMAL(11,2) NOT NULL DEFAULT '0'   ;
	ALTER TABLE `tbpbarang`  ADD `jlhisi` DECIMAL(11,2) NOT NULL DEFAULT '1'   ;
	ALTER TABLE `tbpbelid` ADD `jlhpkg` DECIMAL(8,2) NOT NULL  , ADD `jlhppkg` DECIMAL(8,2) NOT NULL AFTER `jlhpkg`;
	ALTER TABLE `tbpbelid` CHANGE `catatan1` `catatan1` VARCHAR(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL;
	ALTER TABLE `tbpbarang` CHANGE `defhrgbeli` `defhrgbeli` DECIMAL(13,2) NOT NULL, CHANGE `realhrgbeli` `realhrgbeli` DECIMAL(13,2) NOT NULL, CHANGE `hppinves` `hppinves` DECIMAL(13,2) NOT NULL COMMENT 'HPP Investasi', CHANGE `hrgjinves` `hrgjinves` DECIMAL(13,2) NOT NULL COMMENT 'Harga jual Investasi', CHANGE `labaps` `labaps` DECIMAL(13,2) NOT NULL, CHANGE `labarp` `labarp` DECIMAL(13,2) NOT NULL, CHANGE `pembulatan` `pembulatan` DECIMAL(13,2) NOT NULL, CHANGE `defdisc` `defdisc` DECIMAL(13,2) NOT NULL, CHANGE `hrgjual` `hrgjual` DECIMAL(13,2) NOT NULL, CHANGE `labarp2` `labarp2` DECIMAL(13,2) NOT NULL, CHANGE `labarp3` `labarp3` DECIMAL(13,2) NOT NULL, CHANGE `hrgjual2` `hrgjual2` DECIMAL(13,2) NOT NULL, CHANGE `hrgjual3` `hrgjual3` DECIMAL(13,2) NOT NULL, CHANGE `cbonus` `cbonus` DECIMAL(13,2) NOT NULL;
	ALTER TABLE `tbpbelid_terpakai` ADD `cek` INT(1) NOT NULL ; 
	";
	
}
//emping 12 jan 2020
if ($dbwebver<3) {
	$ssq.="  
ALTER TABLE `tbpbelid` CHANGE `jlh_tarra` `jlh_tarra` VARCHAR(11) NOT NULL;
ALTER TABLE `tbpbayard` ADD `cek` INT(1) NOT NULL ; 
ALTER TABLE `tbpbeli` ADD `catatansj` TEXT NOT NULL AFTER `catatan`;
ALTER TABLE `tbppembantu` ADD `norek` TEXT NOT NULL COMMENT 'informasi bank' AFTER `email`;

ALTER TABLE `tbpbeli` ADD `kdkendaraan` INT(5) NOT NULL AFTER `bytimbang`, ADD `sopir1` VARCHAR(30) NOT NULL AFTER `kdkendaraan`, ADD `sopir2` VARCHAR(30) NOT NULL AFTER `sopir1`;


CREATE TABLE `tbkendaraan` (
  `id` int(11) NOT NULL,
  `kendaraan` varchar(50) NOT NULL,
  `jenis` text NOT NULL,
  `nopol` varchar(20) NOT NULL,
  `pemilik` varchar(40) NOT NULL,
  `sopir1` varchar(30) NOT NULL,
  `sopir2` varchar(30) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `".$oNamaTb->gl."` ADD UNIQUE(`notrans`);
ALTER TABLE `$oNamaTb->kontrolAkun` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`);
ALTER TABLE `$oNamaTb->kontrolAkun` ADD `ket` VARCHAR(60) NOT NULL , ADD `aktif` INT(1) NOT NULL default 1;
update  `$oNamaTb->kontrolAkun` set aktif=1;

	";
	querysql($ssq);
	
}

//emping 12 jan 2020
if ($dbwebver<4) {
$ssq.="
ALTER TABLE `tbuser` CHANGE `userid` `vuserid` VARCHAR(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `username` `vusername` VARCHAR(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `usertype` `vusertype` VARCHAR(60) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL; 
ALTER TABLE `tbppegawai` ADD `tempatlahir` VARCHAR(60) NOT NULL AFTER `vemail`, ADD `tgllahir` DATE NOT NULL AFTER `tempatlahir`; 

	";
}

//bbm
if ($dbwebver<5) {
$ssq.="
	ALTER TABLE `tbconfig` ADD `alamat4` VARCHAR(200) NOT NULL AFTER `alamat3`; 
	ALTER TABLE `tbconfig` ADD `defkdlokasi` int(5) default 1; 
	ALTER TABLE `tbconfig` ADD `nflogo` varchar(120) default '';
	ALTER TABLE `tb1kode` ADD `catatan` VARCHAR(50) NOT NULL ; 
	ALTER TABLE `tbpstock` ADD `statterpakai` int(1) NOT NULL; 
	ALTER TABLE `tbpbelid` ADD `statterpakai` int(1) NOT NULL; 
	
	ALTER TABLE `tbpstock` ADD `jlh_terpakai` DECIMAL(11,2) NOT NULL AFTER `statterpakai`; 
	ALTER TABLE `tbpbelid` ADD `jlh_terpakai` DECIMAL(11,2) NOT NULL AFTER `statterpakai`; 
	ALTER TABLE `tbpbelid` DROP `kdlokasi`;
	ALTER TABLE `tbpbelid_terpakai` DROP `idbp`, DROP `idbs`;
	ALTER TABLE `tbpbelid_terpakai` change jlh jlh decimal(11,2) NOT NULL  ;
	ALTER TABLE `tbpbelid_terpakai` ADD INDEX(`idbb`);
	ALTER TABLE `tbppegawai` ADD `nffoto` VARCHAR(120); 
	ALTER TABLE `tbpbelid` ADD `jenisd` varchar(20) NOT NULL  ; 
	ALTER TABLE `tbppegawai` ADD `kode` VARCHAR(5) NOT NULL default ''; 
	ALTER TABLE `tbppegawai` ADD `profile` LONGTEXT NOT NULL DEFAULT '' ; 
	ALTER TABLE `tbpstock` ADD `hrgawal` DECIMAL(17,2) NOT NULL AFTER `stex`; 
	ALTER TABLE `tbconfig` ADD `judulweb` VARCHAR(200) NOT NULL AFTER `nflogo`, ADD `deskripsiweb` VARCHAR(300) NOT NULL AFTER `juduweb`; 
	ALTER TABLE `tbconfig` DROP `branch`, DROP `kdbranch`;
    ALTER TABLE `tbpbranch` DROP `id`;
    ALTER TABLE `tbpbranch` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`); 
    ALTER TABLE `tbpbranch` ADD `defkdlokasi` INT NOT NULL;
 	
	ALTER TABLE `tbconfig` ADD `judulweb` VARCHAR(120); 
	ALTER TABLE `tbconfig` ADD `deskripsiweb` VARCHAR(120); 
	
	ALTER TABLE `tbpstock` ADD `defhrgbeli` DECIMAL(11,2) NOT NULL AFTER `jlh_terpakai`; 
	ALTER TABLE `tbplokasi` ADD `kode` VARCHAR(10) NOT NULL AFTER `id`; 
	ALTER TABLE `tbpbeli` ADD `byopr` DECIMAL(11,2) NOT NULL AFTER `sopir2`; 
	update tbconfig set dbwebver=5;
	";
}

//hk bs
if ($dbwebver<6) {
$ssq.="
ALTER TABLE `tbpage` ADD `tglentry` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `jenis`; 
ALTER TABLE `tbppembantu` ADD `vuserid` varchar(32) NOT NULL, ADD `vpass` varchar(40); 
ALTER TABLE `tbppembantu` ADD `kdbranch` VARCHAR(10) NOT NULL AFTER `modified_date`; 
ALTER TABLE `tbppembantu` ADD `statuser` INT(2) NOT NULL AFTER `vpass`, ADD `lastclick` DATETIME NOT NULL  DEFAULT CURRENT_TIMESTAMP; 

ALTER TABLE `tbconfig` ADD `nflogo2` varchar(40) NOT NULL;

";
}

//hrd
if ($dbwebver<7) {
	$ssq.="
	
	CREATE TABLE `tbppegawai_mdept` (
	  `id` int(11) NOT NULL,
	  `kode` varchar(10) NOT NULL,
	  `departemen` varchar(40) NOT NULL
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;
	INSERT INTO `tbppegawai_mdept` (`id`, `kode`, `departemen`) VALUES
	(1, 'dadm', 'Administrasi'),
	(2, 'dacc', 'Keuangan'),
	(3, 'dit', 'IT'),
	(4, 'dsp', 'Support'),
	(5, 'dgd', 'Gudang'),
	(6, 'dpc', 'Purchasing'),
	(7, 'dks', 'Kasir'),
	(8, 'ddr', 'Direksi');
	ALTER TABLE `tbppegawai_mdept`  ADD PRIMARY KEY (`id`);
	ALTER TABLE `tbppegawai_mdept`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

CREATE TABLE `tbppegawai_mjab` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) NOT NULL,
  `jabatan` varchar(120) NOT NULL,
  `gapok` decimal(11,0) NOT NULL,
  `kddept` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbppegawai_mjab` (`id`, `kode`, `jabatan`, `gapok`, `kddept`) VALUES
(1, 'dirut', 'Direktur Utama', '7000000', 'ddir'),
(2, 'acc', 'Akunting/Keuangan', '0', 'dacc');
ALTER TABLE `tbppegawai_mjab`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_mjab`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

CREATE TABLE `tbppegawai_sangsi` (
  `id` int(11) NOT NULL,
  `idpegawai` int(11) NOT NULL,
  `tglsangsi` date NOT NULL,
  `sangsi` varchar(30) NOT NULL,
  `sebab` varchar(200) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbppegawai_sangsi`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_sangsi`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbppegawai_absensi` (
  `id` int(11) NOT NULL,
  `idpegawai` int(11) NOT NULL,
  `tgl` date NOT NULL,
  `jammasuk` time NOT NULL,
  `jamkeluar` time NOT NULL,
  `jamreal` decimal(6,2) NOT NULL,
  `jamhitung` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbppegawai_absensi`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_absensi`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbppegawai_mlibur` (
  `id` int(11) NOT NULL,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbppegawai_mlibur`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_mlibur`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbppegawai_mcuti` (
  `id` int(11) NOT NULL,
  `deskripsi` varchar(100) NOT NULL,
  `jlhhari` int(3) NOT NULL,
  `ispaid` int(1) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbppegawai_mcuti`  ADD UNIQUE KEY `id` (`id`);
ALTER TABLE `tbppegawai_mcuti`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbppegawai_cuti` (
  `id` int(11) NOT NULL,
  `idpegawai` int(11) NOT NULL,
  `jcuti` int(11) NOT NULL,
  `jdurasi` varchar(1) NOT NULL,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `jlhjam` decimal(10,0) NOT NULL,
  `alasan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbppegawai_cuti`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_cuti`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbppegawai_tugas` (
  `id` int(11) NOT NULL,
  `idproject` int(11) NOT NULL,
  `sidpegawai` varchar(200) NOT NULL,
  `tugas` int(11) NOT NULL,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `deskripsi` text NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbppegawai_tugas` ADD PRIMARY KEY (`id`);
ALTER TABLE `tbppegawai_tugas`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE `tbpproject` (
  `id` int(11) NOT NULL,
  `judul` varchar(200) NOT NULL,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `jproject` varchar(30) NOT NULL,
  `stat` int(1) NOT NULL,
  `deskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
ALTER TABLE `tbpproject`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbpproject`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


";
		
}

if ($dbwebver<8) {
	$ssq.="
CREATE TABLE `tbpbarang_cat` (
  `id` int(11) NOT NULL,
  `kode` varchar(10) NOT NULL,
  `kategori` varchar(32) NOT NULL,
  `nficon` varchar(60) NOT NULL,
  `spesifikasi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbpbarang_cat`   ADD PRIMARY KEY (`id`);
ALTER TABLE `tbpbarang_cat`   MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `tbpbeli` ADD `kdprkkas` VARCHAR(12) NOT NULL ; 
ALTER TABLE `tbuser` ADD `kdlokasi` INT NOT NULL ; 
ALTER TABLE `tbpbranch` ADD `kdprkkask` INT(11) NOT NULL AFTER `kdprkhutang`; 
ALTER TABLE `tbpbranch` ADD `kdprkkaskecil` INT(11) NOT NULL ; 


ALTER TABLE `tbpbranch` ADD `alamat2` VARCHAR(120) NOT NULL AFTER `alamat`; 
ALTER TABLE `tbpbranch` CHANGE `kdprkkas` `kdprkkasm` INT(11) NOT NULL; 
ALTER TABLE `tbpbranch` ADD `defkdlokasi` INT NOT NULL AFTER `kdprkkask`; 

INSERT INTO `$oNamaTb->kontrolAkun` (`name`, ket, `aktif`, `length`, `value`) VALUES ( 'bank','Akun bank', '1',  '0', '11120');

ALTER TABLE `tbpbeli` CHANGE `kdprkkas` `kdprkkas` INT(11) NOT NULL; 
ALTER TABLE `tbppembantu` ADD `tglsawal` DATE NOT NULL AFTER `sawal`;
ALTER TABLE `tbppembantu` CHANGE `tglsawal` `tglsawal` DATE NOT NULL DEFAULT '1900-01-01'; 

ALTER TABLE `0_chart_sa` ADD `kdpembantu` INT NOT NULL AFTER `sawal`; 
ALTER TABLE `0_chart_sa` ADD `tglsa` DATE NOT NULL AFTER `sawal`; 

ALTER TABLE `tbpbranch` ADD `alamat2` VARCHAR(60) NOT NULL AFTER `alamat`; 
ALTER TABLE `tbpbranch` ADD `kdprkbank` INT(11) NOT NULL ; 
ALTER TABLE `tbpbranch` ADD `kdpembantuumum` INT NOT NULL AFTER `kdprkbank`; 

ALTER TABLE `tbpbelid` ADD `stsystem` FLOAT(11,2) NOT NULL AFTER `statterpakai`, ADD `stfisik` FLOAT(11,2) NOT NULL AFTER `stsystem`; 
INSERT INTO `$oNamaTb->kontrolAkun` (`name`, `ket`, `aktif`, `category`, `type`, `length`, `value` ) 
VALUES ('penyesuaian_persediaan', 'Penyesuaian Persediaan (Stock Opname)', '1', '', '', 0,'94000' ); 
INSERT INTO `".$oNamaTb->akun."` (`account_code`, `account_name`, `account_type`, `inactive`, `acc`, `sawal`, `modified_date`, `accinduk`, `ish`, `kdbranch`) VALUES
(94000, 'Rugi Selisih Stock', '190', 0, 0, '0.00', '2022-01-12 02:24:14', 90000, 0, '');

ALTER TABLE `tbuser` ADD `idpegawai` INT NOT NULL ; 



CREATE TABLE `tbpproduksi2` (
  `id` int(11) NOT NULL,
  `kdproduksi` varchar(20) NOT NULL,
  `kdjp` varchar(8) NOT NULL,
  `tglmulai` date NOT NULL,
  `tglselesai` date NOT NULL,
  `volume` decimal(10,0) NOT NULL,
  `catatan` text NOT NULL,
  `tglentry` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `kdbranch` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
 
ALTER TABLE `tbpproduksi2`  ADD PRIMARY KEY (`id`);
 
ALTER TABLE `tbpproduksi2`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
 
 
CREATE TABLE `tbpproduksij` (
  `id` int(11) NOT NULL,
  `kdjp` varchar(6) NOT NULL,
  `jenis` varchar(60) NOT NULL,
  `jlhhari` decimal(7,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbpproduksij`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbpproduksij`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `tbpbeli` DROP INDEX `kdlokasi_2`;
ALTER TABLE `tbpbeli` ADD `ballance` DECIMAL(11,2) NOT NULL ; 
ALTER TABLE `".$oNamaTb->akun."` ADD `kdbranch` VARCHAR(10) NOT NULL AFTER `ish`; 
";

}

if ($dbwebver<9) {
	$ssq.="
DROP TABLE `tbpjuale`;
drop table `tbpjualed`;
drop table tbpbarang_tmp;
drop table tbpbarang_bak_20180810_10_45_35;

ALTER TABLE `tbpbarang` ADD `jenisb` VARCHAR(3) NOT NULL AFTER `jlhisi`; 
ALTER TABLE `tbppegawai_absensi` CHANGE `tgl` `tglabsensi` DATE NOT NULL; 
ALTER TABLE `tbppegawai_absensi` ADD `tglentry` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER `jamhitung`; 
ALTER TABLE `tbppegawai_absensi` ADD `kehadiran` VARCHAR(2) NOT NULL AFTER `tglentry`; 	
ALTER TABLE `tbppegawai_absensi` ADD `ket` TEXT NOT NULL AFTER `kehadiran`; 
ALTER TABLE `tbpbelid` ADD `defhrgj` FLOAT(11,2) NOT NULL AFTER `hrgjinves`; 
ALTER TABLE `tbpbelid_terpakai` ADD `hpp` FLOAT(11,2) NOT NULL AFTER `jenisidb`; 
ALTER TABLE `tbpstock` ADD `hrgpokok1` FLOAT(11,2) NOT NULL AFTER `defhrgbeli`;


	";
	//nikiharum+bayu siap edit
}
if ($dbwebver<10) {
	$ssq.="
	ALTER TABLE `tbpstock` ADD `stawalterpakai` FLOAT(11,2) NOT NULL DEFAULT '0' AFTER `statterpakai`;
	ALTER TABLE `".$oNamaTb->akun."` ADD `account_code2` VARCHAR(20) NOT NULL; 
	ALTER TABLE `tbppegawai_mjab` ADD `isuser` INT(1) NOT NULL AFTER `kddept`, ADD `role` TEXT NOT NULL AFTER `isuser`; 
	ALTER TABLE `tbpstock` ADD `defhrgbeli` FLOAT(11,2) NOT NULL AFTER `stawalterpakai`, ADD `defhrgjual` FLOAT(11,2) NOT NULL AFTER `defhrgbeli`; 
	
	
	
	update tbconfig set dbwebver=10;
	";
 
}
if ($dbwebver<11) {
	$ssq.="
	ALTER TABLE `tbpbelid_terpakai` ADD `idbj` INT NOT NULL AFTER `idbb`; 
	ALTER TABLE `tbpbelid_terpakai` CHANGE `jtrans` `jtrans` VARCHAR(10) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `notrans_t` `notrans_t` VARCHAR(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `kdbrg` `kdbrg` VARCHAR(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `notrans` `notrans` VARCHAR(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `jenisidb` `jenisidb` VARCHAR(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL; 
	
	CREATE TABLE `tbh_logsql` (
  `id` mediumint(9) NOT NULL,
  `tgl` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user` varchar(40) NOT NULL,
  `ket` text NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `created_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` varchar(30) NOT NULL,
  `modified_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `idtrans` varchar(30) NOT NULL,
  `jenislog` varchar(60) NOT NULL,
  `ip` varchar(40) DEFAULT NULL,
  `tb` varchar(30) NOT NULL,
  `strsql` longtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
ALTER TABLE `tbh_logsql`  ADD PRIMARY KEY (`id`);
ALTER TABLE `tbh_logsql`  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT;

	";
 
}


if ($dbwebver<12) {
	$ssq.="
	ALTER TABLE `tbh_logh2` DROP `tgl`;
	ALTER TABLE `tbh_logh2` CHANGE `created_by` `created_by` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, CHANGE `modified_by` `modified_by` DATETIME on update CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP; 
	";
 
}
if ($dbwebver<13) {
	$ssq.="
	ALTER TABLE `tbpbelid` CHANGE `jlh_pesan` `jlh_pesan` FLOAT(15,4) NOT NULL DEFAULT '0.00', CHANGE `jlh_terima` `jlh_terima` FLOAT(15,4) NOT NULL DEFAULT '0.00', CHANGE `jlh_retur` `jlh_retur` FLOAT(15,4) NOT NULL DEFAULT '0.00', CHANGE `jlh_terpenuhi` `jlh_terpenuhi` FLOAT(15,4) NOT NULL, CHANGE `jlh_brutto` `jlh_brutto` FLOAT(15,4) NOT NULL, CHANGE `jlh_tarra` `jlh_tarra` VARCHAR(120) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `jlhpkg` `jlhpkg` DECIMAL(15,4) NOT NULL, CHANGE `jlhppkg` `jlhppkg` DECIMAL(15,4) NOT NULL; 
	ALTER TABLE `tbpbelid_terpakai` CHANGE `jlh` `jlh` FLOAT(15,4) NOT NULL; 
	ALTER TABLE `tbpstock` CHANGE `stawal` `stawal` FLOAT(15,4) NOT NULL, CHANGE `stbeli` `stbeli` FLOAT(15,4) NOT NULL, CHANGE `strbeli` `strbeli` FLOAT(15,4) NOT NULL, CHANGE `stjual` `stjual` FLOAT(15,4) NOT NULL, CHANGE `strjual` `strjual` FLOAT(15,4) NOT NULL, CHANGE `stadjust` `stadjust` FLOAT(15,4) NOT NULL, CHANGE `stpbeli` `stpbeli` FLOAT(15,4) NOT NULL, CHANGE `reorder` `reorder` FLOAT(15,4) NOT NULL, CHANGE `stprodm` `stprodm` FLOAT(15,4) NOT NULL, CHANGE `stprodk` `stprodk` FLOAT(15,4) NOT NULL, CHANGE `stdistm` `stdistm` FLOAT(15,4) NOT NULL, CHANGE `stdistk` `stdistk` FLOAT(15,4) NOT NULL, CHANGE `stex` `stex` FLOAT(15,4) NOT NULL DEFAULT '0.00' COMMENT 'extract/pack stock', CHANGE `hrgawal` `hrgawal` FLOAT(11,2) NOT NULL, CHANGE `reorderq` `reorderq` FLOAT(15,4) NOT NULL, CHANGE `stpjual` `stpjual` FLOAT(15,4) NOT NULL, CHANGE `stawalterpakai` `stawalterpakai` FLOAT(15,4) NOT NULL DEFAULT '0.00'; 
	";
 
}

if ($dbwebver<1) {
	//niki
	$ssq.="
	ALTER TABLE `tbppegawai` CHANGE `jabatan` `kdjab` VARCHAR(20) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL; 
";
}

if ($dbwebver<15) {
	//niki
	$ssq.="
	ALTER TABLE `tbpbeli` CHANGE `ppn` `ppn` DECIMAL(11,2) NOT NULL; 
	INSERT INTO `$oNamaTb->kontrolAkun` (`id`, `name`, `ket`, `aktif`, `category`, `type`, `length`, `value`, `aw`, `modified_date`) VALUES (NULL, 'default_inventory_act_bdp', 'Persediaan Barang Dalam Proses', '1', '', '', '0', '0', '0', '2022-02-16 11:47:20'); 
	INSERT INTO `$oNamaTb->kontrolAkun` (`id`, `name`, `ket`, `aktif`, `category`, `type`, `length`, `value`, `aw`, `modified_date`) VALUES (NULL, 'default_inventory_act_bj', 'Persediaan Barang Jadi', '1', '', '', '0', '0', '0', '2022-02-16 11:47:20'); 
";
}


if ($dbwebver<16) {
	//niki
	$ssq.="
	ALTER TABLE `tbppegawai_mjab` CHANGE `kode` `kode` VARCHAR(10) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `jabatan` `jabatan` VARCHAR(120) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `kddept` `kddept` VARCHAR(10) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL, CHANGE `role` `role` TEXT CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL; 
	ALTER TABLE `tbacc_gl` ADD `idnotif` INT NOT NULL AFTER `dk`; 
	ALTER TABLE `tbppegawai` ADD `lastclick` datetime NOT NULL ;  
	ALTER TABLE `tbppegawai` ADD `statuser` int(1) NOT NULL ; 
	
	CREATE TABLE `tbpnotif` (
	  `id` int(11) NOT NULL,
	  `notrans` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `tglnotif` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
	  `info` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `dariuid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `kpduid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `kpdsjab` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `stat` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `statuid` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
	  `modified_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
	) ENGINE=InnoDB DEFAULT CHARSET=latin1;
	ALTER TABLE `tbpnotif` ADD PRIMARY KEY (`id`);
	ALTER TABLE `tbpnotif`  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
	ALTER TABLE `tbpnotif` ADD `detnotif` VARCHAR(30) NOT NULL AFTER `modified_date`, ADD `opnotif` VARCHAR(30) NOT NULL AFTER `detnotif`;
	DROP TABLE ` tbl1kode;
	ALTER TABLE `tbpproduksi2` ADD `stat` INT NOT NULL COMMENT '0:unfinish,1:finish' AFTER `kdbranch`; 
	ALTER TABLE `tbpbelid` ADD `sat` VARCHAR(20) NOT NULL AFTER `stfisik`; 
	ALTER TABLE `tbpbeli` ADD `kdproduksi` VARCHAR(30) NOT NULL ; 
	INSERT INTO `tbakun_ca` (`id`, `name`, `ket`, `aktif`, `category`, `type`, `length`, `value`, `aw`, `modified_date`) VALUES (NULL, 'penyeimbang_by_produksi', 'Penyeimbang Biaya Produksi/By Produksi Lain2', '1', '', '', '0', '', '0', ''); 
	ALTER TABLE `tbpbelid` ADD `jlh_terpakai` FLOAT(15,4) NOT NULL; 
	";
}

if ($dbwebver<20) {
$ssq.="
	ALTER TABLE `tbpbelid_terpakai` ADD `hpp` FLOAT(15,2) NOT NULL AFTER `jenisidb`; 
	ALTER TABLE `tbpbelid` CHANGE `hpp` `hpp` FLOAT(15,4) NOT NULL; 
	ALTER TABLE `tbpproduksi2` ADD `totbb` FLOAT(15,2) NOT NULL AFTER `stat`, ADD `totbj` FLOAT(15,2) NOT NULL AFTER `totbb`; 
	ALTER TABLE `tbpproduksi2` ADD `ballance` FLOAT(15,2) NOT NULL AFTER `totbj`; 	
	ALTER TABLE `tbpproduksi2` ADD `tglstat` DATETIME NOT NULL AFTER `ballance`; 
	ALTER TABLE `tbpproduksi2` CHANGE `stat` `psstat` INT(11) NOT NULL COMMENT 'prosentase '; 
	update tbconfig set dbwebver=20;
";
}
if ($ssq!='') {
	
	querysql($ssq,$cancelIfError=false,$showPes=true,$saveLog=false);
	echo $ssq;
}
//exit;
//change collation
//changeCollation();

?>