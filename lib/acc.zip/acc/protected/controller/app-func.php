<?php

include_once $lib_app_path."protected/controller/app-func-acc-defvar.php";
include_once $lib_app_path."protected/controller/updatedb.php";
include_once $lib_app_path."protected/controller/app-func-acc.php";
include_once $lib_app_path."protected/controller/app-func-laporan.php";

//isi default acc
?>