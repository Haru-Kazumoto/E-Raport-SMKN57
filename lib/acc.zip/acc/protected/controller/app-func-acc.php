<?php


function getFldJTrans($jtrans,$fld="cap") {
	global $gAJTransLengkap;
	foreach($gAJTransLengkap as $gj) {
		if ($gj['kode']==$jtrans) return $gj[$fld];
	}	
}
function jtrans($sjtrans=""){
	global $jtrans;
	return (strstr(",$sjtrans,",",$jtrans,")==""?false:true);
}
//update hrgbeli terakhir dan hrgjual terakhir, hrgbj:b (beli),j(jual)
function updateDefHrg($skdbrg,$kdlokasi, $jtrans="PB"){
	$akdbrg=explode(",",$skdbrg);
	if (strstr(",PB,",",$jtrans,")!='') {
		$isBeli=true;
		$syjtrans="
		and (h.jtrans='PB' and h.kdlokasi='$kdlokasi')
		";
		$fld="defhrgbeli";
	} else {
		$isBeli=false;
		$syjtrans="
		and ((h.jtrans='SL' or h.jtrans='JE') and h.kdlokasi='$kdlokasi') ";
		$fld="defhrgjual";
		
	}
	$ssql="";
	$ketSql="";
	$c="";
	$ssq="";
	global $idbd,$hbt,$isTest;
	foreach($akdbrg as $kdbrg) {
		$kdbrg=trim($kdbrg);
		$sqj=	"select d.id as idbd,d.hrg as hbt from tbpbelid d 
		inner join tbpbeli h on d.notrans=h.notrans 
		where d.kdbrg='$kdbrg' 		
		$syjtrans
		
		order by h.tgl desc, h.id desc
		limit 0,1
		";
		extractRecord($sqj);
		if ($isTest )echo "<br><br>$sqj>$idbd ";
		if ($idbd*1==0) {
			if ($isBeli) {
				$hbt=carifield("select hrgawal from tbpstock where kdbrg='$kdbrg' and kdlokasi='$kdlokasi' ")*1;
			}
		} 
		$hbt*=1;
		if ($hbt>0) {
			$ssq="update tbpstock set $fld=$hbt where kdbrg='$kdbrg' and kdlokasi='$kdlokasi' ;";
		}
	}
	querysql($ssq);
	if ($isTest) echo $ssq;
}
//update hrgjual khusus yg hrgjualnya diset saat pembelian (input-pembelian2)
function updateHrgJual($skdbrg="",$kdlokasi=""){
	if (is_array($skdbrg)) {
		$akdbrg=$skdbrg;
	}else {
		$akdbrg=explode(",",$skdbrg);
	}
	$ssq="";
	
	$sfstock="";
	global $hrgjold,$hrgjnew,$idbd,$isTest;
	foreach ($akdbrg as $kdbrg) {
		$idbd=0;
		/*
		$sq="select d.id as idbd,b.hrgjual as hrgjold,d.defhrgj as hrgjnew 
		from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans
		inner join tbpbarang b on d.kdbrg=b.kdbrg
		where d.kdbrg='$kdbrg' and h.jtrans='PB' and h.kdlokasi='$kdlokasi' order by h.tgl desc limit 0,1";
*/

		$sq="select d.id as idbd,s.defhrgjual as hrgjold,d.defhrgj as hrgjnew 
		from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans
		inner join tbpstock s on (d.kdbrg=s.kdbrg and h.kdlokasi=s.kdlokasi)
		where d.kdbrg='$kdbrg' and h.jtrans='PB' and h.kdlokasi='$kdlokasi' order by h.tgl desc limit 0,1";

		extractRecord($sq);		
		if (($hrgjold<>$hrgjnew) && ($idbd>0)) {
			//$ssq.="update tbpbarang set hrgjual='$hrgjnew' where kdbrg='$kdbrg';";
			$ssq.="update tbpstock set defhrgjual='$hrgjnew' where kdbrg='$kdbrg' and kdlokasi='$kdlokasi';";
		}
	}
	querysql($ssq);
	if ($isTest) echo $ssq;
}

	
function updateSaldoAwalPB() {
	global $op,$aid,$idRecord,$sawal,$tgl,$defKdBranch,$xjp;
	
	//if (op("tb,ed,hp")){
	$jristan=($xjp=="PM"?"AH":"AP");
	
	if (op("hp")) {
		$sq="delete from tbpbeli where jtrans='$jristan' and ".changeParamSySql2($aid,$fld="kdpembantu",$param=",",$oprx="=","or")."' ";
	}elseif (op("tb,ed")) {
		$xtgl=tgltosql($_REQUEST['tglsawal']);
		$sawal=unmaskRp($_REQUEST['sawal']);
		
		if ($sawal==0)
			$sq="delete from tbpbeli where jtrans='$jristan' and kdpembantu='$idRecord'";
		else {
			$c=carifield("select id from tbpbeli where  jtrans='$jristan' and kdpembantu='$idRecord' ");
			$notrans="$jristan$defKdBranch-$idRecord";
			if ($c=="") {
				$sq="insert into tbpbeli(notrans,tgl,jtrans,kdpembantu,kdbranch,brutto,netto) 
				values('$notrans','$xtgl','$jristan','$idRecord','$defKdBranch','$sawal','$sawal')";
			} else {
				$sq="update   tbpbeli set brutto='$sawal',netto='$sawal',tgl='$xtgl' where kdpembantu='$idRecord' and jtrans='$jristan'";
				
			}
		}			
	}
	
	if ($sq!='') {
		querysql($sq);
		//echo "<br>$sq";
	}
	//}
}

//saldo hutang piutang
function getSaldoHP($kdpembantu,$formatted=true){
	global $defKdBranch,$jp,$sawal;
	$addsy="";
	if ($defKdBranch!="") $addsy=" and kdbranch='$defKdBranch'";
	
	//extractRecord("select sawal,jpembantu as jp from tbppembantu where id='$kdpembantu' $addsy ");
	$sawal=0;//sudah dimasukkan di tbpbeli dengan kode AH/AP
	//saldo hutang
	$sqs="select sum(netto-paidtoday-paidafter-retur) from tbpbeli h
	where kdpembantu='$kdpembantu' $addsy ";
	
	if ($jp=="pm") { //hutang
		$addSy="and ( h.jtrans='PB' or h.jtrans='AH' ) ";
	} else { //piutang
		$addSy="and ( h.jtrans='SL' or h.jtrans='JE' or h.jtrans='AP') ";
	}
	//echo "$sqs $addSy";
	$sq="$sqs $addSy";
	$c2=carifield($sq);
	$c=$sawal*1+$c2*1;
	return($formatted?maskRp($c,1,0):$c);
}

//echo "uselokasi $useLokasi>>";

function tbAksiNotif(){	 	
	global $r,$det,$br;
	$b='';//$r['kdbrg'];
	
	$rndx=rand(1223,9712312);
	//if (usertype("sa")) {
		/*
		$b.="
		<span id=tt$rndx></span>
		<a class='btn btn-success btn-xs' title='Analisis' href=# onclick=\"bukaAjaxD('tt$rndx','index.php?det=analisis&kdbrg=$r[kdbrg]&isDetail=1&newrnd=$rndx','width:1100,height:200','awalEdit($rndx)');return false;\" >Analisis</a>
		";
		*/
		$b.=buatBtn([
			'cap'=>'view',
			'title'=>'View',
			'opsi'=>'width:wMax',
			'url'=>"index.php?det=$r[detnotif]&op=$r[opnotif]&id=$r[idtrans]",
			'cls'=>'btn btn-mini btn-xs btn-info',
			'target'=>"idtd$det$br"
			]);
		
		if ($r['stat']!=20) {
			$b.=" ".buatBtn([
			'cap'=>'ACC',
			'title'=>'ACC',
			'opsi'=>'width:300',
			'url'=>"index.php?det=listnotif&op=approve&detnotif=$r[detnotif]&idtrans=$r[idtrans]&id=$r[id]",
			'cls'=>'btn btn-mini btn-xs btn-success',
			'target'=>"idtd$det$br"
			]);
		}
	//}
	

		
	return $b; 
}

function tbAksiBrg(){	 	
	global $r,$det,$br;
	$b='';//$r['kdbrg'];
	
	$rndx=rand(1223,9712312);
	if (usertype("sa")) {
		/*
		$b.="
		<span id=tt$rndx></span>
		<a class='btn btn-success btn-xs' title='Analisis' href=# onclick=\"bukaAjaxD('tt$rndx','index.php?det=analisis&kdbrg=$r[kdbrg]&isDetail=1&newrnd=$rndx','width:1100,height:200','awalEdit($rndx)');return false;\" >Analisis</a>
		";
		*/
		$b.=buatBtn([
			'cap'=>'UK',
			'title'=>'Ubah Kode Barang',
			'url'=>"index.php?det=barang&op=ubahkdbrg&kdbrg=$r[kdbrg]",
			'cls'=>'btn btn-mini btn-xs btn-danger',
			'target'=>"idtd$det$br"
			]);
	}
	

		
	return $b; 
}

function tbAksiPembayaranHutang($jaksi=1){	 	
	global $r,$det,$br;
	$b='';//$r['kdbrg'];
	
	$rndx=rand(1223,9712312);
	if ($jaksi==1) {
	
	/*
	$b.=buatBtn([
		'cap'=>'Auto Allocated',
		'title'=>'Alokasi Otomatis',
		'url'=>"index.php?det=pembelian&op=alokasibayar&kdbrg=$r[kdbrg]",
		'cls'=>'btn btn-mini btn-xs btn-danger',
		'target'=>"idtd$det$br"
		]);
	*/
	}	
	return $b; 
}


function tbAksiStock($idStock,$kdlokasi='') {
	global $det,$br,$r,$appMode;
	$b=buatBtn([
		'cap'=>'HU',
		'title'=>'Hitung Ulang',
		'url'=>"index.php?det=stockbarang&op=hu&id=$idStock",
		'cls'=>'btn btn-mini btn-xs btn-warning',
		'target'=>"idtd$det$br"
		]);
		
	if ($appMode!='production') {
		$b.=buatBtn([
			'cap'=>'STA',
			'title'=>'Ubah Stock Akhir',
			'url'=>"index.php?det=stockbarang&op=ubahsta&id=$idStock",
			'cls'=>'btn btn-mini btn-xs btn-info',
			'target'=>"idtd$det$br"
			]);
	}
	
	/*
	$b.=buatBtn([
		'cap'=>'MG',
		'title'=>'Merger Barang ke Barang Lain',
		'url'=>"index.php?det=barang&op=mergebrg&kdbrg=$r[kdbrg]",
		'cls'=>'btn btn-mini btn-xs btn-danger',
		'target'=>"idtd$det$br"
		]);

	*/
	return $b;
	//"<a href='#' class='btn btn-xs btn-mini btn-primary' title='Hitung Ulang Stock' onclick='return false;'>Hitung Ulang</a>";
}

function tbAksiProduksi($id) {
	global $det,$br,$rnd,$r,$appMode;
	$rndx=genRnd();
	$b='';
	/*
	$b.=buatBtn([
		'cap'=>'LT',
		'title'=>'List Trans',
		'url'=>"index.php?det=listtrans&jtrans=PG&kdproduksi=$r[kdproduksi]",
		'cls'=>'btn btn-mini btn-xs btn-info',
		'target'=>"_blank"
		]); 
	*/
	
	$b.=buatBtn([ 
		'cap'=>'BB',
		'title'=>'Input Bahan Baku',
		'url'=>"index.php?det=prod-bbaku&vkdproduksi=$r[kdproduksi]&newrnd=$rndx&parentrnd=$rnd",
		'cls'=>'btn btn-mini btn-xs btn-info',
		'target'=>"idtd$det$br",
		'func'=>"awalEdit($rndx)"
		]); 
	$b.=buatBtn([ 
		'cap'=>'BJ',
		'title'=>'Input Bahan Jadi',
		'url'=>"index.php?det=prod-bjadi&xkdproduksi=$r[kdproduksi]&newrnd=$rndx&parentrnd=$rnd",
		'cls'=>'btn btn-mini btn-xs btn-primary',
		'target'=>"idtd$det$br",
		'func'=>"awalEdit($rndx)"
		]); 
		
	if ($r['psstat']<100) {
		$b.=buatBtn([ 
			'cap'=>'Finish',
			'title'=>'Finish',
			'url'=>"index.php?det=produksi2&kdproduksi=$r[kdproduksi]&op=finish&newrnd=$rndx&parentrnd=$rnd",
			'cls'=>'btn btn-mini btn-xs btn-success',
			'target'=>"idtd$det$br",
			'func'=>"awalEdit($rndx)"
		]); 
			
	}
	return $b;
	//"<a href='#' class='btn btn-xs btn-mini btn-primary' title='Hitung Ulang Stock' onclick='return false;'>Hitung Ulang</a>";
}

function tbAksiTrans($jtrans) {
	global $r,$rndx;
	$btn="";
	$btn.="
		<span id=tt$rndx></span>
	";
	if (usertype("sa")) {
	$btn.="
		<a class='btn btn-success btn-xs btn-mini' title='Analisis' href=# 
		onclick=\"bukaAjaxD('tt$rndx','index.php?det=gltrans&op=showgl&notrans=$r[notrans]&isDetail=1&lengkap=1&newrnd=$rndx',
		'width:1100,height:500','awalEdit($rndx)');return false;\" >GL</a>
		";
			
	}
	if (jtrans("SL,JE,PG,BB,BJ")) {
		$nop="showdethppj";
		$btn.="
		<a class='btn btn-info btn-xs btn-mini' title='Detail HPP' href=# 
		onclick=\"bukaAjaxD('tt$rndx','index.php?det=pembelian&op=$nop&notrans=$r[notrans]&jtrans=$jtrans&newrnd=$rndx',
		'width:1100,height:500','awalEdit($rndx)');return false;\" >HPP</a>
		";
	
	}
	return $btn;
	
}

function tbAksiLapPemakaianStock() {
	$rndx=rand(123,98771);
	global $r;
	$btn="";
	
	$btn.="
		<span id=tt$rndx></span>
		<a class='btn btn-success btn-xs btn-mini' title='Analisis' href=# 
		onclick=\"bukaAjaxD('tt$rndx','index.php?det=lap-pemakaian-stockd&idbb=$r[id]&isDetail=1&newrnd=$rndx',
		'width:wMax,height:hMax','awalEdit($rndx)');return false;\" >Detail</a>
		";
			
	return $btn;
	
}

//update control account
function updateCA($showMsg=false){
	global $db,$oNamaTb;
	$sy="where aktif=1";
	$sacc=getstring("select distinct(value) from $oNamaTb->kontrolAkun $sy");
	$sy=changeParamSySql2($sacc,$fld="account_code",$param=",",$oprx="=","or");
	$ssq="update ".$oNamaTb->akun." set acc=0;";
	$ssq.="update ".$oNamaTb->akun." set acc=1 where $sy;";
	mysql_query2($ssq);	
	if ($showMsg) echo um412_falr("Update Control Account Sukses","success");
}


function showListPembantu($jpembantu,$func='',$nama='kdpembantu') {
	global $r,$defKdBranch,$$nama;
	if (!isset($kdpembantu)) $kdpembantu='';
	if (isset($r['kdpembantu'])) {
		$kdpembantu=$r['kdpembantu'];
	}
	$addSy="";
	if ($defKdBranch!='') $addSy.=" and kdbranch='$defKdBranch'";
	return um412_isicombo5("select id,nama,alamat,kota from tbppembantu where jpembantu='$jpembantu'
	$addSy",$nama,'id','nama kota','',$$nama,"$func");
}


function isiCbProduksi($nama,$kdbranch="",$stat="",$func="") {
	return showListProduksi($nama,$kdbranch,$stat,$func);
}
function showListProduksi($nama,$kdbranch="",$stat="",$func="") {
	global $r,$$nama,$defKdBranch;
	$addsy="";
	if ($kdbranch=="") $kdbranch=$defKdBranch;
	if ($kdbranch!='')$addsy.=" and p.kdbranch='$kdbranch'";
	
	if ($stat!="") $addsy.=" and p.stat='$stat'";
	return um412_isicombo6("select kdproduksi, concat( tglmulai,' ',j.jenis) as jj from tbpproduksi2 p 
	left join tbpproduksij j on p.kdjp=j.kdjp where p.kdbranch='$kdbranch'
	$addsy order by p.tglmulai asc",$nama,$func);
	
}

function isCbPJ($jabatan='',$func='') {
	return showListPj($jabatan,$func) ;
}

function showListPj($jabatan='',$func='') {
	global $r,$kdpj;
	$adds="";
	if ($jabatan!='') $adds.=" and jabatan='$jabatan'";
	return um412_isicombo5("select id,nama from tbppegawai where 1 $adds ",'kdpj','id','nama','',$kdpj,"$func");
}

function showGL($notrans,$lengkap=false) {
	global $idtrans,$tgl,$catatan,$oNamaTb,$fldAccNo;
	$rndx=rand(1,2913);
	extractRecord("select id as idtrans,tgl,catatan from  ".$oNamaTb->gl."  where notrans='$notrans' ");
 
	$t="
	<hr>
	<div class='row trowju' >
	<div class='tketju' id='ju-$idtrans' title='$idtrans'>  ".tglIndo2($tgl,'d x Y')." - $notrans  - $catatan</div>";
	$sq="
	select g.*,prk.account_name as nmprk,prk.account_code2 
	from ".$oNamaTb->gld." g left join ".$oNamaTb->akun." prk on g.kdprk=prk.account_code  
	where g.notrans='$notrans' order by g.id
	";
	$h=mysql_query2($sq);
	while ( $ro=mysql_fetch_array($h)) {
		$d=$k="&nbsp;";
		if ($ro['jlhuang']>=0)
			$d=maskRp(abs($ro['jlhuang']));
		else
			$k=maskRp(abs($ro['jlhuang']));
			
		$cls=($ro['jlhuang']>=0?"tjudebet":"tjukredit");
		$t.="<div class='row $cls' >".
		'<span class=col-sm-2>'.$ro[$fldAccNo].'</span>'.
		'<span class=col-sm-4>'.$ro['nmprk'].'</span>'.
		'<div class=col-sm-3 style="text-align:right;display:block">'.$d.'</div>'. 
		'<div class=col-sm-3 style="text-align:right;display:block">'.$k.'</div>' 
		."</div>";
		
	}
	$t.="
	<style>
	.trowju {
		margin-left:20px;
	}
	</style>
	
	</div>
	";
	
	if ($lengkap) {
		global $js_path,$nmCaptionTabel;
		$t="
		<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >
			<div class='tbviewatas noprint' style='margin:0px 0 10px 0;text-align:right' >
					<button class='btn btn-success btn-sm' onclick=\"printDiv('tview_$rndx')\">Cetak</button>
			</div>
			<div class='tview' id='tview_$rndx'>
			<div class=page>
				<h2 class=titleview>$nmCaptionTabel</h2>
				$t
			</div>
		</div>";
	}
	
	return $t;
}


function getPrk($kdPrk,$fld='account_name') {
	global $oNamaTb;
	//$fld=($xfld==1?"kdprk1":($xfld==2?"kdprk2":"kdprk3"));
	 $sq="select $fld from ".$oNamaTb->akun." where account_code='$kdPrk'";	
	return carifield($sq);
}

function getKdPrkTrans($jtrans,$xfld=1) {
	$fld=($xfld==1?"kdprk1":($xfld==2?"kdprk2":"kdprk3"));
	$sq="select $fld from tbpjtrans where jtrans='$jtrans'";
	
	return carifield($sq);
}
function getKdPrkKas($mk="M",$kdbranch="") {
	global $defKdBranch;
	if ($kdbranch=="") $kdbranch=$defKdBranch;
	$sq="select ".($mk=="M"?"kdprkkasm":"kdprkkask")." from tbpbranch where kdbranch='$kdbranch'";
	$kdPrkkas=carifield($sq);
	
	$jmk=($mk=="M"?'penerimaan_tunai':'pembayaran_tunai');
	if ($kdPrkkas=='') $kdPrkkas=getAcc($jmk);
	return $kdPrkkas;
}

function getBranch($kdbranch) {
	return carifield("select branch from tbpbranch where kdbranch='$kdbranch'");
}
function getLokasi($kdlokasi) {
	return carifield("select lokasi from tbplokasi where id='$kdlokasi'");
}
function getKdBranch($branch) {
	return carifield("select kdbranch from tbpbranch where branch='$branch'");
}

function getPegawai($kdpegawai) {
	return carifield("select nama from tbppegawai where id='$kdpegawai'");
}
function getKdPegawai($namapeg) {
	return carifield("select id from tbppegawai where nama='$namapeg'");
}

Function getACC($ket, $fld = 0,$forceAdd=0) { //'0:get account control (acc_kode),1:get account control (account name)
	global $ga,$idacc,$oNamaTb;
    extractRecord("select `value` as ga,id as idacc from ".$oNamaTb->kontrolAkun." where `name`='$ket'");
	
	if (($idacc=="")&& ($forceAdd==1)) {
		$ga=30999;
		mysql_query2("insert into ".$oNamaTb->kontrolAkun."(`name`,`ket`,`value`,aktif) values('$ket','$ket','$ga',1)");
	}
	if ($fld == 1) $ga = cariField("select account_name from ".$oNamaTb->akun." where account_code='$ga' ");
    return $ga;
}

Function getPembantu($kdpembantu,$fld="nama") {
    return cariField("select $fld from tbppembantu where  id='$kdpembantu'");
}

Function getAsset($kdasset) {
    return cariField("select nama_asset from tbpasset where id='$kdasset'");
}

Function getMK($jtrans) { //'get masuk/keluar
    $ga = cariField("select `defdk` from tbpjtrans where jtrans='$jtrans'");
    return $ga;
}

Function updateGLTransBeli($notrans,$vjtrans="") {
	global $isTest,$jtrans,$oNamaTb;
	global $tglgl,$kdpembantu,$paidToday,$namaPb,$byOprBeli,$byAngkut,$byAngkutEst,$pDeposit,$nopo,$kdpembantu,$disc2;
	global $byAngkutTunai,$byKuli,$byTimbang;
	global $hpp,$tdisc,$jcb,$hrgkotor,$kdprkkasbeli;
	global $ballance;
	if ($vjtrans!="") $jtrans=$vjtrans;
	
	$log="";
	
	$sqq="
	select b.tgl as tglgl,b.kdprkkas as kdprkkasbeli, kdpembantu,paidtoday as paidToday,
	b.catatan,p.nama as namaPb,b.nopo,disc2,
	bytimbang as byTimbang,byopr as byOprBeli, 
	bykuli as byKuli,byangkut as byAngkut,
	byangkutest as byAngkutEst,byangkuttunai as byAngkutTunai,pdeposit as pDeposit 
	,ballance
	from tbpbeli b left join tbppembantu p on b.kdpembantu=p.id where b.notrans='$notrans'";
	extractRecord($sqq);
	
	if ($isTest) echo  "
	<br><br><b>Update GL Transaksi </b>
	Jtrans : $jtrans<br>
	$sqq<br>";
		
	$tglgl=sqltotgl($tglgl);
	//$varjlh = ((($jtrans == "SR" )|| ($jtrans == "PR"))? "jlh_retur":"jlh_terima");
	//$varjlh = strstr("SR,PR",$jtrans) != ""? "jlh_retur":"jlh_terima";
	$varjlh = "jlh_terima";
	
	//querysql( "delete from ".$oNamaTb->gl." where notrans='$notrans';");
	
	$kdPrkKasKeluar = ($kdprkkasbeli==0?getACC("pembayaran_tunai"):$kdprkkasbeli);
	$kdPrkKasMasuk = ($kdprkkasbeli==0?getACC("penerimaan_tunai"):$kdprkkasbeli);
	$kdPrkDepositPM = getACC("deposit_pm");
	$kdPrkDepositPL = getACC("deposit_pl");

	$kdPrkPenyesuaianPsd = getACC("penyesuaian_persediaan");

	$kdPrkjual = getACC("default_sales_act");
	$kdPrkDiscJual = getACC("default_sales_discount_act");
	//$kdPrkDiscJual2 = getACC("default_sales_discount_act");

	$kdPrkByAngkutjual = getACC("freight_act");;
	$kdPrkByOprBeli = getACC("biaya_opr_beli");;
	$kdPrkByKuli = getACC("biaya_kuli",0,$forceAdd=1);
	$kdPrkByTimbang = getACC("biaya_timbang",0,$forceAdd=1);
	

	$kdPrkPiutang = getACC("debtors_act");
	$kdPrkHPP = getACC("default_cogs_act");
	$kdPrkBonus = getACC("cadangan_bonus_penjualan");

	$kdPrkDiscBeli = getACC("pyt_discount_act");
	$kdPrkByAngkutbeli = getACC("biaya_angkut_pembelian");

	$kdPrkHutang = getACC("creditors_act");
	$kdPrkRBeli = getACC("retur_pembelian");
	$kdPrkRJual = getACC("retur_penjualan");
	$kdPrkPersediaan = getACC("default_inventory_act");
	$kdPrkPersediaanBDP = getACC("default_inventory_act_bdp");
	$kdPrkPersediaanBJ = getACC("default_inventory_act_bj");
	$kdPrkBalProduksi = getACC("penyeimbang_by_produksi");
	
	global $hpp,$tdisc,$jcb,$hrgkotor,$hrgkotorD,$hrgkotorK;
	//produksi
	if ($jtrans=="PD") {
		$sq="select sum(hpp*$varjlh) as hpp,sum(hrg*$varjlh) as hrgkotor,sum(disc*$varjlh) as tdisc  ,sum(cbonus*$varjlh) as jcb  from tbpbelid 
		where notrans='$notrans' and jlh_terima>=0";
		extractRecord ($sq);
		$hrgkotorD=round($hrgkotor,0);
		
		$sq="select sum(hpp*$varjlh) as hpp,sum(hrg*$varjlh) as hrgkotor,sum(disc*$varjlh) as tdisc  ,sum(cbonus*$varjlh) as jcb  from tbpbelid 
		where notrans='$notrans' and jlh_terima<0";
		extractRecord ($sq);
		$hrgkotorK=round($hrgkotor,0);
		updateGLTrans ($notrans, $catatan, $kdPrkPersediaan, 0 , $jtrans, $tglgl, 0);			
		updateGLTransD($notrans, $catatan, $kdPrkPersediaan, $hrgkotorD,0,"Stock In");
		updateGLTransD($notrans, $catatan, $kdPrkPersediaan, $hrgkotorK,1,"Stock Out");
		return;
		
	}else if (($jtrans=="PG") || ($jtrans=="BB")|| ($jtrans=="BJ")) {
		//packaging
		//bb/bdp/bjadi
		
		$ajn=explode(",","bb,bj,bdp");
		$akdprk=[$kdPrkPersediaan,$kdPrkPersediaanBJ,$kdPrkPersediaanBDP];
		$idx=0;
		
		$catatan="";
		updateGLTrans ($notrans, $catatan, $kdPrkPersediaan, 0 , $jtrans, $tglgl, 0);
		updateGLTransD($notrans,"deltrans");
		
		$i=0;
		foreach($ajn as $jns) {
			$kdPrkPd=$akdprk[$i];
			$idx++;
			
			
			$sq="select sum(hpp*$varjlh) as hpp,sum(hrg*$varjlh) as hrgkotor,sum(disc*$varjlh) as tdisc    from tbpbelid d inner join tbpbarang b
			on d.kdbrg=b.kdbrg";
			//echo "<br>kdprkpd $kdPrkPd<br>";
			if ($jtrans=="PG") {
				
				$sq1="$sq where notrans='$notrans' and jlh_terima>=0 and b.jenis='$jns'";
				
				$hrgkotor=0;
				extractRecord ($sq1);
				$jlhu=round($hrgkotor,0);
				updateGLTransD($notrans, $catatan, $kdPrkPd, $jlhu,$idx,"Stock In");
				
				$idx++;
				$sq2="$sq where notrans='$notrans' and jlh_terima<0  and b.jenis='$jns' ";
							$hrgkotor=0;
				extractRecord ($sq2);
				$jlhu=round($hrgkotor,0);
				updateGLTransD($notrans, $catatan, $kdPrkPd, $jlhu,$idx,"Stock Out");
			}elseif ($jtrans=="BB") {
				//bahan baku			
				$sq1="$sq where notrans='$notrans'  and b.jenis='$jns'";

				$hrgkotor=0;
				extractRecord ($sq1);
				$jlhu=round($hrgkotor,0);
				updateGLTransD($notrans, $catatan, $kdPrkPd, $jlhu*-1,$idx,"Stock In");				
			}elseif ($jtrans=="BJ") {
				//bahan baku			
				$sq1="$sq where notrans='$notrans'  and b.jenis='$jns'";

				$hrgkotor=0;
				extractRecord ($sq1);
				$jlhu=round($hrgkotor,0);
				updateGLTransD($notrans, $catatan, $kdPrkPd, $jlhu,$idx,"Stock In");				
			}
			
			$i++;
		}
		//packaging
		//bb/bdp/bjadi
		
		$idx++;
		if ($jtrans=='PG')
			updateGLTransD($notrans, $catatan, $kdPrkBalProduksi, $ballance*-1,0,"");
		elseif ($jtrans=='BB')
			updateGLTransD($notrans, $catatan, $kdPrkPersediaanBDP, $ballance,$idx,"");
		elseif ($jtrans=='BJ')
			updateGLTransD($notrans, $catatan, $kdPrkPersediaanBDP, $ballance*-1,$idx,"");
			
		//echo "sampai lho..... ";exit;
		return;
		
	}else if ($jtrans=="PU") {
		
		
	} else {
		$sq="select sum(hpp*$varjlh) as hpp,sum(hrg*$varjlh) as hrgkotor,sum(disc*$varjlh) as tdisc  ,sum(cbonus*$varjlh) as jcb  from tbpbelid where notrans='$notrans'";
		extractRecord ($sq);
		$hrgkotor=round($hrgkotor,0);
	}
	//hpp dihitung dari terpakai
	$hpp=carifield("select sum(jlh*hpp) from tbpbelid_terpakai where notrans='$notrans'")*1;
	if ($hpp==0) $hpp=$hrgkotor;
	$disc = $tdisc*1;
	
	$tk = ($hrgkotor - $disc == $paidToday?"Tunai":"Kredit");
	$jlhUang = 0;
	$catatan = getFldJTrans($jtrans,"cap")."- $namaPb";
	If ($nopo != "") $catatan.="/ $nopo";

	//$kdPrkDiscBeli2 = getACC("pyt_discount_act");// 'potongan pembayaran digabung

	
	
	//biaya kuli walaupun sebenarnya tunai, tetapi permintaan custom dianggap sebagai hutang/piutang. biaya kuli tunai dibayarkan lewat jurnal pengeluaran kas
	//hutang piutang
	//sisa (biaya angkut-biaya angkut tunai) dianggap sudah dibayar saat barang datang
	//$kdPrkDiscBeli2 = getACC("pyt_discount_act");// 'potongan pembayaran digabung
//hitung sisa biaya angkut dan estimasi, otomatis jadi deposit
	//Dim jlhDeposit, byAngkutReal

	$kali = 1;
	
	
	//jika byAngkut>0, yg digunakan byAngkut, selain itu yg digunakan byAngkutEst
	//hitung sisa biaya angkut dan estimasi, otomatis jadi deposit
	$ketByAngkut="Biaya Angkut";
	If ($byAngkut > 0){
		$jlhDeposit = ($byAngkutEst - $byAngkut) - $pDeposit;
		$byAngkutReal = $byAngkut;
	} Else {
		$jlhDeposit = 0 - $pDeposit;
		$byAngkutReal = $byAngkutEst;
		$ketByAngkut.= " Est";
	}
	//echo "bya $byAngkutRe";
	$jlhTunai = round($paidToday*1-$byAngkutTunai,0);//jumlah pengeluaran
	//$netto = $hrgkotor - $disc - $disc2 + $byAngkutEst+$byOprBeli+$byKuli+$byTimbang ;//' valrf(frm.txtfields(7).Text)
	$netto = $hrgkotor - $disc - $disc2 + $byAngkutReal+$byOprBeli+$byKuli+$byTimbang ;//' valrf(frm.txtfields(7).Text)
	$jlhDeposit = 0 - $pDeposit;
	$jlhKredit = $netto - $jlhTunai +$jlhDeposit;
	 
	//echo "jumlah deposit -------------->$jlhDeposit";
	//hapus data lama dulu
	$sq= "
	delete from ".$oNamaTb->gl." where notrans='$notrans';
	delete from ".$oNamaTb->gld." where notrans='$notrans';";
	querysql($sq);
	$log.=$sq;
	$kali = 1;
	$jlhhpp = cariField("select sum(jlh_terima*hpp) as jlhhpp from tbpbelid where notrans='$notrans'");
	
	if (strstr("PA",$jtrans)!="") { //penyesuaian stock
			$jlhsubtot = cariField("select sum(jlh_terima*hrg) as jlhsubtot from tbpbelid where notrans='$notrans'");
			updateGLTrans ($notrans, $catatan, $kdPrkPersediaan, $jlhsubtot  * $kali, $jtrans, $tglgl, $kdpembantu,0,"Kas keluar $jtrans");
			updateGLTransD($notrans, $catatan, $kdPrkPenyesuaianPsd, 1 * $jlhsubtot * $kali,0,"Penyesuaian Persediaan");
			updateGLTransD($notrans, $catatan, $kdPrkPersediaan, -1 * $jlhsubtot * $kali,0,"Persediaan ");
			
	} else If (strstr("SL,JE,SR",$jtrans) !="") {
			//'kdpembantu = frm.txtfields(2)
			If ($jtrans == "SR"){ 
				$kali = -1;
				$kdprkT=$kdPrkRJual;
			} else {
				$kdprkT=$kdPrkjual;
			}
			
			updateGLTrans ($notrans, $catatan, $kdPrkKasMasuk, $jlhTunai * $kali, $jtrans, $tglgl, $kdpembantu,0,"Kas keluar $jtrans");
			updateGLTransD($notrans, $catatan, $kdPrkT, -1 * $hrgkotor * $kali );//'retur/penjualan
			updateGLTransD($notrans, $catatan, $kdPrkDiscJual, ($disc + $disc2) * $kali,0,"Potongan Penjualan"); //penjualan
			updateGLTransD($notrans, $catatan, $kdPrkPiutang, $jlhKredit * $kali,0,"Piutang");
			updateGLTransD($notrans, $catatan, $kdPrkKasMasuk, $jlhTunai * $kali,0,"Penjualan Tunai");
			updateGLTransD($notrans, $catatan, $kdPrkDepositPL, -1 * $jlhDeposit,0,"Deposit ");
			
			updateGLTransD($notrans, $catatan, $kdPrkHPP, $jlhhpp * $kali,0,"Hpp");
			updateGLTransD($notrans, $catatan, $kdPrkPersediaan, -1 * $jlhhpp * $kali,0,"Persediaan");
			
			updateGLTransD($notrans, $catatan, $kdPrkByOprBeli, $byOprBeli * $kali,0,"Biaya Operasional Beli");			

			updateGLTransD($notrans, $catatan, $kdPrkByAngkutjual, -1 * $byAngkutReal * $kali,0,$ketByAngkut);
			updateGLTransD($notrans, $catatan, $kdPrkByAngkutjual, $byAngkutReal * $kali, 1,$ketByAngkut);
			updateGLTransD($notrans, $catatan, $kdPrkKasMasuk, -1 * $byAngkutReal * $kali, 1,"Pemasukan By Angkut");
	//pemakaaian bb		
	} else If (strstr("BB",$jtrans) !="") {
			//'kdpembantu = frm.txtfields(2)
			//kdprkhpp diganti dengan kdprkbdp
			//$kdPrkPersediaanBDP = getACC("default_inventory_act_bdp");
	
			$kdprkT=$kdPrkjual;
			
			updateGLTrans ($notrans, $catatan, $kdPrkKasMasuk, $jlhTunai * $kali, $jtrans, $tglgl, $kdpembantu,0,"Kas keluar $jtrans");
			updateGLTransD($notrans, $catatan, $kdPrkT, -1 * $hrgkotor * $kali );//'retur/penjualan
			//updateGLTransD($notrans, $catatan, $kdPrkDiscJual, ($disc + $disc2) * $kali,0,"Potongan Penjualan"); //penjualan
			//updateGLTransD($notrans, $catatan, $kdPrkPiutang, $jlhKredit * $kali,0,"Piutang");
			//updateGLTransD($notrans, $catatan, $kdPrkKasMasuk, $jlhTunai * $kali,0,"Penjualan Tunai");
			//updateGLTransD($notrans, $catatan, $kdPrkDepositPL, -1 * $jlhDeposit,0,"Deposit ");
			
			updateGLTransD($notrans, $catatan, $kdPrkPersediaanBDP, $jlhhpp * $kali,0,"Hpp");
			updateGLTransD($notrans, $catatan, $kdPrkPersediaan, -1 * $jlhhpp * $kali,0,"Persediaan");
			
			//updateGLTransD($notrans, $catatan, $kdPrkByOprBeli, $byOprBeli * $kali,0,"Biaya Operasional Beli");			

			//updateGLTransD($notrans, $catatan, $kdPrkByAngkutjual, -1 * $byAngkutReal * $kali,0,$ketByAngkut);
			//updateGLTransD($notrans, $catatan, $kdPrkByAngkutjual, $byAngkutReal * $kali, 1,$ketByAngkut);
			//updateGLTransD($notrans, $catatan, $kdPrkKasMasuk, -1 * $byAngkutReal * $kali, 1,"Pemasukan By Angkut");
			
	} elseif (strstr("PP,PB,PR,DM,DK",$jtrans)!="") {
		If (($jtrans == "PR" )||($jtrans == "DK")) { 
			$kali = -1;
		}
		
		updateGLTrans ($notrans, $catatan, $netto, $hrgkotor * $kali, $jtrans, $tglgl, $kdpembantu," netto $jtrans");
		updateGLTransD($notrans, $catatan, $kdPrkPersediaan, $hrgkotor * $kali,0,"Persediaan Masuk");
		updateGLTransD($notrans, $catatan, $kdPrkByAngkutbeli, $byAngkutReal * $kali,0,"By angkut Beli");
		updateGLTransD($notrans, $catatan, $kdPrkByOprBeli, $byOprBeli * $kali,0,"Biaya Operasional Beli");			
		updateGLTransD($notrans, $catatan, $kdPrkHutang, -1 * $jlhKredit * $kali,0,"Hutang");
		updateGLTransD($notrans, $catatan, $kdPrkDiscBeli, -1 * ($disc*1 + $disc2*1) * $kali,0,"Pot Pembelian");// penjualan
		updateGLTransD($notrans, $catatan, $kdPrkKasKeluar, -1 * $jlhTunai * $kali,0,"Pembayaran tunai");
		updateGLTransD($notrans, $catatan, $kdPrkDepositPM, $jlhDeposit,0,"Deposit");
	}
	//conn1.CommitTrans		
}

function updateGLAndStockTransBeli($sid,$op="hp"){
	//global $op;
	
	$aid=explode(",",$sid);
	global $jtrans,$notrans,$kdlokasi;
	$i=0;
	foreach($aid as $id) {
		if (op("del,hp")) {
			extractRecord("select jtrans,notrans,kdlokasi from tbpbeli where id='$id'");
			$skdbrg=getstring("select kdbrg from tbpbelid where notrans='$notrans' ",",");
			$sq="delete from tbpbelid where  notrans='$notrans'  ";
			mysql_query2($sq);
			updateGLTransBeli($notrans,$jtrans);
			updateStockTrans($skdbrg,$kdlokasi,$jtrans);
			
		}
		$i++;
	}
}

function getJlhTerima($kdbrg,$notrans){
	return carifield("select jlh_terima from tbpbelid where notrans='$notrans' and kdbrg='$kdbrg'")*1;
	
}


Function getStAkhir($kdbrg, $kdlokasi = 0, $op = "cek") {
	global $sqStAkhir0;
    $s = $sqStAkhir0;
	$addSy=($kdlokasi == 0? "": " and  kdlokasi='$kdlokasi'");	
    return cariField("select sum($s) from tbpstock where kdbrg='$kdbrg' $addSy ")*1;
}


Function getStAkhirByID($id, $op = "cek") {
	global $sqStAkhir0;
	 return cariField("select $sqStAkhir0 from tbpstock where id='$id'")*1;
}


//cek stok sebelum penyimpanan penjualan
function cekStSbJual($notrans,$kdlokasi){
	$i=0;
	//$kdlokasi,$jtrans
	$s="";
	foreach ($_REQUEST["d_id"] as $idd) {
		$kdbrg=$_REQUEST["d_kdbrg"][$i];
		$jlh=$_REQUEST["d_jlh_terima"][$i]*1;
		$jlhlama=getJlhTerima($kdbrg,$notrans);
		$sta=getStAkhir($kdbrg,$kdlokasi);
		$sta2=$sta-($jlh-$jlhlama);
		if ($sta2<0) {
			$s.="<br>Stock Tidak Mencukupi, Kode: $kdbrg, Lokasi:$kdlokasi, Stock Akhir:$sta2, Dibutuhkan: $jlh ";
		}
		$i++;
	}
	return $s;
}


Function updateGLTransPelunasan($snotrans) {
	global $oNamaTb,$isTest;
	global $tglgl,$kdpembantu,$paidToday,$namaPb,$jlhbayar,$snotrans,$jtrans,$kdPrk1;
		
	if ($snotrans=="") return "";
	$anotrans=explode(",",$snotrans);
	foreach ($anotrans as $notrans ) {
		$ssq="select b.tgl as tglgl,kdpembantu,b.catatan,p.nama as namaPb,b.kdprk1 as kdPrk1,jlhbayar,snotrans from 
		tbpbayar b left join tbppembantu p on b.kdpembantu=p.id where b.kdbayar='$notrans'";
		//echo "<br>".$ssq;
		
		$jlhbayar=(round($jlhbayar,0));
		extractRecord($ssq,1,1);
		
		$tglgl=sqltotgl($tglgl);
		
	//	echo "<br>tgl:$tglgl,kdpb:$kdpembantu,namapb:$namaPb,jlhby:$jlhbayar,jtrans:$jtrans;	";
		$catatan = ($jtrans == "PP" ? " Penerimaan Piutang ":($jtrans =="PH"? "Pembayaran Hutang ":" $jtrans"))." - $namaPb, ref:$snotrans ";
		
		$kdPrkKasKeluar =$kdPrk1;// getACC("pembayaran_tunai");
		$kdPrkKasMasuk = $kdPrk1;//getACC("penerimaan_tunai");
		
		$kdPrkPiutang = getACC("debtors_act");
		$kdPrkHutang = getACC("creditors_act");
		
		//hapus data lama dulu
		querysql( "delete from ".$oNamaTb->gl." where notrans='$notrans';");
		If ($jtrans == "PP" ) {
				updateGLTrans ($notrans, $catatan, $kdPrkKasMasuk,$jlhbayar, $jtrans, $tglgl, $kdpembantu);
				updateGLTransD($notrans, $catatan, $kdPrkKasMasuk, $jlhbayar ,0);//'retur penjualan
				updateGLTransD($notrans, $catatan, $kdPrkPiutang,$jlhbayar*-1,0 );//'retur penjualan
		} else If ($jtrans == "PH" ) {
				//'kdpembantu = frm.txtfields(2)
				updateGLTrans ($notrans, $catatan, $kdPrkKasKeluar,$jlhbayar, $jtrans, $tglgl, $kdpembantu);
				updateGLTransD($notrans, $catatan, $kdPrkKasKeluar, $jlhbayar*-1 ,0);//'retur penjualan
				updateGLTransD($notrans, $catatan, $kdPrkHutang,$jlhbayar,0 );//'retur penjualan
		} else {
			echo "<br>jtrans $jtrans err";
		}
	}
}

 

Function updateGLTrans($notrans, $catatan, $kdPrkkas, $jlhUang, $jtrans, $tgl, $kdpembantu = "", $kdPj = "") {
	global $defKdBranch,$isTest,$oNamaTb;
	$log="<br><b>update GL Trans</b>";
	$tgl=tgltosql($tgl);
	$catatan = str_replace( "'", "`",$catatan);
	$ss = "select id as idtrans from `".$oNamaTb->gl."`  where notrans='$notrans' ";
	$idtrans = cariField($ss);
	$log.="<br>cek updateGLTrans :$idtrans >$ss <br>";
	$sqSet = "jtrans='$jtrans',jenisju='$jtrans',notrans='$notrans',tgl='$tgl',kdpembantu='$kdpembantu',catatan='$catatan',kdprkkas='$kdPrkkas',jlhuang='$jlhUang'";
	$sqSet.= ",kdbranch='$defKdBranch'";
	
	If ($idtrans == "")  
		$sq = "insert into ".$oNamaTb->gl." set $sqSet";
	else
		$sq = "update ".$oNamaTb->gl." set $sqSet where id=$idtrans";
	$log.="<br>$sq";
	if ($isTest) echo $log;
	querysql($sq);
}

function delTransBeli($aid,$jtrans){
	$sy=changeParamSySql2($aid,$fld="id",$param=",",$oprx="=","or");
	$akdlokasi=getString("select distinct(kdlokasi) from tbpbeli where $sy","array");
	foreach ($akdlokasi as $kdlokasi) {
		$sq="select notrans from tbpbeli where ($sy) and kdlokasi='$kdlokasi'";
		$anotrans=getString($sq,"array");
		$skdbrg="";
		foreach ($anotrans as $notrans) {	
			$skdbrg.=",".getstring("select kdbrg from tbpbelid where notrans='$notrans' ",",");
			mysql_query2("delete from tbpbelid where  notrans='$notrans' ");
			mysql_query2("delete from tbpbelid_terpakai where  notrans='$notrans'  ");
			updateGLTransBeli($notrans,$jtrans);
			mysql_query2("delete from ".$oNamaTb->gl." where  notrans='$notrans' ");
			mysql_query2("delete from ".$oNamaTb->gld." where  notrans='$notrans' ");
		}
		updateStockTrans($skdbrg,$kdlokasi,$jtrans);
	}	
}

/*
idc:kode hapus, menghapus semua ".$oNamaTb->gld." yg kdprk,notrans dan idcnya sama 	 
	jika dalam 1 transaksi ada kdprk yang sama dan tidak ingin dihapus kdprk yg lama, maka gunakan idc: 0,1,2 dst
*/
Function updateGLTransD($notrans, $catatan, $kdPrk=0, $jlhUang=0, $idc = 0,$txtDebug="") { 
	global $isTest,$oNamaTb;
	$log="";
	if ($isTest) 
		echo "<br>$txtDebug > <b>updateGLTransD</b> <br>notrans:$notrans, catatan :'$catatan', kdprk:$kdPrk, jlhuang:$jlhUang, idc=$idc<br>";
	if (($catatan=="deltrans") ) {
		mysql_query2("delete from ".$oNamaTb->gld." where notrans='$notrans'");
		return;
	} 
	
	if ($kdPrk==0) {
		echo  "<br>Err kdprk:0->module updateGLTransD($notrans, $catatan, $kdPrk, $jlhUang, $idc)";
		return;
	}
	global $defKdBranch;
	$sy = " notrans='$notrans' and kdPrk='$kdPrk' and idc=$idc" ;
	$sq="select id from ".$oNamaTb->gld." where $sy" ;
	$C = cariField($sq)*1;
	if ($jlhUang == 0)  {
		//$sq="delete from ".$oNamaTb->gld." where id='$C'";
		//mysql_query2($sq);
		$log.= "jumlah uang nol ya...";
		return;
	} 
	elseif ($C!=0) {
		$sq="delete from ".$oNamaTb->gld." where id='$C'";
		mysql_query2($sq);
		$C=0;
	} 
	$log.= "<br>Pencarian data gld awal: $sq <br>hasil:$C";
	
	//echo "<br>squpdate:  $sq";
	If ($C == 0 )
	  $sq="insert into ".$oNamaTb->gld." set idc=$idc,cek=1,notrans='$notrans', jlhuang='$jlhUang',kdprk='$kdPrk'";
	else
	  $sq="update ".$oNamaTb->gld." set idc=$idc,cek=1,notrans='$notrans', jlhuang='$jlhUang',kdprk='$kdPrk' where id='$C'"  ;

	mysql_query2($sq);
	if ($isTest) echo "<br>$log<br>$sq";

}

function tbActGaji(){
	global $r,$det,$lv,$nop;
	$btn='';
	$rndx=rand(1223,9712312);
	
	$btn.="<a class='btn btn-primary btn-xs' title='Cetak Kuitansi' href=# 
		onclick=\"bukaJendela('index.php?det=$det&id=$r[id]&isDetail=1&newrnd=$rndx&op=view&custom=kuitansi','width:1100,height:200','awalEdit($rndx)');return false;\" >
		<i class='fa fa-print' ></i></a>
	";
	 
	$btn.="
	<span id=tt$rndx></span>
	
	";
	
	return $btn;
	
}


function isiComboPembantu($nama,$jpembantu) {
	global $rnd,$defKdBranch,$userType;
	return um412_isicombo6("select id,concat(nama,'-',kota) from tbppembantu where jpembantu='$jpembantu' ".($userType=="marketing"?" and kdbranch='$defKdBranch'":"")." order by nama",$nama,"");
	
}

/*
jenis:0/1:detail,header, 1200:piutang,11100:kas,
40000/40001/40002(belum):pendapatan/header/detailinclude acccontrol,
50000/500001:hpp/header,...
*/
function isiComboAcc($nama,$allowAdd=0,$jenis=25,$kdbranch='',$def='',$func=""){
	global $rnd,$kdPrk,$d_kdprk,$defKdBranch,$$nama,$oNamaTb;
	//$ev=" global $$nama;$"."def=$$nama; ";
	$ev="$$nama='$def';";
	@eval($ev);
	$addsy="";
	if ($jenis==1) {
		$addsy.="and ish=1";
	}
	elseif (($jenis==0)||($jenis==25)) {
		$addsy.="and ish=0";
	}
	elseif ($jenis==10000) {//jenis piutang
		$addsy.="and ish=0 and account_code>=10000 and account_code<20000 and not(account_name like '%depr%') ";
	}elseif ($jenis==12000) {//jenis piutang
		$addsy.="and ish=0 and account_code>=12000 and account_code<20000 and not(account_name like '%depr%') ";
	} elseif ($jenis==11100) {//jenis kas
		$addsy.="and ish=0 and account_type=25 ";
	} elseif ($jenis==13000) {//jenis barang dagangan
		$addsy.="and ish=0 and account_type=27 ";
		//if (userType("kasir")) $addsy.=" and account_name like '%Kas%' ";
	} elseif ($jenis==40000) {//jenis pendapatan
		$addsy.="and ish=0 and account_code>=40000 and account_code<50000 ";
	} elseif ($jenis==40001) {//jenis pendapatan
		$addsy.="and ish=1 and account_code>=40000 and account_code<50000 ";
	} elseif ($jenis==40025) {//jenis pendapatan
		$addsy.="and ish=0 and ( (account_code>=40000 and account_code<50000) or (account_type=25) ) ";
	} elseif ($jenis==50000) {//jenis pengeluaran
		$addsy.="and ish=0 and account_code>=50000 and account_code<60000 ";
	} elseif ($jenis==50001) {//jenis pendapatan
		$addsy.="and ish=1 and account_code>=50000 and account_code<60000 ";
	} elseif ($jenis==50025) {//jenis pendapatan
		$addsy.="and ish=0 and ( (account_code>=50000 and account_code<60000) or (account_type=25) ) ";
	} elseif ($jenis==60000) {//jenis pengeluaran
		$addsy.="and ish=0 and account_code>=60000 and account_code<70000 ";
	} elseif ($jenis==60001) {//jenis pengeluaran
		$addsy.="and ish=1 and account_code>=60000 and account_code<70000 ";
	} elseif ($jenis==60025) {//jenis pendapatan
		$addsy.="and ish=0 and ( (account_code>=60000 and account_code<70000) or (account_type=25) ) ";
	}
	
	if ($kdbranch!='') {
		$addsy.=" and kdbranch='$kdbranch'";
	} else {
		if (!usertype("sa")) {
			$addsy.=" and ( kdbranch='' or kdbranch='$defKdBranch') ";
		}
	}
	$tx="";
	 
	$sqs="select account_code,account_name from ".$oNamaTb->akun." where 1 $addsy order by account_name";
	if (substr($nama,0,2)=="d_") {
		//$nama=str_replace("#no#",$no,$nama);
		$kdPrk=$def;
	}
	//echo "default $nama:".$$nama;
	if ($allowAdd==1)
		$tx.= isiComboAA($sqs,$nama,"index.php?det=prk&op=itb&newrnd=3$rnd",'',"awalEdit(3$rnd);$func");
	else
		$tx.= um412_isiCombo6($sqs,$nama,$func);
	return $tx;
}

function isiComboBrg($nama,$allowAdd=0,$func=""){
	global $rnd,$kdPrk,$d_kdprk,$def;
	$addsy="";
	$t="";
	 
	$sqs="select kdbrg,nmbarang from tbpbarang order by nmbarang ";
	if (substr($nama,0,2)=="d_") {
		$kdbrg=$def;
	}
	if ($allowAdd==1)
		$t.= isiComboAA($sqs,$nama,"index.php?det=barang&op=itb&newrnd=3$rnd",'',"awalEdit(3$rnd);$func");
	else
		$t.= um412_isiCombo6($sqs,$nama,$func);
	//$t=str_replace("select","sel",$t);
	return $t;
}

function getByProduksi($kdproduksi,$jenis='BB',$formated=false){
	$sqfrom=" from tbpbeli h inner join tbpbelid d on h.notrans=d.notrans 
	where  h.kdproduksi='$kdproduksi' ";
 
	if (($jenis=='BB')||($jenis=='bal')) {
		$jlhbb=carifield("select sum(hpp*jlh_terima) $sqfrom and h.jtrans='BB' ")*1;
	}
	
	if (($jenis=='BJ')||($jenis=='bal')) {
		$jlhbj=carifield("select sum(hrg*jlh_terima) $sqfrom  and h.jtrans='BJ' ")*1;
	}
	
	if ($jenis=='BB')
		$c=$jlhbb;
	elseif ($jenis=='BJ')
		$c=$jlhbj;
	elseif ($jenis=='bal') {
		$c=$jlhbb-$jlhbj;
		//return "$c = $jlhbb -$jlhbj";
	}
	return ($formated?maskRp($c,0,0):$c);
}

//includetgl: tgl2 ikut dihitung atau tidak
function getSaldoAkhir($kdPrk,$tgl2="",$includeTgl=1) {
	global $useKdBranch,$kdbranch,$oNamaTb;
	if (($kdPrk=="N") || ($kdPrk==33000)) {//cari laba rugi
		$syprk1="account_code<'40000'";		
		$syprk2="kdprk<'40000'";		
	} else {
		$syprk1="account_code='$kdPrk'";
		$syprk2="kdprk='$kdPrk'";
		
	}
	$addsy=($tgl2==""?"":" and tgl".($includeTgl==1?"<=":"<")."'$tgl2'  ");
 
	if ($useKdBranch)
		$sq1="select sum(sawal)  from `0_chart_sa`  where $syprk1 and kdbranch='$kdbranch'";
	else
		$sq1="select sum(sawal)  from `".$oNamaTb->akun."`  where $syprk1 ";
	
	$sq2="select sum(d.jlhuang) from `".$oNamaTb->gld."` d inner join `".$oNamaTb->gl."` h on d.notrans=h.notrans where $syprk2 $addsy";
	$sakhir=carifield($sq1)*1+carifield($sq2)*1;
	//return $sq1;
	if (($kdPrk=="N") || ($kdPrk==33000)) $sakhir=$sakhir*-1;
	
	return $sakhir;
}

function getLabaRugi($tgl2=""){
	//cari saldo akhir semua perkiraan
	return getSaldoAkhir("N",$tgl2);
}
 

function buatLinkViewTrans($id,$notrans="",$maxl=100) {
	global $media,$oNamaTb;
	$xnotrans=$notrans;
	$cap=$notrans;
	if (strlen($cap)>$maxl) {
		$cap1=potong($cap,$maxl,true,"","/");
		$cap2=substr($cap,strlen($cap1),strlen($cap));
		$cap="$cap1<br>$cap2";
		
	}
	if ($notrans=="") $notrans=carifield("select notrans from ".$oNamaTb->gl." where id='$id'");
	if ($media=='xls')
		return $cap;
	else
		return "<a href='#' onclick=bukaAjaxD('tdialog','index.php?det=transaksi&id=$id&op=view&contentOnly=1','width:1000')>$cap</a>";

}


function buatLinkDafHutang($idnlink,$kdpembantu,$jtrans,$defnotrans="",$maxl=100) {
	global $media;
	$ai=explode(",",$idnlink);
	$idlink=$ai[0];$nmlink=$ai[1];
	$cap=($defnotrans==''?'Cari':$defnotrans);
	$t="";
	$tempat="tdia".rand(123,456);
	$t.="<span id='$tempat' style='display:none'></span>";
	$t.= "<a href='#' onclick=\"bukaAjaxD('$tempat','index.php?det=gv&kdpembantu=$kdpembantu&op=caritransterhutang&jtrans=$jtrans&contentOnly=1','width:1000') \" >$cap</a>";
	$t.="<input type=text id='$idlink' name='$nmlink' value='$defnotrans'>";
return $t;
}

function updatePelunasan($snotrans,$jtrans){
	$anotrans=array_unique(explode(",",$snotrans));	
	//echo "<br><br><br>snow: ".$snotrans;
	$s="";
	foreach ($anotrans as $notrans) {
		if (trim($notrans)!='') {
			//echo "<br>-----> not $notrans";
			$pelunasan=carifield("select sum(jlhbayar) from tbpbayard where notrans='$notrans'");
			$s.="update tbpbeli set paidafter='$pelunasan' where notrans='$notrans' ;";
		}
	}
	querysql($s);
	//echo $s;
		
}
function updateJlhRetur($nopo,$kosongkanRetur =false) {
	global $isTest,$db;
	$ssq="";
	if ($kosongkanRetur) {
		$jlhretur=0;
		$ssq.="update tbpbelid set jlh_retur='0' where notrans='$nopo';";
	}
	else {
		$jlhretur=carifield("select sum(netto) from tbpbeli where nopo='$nopo'")*1;
		$dt=$db->query("select * from tbpbelid where notrans='$nopo'")->fetch();
		foreach($dt as $r) {
			$kdbrg=$r['kdbrg'];
			$jr=carifield("select sum(jlh_terima) as jr from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans where h.nopo='$nopo' and kdbrg='$kdbrg';");
			$jr*=1;
			$ssq.="update tbpbelid set jlh_retur='$jr' where notrans='$nopo' and kdbrg='$kdbrg';";
			//update jlhterpenuhi juga...
			
		}		
	}
	
	$ssq.="update tbpbeli set retur='$jlhretur' where notrans='$nopo';";
	if ($isTest) echo $ssq;
	querysql($ssq);
}   
/*
//update jlhbayar yang ada di transbeli
function updateJlhBayar($skdbayar){
	$akdbayar=explode(",",$skdbayar);
	global $db;
	$ssq="";
	foreach($akdbayar as $kdbayar) {
		$snotrans=getString("select notrans from tbpbayard where kdbayar='$kdbayar'");
		$ant=explode(",",$snotrans);
		foreach($ant as $notrans) {
			$jlhb=carifield("select sum(jlhbayar) from tbpbayard where notrans='$notrans'")*1;
			$ssq.="update tbpbeli set paidafter='$jlhb' where notrans='$notrans' ";
			
		}
		
	}
	if ($ssq!='') {
		querysql($ssq);
	}
}	
*/

Function isiListCBKas($nama="kdprk1",$func="",$jkas="KM") {
	global $rnd,$$nama,$defKdPrkKasM,$defKdPrkKasK,$oNamaTb;
	if (!isset($$nama)) {
		$$nama=($jkas=="KM"?$defKdPrkKasM:$defKdPrkKasK);
	}
	
	return isiComboAcc($nama,$allowAdd=0,$jenis=11100,"",$$nama);
	/*
	return um412_isicombo6("select account_code,account_name from ".$oNamaTb->akun." 
	where (account_type like '25%' or account_name like '%PROMO%' or account_name like '%DEPOSIT%' 
	or account_name like '%KAS%') and ish=0 ",$nama,$func);
	*/
}


Function isiListCBTipeAkun($nama="tipe",$func="") {
	global $rnd,$$nama,$oNamaTb;
	return um412_isicombo6("select id,name from ".$oNamaTb->tipeAkun." order by id ",$nama,$func);

}

function isiCbBranch($nama="kdbranch",$func="") {
	global $$nama,$defKdBranch;
	//if ($$nama=='') $$nama=$defKdBranch;
	return um412_isicombo6("select kdbranch,branch from tbpbranch order by branch",$nama,$func);
	
}

function isiCbPeriodeLap($nama="periode"){
	global $rnd,$$nama;
	return um412_isiCombo6("Hari Ini,Minggu Ini,Bulan Ini,Tahun Ini,All Time,Custom","periode","gantiPeriode($rnd)");
}
function isiComboLokasi($nama,$func) {
	global $$nama;
	return "deprecated isiComboLokasi, use isiCbLokasi";//um412_isicombo6("select id,lokasi from tbplokasi order by lokasi",$nama,$func);
	
}
Function isiCbLokasi($nama='kdlokasi',$func='',$kdbranch='') {
	global $rnd,$$nama,$defKdBranch,$defKdLokasi;
	$sy='';
	if ($kdbranch!='') 
		$sy.=" and kdbranch='$kdbranch' ";
	elseif ($defKdBranch) {
		$sy.=" and kdbranch='$defKdBranch' ";
		
	}
	
	if (!isset($$nama)) $$nama=$defKdLokasi;
	return um412_isicombo6("select id,lokasi from tbplokasi where 1 $sy order by lokasi","$nama","$func");
}

Function isiCbDepartemen($nama='kddept',$func='') {
	global $rnd,$$nama,$defKdBranch;
	$sy='';
	return um412_isicombo6("select kode,departemen from tbppegawai_mdept where 1 $sy order by departemen","$nama","$func");
}

Function isiCbBrg($kdlokasi='',$nama='kdbrg') {
	global $rnd,$$nama;
	$sy='';
	if ($kdlokasi!='') 
		$sq="select b.kdbrg,concat(nmbarang,' - ',b.kdbrg) from tbpbarang b inner join tbpstock s on b.kdbrg=s.kdbrg where s.kdlokasi='$kdlokasi' ";
	else
		$sq="select b.kdbrg,concat(nmbarang,' - ',b.kdbrg) from tbpbarang b ";
	return um412_isicombo6($sq,"$nama");
}

Function isiCbBrgStock($kdlokasi='',$nama='idstock') {
	global $rnd,$$nama;
	$sy='';
	if ($kdlokasi!='') 
		$sq=" select s.id,concat(nmbarang,' - ',b.kdbrg) from tbpbarang b 
	inner join tbpstock s on b.kdbrg=s.kdbrg where s.kdlokasi='$kdlokasi' ";
	else
		$sq=" select 1 where 1=2";
	return um412_isicombo6($sq,"$nama","");
}

function getBarang($kdbrg){
	return carifield("select nmbarang from tbpbarang where kdbrg='$kdbrg'");
}

function getKetTransJU($id,$def="") {
	global $oNamaTb;
	if ($def!="") 
		return $def;
	else {
		return getstring("select a.account_name from ".$oNamaTb->gl." m inner join ".$oNamaTb->gld."  d on m.notrans=d.notrans inner join ".$oNamaTb->akun." a on d.kdprk=a.account_code where m.id='$id' ");
		
		
	}
}

function emptyDBAcc(){
	global $oNamaTb;
	$stb="tbpbeli,tbpbelid,tbpbelid_terpakai,tbpasset,tblog,tbppembantu,tbpstock,tbpstockd,tbpstock_tmp,tbpbarang,tbpbarangg,tbpbarangj";
	$stb.=",tbkendaraan";
	$atb=explode(",",$stb);
	$ssq='';
	foreach ($atb as $tb) {
		$ssq.="<br>truncate table $tb;";
	}
	echo $ssq;	
	
}

//update hpp metode avg
function updateHPPAllTrans($lim=0) {
	global $sqStAkhir0;
	//$sqStAkhir0="(stawal+stbeli-strbeli-stjual+strjual+stadjust+stprodm-stprodk+stex+stdistm-stdistk) ";

	$lim*=1;
	$limb=140000;
	$ssq="";

	if ($lim==0) {
		$ssq.="
			update tbpbeli set tgl='2021-05-06' where notrans='SL210506000002' and tgl='0000-00-00';	
			update tbpbeli set tgl='2021-01-27' where notrans='SL201027000004' and tgl='2003-10-27';	
			update tbpbelid set hpp=hrg where notrans like 'pb%';
			drop table if exists tbpbarang_tmp1;
			CREATE TABLE tbpbarang_tmp1 LIKE tbpbarang;
			INSERT INTO tbpbarang_tmp1 SELECT * FROM tbpbarang;

			drop table if exists tbpstock_tmp1;
			CREATE TABLE tbpstock_tmp1 LIKE tbpstock;
			INSERT INTO tbpstock_tmp1 SELECT * FROM tbpstock;
			update tbpstock_tmp1 set stbeli=0,stjual=0,strbeli=0,strjual=0,stdistk=0,stdistm=0;
			update tbpbarang_tmp1 set defhrgbeli =0,hrgpokok=0;
		";
		
		querysql($ssq);
	} else {
		
	}
		$ssqBalik1="
			drop table if exists tbpbarang_bak;
			CREATE TABLE tbpbarang_bak LIKE tbpbarang;
			INSERT INTO tbpbarang_bak SELECT * FROM tbpbarang;

			drop table if exists tbpstock_bak;
			CREATE TABLE tbpstock_bak LIKE tbpstock;
			INSERT INTO tbpstock_bak SELECT * FROM tbpstock;
		";
		$ssqBalik2="
			drop table if exists tbpbarang;
			CREATE TABLE tbpbarang LIKE tbpbarang_tmp1;
			INSERT INTO tbpbarang SELECT * FROM tbpbarang_tmp1;

			drop table if exists tbpstock;
			CREATE TABLE tbpstock LIKE tbpstock_tmp1;
			INSERT INTO tbpstock SELECT * FROM tbpstock_tmp1;
		";


	$sq="select id,notrans,jtrans,tgl,kdlokasi from tbpbeli 
	where NOT(notrans like 'SAPL%') order by tgl 
	limit $lim,$limb ";

	$t='';
	$dt=$db->query($sq)->fetch();
	$br=0;
	foreach($dt as $r) {
		$br++;
		$xbr=$br+$lim;
		$notrans=$r['notrans'];
		$jtrans=$r['jtrans'];
		$kdlokasi=$r['kdlokasi'];
		
		$t.="<br><br>$xbr > No Trans : $r[notrans], JTrans: $jtrans, Tgl : $r[tgl], id : $r[id],Lokasi $kdlokasi ";
		$fldstock='';
		$updateHPPBrg=false;
		$updateHPPPenjualan=false;
		if ($jtrans=='PB') {
			$fldstock='stbeli';
			$updateHPPBrg=true;
		} elseif (($jtrans=='SL') |($jtrans=='JE')) {
			$fldstock='stjual';
			$updateHPPPenjualan=true;
		}
		
		if ($fldstock=="") {
			echo "<h2>$jtrans</h2>";exit;
		}
		$sq2="select * from tbpbelid where notrans='$notrans'";
		$dt2=$db->query($sq2)->fetch();
		$t.="-><br>".$db->sql;
		$ssq2='';
		foreach($dt2 as $r2) {
			$idd=$r2['id'];
			$kdbrg=$r2['kdbrg'];
			$jlh=$r2['jlh_terima']*1;
			$hrg=$r2['hrg']*1;
			//$hppOld=carifield("select hrgpokok from tbpstock_tmp1 where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'")*1;
			$hppOld=carifield("select hrgpokok from tbpbarang_tmp1 where kdbrg='$kdbrg' ")*1;
			if ($updateHPPBrg) {
			$t.="<br>Notrans:$notrans Kdbrg:$kdbrg Jlh:$jlh hpp Old:$hppOld";
				if ($hppOld==0) {
					$hppNew=$hrg*1;
				} else {
					$stAkhirOld=carifield("select $sqStAkhir0 from tbpstock_tmp1 where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'")*1; //' 
					if ($stAkhirOld<=0) {
						$hppNew=$hrg;
					} else {					
						$jaa=$stAkhirOld+$jlh;
						if ($jaa==0) $jaa=1;
						$hppNew=($stAkhirOld*$hppOld+$jlh*$hrg)/($jaa);
					}
				}
				$ssq2="update tbpbarang_tmp1 set hrgpokok='$hppNew' where kdbrg='$kdbrg'";
				querysql($ssq2);				
				/*
				$ssq2="update tbpstock_tmp1 set defhrgbeli='$hppNew' where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'";
				querysql($ssq2);				
				*/
				$t.="<br>Update HPP : $ssq2";

			}
			
			if ($updateHPPPenjualan) {
				$ssq2="update tbpbelid set hpp='$hppOld' where id=$idd;";
				querysql($ssq2);
				$t.="<br>$ssq2";
			}	
			$ssq2="update tbpstock_tmp1 set $fldstock=$fldstock+$jlh where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'";
			querysql($ssq2);
			$t.="<br>$ssq2";
			
		}//detail
		//if ($ssq2!='') 
	}//all transaksi

	querysql($ssqBalik2);
	echo $t;
	
}
function cekExistStockBrg($skdbrg, $kdlokasi, $autoAdd = True,$stawal=0,$hrgawal=0) {
	global $isTest;
	if ($skdbrg=="") return;
	if ($skdbrg=="all") {
		 $skdbrg=getstring("select kdbrg from tbpbarang where inactive=0");
	}
	$x=true;
	$akdbrg=explode(",",$skdbrg);
	$ssql="";
	$ketSql="";
	$c="";
	foreach($akdbrg as $kdbrg) {
		$kdbrg=trim($kdbrg);
		if ($kdbrg!='') {
			$sy="kdbrg='$kdbrg' and kdlokasi='$kdlokasi'";
			$sq="select kdbrg from tbpstock where $sy";
			$ketSql.="<br>$sq";
			$c = cariField($sq);
			If ($c == "") {
				
				If ($autoAdd)  {
					//cari hrgawal
					$hrgawal=carifield("select defhrgbeli from tbpbarang where kdbrg='$kdbrg'");
					$adds1=$adds2="";
					/*
					if ($stawal!=0) {
						$adds1="stawal,hrgawal";
						$adds2="$stawal,$hrgawal";
					}
					*/
						$adds1=",hrgawal";
						$adds2=",'$hrgawal'";
					
					$sqi="insert into tbpstock(kdbrg,kdlokasi $adds1) values('$kdbrg','$kdlokasi' $adds2);";
					$c=mysql_query2($sqi);
					//mysql_insert_id();
					//$ssql.=$sqi;
					$ketSql.="<br>$sqi";
				}
			} else {
				//hanya sekedar update stock
				if ($stawal!=0) {
					$sqi="update tbpstock set stawal=$stawal,hrgawal='$hrgawal' where $sy";
					$ssql.=$sqi;
					$ketSql.="<br>$sqi";
				}
			}
		}
	}
	if ($ssql!="") querysql($ssql);
	if ($isTest) {
		//echo "<br>Checking $skdbrg autoadd:$autoAdd ><br>$ketSql<br>";
	}
	return $c;
}

/*
function updateStockTerpakai($jenisidb,$idb,$update=true){
	global $log,$kdbrg,$db;
	$sqc="select sum(jlh) as jlhk from tbpbelid_terpakai 
	where jenisidb='$jenisidb'  and idbb=$idb and cek=1";
	$terpakai=carifield($sqc);
	$sq = "update ".(($jenisidb=="sa"?"tbpstock":"tbpbelid")." set jlh_terpakai=$terpakai where id=$idb ";
	$log.="<br> Update Pemakaian Stock ".(isset($kdbrg)?$kdbrg:"")." : 
	$sqc
	<br>$sq";
	if ($update) 
		querysql($sq);
	else 
		return $sq;
}
*/
/*
hitung ulang stockbarang, 
untuk program lama, ada data di tabel tbodistribusid, 
belum dihitung di sini
*/
function updateStockTrans($skdbrg="",$kdlokasi="",$sjtrans="",$tb="tbpbelid"){
	global $isTest,$gAJTrans;
	if ($skdbrg=="") return;
	$skdbrg = implode(',', array_unique(explode(',', $skdbrg)));
	cekExistStockBrg($skdbrg, $kdlokasi ) ;
	
	if ($sjtrans=="") 
		$sjtrans=implode($gAJTrans);//"SL,JE,PB,SR,PR,PA,DD,DK,PD,PG";
	elseif (($sjtrans=="SL")||($sjtrans=="JE"))
		$sjtrans="SL,JE";
	elseif (($sjtrans=="PD")||($sjtrans=="PG"))
		$sjtrans="PD,PG";//produksi n packaging
		
	$ajtrans=explode(",",$sjtrans);
	
	if (is_array($skdbrg)) {
		$akdbrg=$skdbrg;
	}else {
		$akdbrg=explode(",",$skdbrg);
	}
	$ssql="";
	
	$sfstock="";
	
	//$astock=array();
	foreach ($ajtrans as $jtrans) {
		$fldstock=getFldJTrans($jtrans,"fldstock");
		if ($fldstock!="") {
			if (strstr(",$sfstock",",$fldstock,")=="") {
				$operasi="new";
				$sfstock.="$fldstock,";
			} else {
				$operasi="add";
				
			}
			$ii=0;
			foreach($akdbrg as $kdbrg) {
				$sy="kdbrg='$kdbrg' and  h.kdlokasi='$kdlokasi' and h.jtrans='$jtrans'";
				$sq="select sum(d.jlh_terima) from tbpbelid  d 
				inner join tbpbeli h on d.notrans=h.notrans where $sy";
				$c=carifield($sq)*1; 
				
				//$astock[$ii]=$c;
				
				if ($operasi=="new")
					$ssql.="update tbpstock set $fldstock=$c where kdbrg='$kdbrg' and kdlokasi='$kdlokasi';";
				else
					$ssql.="update tbpstock set $fldstock=$fldstock + $c where kdbrg='$kdbrg' and kdlokasi='$kdlokasi';";
				if (strstr("SL,PA,SR",$jtrans)) {
					//$ssql.=updateStockTerpakai(---);		
				}
				$ii++;
			}
		} // if
	} //for	
	
	querysql($ssql);
	if ($isTest) echo "<br>Update Stock :<br>$ssql";
}


//untuk merger semua barang yang namanya sama persis
function mergeBarang(){
	$sq="select kdbrg,nmbarang,kdpemasok from tbpbarang order by nmbarang,kdpemasok desc";
	$hq=mysql_query2($sq);
	$lastnb=$latkdbrg="";
	$s="";
	$skdbrg="";
	$lastkb=$lastnb="";
	querysql("update tbpstock set cacatan=''");
	while ($r=mysql_fetch_array($hq)) {
		$kdbrg=$r["kdbrg"];
		$nmbrg=$r["nmbarang"];
		if ($lastnb==$r['nmbarang']) {
			//hapus
			// Full texts	id	kdlokasi	kdbrg	stawal	stbeli	strbeli	stjual	strjual	stadjust	stpbeli	reorder	stprodm	stprodk	stdistm	stdistk	stexext
			if ($kdbrg!="") {
				$s.="update tbpbelid set kdbrg='$lastkb' where kdbrg='$kdbrg';<br>";
				//$s.="update tbpbelid_terpakai set kdbrg='$lastkb' where kdbrg='$kdbrg';<br>";
				$s.="update tbpstock set kdbrg='$lastkb',catatan='akan dihapus' where kdbrg='$kdbrg';<br>";
				$s.="delete from tbphrgjual where kdbrg='$kdbrg';<br>";
				$s.="delete from tbpbarang where kdbrg='$kdbrg';<br>";				
				;
				$skdbrg.=($skdbrg==""?"":",").$lastkb;
			}
		} else {
			$lastnb=$r["nmbarang"];
			$lastkb=$r["kdbrg"];
		}
	
		
	}
	
	//update stock
	$akdbrg=explode(",",$skdbrg) ;
	$j=0;
	foreach($akdbrg as $kdbrg){
		if ($kdbrg=="") continue;
		$sqst="select 1 as a,kdbrg,kdlokasi,sum(stawal) as ssta,sum(stbeli) as sstbeli,sum(strbeli) as sstrbeli,sum(strjual) as sstrjual,sum(stadjust) as sstadjust,sum(stpbeli) as sstpbeli,sum(stpjual) as sstpjual,sum(stprodm) as sstprodm,sum(stprodk) as sstprodk,sum(stdistm) as sstdistm,sum(stdistk) as sstdistk from tbpstock where kdbrg='$kdbrg' group by kdbrg,kdlokasi  ";
		//$s.=$sqst."<br>"	
		$hqst=mysql_query2($sqst);
		while ($r=mysql_fetch_array($hqst)) {
			//extractrow($r,1,1);
			$kdlokasi = $r['kdlokasi'];
			$ssta = $r['ssta'];
			$sstbeli = $r['sstbeli'];
			$sstrbeli = $r['sstrbeli'];
			$sstrjual = $r['sstrjual'];
			$sstadjust = $r['sstadjust'];
			$sstpbeli = $r['sstpbeli'];
			$sstpjual = $r['sstpjual'];
			$sstprodm = $r['sstprodm'];
			$sstprodk = $r['sstprodk'];
			$sstdistm = $r['sstdistm'];
			$sstdistk = $r['sstdistk'];
			$s.="update tbpstock set stawal=ssta,stbeli=sstbeli, strbeli=sstrbeli,strjual=sstrjual,
			 stadjust=sstadjust,stpbeli=sstpbeli,stpjua=sstpjual,stprodm=sstprodm,stprodk=sstprodk,stdistm=sstdistm,stdistk=sstdistk
			  where kdbrg='$kdbrg' and kdlokasi='$kdlokasi';<br> ";
		 
		}
		$j++;
	}
	if ($j>0) 
		$s.="delete from tbpstock where catatan='akan dihapus';";
	else 
		$s.="Tidak ditemukan nama barang yang sama...";
	$s=str_replace("<br>","\n",$s);
	return "<textarea cols=120 rows=10>$s</textarea>";
	
	//echo "<br>$skdbrg";
	
}


function hapusHrgJualGDP(){
	$s1=getstring("select distinct(kdbrg) from tbpbarang");
	$s2=getstring("select distinct(kdbrg) from tbphrgjual");
	$as2=explode(",",$s2);
	
	$s1=",$s1,";
	$sd="";
	$i=0;
	foreach ($as2 as $kdbrg) {
		if (strstr($s1,",$kdbrg,")=="") {
			$sqh="delete from tbphrgjual where kdbrg='$kdbrg';";
			$sd.=$sqh;
			//$sd.=($sd==""?"":",").$sqh;
			$i++;
		}
		
	}
	return "<textarea cols=120 rows=10>$i > $sd</textarea>";
}


Function reIndexJlhTerpakai($kdlokasi = "", $kdbrg = "", $notransPengecualian ="", $showMsg = True) {
    //'update statterpakai menjadi 1 jika sisa=0. jika notrans diisi, maka yg dicek hanya selain yg notran, sedangkan yg notrans dianggap belum terpakai
    //Dim sy As String, fldsisa, sq As String, julang As Integer
    global $db,$isTest;
	$log="";
    If (($kdbrg == "") || ($kdlokasi == "")) {
        echo "Err ReindexJlhTerpakai: Kode barang dan lokasi harus ditentukan";
        return 0;
	}
	$sy = " and d.statterpakai=0";
	If ($kdbrg !="")   $sy.= " and d.kdbrg='$kdbrg'";

	//julang :0 untuk mencari di saldo awal, dan 1 untuk mencari di data penjualan
	for ($julang = 0;$julang<=1;$julang++) {
		$sy2 = $sy;
		If ($notransPengecualian != "") $julang = 1;
		If ($kdlokasi!= "") {
			$sy2 .= " and " .($julang == 0? "d": "h"). ".kdlokasi='$kdlokasi'";
		}
		
		
		If ($julang == 0) {//' mencari di stock awal
			//'update distock awal
			$sq = "select * from 
			(select d.kdbrg,d.kdlokasi,h.defhrgbeli as hrg,
			stawal-if(isnull(sum(dd.jlh)),0,sum(dd.jlh)) as sisa,
				d.id, dd.jenisidb from (tbpstock d  left join tbpbarang h on d.kdbrg=h.kdbrg) left join tbpbelid_terpakai dd on (d.id=dd.idbb)  
				where (isnull(jenisidb) or jenisidb='sa') $sy2  group by d.id )  as ss where sisa=0  ";
		} Else {
			If ($notransPengecualian !="") $sy2 .= " and h.notrans <>'$notransPengecualian'";
			$fldsisa = "d.jlh_terima-d.jlh_retur-if(isnull(sum(dd.jlh)),0,sum(dd.jlh))";
			//update di detail pembelian
			$sq = "select * from (
			select 			
			d.kdbrg,h.kdlokasi,d.hrg,$fldsisa as sisa,d.id,dd.jenisidb,h.jtrans,h.notrans,h.tgl 
				from (tbpbelid d inner join tbpbeli h on d.notrans=h.notrans) left join tbpbelid_terpakai dd on d.id=dd.idbb 
				where (h.jtrans='PB' or (h.jtrans='PP' and d.jlh_terima>0)) $sy2
						and (isnull(dd.jenisidb) or dd.jenisidb='PB')  group by d.id order by tgl,d.id) as ss where sisa=0  ";
		}
		
		$log.="<br>$sq ";
		 
		$dt=$db->query($sq)->fetch();
		foreach($dt as $r) {
			If ($julang == 0) {
				$sq="update tbpbelid set statterpakai=1,jlh_terpakai=jlh_terima where id='$r[id]'";
			} Else {
				$sq= "update tbpstock set statterpakai=1,jlh_terpakai=stawal where id='$r[id]'";
			}
			$log.="<br><br>$sq";
			mysql_query2($sq);
		}	//foreach
	} //for

	If ($notransPengecualian <> "" ) {
		$sq="update tbpbelid set statterpakai=0 where notrans='$notransPengecualian'";
		$log.="<br>$sq";
		mysql_query2($sq);
	}
	If ($showMsg) echo "Reindex jlhterpakai selesai";
	//If ($showMsg) echo "Reindex tidak berhasil : ";
	//if ($isTest) echo $log;
}


//metode fifo
function getSyTransHPP($kdlokasi) {
	//mencari dari data yg masuk saja, dari -> (pembelian (PB), distribusi DD/DK,packing masuk (PG),produksi masuk (PD),barang jadi (BJ)
	return " and (
	((
	((h.jtrans='DD' or h.jtrans='PB' or h.jtrans='PD'  or h.jtrans='BJ' ) and h.kdlokasi='$kdlokasi') 
	or
	(h.jtrans='DK' and h.kdlokasi2='$kdlokasi' ))	and (d.jlh_terima-d.jlh_retur)>0)
	or (h.jtrans='PG' and d.dk='d')
	)";
}

//hitung hpp saat penjualan dan distribusi dengan metode fifo
//$hpp=  cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans,$idbj, $hpplama, $jlhlama,1 );

Function cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans,$idbj, $hpplama = 0, $jlhlama = 0,$force=false,$updateHrgJadiHPP =false) {
	global $hasilCari,$isTest,$loghpp;
	$idstock=carifield("select id from tbpstock where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'")*1;
	$hasil=0;
	//Dim fldsisa, hpp, terpenuhi, subtot, sisa, hrg, jlhterpenuhi, la 'limitawal
	//Dim jumlah, sq, xhrg
	$log="<br><b>Mencari HPP ($notrans,$kdbrg,$idbj) </b> <br>Dibutuhkan $jlhdibutuhkan, jlhlama $jlhlama <br>";
	$la = 0;
	$hpp = 0;
	$jumlah = 0;
	$terpenuhi = 0;
	$jlhterpenuhi=0;
	$subtot = 0;
	//Dim sket, idb, xjlh, aidb
	$subtot = 0;//$subtot + $hpplama * $jlhlama;
	$log.="subtot awal :hpplama $hpplama * jlhlama $jlhlama  ";
	//$jlhdibutuhkan = $jlhdibutuhkan - $jlhlama;

	$sket = "";
	$ssq="";
	//bersihkan di terpakai (sebelumnya)
	global $db;
	/*
	$sq="select t.* from tbpbelid_terpakai t where notrans='$notrans' and kdbrg='$kdbrg'";
	$loghpp.="<br>hitung jlh terpakai sebelum transaksi (semua idbb yg notrans<>$notrans) <br>".$sq;
	
	$ssq="";
	$sIdbb="";
	$dt=$db->query($sq)->fetch();
	foreach($dt as $r) {
		$idbb=$r['idbb'];
		if ($r['jenisidb']=='sa') {
			//jika ambil dari saldo awal, maka hitung ulang jumlah diambil 
			$c=carifield("select sum(jlh) from tbpbelid_terpakai where jenisidb='sa' and idbb='$idbb' and notrans<>'$notrans' ")*1;
			$ssq.="update tbpstock set statterpakai=$c,stawalterpakai='$c' where id='$idbb'; ";
		} else {
			$c=carifield("select sum(jlh) from tbpbelid_terpakai where jenisidb='pb' and idbb=$idbb and notrans<>'$notrans' ");
			$ssq.="update tbpbelid set jlh_terpakai='$c' where id='$idbb'; ";		
		}
		$sIdbb.=",$r[id]";
	}
	*/
	$ssq.="delete from tbpbelid_terpakai where notrans='$notrans' and kdbrg='$kdbrg' and idbj='$idbj';";
	
	$log.="<br>$ssq <br>";
	querysql($ssq);
	
	//Dim julang, jenisidb, gt, sk
	//Dim aket, ket, ak, qs, jt, qs2, sq1 As String
	
	//menghitung ulang stok terpakai
	$ssq="";
	$log.="<br>Data Awal: kdbrg:$kdbrg terpenuhi $terpenuhi dib $jlhdibutuhkan >";
	If (($terpenuhi < $jlhdibutuhkan) || $force ) {
		$julang = 0;// '0 untuk mencari di saldo awal, dan 1 untuk mencari di data penjualan
		x_ulang:
		//sq = "select kdbrg," & fldsisa & " as sisa,hrg from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans where h.jtrans='PB' and " & fldsisa & ">0 and kdbrg='" & kdbrg & "' and m.kdlokasi='" & kdlokasi & "' order by tgl,id limit 0,1"		
		If ($julang == 0) {//' mencari di stock awal
			//mencari jumlah terpakai dari stock awal
			$jenisidb = "sa";
			$idbb=$idstock;
			$terp=carifield("select sum(jlh) from tbpbelid_terpakai where jenisidb='sa' and idbb=$idbb and notrans<>'$notrans' ")*1;
			$sq="select kdbrg,kdlokasi,hrgawal as hrg,stawal-$terp as sisa,id from tbpstock where id=$idstock and stawal-$terp>0";
			carifield($sq)*1;
			$log.= "<br>mencari di stokawal....julang:$julang";
		} else {
			
			$fldsisa = "d.jlh_terima-d.jlh_retur-if(isnull(sum(dd.jlh)),0,sum(dd.jlh))";
			$syTransHPP=getSyTransHPP($kdlokasi);
			$log.="<br>mencari di pembelian....$julang. ";
			//mencari jumlah terpakai dari pembelian
			$jenisidb = "pb"; //mencari di pb dan produksi, hanya yg paling atas (limit 0,1 atau fifo)
			$sq = "select * from (select d.kdbrg,h.kdlokasi,d.hrg,$fldsisa as sisa,
					d.id,dd.jenisidb,h.jtrans,h.notrans,h.tgl 
					from (tbpbelid d inner join tbpbeli h on d.notrans=h.notrans) left join tbpbelid_terpakai dd on d.id=dd.idbb  
					where 
					d.statterpakai=0 and d.kdbrg='$kdbrg' 
					$syTransHPP 
					
					and (isnull(dd.jenisidb) or dd.jenisidb='PB')  
					group by d.id order by tgl,d.id) as ss where sisa>0  limit 0,1";

			cariField($sq);
			$log.= "<br>mencari di pembelian....julang:$julang";
		}
		$log.="<br>$sq<br><br>";;
		//var_dump($hasilCari);
		
		$julang ++;
		$log.="hasilcari $hasilCari[1] ";
		If ($hasilCari[1] <> "") {
			$sisa = $hasilCari[4]*1;
			$xhrg = $hasilCari[3]*1;
			$idb = $hasilCari[5]*1;
			$log.="<br> ketemu, jumlah sisa :$sisa, harga: $xhrg, id:$idb, jenis:$jenisidb > ";
			$log.="<br> jumlah dibutuhkan: $jlhdibutuhkan, jumlah tepenuhi sampai point ini:$terpenuhi > ";
			If ($sisa >= ($jlhdibutuhkan - $terpenuhi)) {
				$xjlh = ($jlhdibutuhkan - $terpenuhi);
				$subtot = $subtot + $xjlh * $xhrg;
				$terpenuhi = $terpenuhi + $xjlh;
				$log.= "<br>subtot+= $xjlh*$xhrg=$subtot > ";
				$gt = "t";
			} Else {//'jika belum terpenuhi semua
				$xjlh = $sisa;
				$subtot = $subtot + $sisa * $xhrg;
				$terpenuhi = $terpenuhi + $xjlh;
				$la ++;
				$gt = "b";
			}			
			$sk = "$idb|$xjlh|$notrans|$jenisidb";
			$sket = $sket .($sket == ""? "": "#").$sk;
		
			$sq2 = "insert into tbpbelid_terpakai(notrans,jtrans,kdbrg,idbb,idbj,jlh,hpp,jenisidb) 
			values('$notrans','$jtrans','$kdbrg','$idb','$idbj','$xjlh','$xhrg','$jenisidb')";
			querysql($sq2);
			
			if ($jenisidb=='sa') {
				//jika ambil dari saldo awal, maka hitung ulang jumlah diambil 
				$c=carifield("select sum(jlh) from tbpbelid_terpakai where jenisidb='$jenisidb' and idbb=$idstock   ");
				$sq="update tbpstock set statterpakai=0,stawalterpakai='$c' where id='$idstock';";
			} else {
				$c=carifield("select sum(jlh) from tbpbelid_terpakai where jenisidb='pb' and idbb=$idb  ");
				$sq="update tbpbelid set statterpakai=0,jlh_terpakai='$c' where id='$idb';";	
			}
			
			querysql($sq);
			
			$log.="<br>$sq2";
			//'setclipboard qs
			//'update jlh_terpenuhi
			
			//$sIdbb.=($sIdbb == ""? "": ";").$idb;
			//$sJenisIdbb.=($sJenisIdbb==""? "":";").$jenisidb;
			If ($gt == "t") {
				GoTo x_terpenuhi;
			} else {
				GoTo x_ulang;
			}
			
		} else {
			If ($julang == 1) GoTo x_ulang;
		}
		

	  //  MsgBox sket
		x_terpenuhi:
		/*If ($terpenuhi ==0) {
				//'cekHrgPokok = cariField("select defhrgbeli from tbpbarang where kdbrg='" & kdbrg & "'")
			$hasil = cariField("select hrgpokok from tbpbarang where kdbrg='kdbrg'");
			echo "tidak terpenuhi $jlhdibutuhkan hasil...... $hasil ";
		} Else {
		*/
		/*
			echo "hasil...... $hasil ";
		}
			*/	
		//   ' updateJlhTerpakai sIdbb, sJenisIdbb, notrans
		//If ($jlhdibutuhkan < $jlhterpenuhi) {
		If ($jlhdibutuhkan < $terpenuhi) {
			echo "Stock barang kurang, Jumlah dibutuhkan:$jlhdibutuhkan, Jumlah yang bisa dipenuhi: $terpenuhi ";
			return "";
		} else {
			//update hpp di tbpbelid;
			$sq4="select sum(jlh*hpp)/sum(jlh) from tbpbelid_terpakai where notrans='$notrans' and kdbrg='$kdbrg'";
			
			$hpp=carifield($sq4);
			$adds="";
			if ($updateHrgJadiHPP) $adds=",hrg='$hpp'";
			$sq="update tbpbelid set hpp='$hpp' $adds where notrans='$notrans' and kdbrg='$kdbrg'; ";
			querysql($sq);
			$log.="<br>Update hpp-> $sq4<br>$sq<br>Stock terpenuhi....";
		}
		
	}
	
	$hasil = $subtot / max(0.000000009, $terpenuhi);
	$log.="<br>subtot $subtot $hasil";
	global $loghpp;
	if (!isset($loghpp)) $loghpp="";
	$loghpp.=$log;
	//if ($isTest)echo $log;
	//echo "hpp...... $hasil >>>><br>";
	return $hasil;
}

/*
jika tgl1='', stok akhir global tanpa hitung (menggunakan yng di tabel stok
jika tgl1='-', stok akhir global dengan menghitung ulang yg di tabel tbpbelid
jika tgl1 diisi  dan tgl2='', menghitung stok awal pada saat tanggal tertentu (sebelum tgl1)
jika tgl1 dan tgl2 diisi, menghitung stock antara tgl1  sampai sebelum tgl2+1
*/
function getStockAkhir($kdbrg,$kdlokasi,$notrans="",$tgl1="",$tgl2="") {
	global  $sqStAkhir0;
	if ($tgl1=="") {
		 $sq="select $sqStAkhir0 from tbpstock where kdbrg='$kdbrg' and kdlokasi='$kdlokasi' ";	
		return carifield($sq)*1;
	} else {
		if ($tgl2=="") {
			$syTgl=" and h.tgl<'$tgl1'";
		}
		elseif ($tgl1=="-") {
			$syTgl="  ";
		}
		else {
			$syTgl=" and (h.tgl>='$tgl1' and h.tgl<='$tgl2 23:59:59')";
		}
		$sa0=carifield("select stawal from tbpstock where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'")*1;
		$sqb0="select sum(jlh_terima) from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans 
		where d.kdbrg='$kdbrg' $syTgl";
		$sqb1=$sqb0." and h.kdlokasi='$kdlokasi' ";
		$sqb1b=$sqb0." and h.kdlokasi2='$kdlokasi' ";
		
		$sqb2=" group by d.kdbrg ";
		//echo "$sqb1 and (h.jtrans='SL' or h.jtrans='JE' ) $sqb2";
		$jBeli=carifield("$sqb1 and h.jtrans='PB' $sqb2")*1;
		$jJual=carifield("$sqb1 and (h.jtrans='SL' or h.jtrans='JE' ) $sqb2")*1;
		$jRBeli=carifield("$sqb1 and h.jtrans='PR' $sqb2")*1;
		$jRJual=carifield("$sqb1 and h.jtrans='SR' $sqb2")*1;
		//$jProduksi=carifield("$sqb1 and h.jtrans='PP' $sqb2")*1;
		$jProduksi=carifield("$sqb1 and (h.jtrans='PP' or h.jtrans='PG') $sqb2")*1;
		$jDisMasuk=carifield("$sqb1b and h.jtrans='DD' $sqb2")*1;
		$jDisKeluar=carifield("$sqb1 and h.jtrans='DD' $sqb2")*1;
		$jAdjust=carifield("$sqb1 and h.jtrans='PA' $sqb2")*1;
		//produksi		
		$sakhir=$sa0+$jBeli-$jJual-$jRBeli+$jRJual+$jProduksi+$jDisMasuk-$jDisKeluar+$jAdjust;
		//echo "$sakhir=$sa0+$jBeli-$jJual-$jRBeli+$jRJual+$jProduksi+$jDisMasuk-$jDisKeluar+$jAdjust;";
		return $sakhir;
		//jika ada tanggal, maka perlu evaluasi data
		
	}
}

function getHppTerakhir($kdbrg,$kdlokasi,$tgl1="") {
	global  $sqStAkhir0;
	if ($tgl1=="") {
		$hpp=cekHrgPokok($kdbrg, $kdlokasi, 1, '', 'SL', $hpplama=0, $jlhlama=0,1 );
	}else{
		$sq="select hpp from tbpbelid  d inner join tbpbeli h on d.notrans=h.notrans
		 where d.kdbrg='$kdbrg' and h.kdlokasi='$kdlokasi' and h.tgl<'$tgl1' 
		 and (h.jtrans='PD' or h.jtrans='SL' or h.jtrans='JE' or h.jtrans='PD')
		 order by h.tgl DESC limit 0,1";
	}		
		return carifield($sq)*1;
	
}
function resetAcc(){
	if (!usertype("sa")) exit;
	
	$stb="tbpbeli,tbpbelid,tbpbelid_terpakai,tbpstock,tb1kode,tblog";
	$stb.="tbpbayar,tbpbayard";
	$stb.=",finger_log";
	$stb.=",tbh_logclick,tbh_logh2,tbh_logip";
	//$stb.=",tbpbarang_tmp,tbl1kode";
	
	$atb=explode(",",$stb);
	$ssq="";
	foreach($atb as $tb) {
		$ssq.="
			truncate table $tb;
		";
	}
	
	return $ssq;
	
}

function hitungUlangHPP_masihtrial($kdbrg,$kdlokasi) {
	$kdbrg="GA02796";
	//Function cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans, $hpplama = 0, $jlhlama = 0,$force=false) {
	global $hasilCari,$isTest;
	$hasil=0;
	//Dim fldsisa, hpp, terpenuhi, subtot, sisa, hrg, jlhterpenuhi, la 'limitawal
	//Dim jumlah, sq, xhrg

	$log="";
	$la = 0;
	$hpp = 0;
	$jumlah = 0;
	$terpenuhi = 0;
	$jlhterpenuhi=0;
	$subtot = 0;
	//Dim sket, idb, xjlh, aidb
	$subtot = 0;//$subtot + $hpplama * $jlhlama;
	$log.="subtot awal $hpplama * $jlhlama = $subtot ";
	//$jlhdibutuhkan = $jlhdibutuhkan - $jlhlama;

	$fldsisa = "d.jlh_terima-d.jlh_retur-if(isnull(sum(dd.jlh)),0,sum(dd.jlh))";

	$sket = "";

	//bersihkan di terpakai
	$sIdbb = GetString("select idbb  from tbpbelid_terpakai where notrans='$notrans' and kdbrg='$kdbrg' ");
	$sJenisIdbb = GetString("select jenisidb   from tbpbelid_terpakai where notrans='$notrans' and kdbrg='$kdbrg' ");

	
	querysql( "delete from tbpbelid_terpakai where notrans='$notrans' and kdbrg='$kdbrg' ");
	querysql( "update tbpstock set statterpakai=0 where kdlokasi='$kdlokasi' and kdbrg='$kdbrg' ");
	$aidb = explode(",",$sIdbb);
	Foreach ($aidb as $idb) {
		querysql ("update tbpbelid set statterpakai=0 where id='$idb';");
		//$i++;
	}

//Dim julang, jenisidb, gt, sk
	//Dim aket, ket, ak, qs, jt, qs2, sq1 As String
	$log.="<br>$kdbrg terpenuhi $terpenuhi dib $jlhdibutuhkan >>>";
	If (($terpenuhi < $jlhdibutuhkan) || $force ) {
		$julang = 0;// '0 untuk mencari di saldo awal, dan 1 untuk mencari di data penjualan
		x_ulang:
		//sq = "select kdbrg," & fldsisa & " as sisa,hrg from tbpbelid d inner join tbpbeli h on d.notrans=h.notrans where h.jtrans='PB' and " & fldsisa & ">0 and kdbrg='" & kdbrg & "' and m.kdlokasi='" & kdlokasi & "' order by tgl,id limit 0,1"		
		If ($julang == 0) {//' mencari di stock awal
			//mencari jumlah terpakai dari stock awal
			$log.= "<br>$julang. mencari di stok awal....";
			$sq = "select * from (select d.kdbrg,d.kdlokasi,h.defhrgbeli as hrg,stawal-if(isnull(sum(dd.jlh)),0,sum(dd.jlh)) as sisa,
			d.id,dd.jenisidb from (tbpstock d  left join tbpbarang h on d.kdbrg=h.kdbrg) 
			left join tbpbelid_terpakai dd on (d.id=dd.idbb)  
			where (isnull(jenisidb) or jenisidb='sa') and d.kdbrg='$kdbrg' and d.kdlokasi='$kdlokasi'  group by d.id )  as ss where sisa >0 limit 0,1";
			$jenisidb = "sa";
		} else {
			
			$syTransHPP=getSyTransHPP($kdlokasi);
					
			
			
			
			$log.="<br>$julang. mencari di pembelian....";
			//mencari jumlah terpakai dari pembelian
			$jenisidb = "pb"; //mencari di pb dan produksi, hanya yg paling atas (limit 0,1 atau fifo)
			 $sq = "select * from (select d.kdbrg,h.kdlokasi,d.hrg,$fldsisa as sisa,
					d.id,dd.jenisidb,h.jtrans,h.notrans,h.tgl 
					from (tbpbelid d inner join tbpbeli h on d.notrans=h.notrans) left join tbpbelid_terpakai dd on d.id=dd.idbb  
					where 
					d.statterpakai=0 and d.kdbrg='$kdbrg' 
					$syTransHPP 
					
					and (isnull(dd.jenisidb) or dd.jenisidb='PB')  
					group by d.id order by tgl,d.id) as ss where sisa>0  limit 0,1";
		}
		cariField($sq);
		$log.="<br>$sq<br><br>";;
		//var_dump($hasilCari);
		
		$julang ++;
		If ($hasilCari[1] <> "") {
			$sisa = $hasilCari[4]*1;
			$xhrg = $hasilCari[3]*1;
			$idb = $hasilCari[5]*1;
			$log.="<br> hoho  $sisa $xhrg $idb > ";
			If ($sisa >= ($jlhdibutuhkan - $terpenuhi)) {
				$xjlh = ($jlhdibutuhkan - $terpenuhi);
				$subtot = $subtot + $xjlh * $xhrg;
				$terpenuhi = $terpenuhi + $xjlh;
				$log.= "<br>subtot+= $xjlh*$xhrg=$subtot > ";
				$sk = "$idb|$xjlh|$notrans|$jenisidb";
				$sket = $sket .($sket == ""? "": "#").$sk;
				$gt = "t";
				
			} Else {//'jika belum terpenuhi semua
				$xjlh = $sisa;
				$subtot = $subtot + $sisa * $xhrg;
				$terpenuhi = $terpenuhi + $xjlh;
				$sk = "$idb|$xjlh|$notrans|$jenisidb";
				$sket = $sket .($sket == ""? "": "#").$sk;
				$la ++;
				$gt = "b";
			}
			
			
			$sq2 = "insert into tbpbelid_terpakai(notrans,jtrans,kdbrg,idbb,idbj,jlh,hpp,jenisidb) 
			values('$notrans','$jtrans','$kdbrg','$idb','$idbj','$xjlh','$xhrg','$jenisidb')";
			querysql($sq2);
			$log.="<br><BR>$sq2";
			//'setclipboard qs
			//'update jlh_terpenuhi
			
			//$sIdbb.=($sIdbb == ""? "": ";").$idb;
			$sJenisIdbb.=($sJenisIdbb==""? "":";").$jenisidb;
			If ($gt == "t") {
				GoTo x_terpenuhi;
			} else {
				GoTo x_ulang;
			}
			
		} else {
			If ($julang == 1) GoTo x_ulang;
		}
		

	  //  MsgBox sket
		x_terpenuhi:
		/*If ($terpenuhi ==0) {
				//'cekHrgPokok = cariField("select defhrgbeli from tbpbarang where kdbrg='" & kdbrg & "'")
			$hasil = cariField("select hrgpokok from tbpbarang where kdbrg='kdbrg'");
			echo "tidak terpenuhi $jlhdibutuhkan hasil...... $hasil ";
		} Else {
		*/
			$hasil = $subtot / max(1, $terpenuhi);
			$log.="<br>subtot $subtot $hasil";
			
		/*
			echo "hasil...... $hasil ";
		}
			*/	
		//   ' updateJlhTerpakai sIdbb, sJenisIdbb, notrans
		//If ($jlhdibutuhkan < $jlhterpenuhi) {
		If ($jlhdibutuhkan < $terpenuhi) {
			echo " Stock barang kurang, Jumlah:$jlhdibutuhkan < $terpenuhi ";
			return "";
		} else {
			$log.="Stock terpenuhi....";
		}
		//if ($isTest) echo $log;
		
	}
	//if ($isTest)echo $log;
	global $logHPP;
	$logHPP=$log;
	//echo "hpp...... $hasil >>>><br>";
	return $hasil;
}

function createLinkTrans($notrans,$jtrans="") {
	$rndx=genRnd();
	$tempat="tnt$rndx";
	return "<span id=$tempat></span><a href=# onclick=''>$notrans</a>";
		
}

function clearEmptyGL(){
	//membersihkan semua gl yang tidak ada barisnya
	global $defKdBranch,$isTest,$oNamaTb;
	$log="<br><b>Clear GL</b>";
	$ss = "select * from( select h.id as idtrans,h.notrans, count(d.id) as jlh from ".$oNamaTb->gl." h left join  ".$oNamaTb->gld." d on h.notrans=d.notrans group by h.notrans) as tb where jlh=0 or isnull(jlh) ";
	$ssq="";
	$dt=sqltoArray2($ss);
	foreach ($dt as $r){
		$ssq.="delete from  ".$oNamaTb->gl." where notrans='$r[notrans]';";
		$ssq.="delete from  ".$oNamaTb->gld." where notrans='$r[notrans]';";
		
	}
	echo $ssq;
	querysql($ssq);
}