<?php
//cekVar("det");
$addSqComboBrg="";
if ($userType=='pm') $addSqComboBrg=" and b.kdpemasok='$defKdPembantu'";
if ($userType=='marketing') $addSqComboPembantu=" and p.kdBranch='$defKdBranch'";
//digunakan untuk memberi filter tabel sesuai dengan level user_error
if ($det=="barang") {
		addFilterTb("b.kdpemasok='$defKdPembantu'",$userType);
}elseif (strstr(",stopname,pembantu,pegawai,transaksi-kas,penjualan,penjualane,pembelian,retur-pembelian,retur-penjualan,packing,produksi,pembayaran-hutang,",",$det,")!="") {		
		if (!usertype("sa")) {
			//if ($defKdBranch!='') {
				addFilterTb("kdbranch='$defKdBranch'");
				//addsave("kdbranch",$defKdBranch);
			//}
			//if ($userType=='marketing') addFilterTb(" h.kdbranch='$defKdBranch'");
			if ($userType=='pm') addFilterTb(" 1=2");
		}
		//addsave("pj",$vidusr,"tb");
}elseif ($det=="penjualand") {
		if ($userType=='pm') addFilterTb(" kdpemasok='$defKdPembantu'",$userType);
		if ($userType=='marketing') addFilterTb(" h.kdbranch='$defKdBranch'");
}

?>