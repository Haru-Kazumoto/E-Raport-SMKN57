<?php
//===================================================================================================
function awalLaporan(){
	global $js_path,$media;
	$t="";
	if ($media!='xls') $t.= "<link href='$js_path"."style-cetak.css' rel='stylesheet'>";
	$t.="
	<style>
	.tbcetakbergaris td,
	.page td {
		font-size:12px;
	}
	
	.page-landscape td{
		font-size:13px;
	}
	.tbhead {
		margin-bottom:10px;
		margin-top:13px;
	}
	.tbhead0 td {
		font-size:15px;
	}

	.tbhead td {
		height:24px;
		font-size:13px;
	}

	.tbfoot1 {
		 
		margin-right:20px;
		margin-bottom:20px;
	}
	.tbfoot1 td {
		height:24px; 
	}
	.tbfoot2 {
	 
	}
	.trhead {
		background:#CCCCCC;
		
	}
	.trhead th  {
		text-align:center;	
		
	}
	.page {
			padding:2cm 2cm 2cm 2cm;
			
		}
	.page-landscape {
			padding:2cm 2cm 2cm 2cm;
			
		}
	@media print {
		.page {
			padding:2.5cm 2.6cm 2.5cm 2.5cm;
			
		}
		.page-landscape {
			padding:2.5cm 2.5cm 2.5cm 2.5cm;
			
		}
	}
	</style>
	";
	return $t;

}

//tbheadlaporan
function buattbhead($judul,$tgl1="",$tgl2=""){
	global $media;
	global $jdl,$toroot,$namaPsh,$nfLogo;
	if ($namaPsh=="") $namaPsh=getconfig("namapsh");
	$periode="";
	if ($tgl1!="") {
			
		$periode.=($tgl2==$tgl1?"PER ":" PERIODE ").tglindo(tgltosql($tgl1));
	}
	
	if (($tgl2!="") && ($tgl2!=$tgl1))  {
		
		$periode.=" SD ".tglindo(tgltosql($tgl2));
	}
	$periode=strtoupper($periode);
	$t=" <table border=0 width='100%' class=tbhead0 style='margin-bottom:10px'>
		<tr>
			".($media==""?"<td width='60'><img src='$nfLogo' width='60'></td>":"")."
			<td align=center valign=midle colspan=4> 
				<div style='font-size:16px;font-weight:bold'>$namaPsh</div>
				$judul<br> 
				$periode
			</td> 
			 
		</tr>
 </table>";
 
	return $t;
}

//kop Faktur dll
function tampilKop($judulF,$noF="") {
	global $rnd,$namaPsh,$alamatPsh1,$alamatPsh2,$alamatPsh3;
	return "<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td style='width:40%'> 
					<div >$namaPsh<div>
					<div >$alamatPsh1<div>
					<div >$alamatPsh2<div>
					<div >$alamatPsh3<div>
					<hr>
				</td>
				<td class='c'>
				 <h2>$judulF
				 ".($noF==""?"":"<br><div style='font-size:16px;margin-top:-10px'>$noF</div>")."
				 </h2>
				 
				</td>
				</tr>
			</table>
		</div>	";

}
function tampilTTDKanan($wKiri=500,$tgl="",$kota="",$jab="",$operator="") {
	global $kotaPsh,$rnd;
	if ($kota=="") $kota=$kotaPsh;
	if ($tgl=="") $tgl=date("Y-m-d");
	
	
	return "<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td style='width:$wKiri"."px'> &nbsp;</td>
				<td >
					$kota, ".tglindo2($tgl)."<br>"
					.($jab==""?"":"$jab,<br>").
					"<br>
					<br>
					".($operator==""?"_______________________":"($operator)")."
				</td>
				</tr>
			</table>
		</div>	";
}


?>