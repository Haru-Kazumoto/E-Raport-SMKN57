<?php

cekvar("det");

if ($det=="emptydb") {
	echo emptyDbAcc();
	
}