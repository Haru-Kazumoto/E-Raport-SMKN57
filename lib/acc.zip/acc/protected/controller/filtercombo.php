<?php
$useJS=2;
include_once "conf.php";
cekVar("op");
if ($op=='cekhrgbrg') {
	cekvar("kdbrg,def,no,newrnd");
	//$gFieldInputD[1]="=um412_isicombo5('select kdbrg,nmbarang from tbpbarang order by nmbarang ','d_kdbrg_$rnd"."_#no#;d_kdbrg[]','','','','#def#','cekKdBrgTransJual($rnd,#no#);' );";

	$sq=("select distinct(harga) from tbphrgjual where kdbrg='$kdbrg' and harga<>0 order by harga asc");
	echo   um412_isicombo5($sq,"d_hrg_$newrnd"."_$no;d_hrg[]",'','','',$def,"evalItemTransJual($newrnd,$no);");
}elseif ($op=='plg') {
	cekvar("kdbranch,kdpj");
	
	$addsy="";
	if ($kdbranch!="") $addsy=" and kdbranch='$kdbranch' ";
	if ($kdpj*1!=0) $addsy=" and kdpj='$kdpj' ";
	echo   um412_isicombo5("select id,nama from tbppembantu where jpembantu='PL' $addsy  order by nama","kdpembantu");
}elseif ($op=='sales') {
	cekvar("kdbranch,func");
	$addsy="";
	if ($kdbranch!="") $addsy=" where kdbranch='$kdbranch' ";
	echo   um412_isicombo6("select id,nama from tbppegawai    $addsy  order by nama","kdpj","$func");
}
?>