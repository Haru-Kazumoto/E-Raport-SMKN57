<?php
$isLogin=false;

cekvar("opcek,op,oplg");
$levelOwner=0;
$lg=new login();
$lg->aTbLogin=$aTbLogin;
//$lg->init();

if ($oplg=='') $oplg=$op;

if (!isset($defKdPembantuUmum)) $defKdPembantuUmum=5;
if (!isset($useEceran)) $useEceran=true;
if (!isset($useWilayah)) $useWilayah=false;
if (!isset($useMarketing)) $useMarketing=false;



if ($oplg=="logout") {
	$lg->userLogout(0);
	//echo "lewat lho...$op ";exit;
}else {
	$isLogin=$lg->cekLogin(0);
}

if ($isLogin) {
	if ($debugMode) {
		//echo "sudah login $levelOwner";exit;
	}
	
	if (usertype("sa")) {
		if ($useBranch) {
			//$defKdBranch="";
			//$defKdLokasi=0;
		}
	} else {
		$defKdBranchTmp=$defKdLokasiTmp='';
		extractRecord("select kdbranch as defKdBranchTmp,kdlokasi as defKdLokasiTmp 
		from tbuser where vuserid='$userid'");
		if ($defKdBranchTmp!='') $defKdBranch=$defKdBranchTmp;
		if ($defKdLokasiTmp!='') $defKdLokasi=$defKdLokasiTmp;
	}
		
}

if (!isset($defKdPembantu)) $defKdPembantu ="0";
if (!isset($appMode)) $appMode ="transisi"; //development,transisi,production
if (!isset($useNoFakturInPB)) $useNoFakturInPB=false;
if (!isset($sqStAkhir0)) {
	$fldStAkhir="stawal+stbeli-strbeli-stjual+strjual+stadjust+stprodm-stprodk+stex+stdistm-stdistk";
	$sqStAkhir0= "($fldStAkhir) ";
}
//-h.disc-h.disc2
$sqTerhutang="h.netto-h.paidtoday-h.paidafter-h.retur"; 

$sqStAkhir=$sqStAkhir0." as stakhir";
$deftgl1=awalBulan(); 
$deftgl2=akhirBulan();
$periode="Bulan Ini"; 
if (isset($_SESSION['tgllap1'])) {
	$deftgl1=$_SESSION['tgllap1'];
	if (isset($_SESSION['tgllap2'])) {
		$deftgl2=$_SESSION['tgllap2'];
	}
	$periode="Custom"; 
}
 

//echo "sampai";exit;
//variabel
if (!isset($useBranch)) $useBranch=false;
if (!isset($useLokasi)) $useLokasi=false;

$tahunini=date("Y");
$bulanini=date("m");
//default
$isiBulan="Januari,Februari,Maret,April,Mei,Juni,Juli,Agustus,September,Oktober,November,Desember";
$aBulan=explode(",",$isiBulan);
$arrAccKas=array("Akun Kas/Bank",25,11000,11199);
$arrAccPemasukan=array("Jenis Pemasukan",120,41000,49999);
$arrAccPengeluaran=array("Jenis Pengeluaran",160,61000,69999);

include_once $lib_app_path."protected/controller/app-func-laporan.php";
//include_once $lib_app_path."protected/controller/app-func-mdbarang.php";

//isi default program acc =======================================
extractRecord("
select namapsh as namaPsh,nflogo as defNfLogo,nflogo2 as defNfLogo2,alamat as alamatPsh1,alamat2 as alamatPsh2,
alamat3 as alamatPsh3,alamat4 as alamatPsh4,kota as kotaPsh
from tbconfig limit 0,1");



if ($defNfLogo!="") {
	$nf=$toroot."img/".$defNfLogo;
	if (!file_exists($nf)) $nf=$tohost."content/img/".$defNfLogo;	
	if (file_exists($nf)) 	$nfLogo=$nf;
} 

//logo kecil
$nfLogo2=createThumbAll($nfLogo, $new_width=50, $new_height='auto', $save_path="",true);
/*
if ($defNfLogo2!="") {
	$nf=$toroot."img/".$defNfLogo2;
	if (!file_exists($nf)) $nf=$tohost."content/img/".$defNfLogo2;	
}
if (file_exists($nf)) 	$nfLogo2=$nf;
if (!isset($nfLogo2)) $nfLogo2=$nfLogo;
*/

/*
*/

if (!isset($defKdBranch)) $defKdBranch="";

if ((!$useBranch) || ($defKdBranch=='')) {
	//setVar("kdbranch",$defKdBranch);
	$defKdPrkKas=$defKdPrkKasKecil=$defKdPrkKasM = getACC("penerimaan_tunai");
	$defKdPrkKasK =getACC("pembayaran_tunai");
	$defKdPrkBank =getACC("bank");
	
}  else {
	extractRecord("select defkdlokasi as defKdLokasi,
	kdprkkask as defKdPrkKasK,
	kdprkkasm as defKdPrkKasM,
	kdprkkaskecil as defKdPrkKasKecil,
	kdprkbank as defKdPrkBank,
	kdpembantuumum as defKdPembantuUmum,
	branch as branchPsh,
	alamat as alamatBranchPsh,
	alamat2 as alamatBranchPsh2
	from tbpbranch where kdbranch='$defKdBranch'" );

	
} 
if ($defKdBranch!='') {
	if ($defKdLokasi*1==0) {
		extractRecord("select id as defKdLokasi from tbplokasi  where kdbranch='$defKdBranch' limit 0,1" );
	}
}

//$namaPsh="UD. Bayu Abadi";
//$alamatPsh="Jl. Jogja-Solo Km.12 Klaten";
$headPsh="
		<div class=nmpsh style=''>
		
		<!--img src='$nfLogo' style='max-width:70px;padding:15px 10px 15px ' align=left -->	
		<div style='font-weight:bold'>$namaPsh</div>
			$alamatPsh<br>
		</div>
";

$headPsh="
		<div class=kop style=''>
		<!--img src='$nfLogo' style='max-width:70px;padding:15px 10px 15px ' align=left -->	
		<div class='cKop'>	
			<div class='cKop1'>
				$namaPsh
			</div>
			<div class='cKop2'>
				$alamatPsh1
			</div>
			<div class='cKop3'>
				$alamatPsh2
			</div>
			<div class='cKop4'>
				$alamatPsh3
			</div>
		</div>
";


if (!isset($defKdLokasi)) $defKdLokasi="0";
if (!$useLokasi) setVar("kdlokasi",$defKdLokasi);
if (!isset($defModePenerimaanPiutang)) $defModePenerimaanPiutang=1;
if (!isset($kdAwalBrg)) $kdAwalBrg="A";
if (!isset($digitKdBrg)) $digitKdBrg=4;

