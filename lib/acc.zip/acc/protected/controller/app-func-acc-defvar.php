<?php
/* default variable modul akunting	*/

//limit pengeluaran yg memerlukan acc
if (!isset($limAccPengeluaran)) $limAccPengeluaran=500*1000*1000;
if (!isset($fldAccNo)) $fldAccNo="account_code2";
if (!isset($defNmTB)) {
	$defNmTB=[
		'akun'=>'0_chart_master',
		'tipeAkun'=>'0_chart_types',
		'kontrolAkun'=>'0_sys_prefs',
		'gl'=>'0_gl',
		'gld'=>'0_gl_trans',
	];
	
	$defNmTB=[
		'akun'=>'tbakun',
		'tipeAkun'=>'tbakun_tipe',
		'kontrolAkun'=>'tbakun_ca',
		'gl'=>'tbacc_gl',
		'gld'=>'tbacc_gld',
	];
	
}
$oNamaTb =(object) $defNmTB;

$gAJTransLengkap=[
	["kode"=>"SL","cap"=>"Penjualan Umum","fldstock"=>"stjual"],
	["kode"=>"JE","cap"=>"Penjualan Eceran","fldstock"=>"stjual"],
	["kode"=>"SR","cap"=>"Retur Penjualan","fldstock"=>"strjual"],
	["kode"=>"PA","cap"=>"Penyesuaian/Penyusutan Persediaan","fldstock"=>"stadjust"],
	["kode"=>"PB","cap"=>"Pembelian","fldstock"=>"stbeli"],
	["kode"=>"PR","cap"=>"Retur Pembelian","fldstock"=>"strbeli"],
	["kode"=>"PD","cap"=>"Produksi","fldstock"=>"stprodm"],
	["kode"=>"BB","cap"=>"Pemakaian Bahan Baku untuk Produksi","fldstock"=>"stprodk"],	
	["kode"=>"BJ","cap"=>"Hasil Produksi","fldstock"=>"stprodm"],	
	["kode"=>"PG","cap"=>"Packing","fldstock"=>"stprodm"],
	["kode"=>"DS","cap"=>"Distribusi Barang","fldstock"=>"stdistk"], //old program
	["kode"=>"DM","cap"=>"Distribusi Masuk","fldstock"=>"stdistm"],
	["kode"=>"DK","cap"=>"Distribusi Keluar","fldstock"=>"stdistk"],
	["kode"=>"PP","cap"=>"Penerimaan Piutang","fldstock"=>""],
	["kode"=>"PH","cap"=>"Pembayaran Hutang","fldstock"=>""],
	["kode"=>"AH","cap"=>"Ristan Hutang Awal","fldstock"=>""],//saldo awal hutang
	["kode"=>"AP","cap"=>"Ristan Piutang Awal","fldstock"=>""],	//saldo awal piutang
	["kode"=>"SO","cap"=>"Pesanan Penjualan","fldstock"=>""],	
	["kode"=>"PO","cap"=>"Pesanan Pembelian","fldstock"=>""],	
	
];

$gAJTrans=array_column($gAJTransLengkap,"kode");


//if (!isset($aTbLogin)) {
	$aTbLogin=[
		[ "tb"=>"tbuser",
			"sy"=>"",
			"fldid"=>"id",
			"flduid"=>"vuserid",
			"flduname"=>"vusername",
			"fldupss"=>"vpass",
			"fldutype"=>"vusertype",
			//"usrtype"=>"marketing",
			"ulv"=>10,
		],
		[ "tb"=>"tbppegawai",
			"sy"=>"",
			"fldid"=>"id",
			"flduid"=>"vuserid",
			"flduname"=>"nama",
			"fldupss"=>"vpass",
			"fldutype"=>"kdjab",
			//"usrtype"=>"marketing",
			"ulv"=>10,
		],
	];
//}

//kdbranch
if (!isset($_SESSION['acc'])) {
	$jlhBranch=carifield("select count(kdbranch) from tbpbranch");
	if ($jlhBranch==1) {
		$defKdBranch=carifield("select kdbranch from tbpbranch");
	}
	$sy=($defKdBranch==''?'':" where kdbranch='$defKdBranch'");
	$jlhLokasi=carifield("select count(id) from tbplokasi $sy");
	if ($jlhLokasi==1) {
		$defKdLokasi=carifield("select id from tbplokasi $sy");
	}
	
	//echo "select count(id) from tbplokasi $sy $defKdLokasi";
	$sacc['defKdBranch']=$defKdBranch;
	$sacc['jlhBranch']=$jlhBranch;
	$sacc['defKdLokasi']=$defKdLokasi;
	$sacc['jlhLokasi']=$jlhLokasi;
	$_SESSION['acc']=$sacc;
	
} else {
	extractSession("acc");
	//echo "defkdbranch $defKdBranch defkdlokasi $defKdLokasi";
}
//unset($_SESSION['acc']);	