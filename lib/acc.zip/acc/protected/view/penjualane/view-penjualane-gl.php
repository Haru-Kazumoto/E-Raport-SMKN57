 <?php
 echo showGL($r['notrans'],1); 