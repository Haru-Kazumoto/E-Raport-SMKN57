<?php
$rh=$r; //rheader
$idview="tview_$rnd";
$clspage="page p58";
$hr="-------------------------------------";
$tbk="
<div class='tbviewatas noprint' style='padding:5px 0 5px 0;text-align:right' >
	<button class='btn btn-success btn-sm' onclick=\"printDiv('$idview')\">
	<i class='fa fa-print'></i> Cetak</button>
</div>
";

$awTb1="<table border='0' class='tbform2xx tbcetaktanpagaris overview-table' width=100% >";

extractRecord("select branch as namaPsh, alamat as alamatPsh,alamat2 as alamatPsh2 from tbpbranch where kdbranch='$kdbranch'");
	$t0="
	$tbk
	<div class='tview' id='$idview'>
	<link rel=\'stylesheet\' type=\'text/css\' href=\'$js_path/style-cetak3.css\' >
	
	<div class='$clspage' >
		<h2 align=center>$namaPsh</h2>
		<center>
		$alamatPsh<br>
		$alamatPsh2<br>
		</center>
		$hr
		$awTb1		
		<div>".$r['notrans']." ".tglIndo2($r['tgl'],'d x Y ').tglIndo2($r['tglentri'],'h:i')."</div>"
//.rowView('Cabang',$r["cabang"])
//.rowView('Lokasi',$r["lokasi"])
."";
	
	echo $t0;
	?>
	 
	
<style>
max-height: 20000px;
overflow: auto;
</style>
<!--h4 class='titleview'>Detail</h4-->
<?php
echo "
$hr
<br>Deskripsi &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Harga
<br>$hr";
?>
<table style='width:100%;border:none'    >
	<thead>
		<!--tr>
<th class='tdjudul'>No.</th>
<th class='tdjudul' align='right' >Kode</th>
<th class='tdjudul' align='right' >Deskripsi</th>
<th class='tdjudul' align='right' >Jumlah</th>
<th class='tdjudul' align='right' >Satuan</th>
<th class='tdjudul' align='right' >Harga</th>
<th class='tdjudul' align='right' >Subtotal</th>
</tr-->
	</thead> 
	<tbody id='tbody_tbdet_<?=$rnd?>'>
	<?php
	
	
	 $sqTabelD="select d.*,b.nmbarang,b.satuan  from 
(tbpbelid d inner join tbpbeli h on d.notrans=h.notrans)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where h.id='$id' 
";
	
	$isiTbD="";
	$brd=0;
	$hd=mysql_query2($sqTabelD);
	$jlhD=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	$arrTabel=array();
	while ($r=mysql_fetch_array($hd)) {
		$br=$brd+1;
		$i=0;
		$jlhD[0]+=$r['kdbrg'];
$jlhD[1]+=$r['nmbarang'];
$jlhD[2]+=$r['jlh_terima'];
$jlhD[3]+=$r['satuan'];
$jlhD[4]+=$r['hrg'];
$jlhD[5]+=$r['subtot'];

		$isiTbD.="
		<tr>
		<td style='width:5%' >$br</td>
<td style='text-align:left;width:30%'  >".$r['nmbarang']."</td>
<td style='text-align:right;width:16%' >".maskrp($r['jlh_terima'],0,9)." ".$r['satuan']."</td>
<td style='text-align:right;width:18%' >".maskrp($r['hrg'],0,0)."</td>
<td style='text-align:right;width:18%' >".maskrp($r['subtot'],0,0)."</td>
</tr>
";
		
		$isiTbD.="";
		$brd++;
	}
	echo $isiTbD;
	
	?>
	
	</tbody>
	<tfoot>	
	</tfoot> 
</table>
		<?php
		$r=$rh;//kembalikan rheader
		
		//rowView('cap|width|col-sm-3','isi|width|right|col-sm-8');
		
		$t1=$hr.$awTb1			

."<tr class='bold'>
	<td style='width:60%'>TOTAL</td>
	<td style='width:10%'>Rp</td>
	<td style='width:30%'  align=right >".maskRp($r['brutto'],0,0)."</td>
</tr>"
."<tr><td>Pembayaran</td>
<td  >Rp</td>
	<td align=right >".maskRp($r['bayar'],0,0)."</td></tr>"
."<tr><td>Kembali</td>
<td  >Rp</td>
	<td  align=right >".maskRp($r['kembalian'],0,0)."</td></tr>";
			$t1.="</table>";
		
		echo $t1;
		
		echo "
		<br>$hr
		<div align=center>
		Terimakasih Atas Kunjungannya<br>
		Barang yang sudah dibeli<br>tidak dapat dikembalikan lagi.<br>
		</div>
		
		";
		
		?>
		<style>
	.page {
		margin: 1cm;
		background: #fff;
	}
.p58 {
	width:58mm;
	padding: 22px;
	margin: 1cm auto;
	
}
.p58,
.p58 th,
.p58 td {
	font-size: 10px !important;
    font-family: 'Courier New' !important;
	line-height: 12px;
} 
.p58 h2 {
	font-size: 11px !important;
	line-height: 13px;
    
}
.p58 th,
.p58 td {
	padding:0px !important;
} 

.p58 h2 {
    font-size: 14px;
    line-height: 18px;
}

.bold, .bold td {
	font-weight:bold;
	font-size:16px;
}


		</style>
	</div>
</div>
