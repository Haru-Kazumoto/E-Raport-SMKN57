<?php 
echo "===
		<div id=tsfrmfltrpenjualan ></div>
		<div id=tinputdialog2_23315></div>
		<form id='frmfltrpenjualan' action='index.php?det=penjualan&op=showtable' method='Post'  style='padding:0px;margin:0 0 5px 0;' > 
		<div style='max-height:400px;overflow:auto;padding:0px 10px'>
		
		<dl id='tritb[0]' ><dt >ID</dt> 
			<dd ><input type=text name=ftl_id id=id_$rnd></dd>
		</dl>
		
		<dl id='tritb[1]' ><dt >NOTRANS</dt> 
			<dd ><input type=text name=ftl_notrans id=notrans_$rnd></dd>
		</dl>
		
		<dl id='tritb[2]' ><dt >JTRANS</dt> 
			<dd ><input type=text name=ftl_jtrans id=jtrans_$rnd></dd>
		</dl>
		
		<dl id='tritb[3]' ><dt >NOFAKTUR</dt> 
			<dd ><input type=text name=ftl_nofaktur id=nofaktur_$rnd></dd>
		</dl>
		
		<dl id='tritb[4]' ><dt >STAT</dt> 
			<dd ><input type=text name=ftl_stat id=stat_$rnd></dd>
		</dl>
		
		<dl id='tritb[5]' ><dt >NOPO</dt> 
			<dd ><input type=text name=ftl_nopo id=nopo_$rnd></dd>
		</dl>
		
		<dl id='tritb[6]' ><dt >TGLENTRI</dt> 
			<dd ><input type=text name=ftl_tglentri id=tglentri_$rnd></dd>
		</dl>
		
		<dl id='tritb[7]' ><dt >TGL</dt> 
			<dd ><input type=text name=ftl_tgl id=tgl_$rnd></dd>
		</dl>
		
		<dl id='tritb[8]' ><dt >TGLJT</dt> 
			<dd ><input type=text name=ftl_tgljt id=tgljt_$rnd></dd>
		</dl>
		
		<dl id='tritb[9]' ><dt >OPR</dt> 
			<dd ><input type=text name=ftl_opr id=opr_$rnd></dd>
		</dl>
		
		<dl id='tritb[10]' ><dt >BRUTTO</dt> 
			<dd ><input type=text name=ftl_brutto id=brutto_$rnd></dd>
		</dl>
		
		<dl id='tritb[11]' ><dt >DISC</dt> 
			<dd ><input type=text name=ftl_disc id=disc_$rnd></dd>
		</dl>
		
		<dl id='tritb[12]' ><dt >DISCP</dt> 
			<dd ><input type=text name=ftl_discp id=discp_$rnd></dd>
		</dl>
		
		<dl id='tritb[13]' ><dt >NETTO</dt> 
			<dd ><input type=text name=ftl_netto id=netto_$rnd></dd>
		</dl>
		
		<dl id='tritb[14]' ><dt >KDPEMBANTU</dt> 
			<dd ><input type=text name=ftl_kdpembantu id=kdpembantu_$rnd></dd>
		</dl>
		
		<dl id='tritb[15]' ><dt >TERM</dt> 
			<dd ><input type=text name=ftl_term id=term_$rnd></dd>
		</dl>
		
		<dl id='tritb[16]' ><dt >CARABAYAR</dt> 
			<dd ><input type=text name=ftl_carabayar id=carabayar_$rnd></dd>
		</dl>
		
		<dl id='tritb[17]' ><dt >PAIDTODAY</dt> 
			<dd ><input type=text name=ftl_paidtoday id=paidtoday_$rnd></dd>
		</dl>
		
		<dl id='tritb[18]' ><dt >PAIDAFTER</dt> 
			<dd ><input type=text name=ftl_paidafter id=paidafter_$rnd></dd>
		</dl>
		
		<dl id='tritb[19]' ><dt >KDBAYAR</dt> 
			<dd ><input type=text name=ftl_kdbayar id=kdbayar_$rnd></dd>
		</dl>
		
		<dl id='tritb[20]' ><dt >RETUR</dt> 
			<dd ><input type=text name=ftl_retur id=retur_$rnd></dd>
		</dl>
		
		<dl id='tritb[21]' ><dt >KDLOKASI</dt> 
			<dd ><input type=text name=ftl_kdlokasi id=kdlokasi_$rnd></dd>
		</dl>
		
		<dl id='tritb[22]' ><dt >KDLOKASI2</dt> 
			<dd ><input type=text name=ftl_kdlokasi2 id=kdlokasi2_$rnd></dd>
		</dl>
		
		<dl id='tritb[23]' ><dt >PPN</dt> 
			<dd ><input type=text name=ftl_ppn id=ppn_$rnd></dd>
		</dl>
		
		<dl id='tritb[24]' ><dt >JENIS</dt> 
			<dd ><input type=text name=ftl_jenis id=jenis_$rnd></dd>
		</dl>
		
		<dl id='tritb[25]' ><dt >KDPJ</dt> 
			<dd ><input type=text name=ftl_kdpj id=kdpj_$rnd></dd>
		</dl>
		
		<dl id='tritb[26]' ><dt >DCCHARGE</dt> 
			<dd ><input type=text name=ftl_dccharge id=dccharge_$rnd></dd>
		</dl>
		
		<dl id='tritb[27]' ><dt >BAYAR</dt> 
			<dd ><input type=text name=ftl_bayar id=bayar_$rnd></dd>
		</dl>
		
		<dl id='tritb[28]' ><dt >KEMBALIAN</dt> 
			<dd ><input type=text name=ftl_kembalian id=kembalian_$rnd></dd>
		</dl>
		
		<dl id='tritb[29]' ><dt >DCREF</dt> 
			<dd ><input type=text name=ftl_dcref id=dcref_$rnd></dd>
		</dl>
		
		<dl id='tritb[30]' ><dt >CATATAN</dt> 
			<dd ><input type=text name=ftl_catatan id=catatan_$rnd></dd>
		</dl>
		
		<dl id='tritb[31]' ><dt >DONASI</dt> 
			<dd ><input type=text name=ftl_donasi id=donasi_$rnd></dd>
		</dl>
		
		<dl id='tritb[32]' ><dt >MARGIN</dt> 
			<dd ><input type=text name=ftl_margin id=margin_$rnd></dd>
		</dl>
		
		<dl id='tritb[33]' ><dt >BYANGKUT</dt> 
			<dd ><input type=text name=ftl_byangkut id=byangkut_$rnd></dd>
		</dl>
		
		<dl id='tritb[34]' ><dt >DISC2</dt> 
			<dd ><input type=text name=ftl_disc2 id=disc2_$rnd></dd>
		</dl>
		
		<dl id='tritb[35]' ><dt >DISCTOT</dt> 
			<dd ><input type=text name=ftl_disctot id=disctot_$rnd></dd>
		</dl>
		
		<dl id='tritb[36]' ><dt >BERAT</dt> 
			<dd ><input type=text name=ftl_berat id=berat_$rnd></dd>
		</dl>
		
		<dl id='tritb[37]' ><dt >EXPEDISI</dt> 
			<dd ><input type=text name=ftl_expedisi id=expedisi_$rnd></dd>
		</dl>
		
		<dl id='tritb[38]' ><dt >STATEXPEDISI</dt> 
			<dd ><input type=text name=ftl_statexpedisi id=statexpedisi_$rnd></dd>
		</dl>
		
		<dl id='tritb[39]' ><dt >TGLKIRIM</dt> 
			<dd ><input type=text name=ftl_tglkirim id=tglkirim_$rnd></dd>
		</dl>
		
		<dl id='tritb[40]' ><dt >TGLSAMPAI</dt> 
			<dd ><input type=text name=ftl_tglsampai id=tglsampai_$rnd></dd>
		</dl>
		
		<dl id='tritb[41]' ><dt >NORESI</dt> 
			<dd ><input type=text name=ftl_noresi id=noresi_$rnd></dd>
		</dl>
		
		<dl id='tritb[42]' ><dt >IDPROJECT</dt> 
			<dd ><input type=text name=ftl_idproject id=idproject_$rnd></dd>
		</dl>
		
		<dl id='tritb[43]' ><dt >BAL</dt> 
			<dd ><input type=text name=ftl_bal id=bal_$rnd></dd>
		</dl>
		
		<dl id='tritb[44]' ><dt >BYANGKUTEST</dt> 
			<dd ><input type=text name=ftl_byangkutest id=byangkutest_$rnd></dd>
		</dl>
		
		<dl id='tritb[45]' ><dt >PDEPOSIT</dt> 
			<dd ><input type=text name=ftl_pdeposit id=pdeposit_$rnd></dd>
		</dl>
		
		<dl id='tritb[46]' ><dt >ALAMATKIRIM</dt> 
			<dd ><input type=text name=ftl_alamatkirim id=alamatkirim_$rnd></dd>
		</dl>
		
		<dl id='tritb[47]' ><dt >KDBRANCH</dt> 
			<dd ><input type=text name=ftl_kdbranch id=kdbranch_$rnd></dd>
		</dl>
		
		<dl id='tritb[48]' ><dt >IDKONSOLIDASI</dt> 
			<dd ><input type=text name=ftl_idkonsolidasi id=idkonsolidasi_$rnd></dd>
		</dl>
		
		<dl id='tritb[49]' ><dt >MODIFIED_DATE</dt> 
			<dd ><input type=text name=ftl_modified_date id=modified_date_$rnd></dd>
		</dl>
		

		</div>
		
		<!--div align=right style='margin:10px 0px;0px 10px;background:#D2D2D2;padding:10px'>
			<input type=submit class='btn btn-sm btn-primary' value='Filter'>
		</div-->
		===
	</form>
";

?>
