<link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
<div class='tview' id='tview_<?=$rnd?>'><div class=page>
<h2 class=titleview>
Penjualan
</h2>
<div class='tbviewatas noprint' style='margin:-35px 0 10px 0;text-align:right' ><button class='btn btn-success btn-sm' onclick="printDiv('tview_<?=$rnd?>')">Cetak</button></div>
<?php
echo showGL($r['notrans']);

?>
</div>
</div></div>