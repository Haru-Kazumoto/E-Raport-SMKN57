<?php 
echo "===
		<div id=tsfrmfltrbarang ></div>
		<div id=tinputdialog2_461408></div>
		<form id='frmfltrbarang' action='index.php?det=barang&op=showtable' method='Post'  style='padding:0px;margin:0 0 5px 0;' > 
		<div style='max-height:400px;overflow:auto;padding:0px 10px'>
		
		<dl id='tritb[0]' ><dt >ID</dt> 
			<dd ><input type=text name=ftl_id id=id_$rnd></dd>
		</dl>
		
		<dl id='tritb[1]' ><dt >KDBRG</dt> 
			<dd ><input type=text name=ftl_kdbrg id=kdbrg_$rnd></dd>
		</dl>
		
		<dl id='tritb[2]' ><dt >NMBARANG</dt> 
			<dd ><input type=text name=ftl_nmbarang id=nmbarang_$rnd></dd>
		</dl>
		
		<dl id='tritb[3]' ><dt >NMBARANGX</dt> 
			<dd ><input type=text name=ftl_nmbarangx id=nmbarangx_$rnd></dd>
		</dl>
		
		<dl id='tritb[4]' ><dt >KDPEMASOK</dt> 
			<dd ><input type=text name=ftl_kdpemasok id=kdpemasok_$rnd></dd>
		</dl>
		
		<dl id='tritb[5]' ><dt >KDMERK</dt> 
			<dd ><input type=text name=ftl_kdmerk id=kdmerk_$rnd></dd>
		</dl>
		
		<dl id='tritb[6]' ><dt >KDBRGPMS</dt> 
			<dd ><input type=text name=ftl_kdbrgpms id=kdbrgpms_$rnd></dd>
		</dl>
		
		<dl id='tritb[7]' ><dt >REORDER</dt> 
			<dd ><input type=text name=ftl_reorder id=reorder_$rnd></dd>
		</dl>
		
		<dl id='tritb[8]' ><dt >JENIS</dt> 
			<dd ><input type=text name=ftl_jenis id=jenis_$rnd></dd>
		</dl>
		
		<dl id='tritb[9]' ><dt >DEFHRGBELI</dt> 
			<dd ><input type=text name=ftl_defhrgbeli id=defhrgbeli_$rnd></dd>
		</dl>
		
		<dl id='tritb[10]' ><dt >REALHRGBELI</dt> 
			<dd ><input type=text name=ftl_realhrgbeli id=realhrgbeli_$rnd></dd>
		</dl>
		
		<dl id='tritb[11]' ><dt >HPPINVES</dt> 
			<dd ><input type=text name=ftl_hppinves id=hppinves_$rnd></dd>
		</dl>
		
		<dl id='tritb[12]' ><dt >HRGJINVES</dt> 
			<dd ><input type=text name=ftl_hrgjinves id=hrgjinves_$rnd></dd>
		</dl>
		
		<dl id='tritb[13]' ><dt >PPN</dt> 
			<dd ><input type=text name=ftl_ppn id=ppn_$rnd></dd>
		</dl>
		
		<dl id='tritb[14]' ><dt >LABAPS</dt> 
			<dd ><input type=text name=ftl_labaps id=labaps_$rnd></dd>
		</dl>
		
		<dl id='tritb[15]' ><dt >LABARP</dt> 
			<dd ><input type=text name=ftl_labarp id=labarp_$rnd></dd>
		</dl>
		
		<dl id='tritb[16]' ><dt >PEMBULATAN</dt> 
			<dd ><input type=text name=ftl_pembulatan id=pembulatan_$rnd></dd>
		</dl>
		
		<dl id='tritb[17]' ><dt >DEFDISC</dt> 
			<dd ><input type=text name=ftl_defdisc id=defdisc_$rnd></dd>
		</dl>
		
		<dl id='tritb[18]' ><dt >HRGJUAL</dt> 
			<dd ><input type=text name=ftl_hrgjual id=hrgjual_$rnd></dd>
		</dl>
		
		<dl id='tritb[19]' ><dt >LABARP2</dt> 
			<dd ><input type=text name=ftl_labarp2 id=labarp2_$rnd></dd>
		</dl>
		
		<dl id='tritb[20]' ><dt >LABARP3</dt> 
			<dd ><input type=text name=ftl_labarp3 id=labarp3_$rnd></dd>
		</dl>
		
		<dl id='tritb[21]' ><dt >HRGJUAL2</dt> 
			<dd ><input type=text name=ftl_hrgjual2 id=hrgjual2_$rnd></dd>
		</dl>
		
		<dl id='tritb[22]' ><dt >HRGJUAL3</dt> 
			<dd ><input type=text name=ftl_hrgjual3 id=hrgjual3_$rnd></dd>
		</dl>
		
		<dl id='tritb[23]' ><dt >CBONUS</dt> 
			<dd ><input type=text name=ftl_cbonus id=cbonus_$rnd></dd>
		</dl>
		
		<dl id='tritb[24]' ><dt >KDPRK</dt> 
			<dd ><input type=text name=ftl_kdprk id=kdprk_$rnd></dd>
		</dl>
		
		<dl id='tritb[25]' ><dt >KDPRKPAJAK</dt> 
			<dd ><input type=text name=ftl_kdprkpajak id=kdprkpajak_$rnd></dd>
		</dl>
		
		<dl id='tritb[26]' ><dt >SATUAN</dt> 
			<dd ><input type=text name=ftl_satuan id=satuan_$rnd></dd>
		</dl>
		
		<dl id='tritb[27]' ><dt >WARNA</dt> 
			<dd ><input type=text name=ftl_warna id=warna_$rnd></dd>
		</dl>
		
		<dl id='tritb[28]' ><dt >INACTIVE</dt> 
			<dd ><input type=text name=ftl_inactive id=inactive_$rnd></dd>
		</dl>
		
		<dl id='tritb[29]' ><dt >UKURAN</dt> 
			<dd ><input type=text name=ftl_ukuran id=ukuran_$rnd></dd>
		</dl>
		
		<dl id='tritb[30]' ><dt >KEMASAN</dt> 
			<dd ><input type=text name=ftl_kemasan id=kemasan_$rnd></dd>
		</dl>
		
		<dl id='tritb[31]' ><dt >KDGBRG</dt> 
			<dd ><input type=text name=ftl_kdgbrg id=kdgbrg_$rnd></dd>
		</dl>
		
		<dl id='tritb[32]' ><dt >ISHEADER</dt> 
			<dd ><input type=text name=ftl_isheader id=isheader_$rnd></dd>
		</dl>
		
		<dl id='tritb[33]' ><dt >JBB</dt> 
			<dd ><input type=text name=ftl_jbb id=jbb_$rnd></dd>
		</dl>
		
		<dl id='tritb[34]' ><dt >AE</dt> 
			<dd ><input type=text name=ftl_ae id=ae_$rnd></dd>
		</dl>
		
		<dl id='tritb[35]' ><dt >JLHBUILD</dt> 
			<dd ><input type=text name=ftl_jlhbuild id=jlhbuild_$rnd></dd>
		</dl>
		
		<dl id='tritb[36]' ><dt >HRGPOKOK</dt> 
			<dd ><input type=text name=ftl_hrgpokok id=hrgpokok_$rnd></dd>
		</dl>
		
		<dl id='tritb[37]' ><dt >IME</dt> 
			<dd ><input type=text name=ftl_ime id=ime_$rnd></dd>
		</dl>
		
		<dl id='tritb[38]' ><dt >CAT1</dt> 
			<dd ><input type=text name=ftl_cat1 id=cat1_$rnd></dd>
		</dl>
		
		<dl id='tritb[39]' ><dt >CAT2</dt> 
			<dd ><input type=text name=ftl_cat2 id=cat2_$rnd></dd>
		</dl>
		
		<dl id='tritb[40]' ><dt >MODIFIED_DATE</dt> 
			<dd ><input type=text name=ftl_modified_date id=modified_date_$rnd></dd>
		</dl>
		

		</div>
		
		<!--div align=right style='margin:10px 0px;0px 10px;background:#D2D2D2;padding:10px'>
			<input type=submit class='btn btn-sm btn-primary' value='Filter'>
		</div-->
		===
	</form>
";

?>
