<section class='content-header'>
		  <h1>
			List Template
			<!--small>Preview</small-->
		  </h1>
		  
		</section><section class='content box-input1'>
	<div class='box box-danger'>
				<!--div class='box-header'>
				  <h3 class='box-title'>Input </h3>
				</div-->
				<div class='box-body'>
				<?php
 
		
			extractRecord("select * from tbtemplate where id='$id'");	

			$t='';
			$newop=($id==''?'tb':'ed');
			$addKetInput='';
			$asf="onsubmit=\"ajaxSubmitAllForm('form_$rnd','tsform_$rnd','template','selesaiEdit($rnd)');return false;\" ";
			
			$t.="
	
	<div id=ts"."$idForm ></div>
	<div id=tinputdialog2_$rnd></div>
	<form id='$idForm' action='$nfAction&op=$newop' method='Post' $asf style='padding:0px;margin:0 0 5px 0;' >";

			echo $t;
			
			?>
			
		<span class='pull-right-container'>
		  <i class='fa fa-angle-down pull-right' id='tgmtemplate' 
		  onclick="
			v=$( '#tmtemplate' ).css('display');
			if (v=='none') {
				$( '#tmtemplate' ).show();
				$('#tgmtemplate').css('transform','rotate(0deg)');
				
			} else {
				$( '#tmtemplate' ).hide();
				$('#tgmtemplate').css('transform','rotate(-90deg)');
				
			}
			
		  "></i>
		</span>
		<div id='tmtemplate' v='1' class='tmscroll' >
			<div style='clear:both; '>
				
		<?php 
		
			$sq="Select * from $nmTabel $nmTabelAlias ";
		
			if ($id!='') {
				$sy=" where $nmTabelAlias.$nmFieldID='$id' ";
				$r=extractRecord($sq,false);
				$r2=sqlToArray2($sqTabel.$sy)[0];
			} else {
				$sq.=" where 1=2 ";
				$r=extractRecord($sq,false,false);
				
			}
		echo ''	
		
.rowITB("id","ID~","
<input type=hidden name=id id=id_$rnd  value='$id' >$id   " ,"$id","display:none;","")
.rowITB("judul","JUDUL~","<input type=text name=judul id=judul_$rnd value='$judul' size='40'  class='require S'  >   " ,"$judul","","")
.rowITB("jtrans","JTRANS~","<input type=text name=jtrans id=jtrans_$rnd value='$jtrans' size='40'  class='require S'  >   " ,"$jtrans","","")
.rowITB("isi","ISI~","<input type=text name=isi id=isi_$rnd value='$isi' size='40'  class='require S'  >   " ,"$isi","","")
.rowITB("ket","Catatan~","<input type=text name=ket id=ket_$rnd value='$ket' size='40'  class='require S'  >   " ,"$ket","","")
.rowITB("jumlah","Jumlah~","<input type=text name=jumlah id=jumlah_$rnd value='$jumlah' size='40'  class='require S'  >   " ,"$jumlah","","")?>

<?php 
 echo'' 
		?>
			</div>
			<div style='clear:both; '>
			
			</div>
		</div>
	<?php
			$ntknitb=makeToken('sss=1&newop=ed&id=3');	

		echo "
				<br>
		<input type=hidden name=op id=opx_$rnd value='$newop'> 
		<input type=hidden name='rndinput' id='rndinput' value='$rnd' >
		<input type=hidden value='$ntknitb' id=tkn_$rnd name=tkn>";
		
		?><div id='trsm<?=$rnd?>' class='dl form-group'>
			<div class='col-sm-3 col-xs-4' id='dtsubmit_<?=$rnd?>'>&nbsp;</div>
			<div class='col-sm-9 col-xs-8' id='ddsubmit_<?=$rnd?>'>
			
			<div style='text-align:right'>
	<input type=submit value='Simpan' id=tbsimpan_<?=$rnd?> 
	class='button btn btn-primary btn-sm'
	onclick="
	v=$('#tfae<?=$rnd?>').html();
	w=$('#tfae2<?=$rnd?>').val();
	$('#tfae<?=$rnd?>').html(v+w);
	"
	></div>
			</div>
		
		</div></p></form>
	
	<div style='display:none' >
		<textarea  name='tfuncAfterEdit2' id='tfae2<?=$rnd?>'>
		 dataTable<?=$rnd?>.ajax.reload(true,true);</textarea> 
		<textarea name='tfuncAfterEdit3' id='tfae3<?=$rnd?>' >
		 refreshDT();
		 bukaAjaxD('maincontent','index.php?det=template&op=itb&parentrnd=&newrnd=23204','width:wMax-100,title: \'List Template\'','awalEdit(23204)');</textarea>
		<div id='tfae<?=$rnd?>' name='tfuncAfterEdit' >
	 $('#').dialog('close');
		</div>
		<div id=tfbe<?=$rnd?> name='function before edit'>
			$(function(){
				 
			})
		</div>
		<div id=tcari3_<?=$rnd?> style='display:none'></div>

	</div>
	
				</div>
				<!-- /.box-body -->
			  </div>
			  </section>