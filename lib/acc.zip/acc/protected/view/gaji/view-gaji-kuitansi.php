<?php
$sq="select pg.*,p.nama as namapeg from tbppegawai_gaji pg left join tbppegawai p on pg.idpegawai=p.id where pg.id='$id'";
$hq=mysql_query2($sq);
$r=mysql_fetch_array($hq);
$kep="Pembayaran Gaji Bulan $r[bulan] $r[tahun] ";
?>
<div class='tview' >
	<div class='tbviewatas noprint' style='margin:10px ;text-align:right' >
			<button class='btn btn-success btn-sm' onclick="printDiv('tview_7319')">Cetak</button>
		</div>
	<style>
	.page {
		margin:1cm;
		padding:20px;
	}
	</style>
	<div id=tview_7319>
		<div class=page >
		<div style='border:1px solid #000;padding:20px'>
			<table style=' '><tr>
			<td width=70 >
			<img src='<?=$nfLogo?>' style='width:40px'>
			</td><td>
			<div style='font-size:20px'>MAMA Mart Swalayan</div>
			<div style='font-size:13px'>
			Kuitansi Pembayaran
			</div>
			</td></tr></table>
			<hr>
			<table border='0' class='tbform2xx tbcetaktanpagaris overview-table' width=100% >

			<?=rowView('No. Ref',$r['notrans']);?>
			<?php //rowView('TANGGAL',tglindo($r['tglr']));?>
			<?=rowView('Kepada',$r['namapeg']);?>
			<?php //rowView('PROGRAM',$r["nmprogram"]);?>
			<?=rowView('Uang Sebanyak',terbilang($r['netto'])." Rupiah");?>
			<?=rowView('Untuk Keperluan',$kep);?>
			


			</table>
			<?php

			echo "
			<br>
			<br>
			<table border='0' class='tbform2xx tbcetaktanpagaris overview-table' width=100% >
			<td align=center>Terbilang : ".rupiah($r['netto'])."</td>
			<td align=center>"."Yogyakarta, ".tglindo($r['tgl'])."</td>
			</table>
			";
			?>
		</div>
		</div>
	</div>
 </div>