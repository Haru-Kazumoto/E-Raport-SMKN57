<div class='tview' id='tview_205208'><div class=page>
<h2 class=titleview>
Data Transaksi
</h2>
<div class='tbviewatas noprint' style='margin:-35px 0 10px 0;text-align:right' ><button class='btn btn-success btn-sm' onclick="printDiv('tview_205208')">Cetak</button></div>
<table border='1' class='tbform2xx tbcetaktanpagaris overview-table' width=100% >

<?php
if ($useBranch) echo rowView('CABANG',$r["branch"]); 
?>
<?=rowView('Jenis Transaksi',$r['jenisju']);?>
<?=rowView('Tanggal',sqltotgl($r['tgl']));?>
<?=rowView('No. Transaksi',$r['notrans']);?>
<?=rowView('Nama Pemasok',$r["nmpemasok"]);?>
<?=rowView('Nama Pegawai',$r["namapeg"]);?>
<?=rowView('Keterangan',$r['catatan']);?>
<?=rowView('Nominal',maskRp($r['jlhuang']));?>
</table>
<?php

$t= "
<style>
.row {
	margin-left:0px;
}
.tju {
	margin-top:20px;
	
}
.trowju {
	margin:20px;
	
}

.tketju { }
.tjudebet {}

.tketju, .tjudebet, .tjukredit {
	padding:5px 0px;
	border-bottom:1px solid #ccc;
}


.tjukredit {
	padding-left:10px;
}
</style>
<div class='row tju'>
<h4>Detail Jurnal</h4>".showGL($r['notrans'])."
</div>
";

echo $t;
?>
</div>