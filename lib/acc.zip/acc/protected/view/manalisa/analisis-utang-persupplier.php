<?php

$sy.=addSyKdPlg();	
if ($jtrans=="PP") {
	$jdtrans="PIUTANG";
	$sy.=addSyLapSL($jtrans);	
	$capPb="PELANGAN";
} else {
	$jdtrans="HUTANG";
	$sy.=addSyLapPB($jtrans);	
	$capPb="SUPPLIER";
}
$judul="DATA $jdtrans PER$capPb";
 
 
	//$sy.=addSyKdBrg();	
	$sqorder="tgl asc";
	
	//$tgls=date("Y-m-d");
	
	$sq="select
	h.kdpembantu  as kdpembantu,pb.nama as namaplg,pb.kota,pb.hp,
	 sum($sqTerhutang) as terhutang,max(h.tgl) as tglterakhir
	from ( (  tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbppegawai pj on h.kdpj=pj.id
		
	 $sy and ($sqTerhutang>0) group by h.kdpembantu order by $sqorder ";
	 
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(30,130,80,70,90,80);
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>NAMA $capPb</td>
	<td valign='midle' align='center'  width='$aw[2]px'>KOTA</td>
	<td valign='midle' align='center'  width='$aw[3]px'>HP</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL<br>$jdtrans</td>
	<td valign='midle' align='center'  width='$aw[5]px'>TRANSAKSI<br>TERAKHIR</td>
	</tr>
	";
	
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$r['terhutang'];
		/*
		
	<td valign='midle' align='center'  width='$aw[1]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	<td valign='midle' align='center'  width='$aw[4]px'>CATATAN</td>
	*/
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>$r[kota]</td>
			<td align='center'>$r[hp]</td>
			<td align='center'>".number_format($r['terhutang'])."</td>
			<td align='center'>".tglIndo2($r['tglterakhir'],'d x Y')."</td>
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td>
			<td align='center' colspan=3>JUMLAH</td>
			<td align='center'>".number_format($ajlh[0])."</td>
			<td >&nbsp;</td> 
		</tr>
		"; 
		
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>