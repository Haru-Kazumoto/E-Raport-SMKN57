<?php 
$judul="REKAP $jdtrans PERPELANGGAN PERJENIS-BARANG";
	$capGrp="JENIS BRG";
	$fldGrp="b.jenis,h.kdpembantu";
	$fldGrp0='$r[\'jenis\']';
	$sqorder=" order by b.jenis asc,pb.nama asc";
	$sqGrp="group by $fldGrp  ";
	
//	concat( pb.nama,'(', pb.id,')'),
	  $sq="select $fldGrp,
	b.jenis,pb.nama,
	round(sum(jlh_terima),0) as jlh,
	round(avg(hrg-d.disc),0) as hrgr,
	sum(jlh_terima)*round(avg(hrg-d.disc)) as subtot
	from ((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
	 $sy $sqGrp $sqorder ";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			 
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b> 
			</td> 
			 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

	$maxbr=25;
	$t="";
	$aw=array(20,200,70, 70,70,70);
	
	
	$jdlTb="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td> 
	<td valign='midle' align='center'  width='$aw[1]px'>NAMA PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[2]px'>JUMLAH </td>
	<td valign='midle' align='center'  width='$aw[3]px'>HRG RATA2</td>
	<td valign='midle' align='center'  width='$aw[4]px'>SUB TOTAL</td>
	</tr>
	";
	
	 
	//echo $sq;
	$cdata=$isi="";
	$ra=sqltoarray2($sq);
	$br=1;$brreal=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	$kel="xxxx";
	$pg=1;
	foreach ($ra as $r){
		cekPindahPage(0);
		$rp1=number_format($r['hrgr']);
		$rp2=number_format($r['subtot']);
		eval("$"."xkel=$fldGrp0;");
		if ($kel!=$xkel) {			
			$kel=$xkel;		
			if ($br!=1) {
				if ($brreal>2) {
					$isi.="
					<tr style='line-height: 25px;'>
						<td align='center' colspan=2>JUMLAH</td>
						<td align='center'>".number_format($ajlh[0])."</td>
						<td align='center'>&nbsp;</td>
						<td align='center'>".number_format($ajlh[1])."</td>
					</tr>

					";
					cekPindahPage(1);
				}
				$isi.="</table><br>
				";
			}
			$isi.="
			<div style='font-size:15px;font-weight:bold;margin:10px 0px'>$capGrp : $xkel </div>
			";
			cekPindahPage(1);
			if  ($brreal!=1)  {
				$isi.= $jdlTb;
				cekPindahPage(1);
			}
			$brreal=1;
		}
		
		if (($br%$maxbr==0) && ($brreal!=1)) {
			$isi.= $jdlTb;
			cekPindahPage(1);
		}

		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$brreal</td>
			  
			<td > &nbsp;&nbsp;$r[jenis]</td>
			
			<td align='center'>".number_format($r['jlh'])."</td>
			<td align='center'>$rp1</td>
			<td align='center'>$rp2</td>
		</tr>
		";
		$ajlh[0]+=$r['jlh'];
		$ajlh[1]+=$r['subtot'];
		$br++;
		$brreal++;
	}	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=2>JUMLAH</td>
			<td align='right'>".number_format($ajlh[0])."</td>
			<td align='right'>&nbsp;</td>
			<td align='right'>".number_format($ajlh[1])."</td>
		</tr>
		";
	$isi.="";
	if ($media!='xls') {
		$t.="
		$kop
		$jdlTb
		$isi
		</table>
		";	
	} else {
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
	} 
?>