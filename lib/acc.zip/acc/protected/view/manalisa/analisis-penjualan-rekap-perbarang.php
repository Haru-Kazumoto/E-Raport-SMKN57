<?php 
$judul="REKAP $jdtrans DETAIL PERBARANG";
	
	$sqorder="nmbarang asc";
	 $sq="
	select d.kdbrg,b.nmbarang,
	round(sum(jlh_terima),0) as jlh,
	round(avg(hrg-d.disc),0) as hrgr,
	sum(jlh_terima)*round(avg(hrg-d.disc)) as subtot
	from ((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
	 $sy group  by kdbrg order by $sqorder ";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			 
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b> 
			</td> 
			 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

	$maxbr=26;
	$t="";
	$aw=array(20,70,270, 70,70,70);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>KODE<BR>BARANG</td>
	<td valign='midle' align='center'  width='$aw[2]px'>NAMA BARANG</td>
	<td valign='midle' align='center'  width='$aw[3]px'>JUMLAH </td>
	<td valign='midle' align='center'  width='$aw[4]px'>HRG RATA2</td>
	<td valign='midle' align='center'  width='$aw[5]px'>SUB TOTAL</td>
	</tr>
	";
	
	 
	//echo $sq;
	$cdata=$isi="";
	$ra=sqltoarray2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	foreach ($ra as $r){
		if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page'>
			$kop
			".$jdl;
		}
		
		$rp1=number_format($r[3]);
		$rp2=number_format($r[4]);
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[0]</td>
			<td > &nbsp;&nbsp;$r[1]</td>
			<td align='center'>$r[2]</td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
		</tr>
		";
		$ajlh[0]+=$r['jlh'];
		$ajlh[1]+=$r['subtot'];
		$br++;
	}	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=3>JUMLAH</td>
			<td align='center'>$ajlh[0]</td>
			<td align='right'>&nbsp;</td>
					<td align='right'>".number_format($ajlh[1])."</td>
	</tr>
		";
	$isi.="";
	if ($media!='xls') {
		$t.="
		$kop
		$jdl
		$isi
		</table>
		";	
	} else {
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
	} 
?>