<?php
//fld,cap,width,align,format,sum





//$aw=hitungskala(array(30,90,90,255,90,90,90,90,90,90,90, 120));

/*
	
$jdl="
<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
".$judulTb;

	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sqLap);
	$br=1;
	while ($r=mysql_fetch_array($h)){
		
		if (($br%$maxbr==0) &&($media!='xls'))  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$r['brutto'];
		$ajlh[1]+=$r['tdisc'];
		$ajlh[2]+=$r['netto'];
		$ajlh[3]+=$r['paidtoday'];
		$ajlh[4]+=$r['paidafter'];
		$ajlh[5]+=$r['retur'];
		$ajlh[6]+=$r['hupi'];
		/*
		
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]%'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]%'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]%'>BRUTTO</td>
	<td valign='midle' align='center'  width='$aw[5]%'>DISC</td>
	<td valign='midle' align='center'  width='$aw[6]%'>NETTO</td>
	<td valign='midle' align='center'  width='$aw[7]%'>TUNAI</td>
	<td valign='midle' align='center'  width='$aw[8]%'>RETUR</td>
	<td valign='midle' align='center'  width='$aw[9]%'>PELUNASAN</td>
	<td valign='midle' align='center'  width='$aw[10]%'>HUTANG/PIUTANG</td>
	<td valign='midle' align='center'  width='$aw[11]%'>CATATAN</td>

	* /
		$xtgl=tglIndo2($r['tgl'],'d x Y');
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[notrans]</td>
			<td align='center'>$xtgl</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>".number_format($r['brutto'])."</td>
			<td align='center'>".number_format($r['tdisc'])."</td>
			<td align='center'>".number_format($r['netto'])."</td>
			<td align='center'>".number_format($r['paidtoday'])."</td>
			<td align='center'>".number_format($r['paidafter'])."</td>
			<td align='center'>".number_format($r['retur'])."</td>
			<td align='center'>".number_format($r['hupi'])."</td>
			<td >$r[catatan]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td>
			<td align='center' colspan=3>JUMLAH</td>
			<td align='center'>".number_format($ajlh[0])."</td>
			<td align='center'>".number_format($ajlh[1])."</td>
			<td align='center'>".number_format($ajlh[2])."</td>
			<td align='center'>".number_format($ajlh[3])."</td>
			<td align='center'>".number_format($ajlh[4])."</td>
			<td align='center'>".number_format($ajlh[5])."</td>
			<td align='center'>".number_format($ajlh[6])."</td>
			<td >&nbsp;</td> 
		</tr>
		"; 
		*/
		
	
?>