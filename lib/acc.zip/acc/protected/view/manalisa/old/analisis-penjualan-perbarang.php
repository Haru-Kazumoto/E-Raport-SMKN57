<?php
$judul="DATA $jdtrans DETAIL PERBARANG";
	
	
	$sqorder="nmbarang asc";
	
	 $sq="select
	br.branch,
	 h.notrans,
	 h.tgl,
	 	d.kdbrg,
	b.nmbarang,
	jlh_terima  as jlh,
	 hrg as hrg,
	 jlh_terima*(hrg-d.disc) as subtot
	 
	from (((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy  order by $sqorder ";
	//echo $sq;
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(20,100,30,25,70,200, 70,70,70);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>CABANG</td>
	<td valign='midle' align='center'  width='$aw[2]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[3]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[4]px'>KODE<BR>BARANG</td>
	<td valign='midle' align='center'  width='$aw[5]px'>NAMA BARANG</td>
	<td valign='midle' align='center'  width='$aw[6]px'>JUMLAH </td>
	<td valign='midle' align='center'  width='$aw[7]px'>HRG JUAL</td>
	<td valign='midle' align='center'  width='$aw[8]px'>SUB TOTAL</td>
	</tr>
	";
	$cdata=$isi="";
	$ra=sqltoarray2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	foreach ($ra as $r){
		if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$jlh=number_format($r['jlh']);
		$rp1=number_format($r['hrg']);
		$rp2=number_format($r['subtot']);
		$ajlh[0]+=$r['jlh'];
		$ajlh[1]+=$r['subtot'];
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[0]</td>
			<td align='center'>$r[1]</td>
			<td align='center'>$r[2]</td>
			
			<td align='center'>$r[3]</td>
			<td > &nbsp;&nbsp;$r[4]</td>
			<td align='center'>$jlh</td>
			<td align='center'>$rp1</td>
			<td align='center'>$rp2</td>
		</tr>
		"; 
		$br++;
		
	}
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=6>JUMLAH </td>
			<td align='center'>".number_format($ajlh[0])."</td>
			<td align='center' >&nbsp;</td>
			<td align='center'>".number_format($ajlh[1])."</td>
		</tr>
		"; 
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>