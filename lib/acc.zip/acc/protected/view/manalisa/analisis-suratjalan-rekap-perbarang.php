<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA SURAT JALAN-REKAP PERBARANG";
$judul2="";
 
	$sy="where jtrans='SL' $addSqComboBrg ";
	if ($kdbrg!='') {
		$sy.="and  d.kdbrg='$kdbrg' ";
		
		$namabrg=carifield("select nmbarang  from tbpbarang b where kdbrg='$kdbrg' $addSqComboBrg");
		$subjd.="
			<tr><td width='180'>Nama Barang </td><td >: $namabrg</td></tr>
		";
	}

	if ($kdbranch!='') {
		$sy.="and  h.kdbranch='$kdbranch' ";
		
		$branch=getBranch($kdbranch);
		$subjd.="
			<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
		";
	}
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl1);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} 
	$sqorder="nmbarang asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			 
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b> 
			</td> 
			 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=26;
	$t="";
	$aw=array(30,120,270, 70,70,70);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>KODE BARANG</td>
	<td valign='midle' align='center'  width='$aw[2]px'>NAMA BARANG</td>
	<td valign='midle' align='center'  width='$aw[3]px'>JUMLAH </td>
	
	</tr>
	";
	
	$sq="select d.kdbrg,b.nmbarang,
	round(sum(jlh_terima),0) as jlh,
	round(avg(hrg),0) as hrgr,
	round(avg(jlh_terima*(hrg-d.disc)),0) as subtot
	from ((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy group  by kdbrg order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$ra=sqltoarray($sq);
	$br=0;
	foreach ($ra as $r){
		if ($br==0) {
			$br++;
			continue;
		}
		if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page'>
			$kop
			
			".$jdl;
		}
		$rp1=number_format($r[3]);
		$rp2=number_format($r[4]);
		
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[0]</td>
			<td > &nbsp;&nbsp;$r[1]</td>
			<td align='center'>$r[2]</td>
		</tr>
		"; 
		$br++;
		
	}
	$isi.="";
	
 
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		
	}
 
 
?>