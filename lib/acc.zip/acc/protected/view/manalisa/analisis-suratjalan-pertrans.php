<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA SURAT JALAN PERTRANSAKSI";
$jtrans="SL";
$judul2="";
cekvar("kdpj"); 
	$sy="where jtrans='$jtrans' $addSqComboBrg ";
	
	if ($kdpembantu!='') {
		$sy.="and  h.kdpembantu='$kdpembantu' ";
		
		$namaPlg=getPembantu($kdpembantu);
		$subjd.="
			<tr><td width='180'>Nama Pelanggan </td><td >: $namaPlg</td></tr>
		";
	}

	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.="and  h.kdbranch='$kdbranch' ";
			
			$branch=getBranch($kdbranch);
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
			";
		}
	}
	if ($kdpj!='') {
		$sy.="and  h.kdpj='$kdpj' ";
		
		$namapeg=getPegawai($kdpj);
		$subjd.="
			<tr><td width='180'>Nama Marketing </td><td >: $namapeg</td></tr>
		";
	}
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl2);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} 

	$sqorder="tgl asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(30,80,70,130,90,80,80,70,70, 300);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>NO.SURAT</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td> 
	<td valign='midle' align='center'  width='$aw[4]px'>KENDARAAN</td> 
	<td valign='midle' align='center'  width='$aw[5]px'>SOPIR</td> 
	<td valign='midle' align='center'  width='$aw[6]px'>ASS.SOPIR</td> 
	<td valign='midle' align='center'  width='$aw[7]px'>BY. ANGKUT</td> 
	<td valign='midle' align='center'  width='$aw[8]px'>BON SUPIR</td> 
	<td valign='midle' align='center'  width='$aw[9]px'>CATATAN</td>
	
	</tr>
	";
	
	$sq="
	select
	 br.branch,
	 h.notrans,
	 h.tgl,
	 h.noresi,
	 h.tglkirim,
	 kd.kendaraan,
	 kd.pemilik,
	 h.byangkut,
	 h.byangkuttunai,
	 h.sopir1,
	 h.sopir2,
	 pb.nama as namaplg,
	 h.brutto,
	 h.netto,
	 h.disc,
	 pj.nama as namapj,
	 h.catatan,
	 h.catatansj
	from (( (  tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbppegawai pj on h.kdpj=pj.id)
		left join tbkendaraan kd on h.kdkendaraan=kd.id
		
	 $sy  order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		
		
		$ajlh[0]+=$r['byangkut'];
		$ajlh[1]+=$r['byangkuttunai'];
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[noresi]</td>
			<td align='center'>".tglindo2($r['tgl'],$formatTglLap)."</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>$r[kendaraan]</td>
			<td align='center'>$r[sopir1]</td>
			<td align='center'>$r[sopir2]</td>
			<td align='center'>".maskRp($r['byangkut'],0,0)."</td>
			<td align='center'>".maskRp($r['byangkuttunai'],0,0)."</td>			
			<td >$r[catatansj]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td>
			<td align='center' colspan=6>JUMLAH</td>
		<td align='center'>".maskRp($ajlh[0],0,0)."</td>
		<td align='center'>".maskRp($ajlh[1],0,0)."</td>
			
			<td colspan=2>&nbsp;</td> 
		</tr>
		"; 
		
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>