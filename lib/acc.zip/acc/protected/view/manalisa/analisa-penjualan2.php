<?php 
cekVar("tgl1,tgl2,kdlokasi,kdbrg,kdbranch,kdpj,kdpembantu,fokus,kdpms");
$jdl=$isi=$addKop="";
if ($tgl1=="") $tgl1="1/1/2000";
if ($tgl2=="") $tgl2="31/12/2999";
$tgl1=tgltosql($tgl1);
$tgl2=tgltosql($tgl2);

$fokusx=($fokus=="omset"?"sum(jlh_terima*hrg-d.disc)":"sum(jlh_terima)");
	
	
$syTgl = " and h.tgl>='$tgl1' and h.tgl<='$tgl2' ";
$addKopTgl="<br>Tanggal ".tglIndo($tgl1)." sd  ".tglIndo($tgl2)."";
$syKdTrans = " and (h.jtrans='SL' or h.jtrans='JE' ) ";
$addKop="";
if ($kdbranch=="")
	$syBranch="";
else {
	$syBranch=($kdbranch==""?"":" and h.kdbranch='$kdbranch'");
	$cabang=getBranch($kdbranch);
	$addKop.="<br>Cabang : $cabang";
}
if ($kdpj=="") 
	$syPJ="";
else {
	$syPJ=($kdpj==""?"":" and h.kdpj='$kdpj'");
	$sales=getPegawai($kdpj);
	$addKop.="<br>Nama Sales : $sales";
}
if ($kdpembantu=="") {
	$syPlg="";
	$addKopPlg="";
} else {
	$syPlg=($kdpembantu==""?"":" and h.kdpembantu='$kdpembantu'");
	$namaPlg=getPembantu($kdpembantu);
	$addKopPlg="<br>Nama Pelanggan : $namaPlg";	
}
if ($userType=="pm") {
	$namaPms=getPembantu($defKdPembantu);
	$syPms="and b.kdpemasok='$defKdPembantu'";
	$addKopPms="<br>Nama Pemasok : $namaPms";	
} elseif ($kdpms!="") {
	$namaPms=getPembantu($kdpms);
	$syPms=" and b.kdpemasok='$kdpms'";
	$addKopPms="<br>Nama Pemasok : $namaPms";	
} else {
	$syPms="";
	$addKopPms="";
	
}
$addKop.=$addKopPms;

if ($kdbrg=="")
	$syBrg="";
else {
	$syBrg=($kdbrg==""?"":"and d.kdbrg='$kdbrg'");
	$namabrg=getBarang($kdbrg);
	$addKop.="<br>Nama Barang : $namabrg ";	
}

$syPokok2="$syBranch $syKdTrans $syPJ";
$syPokok=$syPokok2." $syPms $syBrg";


//echo $userType." ".$syPms;
	$clsPage="page";
$th=date("Y",strtotime($tgl1));

if ($jreport=='tpj') {
	$kop="<h2 align=center>Trend Penjualan Tahun $th</h2>";
	
	if ($kdbrg=='') {
		$clsPage="page-landscape";
		$fldsum=str_replace("sum(","(",$fokusx);
		$xsq=generateSqlTrendBulanan($fldTgl="tgl",$fldBar="b.kdbrg,b.nmbarang",
		$nmTable=" (tbpbelid d inner join tbpbeli h on d.notrans=h.notrans) 
			inner join tbpbarang b on d.kdbrg=b.kdbrg ",$showTotal=true,$order="",$fldsum, $th,$sy=" 1=1 $syPokok") ;
	//	$isi=sqltohtmltable($xsq,"class='table table-bordered tbcetakbergaris' width=100%","","C,L,C");
		
		$usePage=false;
		$aOption['sAddAttr']="class='table table-bordered tbcetakbergaris' width=100%";		
		$aOption['clsPage']='page-landscape';
		$aOption['sJudul']="NO,KODE,NAMA BARANG,JAN,FEB,MAR,APR,MEI,JUN,JUL,AGT,SEPT,OKT,NOV,DES,TOTAL";
		$isi=sqltohtmltable2($xsq,$aOption);
	} else {
		$kop="<h2 align=center>Trend Penjualan $namabrg Tahun $th</h2>";
		$arrTabel=array();
		$ajlh=array(0,0,0,0,0,0,0,0,0,0,0,0,0);
		$ajlh2=array(0,0,0,0,0,0,0,0,0,0,0,0,0);
		for ($b=1;$b<=12;$b++) {
			$sy=" where  month(h.tgl)=$b $syPokok $syKdTrans ";
			if ($kdbrg!='') {
				$sy.="and d.kdbrg='$kdbrg' ";//$syTgl;
			}
			
			//$sy.=$syPms;
			$j=array();
			for ($x=0;$x<=1;$x++) {
				$thx=$th-(1-$x);
				$sq="select month(h.tgl) as Bulan,year(h.tgl) as Tahun,$fokusx as Jumlah 
				from tbpbelid d left join tbpbeli h on d.notrans=h.notrans 
				left join tbpbarang b on d.kdbrg=b.kdbrg
				$sy and year(h.tgl)=$thx
				group by left(h.tgl,7)
				order by tgl	";
				$xsq = " select * from (" . $sq . " ) as ss  ";
				extractRecord($xsq);
				$Jumlah*=1;
				$j[$x]=$Jumlah;
				$ajlh[$x]+=$Jumlah;			
			}
			$arrBr=array($b,$Tahun,$j[0],$j[1]);
			$arrTabel[]=$arrBr;
		}
		
		$s="";
		$s.="<table width=100%>";
		$s.="<tr><td>Bulan</td><td align=right>Tahun ".($th-1)."</td><td align=right>Tahun $th</td></tr>";
		$sdata="";
		foreach ($arrTabel as $at) {
			$b=$aBulan[$at[0]-1];
			$s.="<tr><td>$b</td><td>$at[2]</td><td>$at[3]</td></tr>";		
			$sdata.=($sdata==""?"":",")."['".$b."',$at[2],$at[3] ]";
		}
		$s.="<tr><td>Jumlah</td><td>$ajlh[0]</td><td>$ajlh[1]</td></tr>";
		$s.="</table>";
		//grafik
		$txtGrafik="<div id='chart-container'  style='width:500px'>
	<canvas id='graphCanvas$rnd'></canvas>
	<div id=tdata$rnd style='display:none'>[".$sdata."]</div>
	</div>";
	$s.=fbe("cetakGrafikPj2('graphCanvas$rnd','tdata$rnd','Penjualan $namabrg','line');");
	$isi=$txtGrafik.$s;
	}

} else if ($jreport=='tpjsales') {
	$namaPJ="";
	$kop="<h2 align=center>Trend Penjualan Persales</h2>";
	if ($kdpj!='') {
		//$addKop.="<br>Nama Sales : $namaPJ";
		$apj=[[$kdpj],[$namaPJ]];
		$awth=0;
		$akth=1;
	} else {
		$clsPage="page-landscape";
		$awth=0;
		$akth=0;
		$apj=getArray("select distinct(kdpj),p.nama from tbpbeli h left join tbppegawai p on h.kdpj=p.id where 1  $syPokok2 ","kdpj,nama");
	}
	$arrTabel=array();
	//echo var_dump($apj);
	$ajlh=$ajlh2=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	$jlhpj=count($apj[0]);
	
	for ($b=1;$b<=12;$b++) {
		$i=0;
		$arrBr=array($b);
		$jumk=0;
		foreach ($apj[0] as $kdp) {
			$sy=" where  month(h.tgl)=$b $syKdTrans ";
			if ($kdbrg!='') {
				$sy.="and d.kdbrg='$kdbrg' ";//$syTgl;
			}
		 
			$sy.=" and kdpj='$kdp' $syPokok  ";
			//$sy.= $syTgl;
			$j=array(0,0);
			for ($x=$awth;$x<=$akth;$x++) {
				$thx=$th-($akth-$x);
				$sq="select month(h.tgl) as Bulan,year(h.tgl) as Tahun,sum(jlh_terima*hrg) as Jumlah 
				from tbpbelid d left join tbpbeli h on d.notrans=h.notrans 
				left join tbpbarang b on d.kdbrg=b.kdbrg
				$sy and year(h.tgl)=$thx 
				group by left(h.tgl,7)
				order by tgl	";
				$xsq = " select * from (" . $sq . " ) as ss  ";
				extractRecord($xsq);
				$Jumlah*=1;
				$j[$x]=$Jumlah;
				$arrBr[]=$Jumlah;
				
			}
			$jumk+=$j[0];
			$i++;
			
		}
		if ($kdpj=="") $arrBr[]=$jumk;
		$arrTabel[]=$arrBr;
	}
	
	$s="";
	$s.="<table width=100%>";
	$s.="<tr><td>Bulan</td>";
	if ($kdpj=='') {
		foreach($apj[1] as $nm) {
			$s.="<td align=right>$nm </td>";
		}
			$s.="<td align=right>Jumlah</td>";
		
	} else {
		$s.="<td>Tahun ".($th-1)."</td>";
		$s.="<td>Tahun $th</td>";
	
	}
	//$s.="<td>Jumlah</td>";
	$s.="</tr>";
	$jlh=[0,0,0,0,0,0,0,0,0,0,0,0];
	$sdata="";
	$br=0;
	foreach ($arrTabel as $at) {
		$s.="<tr>";
		$i=0; 
		$sbrdata="";
		foreach ($at as $dt) {
			$sdata.=($sdata==""?"":",");
			if ($i==0) {
				$d=$aBulan[$dt-1];
				$alg="left";
				$sbrdata="['$d'";
			}else{
				$d=maskRp($dt);
				$alg="right";
				$sbrdata.=",$dt";
				
			}				
			
			$s.="<td align='$alg'>$d</td>";
			if ($i>0) $jlh[$i]+=$dt;
			$i++;
		 
		}
		$sbrdata.="]";
		if ($br<12) $sdata.=($sdata==""?"":",").$sbrdata;
		$s.="</tr>";	
		$br++;
	}
	
	
	$s.="<tr><td>Jumlah</td>";
	for ($i=1;$i<=$jlhpj+1;$i++) {
		$s.="<td align=right>".maskRp($jlh[$i])."</td>";
	}
	
	$s.="</tr>";	
	$s.="</table>";
	
	$txtGrafik="";
	if ($syPJ!='') {
		$txtGrafik="<div id='chart-container'  style='width:500px'>
		<canvas id='graphCanvas$rnd'></canvas>
		 
		<div id=tdata$rnd style='display:none'>[".$sdata."]</div>
		</div>";
		$s.=fbe("cetakGrafikPj2('graphCanvas$rnd','tdata$rnd','Penjualan $namaPJ','line');");
	}
	$isi=$txtGrafik.$s;

	
} else if ($jreport=="omsetbrg") {
	$kop="<h2 align=center>Analisa Jumlah Barang Terjual Kepada Pelanggan </h2>";
	//if ($kdpembantu=="")
	//	$isi=um412_falr("Pilih salah satu pelanggan terlebih dahulu");
	//else {
		if ($kdpembantu!="") {
			$addKop.=$addKopPlg;
			$syPokok.=$syPlg;
				
		}
		$kop="<h2 align=center>Analisa Jumlah Barang Terjual</h2>";
		//sama dengan di analisa penjualan
		$ttt=($jreport=='pb'?'desc':'asc');
		
		$lim = " limit 0,30";
		$sqGroup = " group by d.kdbrg "; 
		$sq = "select d.kdbrg as Kode,b.nmbarang as Nama_Barang,$fokusx as Jumlah from 
		(tbpbelid d inner join tbpbarang b on d.kdbrg=b.kdbrg) 
		inner join tbpbeli h on d.notrans=h.notrans $syPokok $sqGroup";
		$xsq = " select * from (" . $sq . " ) as ss order by jumlah desc " . $lim;
		 //function sqlToHtmlTable($ssql,$sAddAttr="", $sJudul="",$sAlignX="",$outputas='html',$showJlh="-" ,$pAddEv='',$includehead=1) {
		$isi=sqltohtmltable($xsq,"class='table table-bordered tbcetakbergaris' width=100%","","C,L,C");
	 
} else if ($jreport=='tpjplg') {
	$namaPJ="";
	$kop="<h2 align=center>Trend Penjualan Pelanggan</h2>";
	if ($kdpembantu!='') {
		$addKop.=$addKopPlg;
		$syPokok.=$syPlg;
		$apj=[[$kdpj],[$namaPJ]];
		$awth=0;
		$akth=1;
		$arrTabel=array();
		//echo var_dump($apj);
		$ajlh=$ajlh2=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
		$jlhpj=count($apj[0]);
		
		for ($b=1;$b<=12;$b++) {
			$i=0;
			$arrBr=array($b);
			$jumk=0;
			$sy=" where  month(h.tgl)=$b $syPokok   ";
			//$sy.= $syTgl;
			$j=array(0,0);
			for ($x=0;$x<=1;$x++) {
				$thx=$th-($akth-$x);
				$sq="select month(h.tgl) as Bulan,year(h.tgl) as Tahun,$fokusx as Jumlah 
				from ((tbpbelid d inner join tbpbeli h on d.notrans=h.notrans) 
				inner join tbpbarang b on d.kdbrg=b.kdbrg
				) inner join tbppembantu pb on h.kdpembantu=pb.id
				$sy and year(h.tgl)=$thx 
				group by left(h.tgl,7)
				order by tgl	";
				 $xsq = " select * from (" . $sq . " ) as ss  ";
				extractRecord($xsq);
				$Jumlah*=1;
				$j[$x]=$Jumlah;
				$arrBr[]=$Jumlah;
				
			}
			$jumk+=$j[0];		
			$arrTabel[]=$arrBr;
		}
		
		$s="";
		$s.="<table width=100%>";
		$s.="<tr><td>Bulan</td>";
		$s.="<td align=right >Tahun ".($th-1)."</td>";
		$s.="<td align=right >Tahun $th</td>";
		//$s.="<td>Jumlah</td>";
		$s.="</tr>";
		$jlh=[0,0,0,0,0,0,0,0,0,0,0,0];
		$sdata="";
		$br=0;
		foreach ($arrTabel as $at) {
			$s.="<tr>";
			$i=0; 
			$sbrdata="";
			foreach ($at as $dt) {
				$sdata.=($sdata==""?"":",");
				if ($i==0) {
					$d=$aBulan[$dt-1];
					$alg="left";
					$sbrdata="['$d'";
				}else{
					$d=maskRp($dt);
					$alg="right";
					$sbrdata.=",$dt";
					
				}				
				
				$s.="<td align='$alg'>$d</td>";
				if ($i>0) $jlh[$i]+=$dt;
				$i++;
			 
			}
			$sbrdata.="]";
			if ($br<12) $sdata.=($sdata==""?"":",").$sbrdata;
			$s.="</tr>";	
			$br++;
		}
		
		
		$s.="<tr><td>Jumlah</td>";
		for ($i=1;$i<=$jlhpj+1;$i++) {
			$s.="<td align=right>".maskRp($jlh[$i])."</td>";
		}
		
		$s.="</tr>";	
		$s.="</table>";
		
		$txtGrafik="";
			$txtGrafik="<div id='chart-container'  style='width:500px'>
			<canvas id='graphCanvas$rnd'></canvas>
			<div id=tdata$rnd style='display:none'>[".$sdata."]</div>
			</div>";
			$s.=fbe("cetakGrafikPj2('graphCanvas$rnd','tdata$rnd','Penjualan $namaPJ','line');");
		
		$isi=$txtGrafik.$s;
	} else {
		//$clsPage="page-landscape";
		$isi=um412_falr("Pilih salah satu pelanggan terlebih dahulu");
	}
	
} elseif ($jreport=="omsetpms") {
	//omset penjualan fokus pada pemasok 
	$addKop.=$addKopTgl;
	$kop=
	"<h2 align=center>".($jreport=="peringkat"?"Peringkat Penjualan ":"Omset Penjualan")." Semua Pemasok</h2>";
	
	//$sqOrder=($jreport=="peringkat"?' order by Omset desc':'');
	$sqOrder=" order by Omset desc";
	
	$lim = ($jreport=="peringkat"?" limit 0,30":"");
	$sqGroup = " group by b.kdpemasok";
	
	$sq = "select b.kdpemasok as Kode,pm.nama as Nama_Pemasok,$fokusx as Omset from 
	(((tbpbeli h inner join tbpbelid d on d.notrans=h.notrans)
	inner join tbpbarang b on d.kdbrg=b.kdbrg)	
	inner join tbppembantu pm on b.kdpemasok=pm.id)	
	
	where 1 $syTgl $syPokok  $sqGroup";
	$xsq = " select * from (" . $sq . " ) as ss $sqOrder " . $lim;
	 //function sqlToHtmlTable($ssql,$sAddAttr="", $sJudul="",$sAlignX="",$outputas='html',$showJlh="-" ,$pAddEv='',$includehead=1) {
	$arrTabel=sqltoarray($xsq,"class='table table-bordered tbcetakbergaris' width=100%","","C,L,C");
	$jdlTb="<table width=100% border=1 class='tbcetakbergaris table table-bordered'>";
	$jdlTb.="<tr><td>NO</td><td>Nama Pemasok</td><td align=right >Omset</td></tr>";
	$t="";
	$t.=$jdlTb;
	$br=1;
	$maxBr=32;
	$pg=1;
	foreach ($arrTabel as $arr) {
		$t.="<tr><td>$br</td><td>$arr[1]</td><td align=right>".maskRp($arr[2])."</td></tr>";
		
		if ($br%$maxBr==0) {
			$t.="</table>
			<center>$pg</center>
			</div><div class='$clsPage'>".$jdlTb;
			$pg++;
		}
		$br++;
	}
	$t.="</table>";
	$t.="<center>$pg</center>";
	
	$isi=$t;
	
} else {
	//omset penjualan pelanggan dan peringkat
	$addKop.=$addKopTgl;
	$kop=
	"<h2 align=center>".($jreport=="peringkat"?"Peringkat Penjualan":"Omset Penjualan")." Semua Pelanggan</h2>";
	
	//$sqOrder=($jreport=="peringkat"?' order by Omset desc':'');
	$sqOrder=" order by Omset desc";
	
	$lim = ($jreport=="peringkat"?" limit 0,30":"");
	$sqGroup = " group by h.kdpembantu ";
	
	$sq = "select h.kdpembantu as Kode,pb.nama as Nama_Pelanggan,pg.nama as sales,$fokusx as Omset from 
	(((tbpbeli h inner join tbpbelid d on d.notrans=h.notrans)
	inner join tbpbarang b on d.kdbrg=b.kdbrg)	
	inner join tbppembantu pb on h.kdpembantu=pb.id)	
	left join tbppegawai pg on pb.kdpj=pg.id
	
	where 1 $syTgl $syPokok  $sqGroup";
	$xsq = " select * from (" . $sq . " ) as ss $sqOrder " . $lim;
	 //function sqlToHtmlTable($ssql,$sAddAttr="", $sJudul="",$sAlignX="",$outputas='html',$showJlh="-" ,$pAddEv='',$includehead=1) {
	$arrTabel=sqltoarray($xsq,"class='table table-bordered tbcetakbergaris' width=100%","","C,L,C");
	$jdlTb="<table width=100% border=1 class='tbcetakbergaris table table-bordered'>";
	$jdlTb.="<tr><td>NO</td><td>Nama Pelanggan</td><td>Nama Sales</td><td align=right >Omset</td></tr>";
	$t="";
	$t.=$jdlTb;
	$br=1;
	$maxBr=32;
	$pg=1;
	foreach ($arrTabel as $arr) {
		$t.="<tr><td>$br</td><td>$arr[1]</td><td>$arr[2]</td><td align=right>".maskRp($arr[3])."</td></tr>";
		
		if ($br%$maxBr==0) {
			$t.="</table>
			<center>$pg</center>
			</div><div class='$clsPage'>".$jdlTb;
			$pg++;
		}
		$br++;
	}
	$t.="</table>";
	$t.="<center>$pg</center>";
	
	$isi=$t;
	
}
	
if (!isset($usePage)) $usePage=true;
if ($usePage) {
	$t="";
	$t.="
		<style>
	.page {
		
		padding:2.5cm ;
		
		
		}
	.page,
	.page td {
		font-size:11px
	}
	</style> 
	<div class='$clsPage'>
	$kop
	<div style='font-weight:bold;font-size:13px'>$addKop</div>
	<br>
	$jdl
	$isi
	 <div>
	";
} else $t=$isi;
 echo $t;
?>