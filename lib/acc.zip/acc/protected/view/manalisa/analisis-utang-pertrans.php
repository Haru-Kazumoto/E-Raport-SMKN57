<?php

$sy.=addSyKdPlg();	
if ($jtrans=="PP") {
	$jd1="PIUTANG";
	$sy.=addSyLapSL($jtrans);	
} else {
	$jd1="HUTANG";
	$sy.=addSyLapPB($jtrans);	
	
}
$judul="DATA $jd1 PERTRANSAKSI";
 

$judul2="";
	//$sy.=addSyKdBrg();	
	$sqorder="tgl asc";
	
	//$tgls=date("Y-m-d");
	
	$sq="select
	br.branch,
	 h.notrans,
	 h.jtrans,
	 h.tgl,
	 pb.nama as namaplg,
	 h.brutto,
	 h.netto,
	 h.disc,
	 h.paidtoday,h.paidafter,h.retur,h.disc,h.disc2,
	 $sqTerhutang as terhutang,
	 pj.nama as namapj,
	 h.catatan
	from ( (  tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbppegawai pj on h.kdpj=pj.id
		
	 $sy and ($sqTerhutang>0) order by $sqorder ";
	 
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(30,100,90,205,90,80,80,80,80,80, 200);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	<td valign='midle' align='center'  width='$aw[5]px'>TUNAI</td>
	<td valign='midle' align='center'  width='$aw[6]px'>PELUNASAN</td>
	<td valign='midle' align='center'  width='$aw[7]px'>RETUR</td>
	<td valign='midle' align='center'  width='$aw[8]px'>$jd1</td>
	<td valign='midle' align='center'  width='$aw[9]px'>CATATAN</td>
	
	</tr>
	";
	
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$xnotrans=createLinkTrans($r['notrans'],$r['jtrans']);
		$ajlh[0]+=$r['netto'];
		$ajlh[1]+=$r['paidtoday'];
		$ajlh[2]+=$r['paidafter'];
		$ajlh[3]+=$r['retur'];
		$ajlh[4]+=$r['terhutang'];
		/*
		
	<td valign='midle' align='center'  width='$aw[1]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	<td valign='midle' align='center'  width='$aw[4]px'>CATATAN</td>
	*/
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$xnotrans</td>
			<td align='center'>".tglIndo2($r['tgl'],'d x Y')."</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>".number_format($r['netto'])."</td>
			<td align='center'>".number_format($r['paidtoday'])."</td>
			<td align='center'>".number_format($r['paidafter'])."</td>
			<td align='center'>".number_format($r['retur'])."</td>
			<td align='center'>".number_format($r['terhutang'])."</td>
			<td >$r[catatan]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td>
			<td align='center' colspan=3>JUMLAH</td>
			<td align='center'>".number_format($ajlh[0])."</td>
			<td align='center'>".number_format($ajlh[1])."</td>
			<td align='center'>".number_format($ajlh[2])."</td>
			<td align='center'>".number_format($ajlh[3])."</td>
			<td align='center'>".number_format($ajlh[4])."</td>
			<td colspan=2>&nbsp;</td> 
		</tr>
		"; 
		
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>