<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA SURAT JALAN DETAIL PERBARANG";
$judul2="";
 
	$sy=addSyLapSL();	
	$sy.=addSyKdPlg();	
	$sy.=addSyKdBrg();
	
	$sqorder="nmbarang asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			</td> 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(20,90,90,120,200, 70,70,70);
	
//	<td valign='midle' align='center'  width='$aw[1]px'>CABANG</td>
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>NO.SURAT</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>KENDARAAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>NAMA BARANG</td>
	<td valign='midle' align='center'  width='$aw[5]px'>JUMLAH </td> 
	</tr>
	";
	
	$sq="select
	br.branch,
	 h.notrans,
	 h.tgl,
	 h.tglkirim,
	 h.noresi,
	kd.kendaraan,
	kd.pemilik,
	h.sopir1,
	h.sopir2,
	h.byangkut,
 	d.kdbrg,
	b.nmbarang,
	jlh_terima  as jlh,
	 hrg as hrgr,
	 jlh_terima*(hrg-d.disc) as subtot
	 
	from ((((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbkendaraan kd on h.kdkendaraan=kd.id
		 
	 $sy  order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$ha=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	while ($ra =mysql_fetch_array($ha)){
		if (($br%$maxbr==0) &&($br>0)) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$ra["jlh"];
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$ra[noresi]</td>
			<td align='center'>".tglindo2($ra['tglkirim'],$formatTglLap)."</td>
			<td align='center'>$ra[kendaraan]</td>
			<td align='center'>$ra[nmbarang]</td>
			<td align='center'>".maskrp($ra['jlh'],0,0)."</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=5>JUMLAH</td>
			<td align='center'>".maskrp($ajlh[0],0,0)."</td> 
		</tr>
		"; 
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>