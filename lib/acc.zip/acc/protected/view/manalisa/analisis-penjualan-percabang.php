<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA PENJUALAN PERTRANSAKSI";
$judul2="";
 
	$sy=addSyLapSL();	
	$sy.=addSyKdPlg();	
	$sy.=addSyKdBrg();
	
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(20,100,30,25,70,200, 70,70,70);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	<td valign='midle' align='center'  width='$aw[4]px'>CATATAN</td>
	
	</tr>
	";
	
	$sq="select
	br.branch,
	 h.notrans,
	 h.tgl,
	 	d.kdbrg,
	b.nmbarang,
	jlh_terima  as jlh,
	 hrg as hrgr,
	 jlh_terima*(hrg-d.disc) as subtot
	 
	from (((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy $addGrp order by $sqorder ";
	
	
	/*
	$sq="select
br.branch,
	 h.notrans,
	 h.tgl,
	 pb.nama as namaplg,
	 h.netto,
	 h.disc,
	 h.catatan
	from (   tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id
	 $sy  $addGrp order by $sqorder ";
	*/
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$r['netto'];
		/*
		
	<td valign='midle' align='center'  width='$aw[1]px'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]px'>TGL</td>
	<td valign='midle' align='center'  width='$aw[3]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	<td valign='midle' align='center'  width='$aw[4]px'>CATATAN</td>
	*/
		
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[notrans]</td>
			<td align='center'>$r[tgl]</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>".number_format($r['netto'])."</td>
			<td >$r[catatan]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td>
			<td align='center' colspan=3>JUMLAH</td>
			<td align='center'>".number_format($ajlh[0])."</td>
			<td >$r[catatan]</td> 
		</tr>
		"; 
		
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>