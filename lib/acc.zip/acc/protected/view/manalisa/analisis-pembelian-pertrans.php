<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA PEMBELIAN PERTRANSAKSI";
$judul2="";
cekvar("kdpj,statby"); 
	$sy="where h.jtrans='PB' $addSqComboBrg ";
	if ($kdpembantu!='') {
		$sy.="and  h.kdpembantu='$kdpembantu' ";
		
		$namaPlg=getPembantu($kdpembantu);
		$subjd.="
			<tr><td width='180'>Nama Pemasok </td><td >: $namaPlg</td></tr>
		";
	}
	
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.="and  h.kdbranch='$kdbranch' ";	
			$branch=getBranch($kdbranch);
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
			";
		}
	}
	/*
	if ($kdpj!='') {
		$sy.="and  h.kdpj='$kdpj' ";
		
		$namapeg=getPegawai($kdpj);
		$subjd.="
			<tr><td width='180'>Nama Marketing </td><td >: $namapeg</td></tr>
		";
	}
	*/
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl2);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} else {
		echo um412_falr("Pilih Tanggal terlebih dahulu","danger");
		exit;
	} 

	if (($statby=='Lunas')||($statby=='Belum Lunas')){
		if ($statby=='Lunas') 
			$sy.="and  (h.netto-h.paidtoday-h.paidafter-h.retur)=0 ";	
		else
			$sy.="and  (h.netto-h.paidtoday-h.paidafter-h.retur)>0 ";	
		
		$subjd.="
			<tr><td width='180'>Status Pembayaran </td><td >: $statby</td></tr>
		";
	
	}
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$xw2=0;
	$xtd2="";
	if ($useNoFakturInPB) {
		$xw2=90;
		$xtd2="<td valign='midle' align='center'  width='$aw[2]px'>No. Faktur</td>";

	} 

	
	$aw=array(30,90,$xw2,90,135,90,80,90,90,90,90,120);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<thead>
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>No</td>
	<td valign='midle' align='center'  width='$aw[1]px'>No. Trans</td>
	$xtd2
	<td valign='midle' align='center'  width='$aw[3]px'>Tanggal</td>
	<td valign='midle' align='center'  width='$aw[4]px'>Pemasok</td>
	<td valign='midle' align='center'  width='$aw[5]px'>Pembelian</td>
	<td valign='midle' align='center'  width='$aw[6]px'>Biaya Timbang</td>
	<td valign='midle' align='center'  width='$aw[7]px'>Total Transaksi</td>
	<td valign='midle' align='center'  width='$aw[8]px'>Pembayaran Tunai</td>
	<td valign='midle' align='center'  width='$aw[9]px'>Pelunasan</td>
	<td valign='midle' align='center'  width='$aw[10]px'>Terhutang</td>
	<td valign='midle' align='center'  width='$aw[11]px'>Catatan</td>
	
	</tr>
	</thead>
	<tbody>
	";
	
	$sq="select
br.branch,
	 h.notrans,
	 h.nofaktur,
	 h.tgl,
	 pb.nama as namaplg,
	 h.brutto,
	 h.bytimbang,
	 h.netto,
	 h.paidtoday,
	 h.paidafter,
	 h.netto-h.paidtoday-h.paidafter-h.retur as terhutang,
	 h.disc,
	 pj.nama as namapj,
	 h.catatan
	from ( (  tbpbeli h  left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbppegawai pj on h.kdpj=pj.id
		
	 $sy  order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$r['brutto'];
		$ajlh[1]+=$r['bytimbang'];
		$ajlh[2]+=$r['netto'];
		$ajlh[3]+=$r['paidtoday'];
		$ajlh[4]+=$r['paidafter'];
		$ajlh[5]+=$r['terhutang'];
		
		$xtdfaktur="";

		if ($useNoFakturInPB) {
			$xtdfaktur="<td align='center'>$r[nofaktur]</td>";			
		} 		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[notrans]</td>
			$xtdfaktur
			<td align='center'>".tglindo($r['tgl'])."</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>".maskRp($r['brutto'],0,0)."</td>
			<td align='center'>".maskRp($r['bytimbang'],0,0)."</td>
			<td align='center'>".maskRp($r['netto'],0,0)."</td>
			<td align='center'>".maskRp($r['paidtoday'],0,0)."</td>	
			<td align='center'>".maskRp($r['paidafter'],0,0)."</td>
			<td align='center'>".maskRp($r['terhutang'],0,0)."</td>
			<td >$r[catatan]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
	</tbody>
	<tfoot>
		<tr style='line-height: 25px;'>
			<td align='center' colspan=5>JUMLAH</td>
			<td align='center'>".maskRp($ajlh[0],0,0)."</td>
			<td align='center'>".maskRp($ajlh[1],0,0)."</td>
			<td align='center'>".maskRp($ajlh[2],0,0)."</td>
			<td align='center'>".maskRp($ajlh[3],0,0)."</td>
			<td align='center'>".maskRp($ajlh[4],0,0)."</td>
			<td align='center'>".maskRp($ajlh[5],0,0)."</td>
		</tr>
	</tfoot>
		"; 
		
	$isi.="";
	
	
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	
 
?>