<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA PACKING REKAP PERBARANG ";
$judul2=""; 
	$sy="where jtrans='PG' $addSqComboBrg ";
	if ($kdbrg!='') {
		$sy.="and  d.kdbrg='$kdbrg' ";
		
		$namabrg=carifield("select nmbarang  from tbpbarang b where kdbrg='$kdbrg' $addSqComboBrg");
		$subjd.="
			<tr><td width='180'>Nama Barang </td><td >: $namabrg</td></tr>
		";
	}
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.="and  h.kdbranch='$kdbranch' ";
			
			$branch=getBranch($kdbranch);
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
			";
		}
	}
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl1);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} 
	$sqorder="nmbarang asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			 
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b> 
			</td> 
			 
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=26;
	$t="";
	$aw=array(20,70,270,70,70,70);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>No.</td>
	<td valign='midle' align='center'  width='$aw[1]px'>Kode Barang</td>
	<td valign='midle' align='center'  width='$aw[2]px'>Nama Barang</td>
	<td valign='midle' align='center'  width='$aw[3]px'>Jumlah</td>
	</tr>
	";
	
	$sq="select d.kdbrg,b.nmbarang,
	round(sum(jlh_terima),2) as jlh,
	round(avg(hrg),0) as hrgr,
	round(avg(jlh_terima*(hrg-d.disc)),0) as subtot
	from ((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy group  by kdbrg order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$ha=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	
	while ($r=mysql_fetch_array($ha)){
 
		if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page'>
			$kop
			
			".$jdl;
		}
 
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[kdbrg]</td>
			<td > &nbsp;&nbsp;$r[nmbarang]</td>
			<td align='center'>".maskRp($r['jlh'])."</td> 
		</tr>
		"; 
		$ajlh[0]+=$r['jlh']*1;
		$br++;
		
	}
	//tampilkan jumlah jika kdbarang nggak milih
	if ($kdbrg=='') {
		$isi.="
			<tr style='line-height: 25px;'>
				<td align='center' colspan=3>JUMLAH</td>
				<td align='center'>".maskRp($ajlh[1],0,1)."</td>
			</tr>
			"; 
	}
	$isi.="";
	
 
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		
	}
 
 
?>