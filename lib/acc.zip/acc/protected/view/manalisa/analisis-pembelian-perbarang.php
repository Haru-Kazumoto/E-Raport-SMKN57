<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$judul="DATA PEMBELIAN DETAIL";
$judul2="";
 
	$sy="where jtrans='PB' $addSqComboBrg ";
	if ($kdbrg!='') {
		$sy.="and  d.kdbrg='$kdbrg' ";
		
		$namabrg=carifield("select nmbarang  from tbpbarang b where kdbrg='$kdbrg' $addSqComboBrg");
		$subjd.="
			<tr><td width='180'>Nama Barang </td><td >: $namabrg</td></tr>
		";
	}
	
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.="and  h.kdbranch='$kdbranch' ";
			
			$branch=getBranch($kdbranch);
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
			";
		}
	}
	
	if ($kdpembantu!='') {
		$sy.="and  h.kdpembantu='$kdpembantu' ";
		
		$namaPlg=getPembantu($kdpembantu);
		$subjd.="
			<tr><td width='180'>Nama Pemasok </td><td >: $namaPlg</td></tr>
		";
	}
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo($xtgl1);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} 
	
	
	
	$sqorder="nmbarang asc";

//			<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 		
			</td> 
		</tr>
 </table>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$xw2=0;
	if ($useNoFakturInPB) {
		$xw2=90;
		$xtd2="<td valign='midle' align='center'  width='$aw[3]px'>No. Faktur</td>";

	} 

	
	$aw=array(30,90,80,$xw2,80,90,120,70,70,70,90,100);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>No.</td>
	<td valign='midle' align='center'  width='$aw[1]px'>Cabang</td>
	<td valign='midle' align='center'  width='$aw[2]px'>No. Trans</td>
	<td valign='midle' align='center'  width='$aw[4]px'>Tanggal</td>
	<td valign='midle' align='center'  width='$aw[4]px'>Pemasok</td>
	<td valign='midle' align='center'  width='$aw[5]px'>Kode Barang</td>
	<td valign='midle' align='center'  width='$aw[6]px'>Nama Barang</td>
	<td valign='midle' align='center'  width='$aw[7]px'>Jumlah</td>
	<td valign='midle' align='center'  width='$aw[8]px'>Tarra</td>
	<td valign='midle' align='center'  width='$aw[9]px'>Net</td>
	<td valign='midle' align='center'  width='$aw[10]px'>Harga</td>
	<td valign='midle' align='center'  width='$aw[11]px'>Subtotal</td>
	</tr>
	";
	
	$sq="select
br.branch,
	 h.notrans,
	 h.nofaktur,
	 h.tgl,
	 d.kdbrg,
	b.nmbarang,
	jlh_brutto ,
	jlh_tarra  ,
	jlh_terima ,
	 hrg,
	 jlh_terima*(hrg-d.disc) as subtot,
	 pb.nama as namapb
	from (((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy  order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$ha=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	
	while ($r=mysql_fetch_array($ha)){
		if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		
		$xtd2="";
		if ($useNoFakturInPB) {
			$xtd2="	<td align='center'>$r[nofaktur]</td>";
		}
	
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[branch]</td>
			<td align='center'>$r[notrans]</td>
			<td align='center'>".tglindo($r['tgl'])."</td>
			<td align='center'>$r[namapb]</td>
			<td align='center'>$r[kdbrg]</td>
			<td align='center'>$r[nmbarang]</td>
			<td align='center'>".maskRp($r['jlh_brutto'])."</td>
			<td align='center'>".maskRp($r['jlh_tarra'])."%</td>
			<td align='center'>".maskRp($r['jlh_terima'])."</td>
			<td align='center'>".maskRp($r['hrg'],0,0)."</td>
			<td align='center'>".maskRp($r['subtot'],0,0)."</td>
		</tr>
		"; 
		$ajlh[0]+=$r['jlh_brutto']*1;
		$ajlh[1]+=$r['jlh_terima']*1;
		$ajlh[2]+=$r['subtot']*1;
		
		$br++;
		
	}
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=8>JUMLAH</td>
			<td align='center'>".maskRp($ajlh[0])."</td>
			<td align='center'>&nbsp;</td>
			<td align='center'>".maskRp($ajlh[1])."</td>
			<td align='center'>&nbsp;</td>
			<td align='center'>".maskRp($ajlh[2],0,0)."</td>
		</tr>
		"; 
		
	$isi.="";
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>