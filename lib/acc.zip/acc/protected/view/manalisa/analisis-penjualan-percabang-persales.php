<?php
 
$judul="DATA $jdtrans PERCABANG PERSALES";	
	//$sqorder="tgl asc";
	$sqorder="";//"order by h.tgl asc";
	$addGrp="group by h.kdbranch, h.kdpj";

	$sq="select
	h.kdbranch as KODE,
	br.branch as CABANG,
	concat(pg.nama,' (',h.kdpj,')') as namapj,
	 jlh_terima*(hrg-d.disc) as subtot
	from ((((tbpbelid d left join tbpbeli h on d.notrans=h.notrans)
		left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbpbarang b on d.kdbrg=b.kdbrg )
		left join tbppembantu pb on h.kdpembantu=pb.id)
		 left join tbppegawai pg on h.kdpj=pg.id
	 $sy  $addGrp $sqorder ";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
			<td width='80' style='width:$ax[2]px' >
			
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 


	$t="";
	$aw=array(20,100,30,25,70,200, 70,70,70);
	
	$jlh=array(0,0,0,0,0,0,0,0);
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>NO</td> 
	<td valign='midle' align='center'  width='$aw[2]px'>CABANG</td>
	<td valign='midle' align='center'  width='$aw[3]px'>SALES</td>
	<td valign='midle' align='center'  width='$aw[4]px'>TOTAL</td>
	</tr>
	";

	//echo $sq;
	$cdata=$isi="";
	$ra=mysql_query2($sq);
	$br=1;
	while  ($r=mysql_fetch_array($ra)){
		 
		if (($br%$maxbr==0)&&($br>0)) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='$clspage'>
			$kop
			
			".$jdl;
		}
		$jlh[0]+=$r['subtot'];
		
		$isi.="
			<tr>
			<td align=center>$br</td>
		 
			<td align=center>".$r['CABANG']."</td>
			<td align=center>".$r['namapj']."</td>
			<td align=center>".number_format($r['subtot'])."</td>
			</tr>
			"; 
			
		$br++;
		
	}
	$isi.="";
		$isi.="
			<tr>
			<td align=center>&nbsp</td>
		 
			<td align=center colspan=2 >JUMLAH</td>
			<td align=center>".number_format($jlh[0])."</td>
			</tr>
			"; 
	
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Cabang,No.Trans,Tgl,Kode Barang,Nama Barang,Jumlah,Hrg Jual,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		echo "sudah";
	}
 
 
?>