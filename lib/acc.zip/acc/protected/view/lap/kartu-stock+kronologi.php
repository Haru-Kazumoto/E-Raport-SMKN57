<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";

$clspage="page";
$page=1;
$maxbr1=25;
$maxbr2=30;
$maxCharPerBr=28;
cekVar("tgl1,tgl2,idstock,kdbrg");
$aw=hitungskala(array(20,170,200,430, 30,90,90,90,90,15),100);

//jika buku besar perkiraan labarugi, tanggal sebelum periode dianggap nol (tidak ada saldo awal)

function evalBr(){
	global $br,$maxbr,$maxbr1,$maxbr2,$media,$isi,$clspage,$kop,$jdl,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$jdl;//$kop
		$br=1;
		$page++;
	}
	//$br++;
	
}

if (($tgl1=="")||($tgl2=="")) {
	echo um412_falr("Masukkan Tanggal terlebih dahulu ");
	exit;
}
$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;


$sy="where 1=1 ";
$judul=$judulLap="KARTU STOCK";

$judul2="";
$subjd='';

$t="";
$t.=awalLaporan();
$t.=buattbhead($judulLap,$tgl1,$tgl2);
	
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.=" and  h.kdbranch='$kdbranch' ";
			$cabang=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $cabang</td></tr>
			";
		}
	}
	
	if ($idstock!='') {
		$sy="s.id='$idstock'"; 
	} elseif ($kdbrg!='') {
		$sy="s.kdbrg='$kdbrg' and s.kdlokasi='$kdlokasi'";
	}else {
		echo um412_falr("Pilih barang yang akan dicetak terlebih dahulu","danger");
		exit;
	}
	extractRecord("
	 select s.id as idstock,s.kdbrg,b.satuan,s.kdlokasi,nmbarang,lokasi,branch from tbpbarang b 
	 left join tbpstock s on b.kdbrg=s.kdbrg 
	 left join tbplokasi l on s.kdlokasi=l.id 
	 left join tbpbranch br on l.kdbranch=br.kdbranch 		  
	where $sy 
	");
	
	$sy2="d.kdbrg='$kdbrg'";
	
	$subjd.="
		<tr><td width='180'>Nama Barang </td><td >: $nmbarang ( $kdbrg )</td></tr>
		<tr><td width='180'>Lokasi</td><td >: $lokasi</td></tr>
	";
	//keterangan data barang
	
	
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy2.="and  h.tgl>='$xtgl1' ";
		$ketTgl=tglindo2($xtgl1);
		$xtgl2=tgltosql($tgl2);
		
		if ($tgl2!=$tgl1) {
			$sy2.=" and h.tgl<='$xtgl2' ";
			$ketTgl.=" sd ".tglindo2($xtgl2);
		}
		
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : $ketTgl</td></tr>
		";
	} 
	$sqorder="tgl asc,jtrans asc";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop=buattbhead($judulLap);
$kop.="
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>	
  ";
  
$ketbrg="";
 extractRecord("select * from tbpbarang where kdbrg='$kdbrg'");

$hrgbeliterakhir=$defhrgbeli;
$xhbt=maskrp($hrgbeliterakhir,0,9);

$ketbrg="
<br>Keterangan Data barang
<br>Jenis : $jenis
<br>Harga Beli : $xhbt, Harga Jual : $hrgjual  
";
$hrgjualterakhir=$hrgjual;
$xhjt=maskrp($hrgjualterakhir,0,9);
extractRecord("select st.*,st.id as idstock from tbpstock st where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'");
//PERBAIKAN HARGA AWAL JIKA HARGA AWAL 0, GANTI DENGAN HRGBELI YANG DI PEMBELIAN

$hrgbeliterakhir=$hrgawal;
$xhbt=maskrp($hrgbeliterakhir,0,9);
$ketbrg.="
<br>Jumlah Stock $nmbarang di Lokasi/Gudang $lokasi 
<br>Stock Awal : $stawal, harga:$hrgawal
<br>Hrg Beli Terakhir: $xhbt, Hrg Jual Terakhir: $xhjt
 ";
if ($hrgawal==0) {
	mysql_query2("
	update tbpstock set hrgawal='$defhrgbeli' where id='$idstock';
	");
	$ketbrg.="<br>Perbaikah harga awal menjadi : $xhbt, Hrg Jual Terakhir: $xhbt";
	$hrgbeliterakhir=$defhrgbeli;
	$xhbt=maskrp($hrgbeliterakhir,0,9);
	
} else {
mysql_query2("
	update tbpbelid  set hpp='$defhrgbeli' where kdbrg='$kdbrg' and kdlokasi='$kdlokasi'
	");
	
}
	 
  
if ($media!='') $kop.="<br><br>";
 

	$t="";
	
	
 	$sq="
	select h.kdlokasi,h.kdlokasi2,h.tgl,h.notrans,h.catatan,'' as ref,
	if(
		h.jtrans='PB' or h.jtrans='SR' or (h.jtrans='PG' and d.jlh_terima>=0)
		or (h.jtrans='DS' and h.kdlokasi2='$kdlokasi')
	,abs(d.jlh_terima),0) as debet,
	if(
		h.jtrans='SL' or h.jtrans='PR' or h.jtrans='JE' or (h.jtrans='PG' and d.jlh_terima<0)
		or (h.jtrans='DS' and h.kdlokasi='$kdlokasi')
	,abs(d.jlh_terima),0) as kredit,
		if(h.jtrans='SL' or h.jtrans='JE' or h.jtrans='SR',hpp,hrg) as vhrg,
	
	
	h.jtrans,jlh_terima,hrg,hpp,
	p.nama as namapeg,
	pb.nama as namapb,
	h.id
	from 
	tbpbelid d left join tbpbeli h on d.notrans=h.notrans
		left join tbppembantu pb on h.kdpembantu=pb.id
		left join tbppegawai p on h.kdpj=p.id
		 
	 where $sy2 and (h.kdlokasi='$kdlokasi' or h.kdlokasi2='$kdlokasi' ) order by $sqorder ";	
//	<td valign='midle' align='center'  width='$aw[4]%'>REF</td>
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[2]%'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[3]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[5]%'>Masuk</td>
	<td valign='midle' align='center'  width='$aw[6]%'>Keluar </td>
	<td valign='midle' align='center'  width='$aw[7]%'>HPP</td>
	<td valign='midle' align='center'  colspan=2 width='".($aw[8]+$aw[9])."%'>Saldo</td>
 
	
	</tr>
	";
	
	$saldo=$saldorp=0;
	$vsaldo=0;
	$hrgbeliterakhir=$hrgjualterakhir=0;
	$cdata=$isi="";
	//if ($isTest) 
	//	echo $sq;
			//cari saldo awal dulu
			$sa=getStockAkhir($kdbrg,$kdlokasi,$xtgl1);
			$vhrg= getHppTerakhir($kdbrg,$kdlokasi,$xtgl1);
			
			
			//jika perkiraan labarugi, saldo awal diabaikan
			//if ($kdprk>=40000) $sa=0;
			$debet=abs(($sa>=0?$sa:0));
			$kredit=abs(($sa<0?$sa:0));
			
			$rp1=number_format($debet);
			$rp2=number_format($kredit);
			$rp3=number_format($vhrg);
			$saldorp+=(($debet-$kredit)*$vhrg);
			$xsaldorp=number_format(abs($saldorp));
			$saldo+=$sa;
			$xsaldo=number_format(abs($saldo));
			
			$dk=($saldo>=0?"D":"K");
			
//			<td align='right'>&nbsp;</td>
			$tglawal=tglIndo2($xtgl1,'d x Y');
			$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>1</td>
			<td align='center'>".$tglawal."</td>
			<td colspan=2> Saldo Awal ($tglawal)</td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'>$rp3</td>
			<td align='right'  width='$aw[8]'>$xsaldo</td>
			<td align='center' width='$aw[9]'>$dk</td>
		</tr>
		"; 
		
	//echo $sq;
	$h=mysql_query2($sq);
	$br=1;
	$no=1;
	$jlhd=$debet;
	$jlhk=$kredit;
	while ($r=mysql_fetch_array($h)){
		$brAwal=$br;
		$no++; 
		$debet=$r['debet'];
		$kredit=$r['kredit'];
		$rp1=number_format($r['debet']);
		$rp2=number_format($r['kredit']);
		$rp3=number_format($r['vhrg']);
		$saldo+=$r['debet']-$r['kredit'];
		$xsaldo=number_format(abs($saldo));
		$saldorp+=(($r['debet']-$r['kredit'])*$r['vhrg']);
		$xsaldorp=number_format(($saldorp));
		$dk=($saldo>=0?"D":"K");
		if ($r['jtrans']=='DS') {
			//distribusi
			$lokasi1=getLokasi($r['kdlokasi']);
			$lokasi2=getLokasi($r['kdlokasi2']);
			
			if ($debet>=$kredit) {
				//$rcat="Distribusi Masuk dari $lokasi1 ke $lokasi2";
				$rcat="Distribusi Masuk dari $lokasi1 ";
			} else {
				$rcat="Distribusi Keluar ke $lokasi2";
			}
		} elseif ($r['jtrans']=='SL') {
				$rcat="Penjualan ke ".$r['namapb'];
		} elseif ($r['jtrans']=='SR') {
				$rcat="Retur Penjualan dari ".$r['namapb'];			
		} elseif ($r['jtrans']=='PB') {
				$rcat="Pembelian dari ".$r['namapb'];
		} elseif ($r['jtrans']=='PR') {
				$rcat="Retur Pembelian ke ".$r['namapb'];			
		} else {
			$rcat=$r['namapb'];//$r["catatan"];
			if ($rcat=="") {
				$rcat=getKetTransJU($r['id'],"");
			}
		}
		/*
		$rcatreplace=str_replace("x","X",$rcat);
		if ($rcatreplace==strtoupper($rcat)) $rcat=ucfirst(strtolower($rcat));
		*/
		$cat1=$rcat;
		$cat2="";
		$brCat=max(ceil(strlen($cat1)/$maxCharPerBr),0);
		$maxbr=($page==1?$maxbr1:$maxbr2);
		$sisaBr=$maxbr-$br;
		if ($brCat>$sisaBr) {
			//membagi catatan
			$cat1=potong($rcat,($sisaBr*$maxCharPerBr),true,""," ")."";
			$cat2=substr($rcat,strlen($cat1),strlen($rcat));			
			$br+=$sisaBr;
		} else {
			$br+=$brCat;
			
		}
		//$br+=$brCat;
		
		//evalBr();
		$jlhd+=$r['debet']*1;
		$jlhk+=$r['kredit']*1;
		
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans'],15);
//			<td align='center'>$r[ref]</td>
//			<td align='right'>$xsaldorp</td>
		$xtgltrans=tglIndo2($r['tgl'],'d x Y');
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".$xtgltrans."</td>
			<td align='center'> &nbsp;$xnotrans</td>
			<td >$cat1 </td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'>$rp3</td>
			<td align='right'>$xsaldo</td>
			<td align='center'>$dk</td>
			
		</tr>
		";
		
		$jtrans=$r['jtrans'];
		$vdk=($r['kredit']>0?"Masuk":"Keluar");
		$jlhtrans=maskrp($r['jlh_terima'], 0,9);
		$xtrans=getFldJTrans($jtrans);
		$vhrg=maskrp($r['hrg'], 0,9);
		$vhpp=maskrp($r['hpp'], 0,9);
		$vsaldo=maskrp($saldo, 0,9);;
		if (strstr(',SL,JE,',",$jtrans")!='') {
			$hrgjualterakhir=$r['hrg'];
			$xhjt=maskRp($hrgjualterakhir,0,9);
		} else {
			
		}
		$ketbrg.="<hr>Tanggal $xtgltrans, terjadi transaksi <b>$xtrans</b> 
		<br>Dengan nomor transaksi $xnotrans
		sebanyak $jlhtrans ($vdk) dengan harga $vhrg,hpp $vhpp, <br>
		<br>Sehingga Saldo sampai saat ini: $vsaldo dengah hpp $vhpp;
		<br>Hrg Beli Terakhir: $xhbt, Hrg Jual Terakhir: $xhjt
		";	
		
		
		
		
		evalBr();
		if ($cat2!='') {
			$br=$brCat-$sisaBr;
			$isi.="
			<tr style='line-height: 25px;'>
				<td align='center'> </td>
				<td align='center'> </td>
				<td align='center'>  </td>
				<td class=tdket >$cat2 </td>
				<td align='center'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='center'> </td>
				
			</tr>
			";
			evalBr();
		}
		//$br++;	
	}
	
	$rp1=number_format($jlhd);
	$rp2=number_format($jlhk);
	$sld=$jlhd-$jlhk;
	$sdk=($sld>=0?"D":"K");
	$rp3=number_format(abs($sld));
	$isi.="";
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=4 >TOTAL</td>
			<td align='right'><b>$rp1</b></td>
			<td align='right'><b>$rp2</b></td>
			<td align='right'><b></b></td>
			<td align='right'><b>$rp3</b></td>
			<td align='center'><b>$sdk</b></td>
		</tr>
		"; 
	
 
		if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";

		echo "
		<style>
		.tbcetakbergaris,
		.tbcetakbergaris td {
			font-size:11px;
		}
		.tdket {
			line-height: 14px;
		}		
		@media print {
			.page {
				padding: 1cm;
			}
		}
		
		hr {
			margin:0px;
		}
		</style>
		<div class='$clspage'>
	
			$kop
			$ketbrg
			$jdl
			$isi
			</table>
		</div>
		";
		

echo "
<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >
$t
";


?>