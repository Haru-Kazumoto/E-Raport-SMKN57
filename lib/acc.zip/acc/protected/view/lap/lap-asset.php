<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
cekVar("kdprk");


$judul="DAFTAR ASSET";

$judul2="";
	$subjd='';
	$sy="where 1=1 ";
	if ($kdbranch!=''){
		$branch=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
		$sy.=" and h.kdbranch='$kdbranch' ";
	 	$subjd.="
			<tr><td width='180'>Cabang </td><td >: $branch</td></tr> 
		";
	
	}
	if ($kdprk!=''){
		$jenisa=carifield("select account_name from ".$oNamaTb->akun." where account_code='$kdprk'");
		$sy.=" and h.idpegawai='$kdpegawai' ";
	 	$subjd.="
			<tr><td width='180'>Jenis Asset </td><td >: $jenisa</td></tr> 
		";
	
	} 
	
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
			
		</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=17;
	$t="";
	$aw=array(20,200,80,120,120,120,220);
	
	/*
	
	<td valign='midle' align='center'  width='$aw[6]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[7]px'>PEGAWAI</td>
	
	<td valign='midle' align='center'  width='$aw[4]px'>REF</td>
	*/
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
		<tr>
		<td valign='midle' align='center'  width='$aw[0]px'>NO</td>
		<td valign='midle' align='left'  width='$aw[1]px'>DESKRIPSI</td>
		<td valign='midle' align='center'  width='$aw[2]px'>TGL. BELI</td>
		<td valign='midle' align='center'  width='$aw[3]px'>HARGA BELI</td>
		<td valign='midle' align='center'  width='$aw[4]px'>TOTAL DEPR.</td>
		<td valign='midle' align='center'  width='$aw[5]px'>NILAI</td>
		<td valign='midle' align='center'  width='$aw[6]px'>CATATAN</td>
	
	</tr>
	";
	
	$sq="select 
	h.nama_asset,h.tglbeli,h.hrgbeli,h.akumulasi,(h.hrgbeli-h.residu-h.akumulasi) as xnilai,h.catatan from tbpasset h 
	 $sy  order by nama_asset asc ";
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$saldo=0;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		if (($br%$maxbr==0 )&&($br>0)) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		} 
		$ajlh[2]+=$r[2]*1;
		$ajlh[3]+=$r[3]*1;
		$ajlh[4]+=$r[4]*1;
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='left'>$r[0]</td>
			<td align='center'>".sqltotgl($r[1],'d M Y')."</td>
			<td align='right'>".rupiah2($r[2])."</td>
			<td align='right'>".rupiah2($r[3])."</td>
			<td align='right'>".rupiah2($r[4])."</td>
			<td align='left'>".$r[5]."</td> 
		</tr>
		"; 
		$br++;
		
	}
	$isi.="
			<tr style='line-height: 25px;'>
			<td align='center'>&nbsp;</td> 
			<td align='left' colspan=2>JUMLAH</td>
			<td align='right'>".rupiah2($ajlh[2])."</td>
			<td align='right'>".rupiah2($ajlh[3])."</td>
			<td align='right'>".rupiah2($ajlh[4])."</td>
			<td align='left'>".$r[5]."</td>
		</tr>
	";
		
 
	
	if ($media!='xls') {
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	} else {
		 
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		
	}
 
 
?>