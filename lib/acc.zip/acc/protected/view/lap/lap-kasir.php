<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0; 

$clspage="page";
$page=1;
$maxbr1=31;
$maxbr2=40;
$maxCharPerBr=28;
cekVar("tgl1,tgl2,kdprk");
$aw=hitungskala(array(20,170,200,430,90),100);


//jika buku besar perkiraan labarugi, tanggal sebelum periode dianggap nol (tidak ada saldo awal)

function evalBr(){
	/*
	global $br,$maxbr,$maxbr1,$maxbr2,$media,$isi,$clspage,$kop,$jdl,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$jdl;//$kop
		$br=1;
		$page++;
	}
	//$br++;
	*/
}
function maskRp0($x,$sty='') {
	$m=maskRp($x,0,0);
	$addsty='';
	//if ($sty=="u") $addsty.="border-top:1px solid #000";
	return "<div style='float:right;text-align:right,width:100px;$addsty'>".$m."</div>";
}



if (($tgl1=="")||($tgl2=="")) {
	echo um412_falr("Masukkan Tanggal terlebih dahulu ");
	exit;
}
$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;


$sy="where 1=1 ";
$judul="LAPORAN KAS KASIR";

$judul2="";
$subjd='';
	
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.=" and  h.kdbranch='$kdbranch' ";
			$cabang=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $cabang</td></tr>
			";
		}
	}
	if ($kdprk!='') {
		$namaakun=carifield("select account_name  from ".$oNamaTb->akun." where account_code='$kdprk'");
		$sy.="and   d.kdprk='$kdprk'   ";
		
		$subjd.="
			<tr><td width='180'>Nama Akun </td><td >: $kdprk - $namaakun</td></tr>
		";
	} else {
		echo um412_falr("Pilih Akun terlebih dahulu","danger");
	}
 	
	
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$xtgl2=tgltosql($tgl2);
		$sytgl1="and  h.tgl>='$xtgl1' and h.tgl<='$xtgl2' ";
		
		$sy.=$sytgl1;
		$xxtgl=tglindo2($xtgl1);
		
		if ($tgl1!=$tgl2) $xxtgl.=" sd ".tglindo2($xtgl2);
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : $xxtgl</td></tr>
		";
	} 
	$sqorder="tgl asc";

//total penerimaan dari penjualaneceran
$sqc="select sum(paidtoday) from tbpbeli h where (jtrans='JE' or jtrans='SL') ";//'and carabayar='C'//kdprkkas<>'$kdprk' and
$sq=$sqc." and kdbranch='$kdbranch' $sytgl1 and kdprkkas='$kdprk' ";
$totcash=carifield($sq)*1;

if (!$isOnline || ($ce==1)) {
	//cekking data
	 $sqc="select sum(brutto) from tbpbeli h where (jtrans='JE' or jtrans='SL') ";//'and carabayar='C'//kdprkkas<>'$kdprk' and
	$sq=$sqc." and kdbranch='$kdbranch' $sytgl1 and kdprkkas='$kdprk' ";
	$totbrutto=carifield($sq)*1;

	$sqc="select sum(jlh_terima*hrg) from tbpbeli h  inner join tbpbelid d on h.notrans=d.notrans where (jtrans='JE' or jtrans='SL') ";//'and carabayar='C'//kdprkkas<>'$kdprk' and
	$sq=$sqc." and kdbranch='$kdbranch' $sytgl1 and kdprkkas='$kdprk' ";
	$totbrutto2=carifield($sq)*1;

	$sqc="select * from (select h.notrans,h.tgl,h.brutto, sum(subtot) as sumb,sum(d.jlh_terima*d.hrg) as sumj,brutto-sum(jlh_terima*hrg) as sisa
	from tbpbeli h left join tbpbelid d on h.notrans=d.notrans where (jtrans='JE' or jtrans='SL') ";
	$sq=$sqc." and kdbranch='$kdbranch' $sytgl1 and kdprkkas='$kdprk' group by h.notrans) 
	as tbku where (isnull(sumj) or sisa<>0) order by sisa ";
	echo "cek data yg mungkin bmasalah";
	echo sqltohtmltable($sq);
	echo "totbrutto $totbrutto totbrutto2 $totbrutto2 totcash $totcash";
	
	
	
	
}
//$sq="select paidtoday from tbpbeli h where jtrans='JE' and kdbranch='$kdbranch' $sytgl1 and carabayar='C'";
$totcard=0;//carifield($sq)*1;

//penerimaan dan pengeluaran dari transaksi lain
$sqFrom="from ".$oNamaTb->gltrans." d inner join ".$oNamaTb->gld." h 
on d.notrans=h.notrans where kdbranch='$kdbranch' 
 and d.kdprk='$kdprk' ";
  $sqd="select sum(abs(d.jlhuang)) $sqFrom $sytgl1 and jtrans<>'JE' and d.jlhuang>=0";
$cashd=carifield($sqd)*1;
$cashk=carifield("select sum(abs(d.jlhuang)) $sqFrom $sytgl1 and jtrans<>'JE' and d.jlhuang<0")*1;

//cari saldo awal
 $sq="select sum(d.jlhuang) $sqFrom and tgl<'$xtgl1'";
$saw1=carifield($sq)*1;
$saw0=carifield("select sawal from ".$oNamaTb->akun." where  account_code='$kdprk'")*1;


$sawalcash=$saw0+$saw1;

$totpd=$totcash+$totcard;
$totcashd=$sawalcash+$cashd+$totcash;
$totcashk=$cashk;
$totcashdk=$totcashd-$totcashk;


$tb1="
<div class='jd2 gb'>POSISI PENDAPATAN</div>
<table width=100%>
<tr>
	<td width=50%>Penerimaan Cash</td>
	<td>: ".maskRp0($totcash)."</td>
</tr>
<tr>
	<td>Card</td>
	<td>: ".maskRp0($totcard)."</td>
</tr>
<tr>
	<td>Total Pendapatan</td>
	<td class='tot'>: ".maskRp0($totpd)."</td>
</tr>

</table>
";

$tb2="
<div class='jd2 gb' >
POSISI KEUANGAN CASH
</div>
<table width=100%>
<tr>
	<td width=33%>Saldo Awal</td>
	<td width=33%>: ".maskRp0($sawalcash)."</td>
	<td width=34% rowspan=3>&nbsp;</td>
</tr>
<tr>
	<td>Tambah Modal</td>
	<td>: ".maskRp0($cashd)."</td>
</tr>
<tr>
	<td>Penerimaan Cash</td>
	<td  class='utot'>: ".maskRp0($totcash)."</td>
</tr>
<tr>
	<td></td>
	<td>Total Cash</td>
	<td class='tot'>: ".maskRp0($totcashd,"u")."</td>
</tr>
<tr>
	<td>Pengeluaran Cash</td>
	<td  class='utot'>: ".maskRp0($cashk)."</td>
</tr>
<tr>
	<td></td>
	<td>Total Pengeluaran</td>
	<td class='tot utot'>: ".maskRp0($totcashk,"u")."</td>
</tr>

<tr>
	<td></td>
	<td>Saldo Akhir</td>
	<td class='tot'>: ".maskRp0($totcashdk,"u")."</td>
</tr>


</table>
";

$tbhead00="


<b>
UD BAYU SEJAHTERA<br>
Kantor Cabang $cabang
</b>
<br>
<br>
<div class='jd1' >
REKAPITULASI AKTIVITAS KASIR
</div>
<div class='jd2' >
Tanggal $xxtgl
</div>
<br>
<br>
</center>
<table width=100%>
<tr>
	<td valign=top width=40% >$tb1</td>
	<td valign=top width=5% >&nbsp;</td>
	<td valign=top >$tb2</td>
</tr>
</table>
";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop="";//buattbhead($judul);
$kop.=$tbhead00."<br><br>";

$t=$isi="";

for ($xx=0;$xx<=1;$xx++) {
	$saldo=0;
	$cdata="";
	
	$xsy=$sy." and d.jlhuang ".($xx==0?">=":"<")." 0 and h.jtrans<>'JE'";
	$xjd="LAPORAN ".($xx==0?"PENERIMAAN":"PENGELUARAN")." KAS";
	$jdl="
<div class='jd2 ' >
$xjd
</div>
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[2]%'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[3]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[4]%'>JLH UANG</td>
	</tr>
	";
	
	$sq="select h.tgl,h.notrans,h.catatan,h.ref,
	if(d.jlhuang>=0,d.jlhuang,0) as debet,
	if(d.jlhuang<0,d.jlhuang*-1,0) as kredit,
	p.nama as namapeg,
	pb.nama as namapb,
	h.id
	from (((".$oNamaTb->gltrans." d left join ".$oNamaTb->gld." h on d.notrans=h.notrans)
		left join tbppegawai p on h.idpegawai=p.id )
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbpjtrans jt on h.jenisju=jt.jtrans		 
	 $xsy  order by $sqorder ";

	$isi.=$jdl;
	$h=mysql_query2($sq);
	$br=1;
	$no=1;
	$jlhd=0;//$debet;
	$jlhk=0;//$kredit;
	while ($r=mysql_fetch_array($h)){
		$brAwal=$br;
		$no++; 
		$rp1=number_format($r['debet']);
		$rp2=number_format($r['kredit']);
		$saldo+=$r['debet']-$r['kredit'];
		$xsaldo=number_format(abs($saldo));
		$dk=($saldo>=0?"D":"K");
		$rcat=$r["catatan"];
		if ($rcat=="") {
			$rcat=getKetTransJU($r['id'],"");
		}
		$rcatreplace=str_replace("x","X",$rcat);
		if ($rcatreplace==strtoupper($rcat)) $rcat=ucfirst(strtolower($rcat));
		$cat1=$rcat;
		$cat2="";
		$brCat=max(ceil(strlen($cat1)/$maxCharPerBr),0);
		$maxbr=($page==1?$maxbr1:$maxbr2);
		$sisaBr=$maxbr-$br;
		if ($brCat>$sisaBr) {
			//membagi catatan
			$cat1=potong($rcat,($sisaBr*$maxCharPerBr),true,""," ")."";
			$cat2=substr($rcat,strlen($cat1),strlen($rcat));			
			$br+=$sisaBr;
		} else {
			$br+=$brCat;
			
		}

		//evalBr();
		$jlhd+=$r['debet']*1;
		$jlhk+=$r['kredit']*1;
		
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans'],15);
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".sqltotgl($r['tgl'],'d M Y')."</td>
			<td align='center'> &nbsp;$xnotrans</td>
			<td >$cat1 </td>
			<td align='right'>$xsaldo</td>
		</tr>
		";
	
			
		evalBr();
		if ($cat2!='') {
			$br=$brCat-$sisaBr;
			$isi.="
			<tr style='line-height: 25px;'>
				<td align='center'> </td>
				<td align='center'> </td>
				<td align='center'>  </td>
				<td >$cat2 </td>
				<td align='center'> </td>
				<td align='right'> </td>			
			</tr>
			";
			evalBr();
		}
		//$br++;	
	}
	
	$rp1=number_format($jlhd);
	$rp2=number_format($jlhk);
	$sld=$jlhd-$jlhk;
	$sdk=($sld>=0?"D":"K");
	$rp3=number_format(abs($sld));
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=4 >TOTAL</td>
			<td align='right'><b>$rp3</b></td>
		</tr>
		</table>
		<br>
		"; 
	$t.=$isi;
} //xx

if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";

echo "
<style>
.tot {
	font-weight:bold;
}
.jd2 {
	font-weight:bold;
	text-align:center;
	margin-bottom:10px;
}
.jd1 {
	font-size:16px;
	font-weight:bold;
	text-align:center;
}

.gb {
	border-bottom:1px solid #000;
}

.utot {
	border-bottom:1px solid #000;
}

.tbcetakbergaris,
.tbcetakbergaris td {
	font-size:11px;
}

@media print {
	.page {
		padding: 1cm;
	}
}
</style>
<div class='$clspage'>

	$kop
	$isi
	</table>
</div>
";
/*
} else {
 
$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
$arrTable =sqltoarray($sq,"");
include $um_path."sql2xls.php";

}
*/
 
?>