<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";

$clspage="page";
$page=1;
$maxbr1=31;
$maxbr2=38;
$maxCharPerBr=42;
cekVar("tgl1,tgl2");
$aw=hitungskala(array(20,280,500,90,90,90,15),100);

function evalBr(){
	global $br,$maxbr,$maxbr1,$maxbr2,$media,$isi,$clspage,$kop,$jdl,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$jdl;//$kop
		$br=1;
		$page++;
	}
	//$br++;
	
}

if (($tgl1=="")||($tgl2=="")) {
	echo um412_falr("Masukkan Tanggal terlebih dahulu ");
	exit;
}

$sy="where 1=1 ";
if ($jlap=="cashflow") {
	$judul="CASH FLOW";
	
} elseif ($jlap=="bukuhutang") {
	$judul="BUKU PEMBANTU HUTANG";
	$kdprkhp=2000;
	$sy.=" and  d.kdprk='$kdprkhp'";
} elseif ($jlap=="bukupiutang") {
	$judul="BUKU PEMBANTU PIUTANG";
	$kdprkhp=1220;
	$sy.=" and  d.kdprk='$kdprkhp'";
} else {
	$judul="LAPORAN BUKU BESAR";
}
$judul2="";
$subjd='';
	if ($useBranch!='') {
		if ($kdbranch!='') {
			$sy.=" and  h.kdbranch='$kdbranch' ";
			$cabang=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
			
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $cabang</td></tr>
			";
		}
	}	 	
	if ($kdprk!='') {
		$namaakun=carifield("select account_name  from ".$oNamaTb->akun." where account_code='$kdprk'");
		$sy.="and   d.kdprk='$kdprk'   ";
		
		$subjd.="
			<tr><td width='180'>Nama Akun </td><td >: $kdprk - $namaakun</td></tr>
		";
	} else {
		if ($jlap=="cashflow") {
			echo um412_falr("Pilih Akun terlebih dahulu","danger");
			exit;
		}

	}
	
	if ($kdpembantu!='') {
		extractRecord("select id,nama as namapb,kota  from tbppembantu where id='$kdpembantu'");
		$sy.="and h.kdpembantu='$kdpembantu'   ";
		
		$subjd.="
			<tr><td width='180'>Nama Pelanggan/Pemasok </td><td >: $namapb ($kota) </td></tr> 
		";
	}
	
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl>='$xtgl1' and h.tgl<='$xtgl2' ";
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : ".tglindo2($xtgl1)." sd ".tglindo2($xtgl2)."</td></tr>
		";
		
		$_SESSION['tgllap1']=$tgl1;
		$_SESSION['tgllap2']=$tgl2;

	} 
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop=buattbhead($judul);
$kop.="
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>	
  ";
if ($media!='') $kop.="<br><br>";
 

	$t="";
	
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>TANGGAL<br>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[2]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[3]%'>DEBET</td>
	<td valign='midle' align='center'  width='$aw[4]%'>KREDIT </td>
	<td valign='midle' align='center'  colspan=2 width='".($aw[5]+$aw[6])."%'>SALDO</td>
 
	
	</tr>
	";
	
	$sq="select h.id,h.tgl,h.notrans,h.catatan,h.ref,
	if(d.jlhuang>=0,d.jlhuang,0) as debet,
	if(d.jlhuang<0,d.jlhuang*-1,0) as kredit,
	p.nama as namapeg,
	pb.nama as namapb,
	h.id
	from (((".$oNamaTb->gltrans." d left join ".$oNamaTb->gld." h on d.notrans=h.notrans)
		left join tbppegawai p on h.idpegawai=p.id )
		left join tbppembantu pb on h.kdpembantu=pb.id)
		left join tbpjtrans jt on h.jenisju=jt.jtrans
		 
	 $sy  order by $sqorder ";
	 
	$saldo=0;
	$cdata=$isi="";
	//if ($isTest) 
	//	echo $sq;
		//cari saldo awal dulu
		if (($jlap=='bukuhutang')||($jlap=='bukupiutang')) {
			$sa0=carifield("select sawal from tbppembantu where id='$kdpembantu' ")*1;
			$sq="select sum(d.jlhuang) from (".$oNamaTb->gltrans." d left join ".$oNamaTb->gld." h on d.notrans=h.notrans) left join tbpjtrans jt on h.jenisju=jt.jtrans where d.kdprk=jt.kdprk and h.kdpembantu='$kdpembantu'  and h.tgl<'$xtgl1'";
			$sa1=carifield($sq)*1;
		} else {
			$sa0=0;
			$sa1=getSaldoAkhir($kdprk,$xtgl1,0);
		}
		
		$sa=$sa0+$sa1;
		//jika perkiraan labarugi, saldo awal diabaikan
		if ($kdprk>=40000) $sa=0;
		
		
		$debet=abs(($sa>=0?$sa:0));
		$kredit=abs(($sa<0?$sa:0));
		
		$rp1=number_format($debet);
		$rp2=number_format($kredit);
		
		$saldo+=$sa;
		$xsaldo=number_format(abs($saldo));
		$dk=($saldo>=0?"D":"K");
		
		$isi.="
	<tr style='line-height: 25px;'>
		<td align='center'>1</td>
		<td align='center'>".sqltotgl($xtgl1,'d M Y')."</td>
		<td colspan=1> Saldo Awal</td>
		<td align='right'>$rp1</td>
		<td align='right'>$rp2</td>
		<td align='right'  width='$aw[5]'>$xsaldo</td>
		<td align='center' width='$aw[6]'>$dk</td>
	</tr>
	"; 
		
	//echo $sq;
	$h=mysql_query2($sq);
	$br=1;
	$no=1;
	$jlhd=$debet;
	$jlhk=$kredit;
	while ($r=mysql_fetch_array($h)){
		$brAwal=$br;
		$no++; 
		$rp1=number_format($r['debet']);
		$rp2=number_format($r['kredit']);
		$saldo+=$r['debet']-$r['kredit'];
		$xsaldo=number_format(abs($saldo));
		$dk=($saldo>=0?"D":"K");
		$rcat=$r["catatan"];
		//jika cattan kosoong
		if ($rcat=="") {
			$rcat=getKetTransJU($r['id'],"");
		}
		
		$rcatreplace=str_replace("x","X",$rcat);
		if ($rcatreplace==strtoupper($rcat)) $rcat=ucfirst(strtolower($rcat));
		$cat1=$rcat;
		$cat2="";
		$brCat=max(ceil(strlen($cat1)/$maxCharPerBr),0);
		$maxbr=($page==1?$maxbr1:$maxbr2);
		$sisaBr=$maxbr-$br;
		if ($brCat>$sisaBr) {
			//membagi catatan
			$cat1=potong($rcat,($sisaBr*$maxCharPerBr),""," ")."";
			$cat2=substr($rcat,strlen($cat1)-1,strlen($rcat));			
			$br+=$sisaBr;
		} else {
			$br+=max($brCat,2);
			
		}
		//$br+=$brCat;
		
		//evalBr();
		$jlhd+=$r['debet']*1;
		$jlhk+=$r['kredit']*1;
		
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans']);
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".sqltotgl($r[0],'d M Y')."<br>$xnotrans</td>
			<td >$cat1 </td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'>$xsaldo</td>
			<td align='center'>$dk</td>
			
		</tr>
		";
	
			
		evalBr();
		if ($cat2!='') {
			$br=$brCat-$sisaBr;
			$isi.="
			<tr style='line-height: 25px;'>
				<td align='center'> </td>
				<td align='center'>  </td>
				<td >$cat2 </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='center'> </td>
				
			</tr>
			";
			evalBr();
		}
		//$br++;	
	}
	
	$rp1=number_format($jlhd);
	$rp2=number_format($jlhk);
	$sld=$jlhd-$jlhk;
	$sdk=($sld>=0?"D":"K");
	$rp3=number_format(abs($sld));
	$isi.="";
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=3 >TOTAL</td>
			<td align='right'><b>$rp1</b></td>
			<td align='right'><b>$rp2</b></td>
			<td align='right'><b>$rp3</b></td>
			<td align='center'><b>$sdk</b></td>
		</tr>
		"; 
	
 
	 
		if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
		echo "
		<style>
		.tbbukubesar td {
			font-size:10px;
		}
		
		@media print {
			.page {
				padding: 1cm;
			}
		}
		</style>
		<div class='$clspage'>
	
			$kop
			$jdl
			$isi
			</table>
		</div>
		";
	
	
 
?>