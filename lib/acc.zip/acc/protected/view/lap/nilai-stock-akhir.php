<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";

$clspage="page";
$page=1;
$maxbr1=25;
$maxbr2=30;
$maxCharPerBr=28;
cekVar("tgl1,tgl2,idstock,kdbrg");
$aw=hitungskala(array(20,170,200,430, 30,90,90,90,90,15),100);


//jika buku besar perkiraan labarugi, tanggal sebelum periode dianggap nol (tidak ada saldo awal)

function evalBr(){
	global $br,$maxbr,$maxbr1,$maxbr2,$media,$isi,$clspage,$kop,$jdl,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$jdl;//$kop
		$br=1;
		$page++;
	}
	//$br++;
	
}

if (($tgl1=="")||($tgl2=="")) {
	echo um412_falr("Masukkan Tanggal terlebih dahulu ");
	exit;
}
$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;


$sy="where 1=1 ";
$judul=$judulLap="NILAI STOCK AKHIR";

$judul2="";
$subjd='';

$t="";
$t.=awalLaporan();
$t.=buattbhead($judulLap,$tgl1,$tgl2);
	
if ($useBranch) {
	if ($kdbranch!='') {
		$sy.=" and  h.kdbranch='$kdbranch' ";
		$cabang=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
		$subjd.="
			<tr><td width='180'>Cabang </td><td >: $cabang</td></tr>
		";
	}
}


	if ($idstock!='') {
		
		$sy="s.id='$idstock'";
		//$sy.=" and d.kdbrg='$kdbrg' ";
	} elseif ($kdbrg!='') {
	
		$sy="s.kdbrg='$kdbrg' and s.kdlokasi='$kdlokasi'";
		
		
	
	}else {
		echo um412_falr("Pilih barang yang akan dicetak terlebih dahulu","danger");
		exit;
	}
	extractRecord("
	 select s.id as idstock,s.kdbrg,b.satuan,s.kdlokasi,nmbarang,lokasi,branch from tbpbarang b 
	 left join tbpstock s on b.kdbrg=s.kdbrg 
	 left join tbplokasi l on s.kdlokasi=l.id 
	 left join tbpbranch br on l.kdbranch=br.kdbranch 		  
	where $sy 
	");
	 
	$sy2="d.kdbrg='$kdbrg'";
		
	$xtgl1="2300-01-01";
	$sta= getStAkhir($kdbrg, $kdlokasi, $op = "cek")*1;
	
	$subjd.="
		<tr><td width='180'>Nama Barang </td><td >: $nmbarang</td></tr>
		<tr><td width='180'>Lokasi </td><td >: $lokasi - $branch</td></tr>
		<tr><td width='180'>Stock Akhir </td><td >: ".maskRp($sta,0,9)." $satuan</td></tr>
		<tr><td width='180'>Nilai Stock Akhir </td><td >: #nsta# </td></tr>
	";

$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop=buattbhead($judulLap);
$kop.="
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>	
  ";
if ($media!='') $kop.="<br><br>";
 

	$t="";
	
	
//	<td valign='midle' align='center'  width='$aw[4]%'>REF</td>
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>Tanggal</td>
	<td valign='midle' align='center'  width='$aw[2]%'>No. Trans</td>
	<td valign='midle' align='center'  width='$aw[3]%'>Ket</td>
	<td valign='midle' align='center'  width='$aw[4]%'>Jumlah</td>
	<td valign='midle' align='center'  width='$aw[5]%'>Harga </td>
	<td valign='midle' align='center'  width='$aw[6]%'>Subtotal</td>
	</tr>
	";
	
	//if(h.jtrans='SL' or h.jtrans='JE'or h.jtrans='SR',hpp,hrg) as hrg,
	$sqorder="h.tgl desc";
 	
	$sy2.=getSyTransHPP($kdlokasi);
	
	   $sq="
	select h.kdlokasi,h.kdlokasi2,h.tgl,h.notrans,h.catatan,'' as ref,
	d.jlh_terima-d.jlh_retur as jlh,
	h.jtrans,
	jlh_terima,
	jlh_retur,hrg,hpp,
	p.nama as namapeg,
	pb.nama as namapb,
	h.id
	from 
	tbpbelid d left join tbpbeli h on d.notrans=h.notrans
		left join tbppembantu pb on h.kdpembantu=pb.id
		left join tbppegawai p on h.kdpj=p.id
	where 1 and $sy2 	
	 order by $sqorder 
	limit 0,100
	";
	
	//echo $sq;
	
	$cdata=$isi="";
	//if ($isTest) 
	//	echo $sq;
	//cari saldo akhir
	//echo $sq;
	$h=mysql_query2($sq);
	$br=1;
	$no=1;
	
	$saldo=$sta;//saldo
	//echo "saldo $saldo ";
	$ajlh=[0,0,0,0];
	while (($r=mysql_fetch_array($h)) && ($saldo>0) && ($br<100)){
		$brAwal=$br;
		//khusus produksi apakah skip atau tidak
		if (($r['jtrans']=="PG") || ($r['jtrans']=="PD")) {
			if ($r['jlh']<=0) continue;
		} 
		$no++; 
		$jlh=$r['jlh'];
		
		
		if ($saldo>=$jlh) {
			$vjlh=$jlh;
		} else {
			$vjlh=$saldo;
		}
		$saldo-=$vjlh;
		$subtot=$vjlh*$r['hrg'];
		$rp1=number_format($vjlh);
		$rp2=number_format($r['hrg']);
		$rp3=number_format($subtot);
		$ajlh[0]+=$vjlh;
		$ajlh[1]+=$subtot;
		
		$rcat=$r['namapb'];//$r["catatan"];
		if ($rcat=="") {
			$rcat=getKetTransJU($r['id'],"");
		}
		
		$cat1=$rcat;
		$cat2="";
		$brCat=max(ceil(strlen($cat1)/$maxCharPerBr),0);
		$maxbr=($page==1?$maxbr1:$maxbr2);
		$sisaBr=$maxbr-$br;
		if ($brCat>$sisaBr) {
			//membagi catatan
			$cat1=potong($rcat,($sisaBr*$maxCharPerBr),true,""," ")."";
			$cat2=substr($rcat,strlen($cat1),strlen($rcat));			
			$br+=$sisaBr;
		} else {
			$br+=$brCat;
			
		}
		//$br+=$brCat;
		
		//evalBr();
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans'],15);
//			<td align='center'>$r[ref]</td>
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".sqltotgl($r['tgl'],'d M Y')."</td>
			<td align='center'> &nbsp;$xnotrans</td>
			<td >$cat1 </td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'>$rp3</td>
		</tr>
		";
	
			
		evalBr();
		if ($cat2!='') {
			$br=$brCat-$sisaBr;
			$isi.="
			<tr style='line-height: 25px;'>
				<td align='center'> </td>
				<td align='center'> </td>
				<td align='center'>  </td>
				<td class=tdket >$cat2 </td>
				<td align='center'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='center'> </td>
				
			</tr>
			";
			evalBr();
		}
		//$br++;	
	}
	//isi nilai stock akhir
	$nsta=$ajlh[1];
	$kop=str_replace("#nsta#",maskRp($nsta,1,9),$kop);
	
	$sdk=0;//($sld>=0?"D":"K");
	$rp1=number_format($ajlh[0]);
	$rp2=number_format($ajlh[1]);
	$isi.="";
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=4 >TOTAL</td>
			<td align='right'><b>$rp1</b></td>
			<td align='right'><b></b></td>
			<td align='right'><b>$rp2</b></td>
		</tr>
		"; 
	
	
 
		if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";

		echo "
		<style>
		.tbcetakbergaris,
		.tbcetakbergaris td {
			font-size:11px;
		}
		.tdket {
			line-height: 14px;
		}		
		@media print {
			.page {
				padding: 1cm;
			}
		}
		</style>
		<div class='$clspage'>
	
			$kop
			$jdl
			$isi
			</table>
		</div>
		";
	/*
	} else {
		 
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		
	}
	*/

echo "
<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >
$t
";


?>