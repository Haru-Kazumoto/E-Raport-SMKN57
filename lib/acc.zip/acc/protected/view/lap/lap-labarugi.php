<?php
error_reporting(E_ALL);

function updateISH() {
	$sq="select distinct(accinduk) as account_code from ".$oNamaTb->akun." where accinduk<>'0' order by account_code ";
	//echo $sq."<br>";
	$h=mysql_query2($sq);
	$subtot=0;
	while ($r=mysql_fetch_array($h)){
		$sqq="update ".$oNamaTb->akun." set ish=1 where account_code=$r[account_code];";
		echo $sqq."<br>";
		querysql($sqq);
	}
}

$maxbr1=35;
$maxbr2=41;

function evalBr(){
	global $isi,$page,$br,$maxbr1,$maxbr2,$judulTb,$oNamaTb;
	$br++;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>$maxbr) {
		$isi.="</table></div>";
		$isi.="<div class=page>";
		$isi.=$judulTb;
		$br=1;
		$page++;
	} 
}

function evalAccInduk($acci) {
	global $isi,$br,$t,$tot,$sy;
	$sq="select * from ".$oNamaTb->akun." where accinduk='$acci' order by account_code ";
	$jdx=carifield("select account_name from ".$oNamaTb->akun." where account_code='$acci'");
	
	//echo $sq." $jdx <br>";
		$h=mysql_query2($sq);
		$subtot=0;
		while ($r=mysql_fetch_array($h)){
			$kdprk=$r['account_code'];
			$rp=100;
			
			$rp=carifield("select sum(d.jlhuang) from `".$oNamaTb->gltrans."` d inner join `".$oNamaTb->gld."` h on d.notrans=h.notrans where $sy and kdprk='$kdprk'")*1;
			
			if ((($kdprk>=40000) and ($kdprk<50000)) || (($kdprk>=80000) and ($kdprk<90000)) ){
				$rp*=-1;
			}
			if ($r['ish']==1) {
				//echo "induk ";
				$jd=$r['account_name'];
				$subtot+=evalAccInduk($r['account_code']);
				//continue;
				
			} else {
				$subtot+=$rp;
				$isi.="
				<tr >
				<td >&nbsp;</td>
				<td >$r[account_code]</td>
				<td colspan=2>$r[account_name]</td>
				<td class=rp>".rupiah($rp)."</td>
				<td class=rp>&nbsp;</td>
				</tr>
				";
			}
			evalBr();
		}
		$isi.="
			<tr class='trh1'>
			<td >&nbsp;</td>
			<td >&nbsp;</td>
			<td colspan=2>Total $jdx</td>
			<td class=rp>&nbsp;</td>
			<td class=rp>".rupiah($subtot)."</td>
			</tr>
			";evalBr();
		//$tot+=$subtot;
		return $subtot;
}

$br=0;
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$brmax=20;
 
$judul="LAPORAN TRANSAKSI";
$judul2="";
$subjd='';

$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;
$sy="  h.tgl >='".tgltosql($tgl1)."' and h.tgl <='".tgltosql($tgl2)."' ";
$sqorder="tgl asc";
	
$ax=array(80,480,100);
 
$kop="";
 
$isi="
<style>
.trh1 {
	font-weight:bold;
	font-size:14px;
}
.rp {
	text-align:right;
}

.tbcetakbergaris td, .page td {
    font-size: 13px;
}

</style>
";
$brkosong="<tr >	<td colspan=6>&nbsp;</td></tr>";

$aw=array(5,20,7,330,70, 70,70);
//pendapatan
$ahd1=array(
	array("PENDAPATAN",array(40000,80000)),
	array("HPP",array(50000)),
	array("BIAYA",array(60000,90000))
	);
$w=hitungskala(array(5,10,30,30,30,30),100);
$judulTb="<table class='tbcetakbergaris' width=100%>
<tr style='height:5px'>
<td style='width:$w[0]%'>&nbsp;</td>
<td style='width:$w[1]%'>&nbsp;</td>
<td style='width:$w[2]%'>&nbsp;</td>
<td style='width:$w[3]%'>&nbsp;</td>
<td style='width:$w[4]%'>&nbsp;</td>
<td style='width:$w[5]%'>&nbsp;</td>

</tr>
";
$isi.=$judulTb;
$labarugi=0;
$xx=0;
$page=1;
foreach ($ahd1 as $ahdx) {
	$hdx=$ahdx[0];
	$ainduk=$ahdx[1];
	$isi.=$brkosong;evalBr();
	$isi.="<tr class='trh1'>
	<td colspan=6>$hdx</td>
	</tr>
	";	evalBr();
	$tot=0;
	
	foreach($ainduk as $acci) {
		$tot+=evalAccInduk($acci);
	}
	
	$isi.="
	<tr class='trh1'>
	<td colspan=2>&nbsp;</td>
	<td colspan=3>TOTAL ".ucwords($hdx)."</td>
	<td class=rp>".rupiah($tot)."</td>
	</tr>
	";evalBr();
	$labarugi+=($xx==0?$tot:$tot*-1);
	$xx++;
} //foreach ahd1

	$isi.="
	<tr class='trh1'>
	<td colspan=2>&nbsp;</td>
	<td colspan=3>LABA RUGI </td>
	<td class='rp labarugi'>".rupiah($labarugi)."</td>
	</tr>
	";evalBr();
$isi.="</table>"; 

$t.=$isi;
 
 
?>