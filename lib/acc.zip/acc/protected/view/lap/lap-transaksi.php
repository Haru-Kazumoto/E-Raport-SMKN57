<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
$maxbr=17;

cekVar("tgl1,tgl2,kdpembantu,kdpegawai,kdasset,jform");
$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;

if ($jlap=="cashflow") {
$judul="CASH FLOW";
	
} else {
$judul="LAPORAN TRANSAKSI";
}
$judul2="";
	$subjd='';
	$sy="where 1=1 ";
	if ($kdbranch!=''){
		$branch=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
		$sy.=" and h.kdbranch='$kdbranch' ";
	 	$subjd.="
			<tr><td width='180'>Cabang </td><td >: $branch</td></tr> 
		";
	
	}
	if ($kdpegawai!=''){
		$namapeg=carifield("select nama  from tbppegawai where id='$kdpegawai'");
		$sy.=" and h.idpegawai='$kdpegawai' ";
	 	$subjd.="
			<tr><td width='180'>Nama Pegawai </td><td >: $namapeg</td></tr> 
		";
	
	}
	if ($jenisju!='') {
		$sy.=" and h.jenisju='$jenisju' ";
	 	$subjd.="
			<tr><td width='180'>Jenis Transaksi </td><td >: $jenisju</td></tr>
		";
	}
	
	if ($kdpembantu!='') {
		$sy.=" and  h.kdpembantu='$kdpembantu' ";
		$subjd.="
			<tr><td width='180'>Pelanggan/Pemasok </td><td > : ".getPembantu($kdpembantu)."</td></tr>
		";
	} 
	
	if ($kdasset!='') {
		$sy.=" and  h.kdasset='$kdasset' ";
		$subjd.="
			<tr><td width='180'>Nama Asset </td><td > : ".getAsset($kdasset)."</td></tr>
		";
	} 
	if (($tgl1!='') &&($tgl2!='') ) {
		$xtgl1=tgltosql($tgl1);
		$xtgl2=tgltosql($tgl2);
		$sy.=" and  h.tgl>='$xtgl1' and  h.tgl<='$xtgl2' ";
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : ".tglindo2($xtgl1)." sd  ".tglindo2($xtgl2)."</td></tr>
		";
	} else {
		echo um412_falr("Masukkan Tanggal terlebih dahulu ");
		exit;
	}
	
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop=buattbhead("LAPORAN TRANSAKSI",$tgl1,$tgl2);
if ($media!='') $kop.="<br><br><br><br>";
	$t="";
	if ($jform=="list") {
		$clspage="page-landscape";
		include $lib_app_path."protected/view/lap/lap-transaksi-list.php";
	}
	else {
		$clspage="page";
		
		include $lib_app_path."protected/view/lap/lap-transaksi-ju.php";
	}
	
	$t.="
		$kop
	 $jdl
		$isi
		</table>
		";

if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";
	
echo "
<div class='$clspage'>
$t
</div>
";


?>