<?php
error_reporting(E_ALL);
cekVar("bentuk");

function evalBr(){
	global $isi,$br,$maxbr,$judulTb,$media;
	$br++;
	if ($br>$maxbr) {
		$isi.="</table></div>";
		$isi.="<div class=page>";
		//if ($media!='xls') 
		$isi.=$judulTb;
		$br=1;
	} 
}

function buattda($level){
	$tda="";
	for ($i=0;$i<$level;$i++) {
		$tda.="&nbsp;&nbsp;&nbsp;";
		//$tda.="<td style='width:10px'>*</td>";
	}
	return $tda;
}
function evalAccIndukNeraca($acci,$level) {
	global $isi,$br,$t,$w,$tot,$subtot,$sy0,$sy1,$tgl2,$bentuk;
	$sq="select * from ".$oNamaTb->akun." where accinduk='$acci' order by account_code ";
	$jdx=carifield("select account_name from ".$oNamaTb->akun." where account_code='$acci'");
	$level++;
	$tda=buattda($level);//if ($level!=1) {
	//if ($bentuk!='Ringkas') {
		$isi.="
		<tr class='trh1'>
		<td >$tda $jdx</td>
		<td class=rp>&nbsp;</td>
		<td class=rp>&nbsp;</td>
		</tr>
		";evalBr();
	//}


	//echo $sq." $jdx <br>";
		$h=mysql_query2($sq);
		$subtot=0;
		while ($r=mysql_fetch_array($h)){
			$kdprk=$r['account_code'];
				
			if ($r['ish']==1) {
				//echo "induk ";
				$jd=$r['account_name'];
				evalAccIndukNeraca($r['account_code'],$level);
			} else {
				$sakhir=getSaldoAkhir($kdprk,tgltosql($tgl2));
				//jika jenis aktiva, saldoakhir dibalik
				if ($kdprk>=20000) $sakhir*=-1;
				$subtot+=$sakhir;
				$tot+=$sakhir;
				if ($bentuk!='Ringkas') {
					$isi.="
					<tr >
					
						<td  width='$w[0]%' >$tda $r[account_code] &nbsp; &nbsp; $r[account_name]</td>
						<td  width='$w[1]%' class=rp>".rupiah2($sakhir)." </td>
						<td  width='$w[2]%' class=rp>&nbsp;</td>
					</tr>
					";evalBr();
				}
			
			}
			
		}
		 
		$isi.="
			<tr class='trh1'>
				<td >$tda ".($bentuk!='Ringkas'?'Total ':'')."$jdx</td>
				<td class=rp>".rupiah2($subtot)."</td>
				<td class=rp>&nbsp;</td>
			</tr>
			";evalBr();
		if ($bentuk!='Ringkas') {
			$isi.="
			<tr class='trh1'> 
			<td colspan=3>&nbsp;</td>
			</tr>
			";evalBr();	 
		}
		return $subtot;
}

$br=0;
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$brmax=20;
 
$judul2="";
$subjd='';
$sy0="  h.tgl<'".tgltosql($tgl1)."' ";
$sy1="  h.tgl>='".tgltosql($tgl1)."' and h.tgl <='".tgltosql($tgl2)."'";
$sqorder="tgl asc";



$ax=array(80,480,100);
 
$kop="";
 
$isi="
<style>
.trh1 {
	font-weight:bold;
	font-size:14px;
}

.trh1b {
	background-color:#ccc;
}
.rp {
	text-align:right;
}
</style>
";
$brkosong="<tr > <td colspan=6>&nbsp;</td></tr>";

$maxbr=33;
$w=array(60,20,20);
$w=hitungskala($w,100);
//pendapatan
$ahd1=array(
	array("AKTIVA",array(10000,12000)),
	array("PASIVA",array(20000,30000)),
	);
$judulTb="<table  class=' table table-bordered' width=100%>";
$isi.=$judulTb;
$beda=0;
$xx=0;
foreach ($ahd1 as $ahdx) {
	$hdx=$ahdx[0];
	$ainduk=$ahdx[1];
	$isi.=$brkosong;evalBr();
	$isi.="<tr class='trh1'>
	 
	<td width='$w[0]%' >$hdx</td>
	<td width='$w[1]%' class=rp>&nbsp;</td>
	<td width='$w[2]%' class=rp>&nbsp;</td>
	</tr>
	";	evalBr();
	$tot=0;
	
	foreach($ainduk as $acci) {
		evalAccIndukNeraca($acci,$level=0);
	}
	
	$isi.="
	<tr class='trh1 trh1b'> 
	<td >Total ".ucwords($hdx)."</td>
	<td class=rp>&nbsp;</td>
	<td class=rp>".rupiah2($tot)."</td>
	</tr>
	";evalBr();
	$isi.="
	<tr class='trh1'> 
	<td colspan=3>&nbsp;</td>
	</tr>
	";evalBr();
	//$beda+=$tot;
	$xx++;
} //foreach ahd1

	/*
	if ($beda!=0) { 
		$isi.="
		<tr class='trh1'>
		<td colspan=2>&nbsp;</td>
		<td colspan=3>KESEIMBANGAN </td>
		<td class=rp>".rupiah2($beda)."</td>
		</tr>
		";evalBr();
	}
	*/
	
$isi.="</table>"; 

$t.=$isi;
 
 
?>