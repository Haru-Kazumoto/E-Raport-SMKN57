<?php

function evalBr(){
	global $br,$isi,$maxbr,$jdl,$kop,$media;
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='page'>";
		if ($media!='xls') $isi.=$kop;	
		$isi.=$jdl;
	
		$br=1;
	} else $br++;
}
$maxbr=32;
	$aw=hitungSkala(array(20,20,70,270,70,70,70));
	$sq="select 
	h.tgl,
	h.jenisju,
	h.notrans,
	h.catatan,
	h.ref,h.jlhuang,
	pb.nama as namapb,	 
	p.nama as namapeg,
	h.notrans,
	h.id
	from (  ".$oNamaTb->gld." h  left join tbppegawai p on h.idpegawai=p.id )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy  order by $sqorder ";
	
	/*
	
	<td valign='midle' align='center'  width='$aw[6]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[7]px'>PEGAWAI</td>
	
	<td valign='midle' align='center'  width='$aw[4]px'>REF</td>
	*/
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'   width='".($aw[1]+$aw[2])."%'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[3]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[4]%'>DEBET</td>
	<td valign='midle' align='center'  width='$aw[5]%'>KREDIT</td>
	
	</tr>
	";
	
	//echo $sq;
	$cdata=$isi="";
	$ra=mysql_query2($sq);
	$br=1;
	$saldo=0;
	$jlhd=$jlhk=0;
	$no=0;
	while ($r=mysql_fetch_array($ra)){
		$no++;
		$rp1=maskRp($r[4]);
		$saldo+=$r[4]; 
		$br+=max(ceil(strlen($r[2])/105)-1,0);
		evalBr();
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans']);
		//echo strlen($r[2])." ".$br.">";
		$isi.="<tr>
		<td >$no</td>
		<td colspan=4>".sqltotgl($r[0],'d M Y')." >$xnotrans - $r[1] - $r[2] $rp1
		</td>
		</tr>";
		
		$jd=$jk=0;
		$sqd="select d.*,m.account_name as nmprk from ".$oNamaTb->gltrans." d left join ".$oNamaTb->akun." m on d.kdprk=m.account_code where notrans='$r[notrans]'";
		$hqd=mysql_query2($sqd);
		while ($rd=mysql_fetch_array($hqd)) {
			$ju=abs($rd['jlhuang']);
			if ($rd['jlhuang']>=0) {
				$isi.="<tr>
						<td class=w1  >&nbsp; </td>
						<td class=w1 width='".($aw[2]+$aw[3])."%' align=left colspan=2 >
							- &nbsp;
							$rd[kdprk] $rd[nmprk] 
						</td>
							<td class=w3 align=right>".maskRp($ju)."</td>
						<td class=w4  align=right>&nbsp;</td>
						</tr>";
						$jd+=$ju;
			}
			
			else{
				$isi.="<tr>
					<td class=w1  >&nbsp; </td> 
					<td class=w1 width='$aw[2]%' align=left colspan=2 >
						&nbsp;&nbsp;
						-&nbsp;
						$rd[kdprk] $rd[nmprk] 
					</td>
					<td class=w4  align=right>&nbsp;</td>
						<td class=w4  align=right>".maskRp($ju)."</td>
					</tr>";
				$jk+=$ju;
			}	
		evalBr();			
		}
		$isi.="<tr>
				<td class=w1  >&nbsp; </td> 
				<td class=w1 colspan=2 ></td>
				<td class=w4  align=right><b>".maskRp($jd)."</b></td>
				<td class=w4  align=right><b>".maskRp($jk)."</b></td>
				</tr>";
		evalBr();
		$jlhd+=$jd*1;
		$jlhk+=$jk*1;
		
	}
	$isi.="
		<tr style='line-height: 25px;'>
			<td colspan=3 align='center'>TOTAL </td>
			<td align='right'><b>".maskRp($jlhd)."</b></td>
			<td align='right'><b>".maskRp($jlhk)."</b></td>
			
			
		</tr>
		"; 
	//evalBr();
			
	$isi.="";
	
 
?>