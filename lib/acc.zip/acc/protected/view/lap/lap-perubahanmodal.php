<?php
error_reporting(E_ALL);
cekVar("bentuk");

function evalBr(){
	global $isi,$br,$maxbr,$judulTb;
	$br++;
	if ($br>$maxbr) {
		$isi.="</table></div>";
		$isi.="<div class=page>";
		$isi.=$judulTb;
		$br=1;
	} 
}

function buattda($level){
	$tda="";
	for ($i=0;$i<$level;$i++) {
		$tda.="&nbsp;&nbsp;&nbsp;";
		//$tda.="<td style='width:10px'>*</td>";
	}
	return $tda;
}
function evalAccIndukNeraca($acci,$level) {
	global $isi,$arrBr,$br,$t,$w,$tot,$subtot,$tgl1,$tgl2,$bentuk,$oNamaTb,$fldAccNo;;
	global $atg,$z,$jz;
	$sq="select * from ".$oNamaTb->akun." where accinduk='$acci' order by account_code ";
	$jdx=carifield("select account_name from ".$oNamaTb->akun." where account_code='$acci'");
	$level++;
	$tda=buattda($level);//if ($level!=1) {
	$jhanak=carifield("select count(account_code) from ".$oNamaTb->akun." where accinduk='$acci' and ish=1")*1;
	if (($bentuk!='Ringkas') ||($jhanak>0)||($acci>=30000)) {
		$arrBr[]="
		<tr class='trh1'>
		<td >$tda $jdx</td>
		<td colspan=$jz class=rp>&nbsp;</td>
		</tr>
		";
	}


	//echo $sq." $jdx <br>";
		$h=mysql_query2($sq);
		$subtot=array(0,0,0,0,0,0,0);
		while ($r=mysql_fetch_array($h)){
			$kdprk=$r['account_code'];
				
			if ($r['ish']==1) {
				//echo "induk ";
				$jd=$r['account_name'];
				evalAccIndukNeraca($r['account_code'],$level);
			} else {
				
				for ($z=0;$z<$jz;$z++){
					$sakhir[$z]=getSaldoAkhir($kdprk,tgltosql($atg[$z]));
					if ($kdprk>=20000) $sakhir[$z]*=-1;
					$subtot[$z]+=$sakhir[$z];
					$tot[$z]+=$sakhir[$z];
				}
				//jika jenis aktiva, saldoakhir dibalik
				
				if (($bentuk!='Ringkas') ||($kdprk>=30000)){
					$acc=$r[$fldAccNo];
					$b="
						<tr class='trh1 '> 
						<td  width='$w[0]%' >$tda $acc &nbsp; &nbsp; $r[account_name]</td>";
						for ($z=0;$z<$jz;$z++){	$b.="<td class=rp>".rupiah2($sakhir[$z])."</td>"; } 
						$b.="</tr>";
					$arrBr[]=$b;
				}
			
			}
			
		}
		 
		$b="
			<tr class='trh1'>
				<td >$tda ".($bentuk!='Ringkas'?'Total ':'')."$jdx</td>";
				for ($z=0;$z<$jz;$z++) { $b.="<td class=rp>".rupiah2($subtot[$z])."</td>"; }
				$b.="
				<td class=rp>&nbsp;</td>
			</tr>
			";
		$arrBr[]=$b;
		if ($bentuk!='Ringkas') {
			$arrBr[]="
			<tr class='trh1'> 
			<td colspan=3>&nbsp;</td>
			</tr>
			";	 
		}
		return $subtot[$z];
}

$br=0;
$armax=array(100,90,80,70,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$brmax=20;
 
$judul2="";
$subjd='';
$sqorder="tgl asc";

$ax=array(80,480,100);
 
$kop="";

$t.="
<style>
.trh1 {
	font-weight:bold;
	font-size:14px;
}

.trh1b {
	background-color:#ccc;
}
.rp {
	text-align:right;
}
</style>
";
$brkosong="<tr > <td colspan=6>&nbsp;</td></tr>";

$maxbr=33;
$w=array(60,20,20);
$w=hitungskala($w,100);
//neraca

	

if ($jlap=="neracasaldo")  {
	$ahd1=array(
		array("AKTIVA",array(10000,12000)),
		array("PASIVA",array(20000,30000)),
		array("PENDAPATAN",array(40000,80000)),
		array("HPP",array(50000)),
		array("BIAYA",array(60000,90000))
	);
} elseif ($jlap=="perubahanmodal") {
	$ahd1=array(
		array("MODAL",array(30000)),
	);
} elseif ($jlap=="neraca") {
	$ahd1=array(
		array("AKTIVA",array(10000,12000)),
		array("PASIVA",array(20000,30000)),
	);
	
}


$atg=array($tgl1,$tgl2);
$jz=count($atg);
$arrBr=array();//arraybaris
	$isi="";
	$judulTb="<table  class=' table table-bordered' width=100%>";
	$isi.=$judulTb;
	$beda=0;
	$xx=0;
	
	foreach ($ahd1 as $ahdx) {
		$hdx=$ahdx[0];
		$ainduk=$ahdx[1];
		
		$arrBr[]=$brkosong;
		$b="<tr class='trh1'>
		<td width='$w[0]%' >$hdx</td>";
		for ($z=0;$z<$jz;$z++){ $b.="<td width='$w[1]%' class=rp>$atg[$z]</td>";	}
		$b.="</tr>";	
		$arrBr[]=$b;
		$tot=array(0,0,0,0,0);
		
		foreach($ainduk as $acci) {
			evalAccIndukNeraca($acci,$level=0);
		}
		
		if ($jlap!="perubahanmodal") {
			$b="
			<tr class='trh1 trh1b'> 
			<td >Total ".ucwords($hdx)."</td>";
			for ($z=0;$z<$jz;$z++){	$b.="<td class=rp>".rupiah2($tot[$z])."</td>";} 
			$b.="</tr>";
			$arrBr[]=$b;
		}
		$arrBr[]="
		<tr class='trh1'> 
		<td colspan=$jz>&nbsp;</td>
		</tr>
		";
		//$beda+=$tot[$z];
		$xx++;
	} //foreach ahd1
	
	$br=0;
	foreach($arrBr as $arr) {
		$isi.=$arr;evalBr();
	}

		/*
		if ($beda!=0) { 
			$isi.="
			<tr class='trh1'>
			<td colspan=2>&nbsp;</td>
			<td colspan=3>KESEIMBANGAN </td>
			<td class=rp>".rupiah2($beda)."</td>
			</tr>
			";evalBr();
		}
		*/
		
	$isi.="</table>"; 
	//yang ditampilkan jika kol=2
	$t.=$isi;
 
 
?>