<?php
error_reporting(E_ALL);
$i=0;
$t="";

$clspage="page";
$page=1;
$maxbr1=25;
$maxbr2=30;
$maxCharPerBr=28;
cekVar("tgl1,tgl2,idstock,kdbrg");
$aw=hitungskala(array(20,170,200,430, 30,90,90,90,15),100);


//jika buku besar perkiraan labarugi, tanggal sebelum periode dianggap nol (tidak ada saldo awal)

function evalBr(){
	global $br,$maxbr,$maxbr1,$maxbr2,$media,$isi,$clspage,$kop,$jdl,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$jdl;//$kop
		$br=1;
		$page++;
	}
	//$br++;
	
}

if (($tgl1=="")||($tgl2=="")) {
	echo um412_falr("Masukkan Tanggal terlebih dahulu ");
	exit;
}
$_SESSION['tgllap1']=$tgl1;
$_SESSION['tgllap2']=$tgl2;


$sy="where 1=1 ";
$judul=$judulLap="KARTU STOCK";

$judul2="";
$subjd='';

$t="";
$t.=awalLaporan();
$t.=buattbhead($judulLap,$tgl1,$tgl2);
	
	if ($useBranch) {
		if ($kdbranch!='') {
			$sy.=" and  h.kdbranch='$kdbranch' ";
			$cabang=carifield("select branch  from tbpbranch where kdbranch='$kdbranch'");
			$subjd.="
				<tr><td width='180'>Cabang </td><td >: $cabang</td></tr>
			";
		}
	}
	
	if ($idstock!='') {
		$sy="s.id='$idstock'"; 
	} elseif ($kdbrg!='') {
		$sy="s.kdbrg='$kdbrg' and s.kdlokasi='$kdlokasi'";
	}else {
		echo um412_falr("Pilih barang yang akan dicetak terlebih dahulu","danger");
		exit;
	}
	extractRecord("
	 select s.id as idstock,s.kdbrg,b.satuan,s.kdlokasi,nmbarang,lokasi,branch from tbpbarang b 
	 left join tbpstock s on b.kdbrg=s.kdbrg 
	 left join tbplokasi l on s.kdlokasi=l.id 
	 left join tbpbranch br on l.kdbranch=br.kdbranch 		  
	where $sy 
	");
	
	$sy2="d.kdbrg='$kdbrg'";
	
		$subjd.="
			<tr><td width='180'>Nama Barang </td><td >: $nmbarang ( $kdbrg )</td></tr>
			<tr><td width='180'>Lokasi</td><td >: $lokasi (Branch)</td></tr>
		";
	
	
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy2.="and  h.tgl>='$xtgl1' ";
		$ketTgl=tglindo2($xtgl1);
		$xtgl2=tgltosql($tgl2);
		
		if ($tgl2!=$tgl1) {
			$sy2.=" and h.tgl<='$xtgl2' ";
			$ketTgl.=" sd ".tglindo2($xtgl2);
		}
		
		$subjd.="
			<tr><td width='180'>Tanggal </td><td > : $ketTgl</td></tr>
		";
	} 
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
//<td width='80' style='width:$ax[0]px'><img src='images/logo-tut.jpg' width='90'></td>
//<td width='80' style='width:$ax[2]px' ><img src='images/logo.png' width='80'></td>
$kop=buattbhead($judulLap);
$kop.="
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>	
  ";
if ($media!='') $kop.="<br><br>";
 

	$t="";
	
	
 	echo $sq="
	select h.kdlokasi,h.kdlokasi2,h.tgl,h.notrans,h.catatan,'' as ref,
	if(
		h.jtrans='PB' or h.jtrans='SR' or (h.jtrans='PG' and d.jlh_terima>=0)
		or (h.jtrans='DS' and h.kdlokasi2='$kdlokasi')
	,abs(d.jlh_terima),0) as debet,
	if(
		h.jtrans='SL' or h.jtrans='PR' or h.jtrans='JE' or (h.jtrans='PG' and d.jlh_terima<0)
		or (h.jtrans='DS' and h.kdlokasi='$kdlokasi')
	,abs(d.jlh_terima),0) as kredit,
	
	if(h.jtrans='SL' or h.jtrans='JE' or h.jtrans='SR',hpp,hrg) as vhrg,
	
	
	h.jtrans,jlh_terima,hrg,hpp,
	p.nama as namapeg,
	pb.nama as namapb,
	h.id
	from 
	tbpbelid d left join tbpbeli h on d.notrans=h.notrans
		left join tbppembantu pb on h.kdpembantu=pb.id
		left join tbppegawai p on h.kdpj=p.id
		 
	 where $sy2 and (h.kdlokasi='$kdlokasi' or h.kdlokasi2='$kdlokasi' ) order by $sqorder ";
	 //echo $sq;
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[2]%'>NO.TRANS</td>
	<td valign='midle' align='center'  width='$aw[3]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[5]%'>Masuk</td>
	<td valign='midle' align='center'  width='$aw[6]%'>Keluar </td>
	<td valign='midle' align='center'  colspan=2 width='".($aw[7]+$aw[8	])."%'>SALDO</td>
 
	
	</tr>
	";
	$saldo=0;
	$cdata=$isi="";
	//if ($isTest) 
	//	echo $sq;
			//cari saldo awal dulu
			$sa=getStockAkhir($kdbrg,$kdlokasi,$xtgl1);
			//jika perkiraan labarugi, saldo awal diabaikan
			//if ($kdprk>=40000) $sa=0;
			$debet=abs(($sa>=0?$sa:0));
			$kredit=abs(($sa<0?$sa:0));
			
			$rp1=number_format($debet);
			$rp2=number_format($kredit);
			
			$saldo+=$sa;
			$xsaldo=number_format(abs($saldo));
			$dk=($saldo>=0?"D":"K");
//			<td align='right'>&nbsp;</td>
			
			$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>1</td>
			<td align='center'>".sqltotgl($xtgl1,'d M Y')."</td>
			<td colspan=2> Saldo Awal</td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'  width='$aw[7]'>$xsaldo</td>
			<td align='center' width='$aw[8]'>$dk</td>
		</tr>
		"; 
		
	//echo $sq;
	$h=mysql_query2($sq);
	$br=1;
	$no=1;
	$jlhd=$debet;
	$jlhk=$kredit;
	while ($r=mysql_fetch_array($h)){
		$brAwal=$br;
		$no++; 
		$rp1=number_format($r['debet']);
		$rp2=number_format($r['kredit']);
		$saldo+=$r['debet']-$r['kredit'];
		$xsaldo=number_format(abs($saldo));
		$dk=($saldo>=0?"D":"K");
		$rcat=$r["catatan"].' ('.$r['namapb'].')';//;
		if ($rcat=="") {
			$rcat=getKetTransJU($r['id'],"");
		}
		/*
		$rcatreplace=str_replace("x","X",$rcat);
		if ($rcatreplace==strtoupper($rcat)) $rcat=ucfirst(strtolower($rcat));
		*/
		$cat1=$rcat;
		$cat2="";
		$brCat=max(ceil(strlen($cat1)/$maxCharPerBr),0);
		$maxbr=($page==1?$maxbr1:$maxbr2);
		$sisaBr=$maxbr-$br;
		if ($brCat>$sisaBr) {
			//membagi catatan
			$cat1=potong($rcat,($sisaBr*$maxCharPerBr),true,""," ")."";
			$cat2=substr($rcat,strlen($cat1),strlen($rcat));			
			$br+=$sisaBr;
		} else {
			$br+=$brCat;
			
		}
		//$br+=$brCat;
		
		//evalBr();
		$jlhd+=$r['debet']*1;
		$jlhk+=$r['kredit']*1;
		
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans'],15);
//			<td align='center'>$r[ref]</td>
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".sqltotgl($r['tgl'],'d M Y')."</td>
			<td align='center'> &nbsp;$xnotrans</td>
			<td >$cat1 </td>
			<td align='right'>$rp1</td>
			<td align='right'>$rp2</td>
			<td align='right'>$xsaldo</td>
			<td align='center'>$dk</td>
			
		</tr>
		";
	
			
		evalBr();
		if ($cat2!='') {
			$br=$brCat-$sisaBr;
			$isi.="
			<tr style='line-height: 25px;'>
				<td align='center'> </td>
				<td align='center'> </td>
				<td align='center'>  </td>
				<td class=tdket >$cat2 </td>
				<td align='center'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='right'> </td>
				<td align='center'> </td>
				
			</tr>
			";
			evalBr();
		}
		//$br++;	
	}
	
	$rp1=number_format($jlhd);
	$rp2=number_format($jlhk);
	$sld=$jlhd-$jlhk;
	$sdk=($sld>=0?"D":"K");
	$rp3=number_format(abs($sld));
	$isi.="";
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=4 >TOTAL</td>
			<td align='right'><b>$rp1</b></td>
			<td align='right'><b>$rp2</b></td>
			<td align='right'><b>$rp3</b></td>
			<td align='center'><b>$sdk</b></td>
		</tr>
		"; 
	
 
		if ($media!='xls') echo "<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >";

		echo "
		<style>
		.tbcetakbergaris,
		.tbcetakbergaris td {
			font-size:11px;
		}
		.tdket {
			line-height: 14px;
		}		
		@media print {
			.page {
				padding: 1cm;
			}
		}
		</style>
		<div class='$clspage'>
	
			$kop
			$jdl
			$isi
			</table>
		</div>
		";
	/*
	} else {
		 
		$aFieldCap=explode(",","Kode Barang,Nama Barang,Jumlah,Hrg Rata-rata,Sub Total");
		$arrTable =sqltoarray($sq,"");
		include $um_path."sql2xls.php";
		
	}
	*/

echo "
<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css' >
$t
";


?>