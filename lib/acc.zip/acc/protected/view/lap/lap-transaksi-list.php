<?php
$maxbr1=13;
$maxbr2=15	;

function cekBr(){
	global $br,$isi,$maxbr,$jdl,$kop,$media,$clspage,$maxbr1,$maxbr2,$page;
	$maxbr=($page==1?$maxbr1:$maxbr2);
	if ($br>=$maxbr) {
		$page++;
		$isi.="</table></div>
		".($media=='pdf'?"#pbpdf#":"")."
		<div class='$clspage'>
		";
		if ($media!='xls') $isi.=$kop;	
		$isi.=$jdl;
		$br=1;
	} else $br++;
}

	$aw=hitungSkala(array(15,35,57,172, 40 ));
	$sq="select 
	h.tgl,
	h.jenisju,
	h.catatan,
	h.ref,
	h.jlhuang,
	pb.nama as namapb,	 
	p.nama as namapeg,
	h.id,
	h.notrans
	from (  ".$oNamaTb->gld." h  left join tbppegawai p on h.idpegawai=p.id )
		left join tbppembantu pb on h.kdpembantu=pb.id
		 
	 $sy  order by $sqorder ";
	
	/*
	
	<td valign='midle' align='center'  width='$aw[6]px'>PELANGGAN</td>
	<td valign='midle' align='center'  width='$aw[7]px'>PEGAWAI</td>
	
	<td valign='midle' align='center'  width='$aw[4]px'>REF</td>
	*/
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]%'>NO</td>
	<td valign='midle' align='center'  width='$aw[1]%'>TANGGAL</td>
	<td valign='midle' align='center'  width='$aw[2]%'>JENIS TRANS</td>
	<td valign='midle' align='center'  width='$aw[3]%'>KETERANGAN</td>
	<td valign='midle' align='center'  width='$aw[4]%'>JUMLAH UANG</td>
	
	</tr>
	";
	
	//echo $sq;
	$cdata=$isi="";
	$ra=mysql_query2($sq);
	$br=0;
	$saldo=0;
	$page=1;
	$no=0;
	while ($r=mysql_fetch_array($ra)){
		$no++;
		$br+=max(round(strlen($r[2])/85,0)-1,0);
		cekBr();
		/*if ($br%$maxbr==0) {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='$clspage'>
			$kop
			
			".$jdl;
		}
		*/
		$rp1=maskRp($r[4]);
		$saldo+=$r[4]; 
		/*
		
			<td align='left'>$r[3]</td>
			<td align='center'>$r[4]</td>
			<td align='center'>$r[5]</td>
			*/
		$xnotrans=buatLinkViewTrans($r['id'],$r['notrans']);
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$no</td>
			<td align='center'>".sqltotgl($r[0],'d M Y')."</td>
			<td align='center'>$r[jenisju]<br>$xnotrans</td>
			<td align='left'>$r[2]</td>
			<td align='right'>$rp1</td>
			
			
		</tr>
		"; 
		
	}
	$isi.="
		<tr style='line-height: 25px;'>
			<td colspan=4 align='center'>TOTAL</td>
			<td align='right'>".maskRp($saldo)."</td>
			
			
		</tr>
		"; 
		
	$isi.="";
	
 
?>