<?php
error_reporting(E_ALL);
$armax=array(100,90,80,70,60,60,50,-1);
$akrit=explode(",","A,B,C,D,E,F");
$acolor=explode(",","#C72C95,#D8E0BD,#B3DBD4,#69A55C,#B5B8D3,#F4E23B");
$jrange=count($armax)-1;
$armin=$arjudul=array();
$i=0;
$t="";
 
$judul2="";
cekvar("kdpj,statby,jtrans");
if ($jtrans=="PH") {
	$capPb="Pemasok";
	$jpb="PM";
	$judul="DATA PEMBAYARAN HUTANG DETAIL";
	
} else {
	$capPb="Pelanggan";
	$jpb="PL";
	$judul="DATA PENERIMAAN PIUTANG DETAIL";
	
}
 

	$sy="where h.jtrans='$jtrans' $addSqComboBrg ";
	if ($kdpembantu!='') {
		$sy.="and  h.kdpembantu='$kdpembantu' ";
		
		$namaPlg=getPembantu($kdpembantu);
		$subjd.="
			<tr><td width='180'>Nama Pemasok </td><td >: $namaPlg</td></tr>
		";
	}
	if ($kdbranch!='') {
		$sy.="and  h.kdbranch='$kdbranch' ";	
		$branch=getBranch($kdbranch);
		$subjd.="
			<tr><td width='180'>Cabang </td><td >: $branch</td></tr>
		";
	}
	/*
	if ($kdpj!='') {
		$sy.="and  h.kdpj='$kdpj' ";
		
		$namapeg=getPegawai($kdpj);
		$subjd.="
			<tr><td width='180'>Nama Marketing </td><td >: $namapeg</td></tr>
		";
	}
	*/
	
	if ($tgl1!='') {
		$xtgl1=tgltosql($tgl1);
		$sy.="and  h.tgl>='$xtgl1' ";
		
		$xtgl2=tgltosql($tgl2);
		$sy.="and  h.tgl<='$xtgl2' ";
		
		$xtg=tglindo2($xtgl1);
		if ($tgl2!=$tgl1)  $xtg.=" sd ". tglindo2($xtgl2);
			
		$subjd.="
			<tr><td width='180'>Tanggal : </td><td > : $xtg </td></tr>
		";
	} 

	 
	$sqorder="tgl asc";
	
$ax=array(80,480,100);
$kop="
	<table border='0' width='100%' style='width:100%'  >
		<tr>
			<td align='center' valign='midle' style='font-size:16px;width:$ax[1]px' >
				<b>
				$judul
				</b>
			 
					
			</td> 
	</tr>
 </table>
 <br>
 
 <table width='100%' style='margin-bottom:24px' >
	$subjd
	</table>
	
	
  ";
if ($media!='') $kop.="<br><br>";
 

$maxbr=14;
	$t="";
	$aw=array(30,90,90,90,135,90,80,90,90,90,90,120);
	
	
	$jdl="
	<table class='tbcetakbergaris' border='1' width='100%' style='width:100%' align='center' >
	<tr>
	<td valign='midle' align='center'  width='$aw[0]px'>No</td>
	<td valign='midle' align='center'  width='$aw[1]px'>Kode Pembayaran</td>
	<td valign='midle' align='center'  width='$aw[2]px'>Tanggal</td>
	<td valign='midle' align='center'  width='$aw[3]px'>Pemasok</td>
	<td valign='midle' align='center'  width='$aw[4]px'>Nomor Transaksi</td>
	<td valign='midle' align='center'  width='$aw[4]px'>Jumlah Pembayaran</td>
	<td valign='midle' align='center'  width='$aw[5]px'>Catatan</td>
	
	</tr>
	";
	
	$sq="select
br.branch,
	 h.kdbayar,	 h.tgl,
	 pb.nama as namaplg,
	 h.jlhbayar as jlhbayarg,
	 h.snotrans,
	 h.catatan,
	 d.jlhbayar
	from ((tbpbayar h  left join tbpbayard d on h.kdbayar=d.kdbayar) left join tbpbranch br on h.kdbranch=br.kdbranch)
		left join tbppembantu pb on h.kdpembantu=pb.id 
		
		
	 $sy  order by $sqorder ";
	//echo $sq;
	$cdata=$isi="";
	$h=mysql_query2($sq);
	$br=1;
	$ajlh=array(0,0,0,0,0,0,0,0,0);
	while ($r=mysql_fetch_array($h)){
		
		if ($br%$maxbr==0)  {
			$isi.="</table></div>
			".($media=='pdf'?"#pbpdf#":"")."
			<div class='page-landscape'>
			$kop
			
			".$jdl;
		}
		$ajlh[0]+=$r['jlhbayar'];
		
		$isi.="
		<tr style='line-height: 25px;'>
			<td align='center'>$br</td>
			<td align='center'>$r[kdbayar]</td>
			<td align='center'>".tglindo2($r['tgl'])."</td>
			<td align='center'>$r[namaplg]</td>
			<td align='center'>".$r['snotrans']."</td> 
			<td align='center'>".maskRp($r['jlhbayar'],0,0)."</td> 
			<td >$r[catatan]</td> 
		</tr>
		"; 
		$br++;
		
	}
	
	$isi.="
		<tr style='line-height: 25px;'>
			<td align='center' colspan=5>JUMLAH</td>
			<td align='center'>".maskRp($ajlh[0],0,0)."</td> 
			<td align='center'  > </td> 
		</tr>
		"; 
		
	$isi.="";
	
	
		$t.="
		$kop
	 $jdl
		$isi
		</table>
		";
	
 
?>