<?php 
echo "===
		<div id=tsfrmfltrcabangg ></div>
		<div id=tinputdialog2_877761></div>
		<form id='frmfltrcabangg' action='index.php?det=cabangg&op=showtable' method='Post'  style='padding:0px;margin:0 0 5px 0;' > 
		<div style='max-height:400px;overflow:auto;padding:0px 10px'>
		
		<dl id='tritb[0]' ><dt >ID</dt> 
			<dd ><input type=text name=ftl_id id=id_$rnd></dd>
		</dl>
		
		<dl id='tritb[1]' ><dt >BRANCH</dt> 
			<dd ><input type=text name=ftl_branch id=branch_$rnd></dd>
		</dl>
		
		<dl id='tritb[2]' ><dt >ALAMAT</dt> 
			<dd ><input type=text name=ftl_alamat id=alamat_$rnd></dd>
		</dl>
		
		<dl id='tritb[3]' ><dt >KDBRANCH</dt> 
			<dd ><input type=text name=ftl_kdbranch id=kdbranch_$rnd></dd>
		</dl>
		
		<dl id='tritb[4]' ><dt >PWD1</dt> 
			<dd ><input type=text name=ftl_pwd1 id=pwd1_$rnd></dd>
		</dl>
		
		<dl id='tritb[5]' ><dt >PWD2</dt> 
			<dd ><input type=text name=ftl_pwd2 id=pwd2_$rnd></dd>
		</dl>
		
		<dl id='tritb[6]' ><dt >MODIFIED_DATE</dt> 
			<dd ><input type=text name=ftl_modified_date id=modified_date_$rnd></dd>
		</dl>
		
		<dl id='tritb[7]' ><dt >KDPRKKAS</dt> 
			<dd ><input type=text name=ftl_kdprkkas id=kdprkkas_$rnd></dd>
		</dl>
		
		<dl id='tritb[8]' ><dt >KDPRKPIUTANG</dt> 
			<dd ><input type=text name=ftl_kdprkpiutang id=kdprkpiutang_$rnd></dd>
		</dl>
		
		<dl id='tritb[9]' ><dt >KDPRKHUTANG</dt> 
			<dd ><input type=text name=ftl_kdprkhutang id=kdprkhutang_$rnd></dd>
		</dl>
		

		</div>
		
		<!--div align=right style='margin:10px 0px;0px 10px;background:#D2D2D2;padding:10px'>
			<input type=submit class='btn btn-sm btn-primary' value='Filter'>
		</div-->
		===
	</form>
";

?>
