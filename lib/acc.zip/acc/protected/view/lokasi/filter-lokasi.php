<?php 
echo "===
		<div id=tsfrmfltrlokasi ></div>
		<div id=tinputdialog2_496377></div>
		<form id='frmfltrlokasi' action='index.php?det=lokasi&op=showtable' method='Post'  style='padding:0px;margin:0 0 5px 0;' > 
		<div style='max-height:400px;overflow:auto;padding:0px 10px'>
		
		<dl id='tritb[0]' ><dt >ID</dt> 
			<dd ><input type=text name=ftl_id id=id_$rnd></dd>
		</dl>
		
		<dl id='tritb[1]' ><dt >LOKASI</dt> 
			<dd ><input type=text name=ftl_lokasi id=lokasi_$rnd></dd>
		</dl>
		
		<dl id='tritb[2]' ><dt >ALAMAT</dt> 
			<dd ><input type=text name=ftl_alamat id=alamat_$rnd></dd>
		</dl>
		
		<dl id='tritb[3]' ><dt >MODIFIED_DATE</dt> 
			<dd ><input type=text name=ftl_modified_date id=modified_date_$rnd></dd>
		</dl>
		
		<dl id='tritb[4]' ><dt >KDBRANCH</dt> 
			<dd ><input type=text name=ftl_kdbranch id=kdbranch_$rnd></dd>
		</dl>
		

		</div>
		
		<!--div align=right style='margin:10px 0px;0px 10px;background:#D2D2D2;padding:10px'>
			<input type=submit class='btn btn-sm btn-primary' value='Filter'>
		</div-->
		===
	</form>
";

?>
