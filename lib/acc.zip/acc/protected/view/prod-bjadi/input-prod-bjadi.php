<?php
$useJS=2;
include_once 'conf.php';
$det="prod-bbaku";
$nmTabel='tbpbeli';
$nmTabelAlias='h';
$nmCaptionTabel="Data Pemakaian Bahan Baku";
$nmFieldID='id';
$jtrans="BB";

$kdAwal="BB".$defKdBranch;
//$capPb="Pelanggan";
//$jenisPb="PL";

addFilterTb("jtrans='$jtrans'");
$isTest=$debugMode;

$showNoInTable=true; 
$showOpr=1;
//$jpperpage=50;
$stb=true;
$showFrmCari=$stb;
$showTbHapus=$stb;
$showTbView=$stb;
$showTbUbah=$stb;
$showTbPrint=$stb;
$showTbTambah=$stb; 
$showExportDB=false; 
$showTbFilter=false;

$showTbUnduh=false;
$showTbUnggah=false;
//$defOrderDT="[0, 'asc']";
$configFrmInput="width:1200,title: \'Input Data\'";

//untuk filter
$addFrmFilter="";


$sqTabel="select * from (
select xh.*,
xh.netto-xh.paidtoday-xh.paidafter-xh.retur as kurangbayar,
br.branch as cabang,pb.nama as namapb,
pg.nama as namapj,l.lokasi
 from (((tbpbeli xh
left join tbppembantu pb on xh.kdpembantu=pb.id)
left join tbpbranch br on xh.kdbranch=br.kdbranch)
left join tbppegawai pg on xh.kdpj=pg.id)
left join tbplokasi l on xh.kdlokasi=l.id
) as  h ";

include $um_path."input-std0.php";
 
$sAllField='';
$i=0;$sAllField.="0|id|ID|11|0|0|0|50|C|I-4,U|0|0";

$i++; $sAllField.="#1|notrans|No.Transaksi|20|1|1|1|30|C|H1-0|1|1";
if ($isAddItb) {
	$gDefField[$i]=getNewNoTrans($kdAwal,"tbpbeli",5);
	//setvar("op","ed");
}

$i++; $sAllField.="#47|kdbranch|Cabang|4|1|1|cabang|30|C|H1-0|1|1";
$gDefField[$i]=$defKdBranch;
$gFieldInput[$i]="=um412_isicombo6('select kdbranch,branch from tbpbranch','kdbranch','cbProdByBranch($rnd)');";

$i++; $sAllField.="#7|tgl|Tanggal|10|1|1|1|30|C|D-0|1|1";
$gDefField[$i]=date($formatTgl);

$i++; $sAllField.="#5|kdproduksi|Kode Produksi|12|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=showListProduksi('kdproduksi','$defKdBranch','0','cbLokasiByProduksi($rnd);');";

/*
$i++; $sAllField.="#14|kdpembantu|$capPb|7|1|1|namapb|7|C|S-1|1|1";
$gFieldInput[$i]="=showListPembantu('$jenisPb').'<span id=tsaldohp_$rnd></span>';";
*/


$i++; $sAllField.="#21|kdlokasi|Lokasi|7|1|1|lokasi|7|C|H1-0|1|1";
$gDefField[$i]=$defKdLokasi;
$gFieldInput[$i]="=isiCbLokasi('kdlokasi');";

//$i++; $sAllField.="#46|alamatkirim|ALAMAT PENGIRIMAN|40|1|1|0|30|C|S-0|1|1";
$i++; $sAllField.="#30|catatan|Catatan|40|1|1|1|30|C|S-0|1|1";
$tPosDetail=$i;
$i++; $sAllField.="#10|brutto|SUB TOTAL|13|3|1|0|7|C|C,1|1|0";
//$i++; $sAllField.="#44|byangkut|By. Angkut/Kirim|13|1|1|0|7|C|N-0,0|1|1";
//$i++; $sAllField.="#44|bytimbang|BY.TIMBANG |13|1|1|0|7|C|C,0|1|1";
//$i++; $sAllField.="#44|bykuli|BY.KULI |13|1|1|0|7|C|C,0|1|1";
$i++; $sAllField.="#13|netto|Total Transaksi|13|0|0|1|7|C|C,1|1|1|0";
//$i++; $sAllField.="#17|paidtoday|Pembayaran Tunai|13|1|1|0|7|C|N-0,0|1|1|0";
//$i++; $sAllField.="#13|retur|Retur|13|3|1|1|7|C|N-0,1|1|1|0";
//$i++; $sAllField.="#17|kurangbayar|Piutang|13|3|0|1|7|C|N,0|1|1|0";
//$i++; $sAllField.="#30|catatan|Catatan|40|1|1|1|30|C|T,0|1|1";

if ($isMarketing) {
	addSave("kdpj",$vidusr);
} else {
	$i++; $sAllField.="#25|kdpj|PJ|7|1|1|kdpj namapj|7|C|S-0|1|1";
	$gFieldInput[$i]="=um412_isicombo6('select id,nama from tbppegawai','kdpj');";	
	$gDefField[$i]=$vidusr;
}

for ($i=$tPosDetail;$i<=20;$i++) {
	$gFuncFld[$i]="evalTRBB($rnd);";
}

/*
$i++; $sAllField.="#2|jtrans|JTRANS|0|0|1|0|30|C|S-0|1|1";
$gDefField[$i]="SL";
$i++; $sAllField.="#6|tglentri|TGLENTRI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#3|nofaktur|NOFAKTUR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#8|tgljt|TGLJT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#4|stat|STAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#11|disc|DISC|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#12|discp|DISCP|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#16|carabayar|CARA BAYAR|40|1|1|1|30|C|S-0|1|1";
$gFieldInput[$i]="=um412_isicombo5('Tunai,Kredit','carabayar');";
$i++; $sAllField.="#18|paidafter|PAIDAFTER|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#45|pdeposit|PENGAMBILAN DEPOSIT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#33|byangkut|BYANGKUT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#37|expedisi|EXPEDISI|40|1|1|1|30|C|S-0|1|1";


$i++; $sAllField.="#19|kdbayar|KDBAYAR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#20|retur|RETUR|7|1|1|1|7|C|S-0|1|1";

$i++; $sAllField.="#34|disc2|DISC2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#35|disctot|DISCTOT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#43|bal|BAL|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#15|term|TERM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#9|opr|OPR|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#36|berat|BERAT|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#38|statexpedisi|STATEXPEDISI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#39|tglkirim|TGLKIRIM|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#40|tglsampai|TGLSAMPAI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#41|noresi|NORESI|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#26|dccharge|DCCHARGE|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#27|bayar|BAYAR|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#28|kembalian|KEMBALIAN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#29|dcref|DCREF|40|1|1|1|30|C|S-0|1|1";

$i++; $sAllField.="#22|kdlokasi2|KDLOKASI2|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#31|donasi|DONASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#32|margin|MARGIN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#42|idproject|IDPROJECT|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#23|ppn|PPN|7|1|1|1|7|C|S-0|1|1";
$i++; $sAllField.="#24|jenis|JENIS|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#48|idkonsolidasi|IDKONSOLIDASI|40|1|1|1|30|C|S-0|1|1";
$i++; $sAllField.="#49|modified_date|MODIFIED_DATE|40|1|1|1|30|C|S-0|1|1";

*/
//$gFieldInput[$i]="$inp=um412_isicombo5('select * from tbsales','idsales');";
//$gFieldView[$i]="='Menu';";
//$isiComboFilterTabel="notrans;tbpbeli.notrans"; 

/*
$addTbOpr=" 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=cetak1','penjualan|penjualan',$rnd,$rndInput,'$configFrmInput');\" value='Cetak' /><i class='fa fa-print'></i> Cetak Dokumen</span> ";
*/

$addTbOpr=" 
<span  class='btn btn-mini btn-info' 
onclick=\"tbOpr('view|&op=view&custom=sj','$det',$rnd,$rndInput,'$configFrmInput');\" value='Surat Jalan' /><i class='fa fa-print'></i> Surat Jalan</span> 
<span  class='btn btn-primary btn-mini btn-sm' 
onclick=\"tbOpr('view|&op=view&custom=gl','$det',$rnd,$rndInput,'$configFrmInput');\" value='GL' /><i class='fa fa-print'></i> GL</span> 
";

 
 
 
$jInputD=3;
$detCari="barang"; 
$fldCari="kdbrg,nmbarang,satuan,hrg";
$funcEvalD=$adf="evalTrBB($rnd)";
$opcari="carib";

$useInputD=true;
$showNoD=true;
//--------------------------detail
$gFieldInputD=$gFieldViewD=explode(",", ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,");
$nmTabelD='tbpbelid';
$nmTabelDAlias='d';
$fldKeyM='notrans';
$fldKeyForeign='notrans';
$fldKeyD='id';
$sFldD="kdbrg,xxnmbarang,jlh_terima,jlh_tarra,hrg,disc,subtot,catatan1";
$sFldDCap="Kode,Deskripsi,Jumlah,Jlh. Penyusutan,Harga,xx,Subtotal,Ket";
$sFuncFldD="$adf,,$adf,,$adf,,,,,,,,,";
$sSzFldD ="4,18,4,7,4,7,7,4,7,7";//ukuran input
$sJenisFldD=",,,,,,i,,i,,,,,,,,,,,,,";

$sClassFldD=",,C,C,C,C,C,,,,,,,,,,,";
$sAlignFldD=",r,r,r,r,r,r,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";

$sLebarFldD="20,65,20,20,20,22,22,22,22,22,22,20,20";
$sClassFldD=",,CX,,N,CX,N,,,,,,,,,,,";
$sAlignFldD=",r,r,r,r,r,,,,,,,,,,,,";
$sAllowEditFldD=",,,,,,,,,,,,,,,,,,";
 
$nmCaptionTabelD="Detail Pembelian";

$addParamDetCari="&kdlokasi='+$('#kdlokasi_$rnd').val()+'";
$footTbD="
<div class='coldet coldet-0'>
	<div class='tisicoldet' id=jlhitemfix_$rnd>&nbsp;</div>
</div >
<div class='coldet coldet-1'>
	<div class='tisicoldet' > </div>
</div >
<div class='coldet coldet-2'>
	<div class='tisicoldet' >Jumlah</div>
</div>
<div class='coldet coldet-3'>
	<div class='tjlhd tisicoldet' id=tjlhnetto_$rnd>i</div>
</div>
<div class='coldet coldet-4 right'>
	<div class='tisicoldet ' ></div>
</div>

<div class='coldet coldet-5'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-6'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
<div class='coldet coldet-7'>
	<div class='tjlhd tisicoldet' id=tbrutto_$rnd></div>
</div>

<div class='coldet coldet-8'>
	<div class='tisicoldet' >&nbsp;</div>
</div>
";

$showOprD=false;
$idxAksi=0;

 
$nmCaptionTabelD="Detail";

$footTbD="
<td><div id=jlhitemfix_$rnd></div></td>
<td >Jumlah</td>
<td align=right><div class='tjlhd' id=tjlhnetto_$rnd></div></td>
<td align=right><div class='tjlhd' id=tjlhnetto_$rnd></div></td>
<td align=right><div class='tjlhd' id=tbrutto_$rnd></div></td>
<td align=right></td>

";


$showOprD=false;
/*
$idxAksi=0;
if (($op=='itb')) {
	if ($idxAksi==0) {
		$sFldD="xxaksi,$sFldD";
		$sFldDCap="Aksi,$sFldDCap";
		$sLebarFldD="10,$sLebarFldD";
		$sClassFldD=",$sClassFldD";
		//$idxplg++;
		//$idxsales++;
	} else {
		$sFldD.=",xxAksi";
		$sFldDCap.=",Aksi";
	}
	//'<a href=# onclick=\"bukaAjaxD(\'#tid#\',\'content1.php?det=piutang&op=pilih&newrnd=$rnd&idpembantu=\',\'width:1240\')\"class=\"btn btn-primary btn-sm\"> + </a>'.
	
	$gFieldInputD[$idxAksi]="=
	'<a href=# onclick=\"$'.'(\'#d_hrg_#rnd#_#no#\').val(0);$'.'(\'#d_jlh_terima_#rnd#_#no#\').val(0);$'.'(\'#trdet_#rnd#_#no#\').hide();evalTRBB($rnd);\"class=\"btn btn-danger btn-sm\"> - </a>'
	;";
	
} elseif ($op=='view') {
	//$gFieldViewD[4]="0";
	//$gFieldViewD[5]="0";
	
}
*/
$gFieldInputD[1]="=um412_isicombo5('select kdbrg,nmbarang from tbpbarang order by nmbarang ','d_kdbrg_$rnd"."_#no#;d_kdbrg[]','','','','#def#','cekKdBrgTrBB($rnd,#no#);' );";
$gFieldViewD[1]="nmbarang";

$gFieldInputD[2]="<input id=d_nmbrg2_#rnd#_#no# size=6 onkeyup='evalJlhTrBB($rnd,#no#);'>";
for ($i=3;$i<=6;$i++) {
	$gFuncFldD[$i]="evalJlhTrBB($rnd,#no#);";
}
	

//$gFieldInputD[4]="=(#jlh_terima#*(#hrg#-#disc#));";
/*
$gFieldInputD[$idxsales]="=um412_isicombo5('select id,nama from tbppegawai','d_idsales[]','','','','#def#' );";
$gFieldViewD[$idxsales]="nmsales";

//

*/

$sqTabelD="select d.*,b.nmbarang,b.satuan  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where $nmTabelAlias.$nmFieldID='#id#' 
";

//$idimport=rand(123101,98766661);
//$sFieldIdImport='idimport'
$formatTglCSV='dmy';
$capImport='Import Data';//caption tombol import
$sFieldCSV=strtolower('id,notrans,jtrans,nofaktur,stat,nopo,tglentri,tgl,tgljt,opr,brutto,disc,discp,netto,kdpembantu,term,carabayar,paidtoday,paidafter,kdbayar,retur,kdlokasi,kdlokasi2,ppn,jenis,kdpj,dccharge,bayar,kembalian,dcref,catatan,donasi,margin,byangkut,disc2,disctot,berat,expedisi,statexpedisi,tglkirim,tglsampai,noresi,idproject,bal,byangkutest,pdeposit,alamatkirim,kdbranch,idkonsolidasi,modified_date');
$sFieldCaptionCSV= strtolower('ID,NOTRANS,JTRANS,NOFAKTUR,STAT,NOPO,TGLENTRI,TGL,TGLJT,OPR,BRUTTO,DISC,DISCP,NETTO,KDPEMBANTU,TERM,CARABAYAR,PAIDTODAY,PAIDAFTER,KDBAYAR,RETUR,KDLOKASI,KDLOKASI2,PPN,JENIS,KDPJ,DCCHARGE,BAYAR,KEMBALIAN,DCREF,CATATAN,DONASI,MARGIN,BYANGKUT,DISC2,DISCTOT,BERAT,EXPEDISI,STATEXPEDISI,TGLKIRIM,TGLSAMPAI,NORESI,IDPROJECT,BAL,BYANGKUTEST,PDEPOSIT,ALAMATKIRIM,KDBRANCH,IDKONSOLIDASI,MODIFIED_DATE');
//$nfCSV='import_Data_Penjualan.csv';
//$sFieldCsvAdd=',idimport';
//$sFieldCsvAddValue=",'".$idimport."'";


$addTbSimpan=array(
	array('Simpan dan Cetak','op=view&aid=#id#')
);


include $lib_app_path."protected/model/input-penjualan-op1.php";	
include $um_path."input-std.php";
include $lib_app_path."protected/model/input-penjualan-op2.php";

?>
