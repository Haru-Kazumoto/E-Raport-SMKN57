<?php
$kota="Limpung";
$nmopr="Sarwono";
?>

<div class='tbviewatas noprint' style='margin:5px 5px -7px 0px;text-align:right' >
	<?php
	echo tbPrint("tview_957442");
	?>
</div>
<div class='tview' id='tview_957442'>
	<link rel='stylesheet' type='text/css' href='<?=$js_path?>/style-cetak.css'></link>
	
		
	
	<div class=page>
		<style>
		table.overview-table tr td {
			padding: 3px;
		}
		#tview_957442,
		#tview_957442 td {
			font-size:10px;
			padding:2px 5px;
			
		}
		
		#tview_957442 .tdjudul1{
			background:#ccc;
			color:#000;
			text-align:center;
			padding:2px 5px;

		}

		#tview_957442 td.rp {
			text-align:right;
			
		}
		#tview_957442 td.c {
			text-align:center;
			
		}
		</style>
		<?php

		$sqTabelD=str_replace("#id#","$id",$sqTabelD);

		$jdTbD="<tr>\n";
		$jdTbD.="<th class='tdjudul1'>NO</th>\n";
		$jdTbD.="<th class='tdjudul1'>KODE</th>\n";
		$jdTbD.="<th class='tdjudul1'>DESKRIPSI</th>\n";
		$jdTbD.="<th class='tdjudul1'>JLH</th>\n";
		//$jdTbD.="<th class='tdjudul1'>SAT</th>\n";
		
		$jdTbD.="<th class='tdjudul1'>HARGA</th>\n";
		$jdTbD.="<th class='tdjudul1'>SUBTOTAL</th>\n";
		$jdTbD.="<th class='tdjudul1'>KETERANGAN</th>\n";
		$jdTbD.="</tr>\n";
		
		$isiTbD="";
		$brd=0;
		$hd=mysql_query2($sqTabelD);
		
		while ($rd=mysql_fetch_array($hd)) {
			$br=$brd+1;
			$rw="<tr>";
			$rw.="<td class='c' >$br</td>\n";
			$rw.="<td class='c' >$rd[kdbrg]</td>\n";
			$rw.="<td>$rd[nmbarang]
			</td>\n";
			$rw.="<td class='rp' >".maskRp($rd['jlh_terima'])."</td>\n";
//				$rw.="<td class='rp' >".maskRp($rd['jlh_terima'])."</td>\n";
			//$rw.="<td class='c' >$rd[satuan]</td>\n";
			
			$rw.="<td class='rp' >".maskRp($rd['hrg'])."</td>\n";
			$rw.="<td class='rp' >".maskRp($rd['subtot'])."</td>\n";
			$rw.="<td>
			Brutto:".str_replace("/"," / ",$rd['catatan1']).", Tarra :".str_replace("/"," / ",$rd['jlh_tarra']).", Netto :".str_replace("/"," / ",$rd['jlh_terima']).", 
			</td>\n";
			$rw.="</tr>";
			$isiTbD.=$rw;	
			$brd++;
		}

		$rw="<tr> 
				<td colspan=5> &nbsp;</td> 
				<td class='rp'>".maskRp($r['brutto'])."</td>\n
			<td > &nbsp;</td> 
				</tr>";
		$isiTbD.=$rw;
		$jlh=$r['brutto']+$r['bytimbang'];
		$terhutang=$jlh-$r['paidtoday'];
		$terbilang=ucwords(terbilang($jlh))." Rupiah";
		
		$h="
		<div  style='max-height:none;'>
		<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td style='width:40%'> 
					<div >$namaPsh<div>
					<div >$alamatPsh<div>
					<hr>
				</td>
				<td class='c'>
				 <h2>Faktur Pembelian</h2>
				</td>
				</tr>
			</table>
		</div>	
		
		<table border='0' class='tbform2 tbcetaktanpagaris overview-table wow fadeInDown animated' >
			<tr> <td align=center> 
				
			 <table border='0' class='tbcetaktanpagaris ' width=100% >	
			 <tr><td width=50%>
					<table border='0' class='tbcetaktanpagaris ' >			
					"
					.rowView('Tanggal',tglindo($r['tgl']))
					.rowView('No. Faktur',$r['notrans'])
					//=rowView('AREA',$r['area']);
					.rowView('Catatan',$r['catatan']) 
					."
					</table>
				</td>
				<td>
					<table border='0' class='tbcetaktanpagaris ' >			
					"
					.rowView('Kepada',$r['namapb'])
					.rowView('Alamat ',$r['alamatkirim'])
					//=rowView('AREA',$r['area']);
					."
					</table>
				
				</td>
				</tr>
				</table>
			</td></tr>		
		</table>
	
	 
		<table style='width:100%' class='  tbcetakbergaris ' id='tbdet_$rnd' border=1   >
			<thead>
				$jdTbD
			</thead> 
			<tbody id='tbody_tbdet_$rnd'>
			$isiTbD
			</tbody>
		</table>
		<br>
		<br>
		<table class=tbcetakberbaris border=1 width=50% >
			<tr><td>Biaya Timbang </td><td align=right >".maskRp($r['bytimbang'])."</td></tr>
			<tr><td>Total  </td><td align=right ><b>".maskRp($r['netto'])."</b></td></tr>
			<tr><td>Bayar hari ini  </td><td align=right >".maskRp($r['paidtoday'])."</td></tr>
			<tr><td>Terhutang  </td><td align=right >".maskRp($terhutang)."</td></tr>
		</table>					
		<div style='font-weight:bold;font-size:12px;padding:10px 0px 0px 5px'>Total : ".maskRp($r['netto'],1)."</div>
		<div style='padding:0px 0px 0px 5px;font-style:italic'>
			Terbilang : $terbilang</div>
		</div>
		<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td style='width:500px'> &nbsp;</td>
				<td >
					$kota, ".tglindo($r['tgl'])."
					<br>
					<br>
					<br>
					($nmopr)
				</td>
				</tr>
			</table>
		</div>	
	
		";


		echo $h;

		?>
	</div>

</div>