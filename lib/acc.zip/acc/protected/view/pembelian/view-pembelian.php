<?php
$kota=getconfig("kota");
$nmopr="____________________";

echo "
<div class='tbviewatas noprint' style='margin:5px 5px -7px 0px;text-align:right' >
	";
echo tbPrint("tview_$rnd");
echo "	</div>;";
echo"
<div class='tview' id='tview_$rnd'>
	<link rel='stylesheet' type='text/css' href='$js_path"."style-cetak.css'></link>
	<div class=page>
		<style>
		table.overview-table tr td {
			padding: 3px;
		}
		#tview_$rnd,
		#tview_$rnd td {
			font-size:10px;
			padding:2px 5px;
			
		}
		#tview_$rnd .col-sm-3,
		#tview_$rnd .col-sm-8 {
			width:50%;
		}
		
		#tview_$rnd .tdjudul1{
			background:#ccc;
			color:#000;
			text-align:center;
			padding:2px 5px;

		}

		#tview_$rnd td.rp {
			text-align:right;
			
		}
		#tview_$rnd td.c {
			text-align:center;
			
		}
		#tview_$rnd .ar,
		.ar {
			text-align:right;
		}
		</style>";
		
		
		$sqTabelD=str_replace("#id#","$id",$sqTabelD);

		$jdTbD="<tr>\n";
		$jdTbD.="<th class='tdjudul1'>NO</th>\n";
		$jdTbD.="<th class='tdjudul1'>KODE</th>\n";
		$jdTbD.="<th class='tdjudul1'>NAMA BARANG</th>\n";
		$jdTbD.="<th class='tdjudul1 ar'>HARGA</th>\n";
		$jdTbD.="<th class='tdjudul1 ar'>JUMLAH</th>\n";		
		$jdTbD.="<th class='tdjudul1 ar'>SUBTOTAL</th>\n";
		$jdTbD.="</tr>\n";
		
		$isiTbD="";
		$brd=0;
		$hd=mysql_query2($sqTabelD);
		
		while ($rd=mysql_fetch_array($hd)) {
			$br=$brd+1;
			$rw="<tr>";
			$rw.="<td class='c' >$br</td>\n";
			$rw.="<td class='c' >$rd[kdbrg]</td>\n";
			$rw.="<td>$rd[nmbarang]</td>\n";
			//$rw.="<td class='rp' >".maskRp($rd['jlhpkg'])."</td>\n";
			$rw.="<td class='rp' >".maskRp($rd['hrg'],0,0)."</td>\n";
			$rw.="<td class='rp' >".maskRp($rd['jlh_terima'],0,9999)." $rd[satuan]</td>\n";		
			$rw.="<td class='rp' >".maskRp($rd['subtot'],0,0)."</td>\n";
			$rw.="</tr>";
			$isiTbD.=$rw;	
			$brd++;
		}

		/*
		$rw="<tr> 
				<td colspan=5> &nbsp;</td> <td class='rp'>".maskRp($r['brutto'],0,0)."</td>\n
			</tr>";
			
		$isiTbD.=$rw;
		*/
		
		$terbilang=ucwords(terbilang($r['netto']*1))." Rupiah";
		
		$h="
		<div style='max-height:none;'>
		<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td style='width:40%'> 
					<div >$namaPsh<div>
					<div >$alamatPsh<div>
					<hr>
				</td>
				<td class='c'>
				 <h2>FAKTUR PEMBELIAN</h2>
				</td>
				</tr>
			</table>
		</div>	";
		
		//rowView('cap|width|col-sm-3','isi|width|right|col-sm-8');

		$scolsm_rowitb="5,5";
		/*rowView("Faktur","-");,$salign="left,left");
		rowView("","Faktur");
		rowView("nofaktur","No. Faktur",$salign="left,left",$usedtdd=false);
		*/
		$alamatk=($r['alamatkirim']!=""?$r['alamatkirim']:$r['alamatpb']);
		$h.="
		<table border='0' class='tbform2 tbcetaktanpagaris overview-table wow fadeInDown animated' >
			<tr> <td align=center> 
				
			 <table border='0' class='tbcetaktanpagaris ' width=100% >	
			 <tr><td width=50%>
					<table border='0' class='tbcetaktanpagaris' width='100%'  >			
					"
					.rowView('No. Faktur||tdview-col-1',$r['notrans']."||tdview-col-2")
					.rowView('Kepada',$r['namapb'])
					.rowView('Alamat ',$alamatk)
					.rowView('Telepon ',$r['telppb'])
					."
					</table>
				</td>
				<td valign=top >
					<table border='0' class='tbcetaktanpagaris' width='100%'  >			
					"
					.rowView('Tanggal',tglindo($r['tgl']))
					//=rowView('AREA',$r['area']);
					//=rowView('AREA',$r['area']);
					."
					</table>
				
				</td>
				</tr>
				</table>
			</td></tr>		
		</table>	
		<table style='width:100%' class='  tbcetakbergaris ' id='tbdet_$rnd' border=1   >
			<thead>
				$jdTbD
			</thead> 
			<tbody id='tbody_tbdet_$rnd'>
			$isiTbD
			</tbody>
		</table>
		<div style='font-weight:bold;font-size:12px;padding:10px 0px 0px 5px'>Total : ".maskRp($r['netto'],1,0)."</div>
		<div style='padding:0px 0px 0px 5px;font-style:italic'>
			Terbilang : $terbilang</div>
		</div>
		<div style='margin-top:0px'>
			<table style='width:100%' class=' tbcetaktanpagaris ' id='tbdet_$rnd' border=0   >
				<tr>
				<td width=33% >
					<br>Sopir,
					<br>
					<br>
					<br>
					______________________
				</td>
				<td width=34% >
					<br>Checker,
					<br>
					<br>
					<br>
					______________________
				</td>
				
				<td width=33% >
					$kota, ".tglindo($r['tgl']).",<br>
					Admin,
					<br>
					<br>
					<br>
					______________________
					</td>
				</tr>
			</table>
		</div>	
	
		";


		echo $h;

		?>
	</div>

</div>