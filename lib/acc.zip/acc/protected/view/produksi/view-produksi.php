<div class='' style=' 0 10px 0;text-align:right' >
	<button class='btn btn-success btn-sm' onclick="printDiv('tview_<?=$rnd?>')">Cetak</button>
</div>
<link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
<div class='tview' id='tview_<?=$rnd?>'>
<div class=page>
<div id='tampilan_<?=$rnd?>'>
<div class=jdlfaktur>JURNAL PRODUKSI</div>
<table border='0' class='tbform2xx tbcetaktanpagaris overview-table' width=100% >
<tr>
	<td style='width:50%'>
		<?php

		echo $headPsh;
		echo "<div style='margin-top:8px'>Tanggal : ".tglIndo($r['tgl'])."</div>";

		?>
	
	</td>
	<td style='width:50%' valign=top>
		<table border='0' class='tbkepada tbcetaktanpagaris overview-table' width=100% >
			<?php
			echo "
			<tr>
			<td width=120>No. Transaksi</td><td  width=120>: $r[notrans]</td>
			</tr>
			<tr>
			";
			?>
		
		</table>
	</td>
</tr>

</table>

 
 
<!--h4 class='titleview'>Detail Pembelian`</h4-->
<div class='' style='border-top:1px solid #000;padding-top:2px'>
<table style='width:100%' class='tbcetakbergaris ' id='tbdet_<?=$rnd?>'   >
	<tbody id='tbody_tbdet_<?=$rnd?>'>
	<?php
cekVar("id");
$sqTabelD="select d.*,b.nmbarang,b.satuan  from 
(tbpbelid d inner join tbpbeli h on d.notrans=h.notrans)
inner join tbpbarang b on d.kdbrg=b.kdbrg 
where h.id='$id' 
";
	
	$isiTbD="";
	$brd=0;
	$hd=mysql_query2($sqTabelD);
	$jlhD=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
	
	$lastkdbrg=$sket="";
	$jlhNetto=0;
	$adt=sqltoarray($sqTabelD,0);
	$jlhBarisD=count($adt);
	$srek="";
	//konversi ke array
	$arrData=array();
	$ir=-1;
	$lastkd="";


	$isiTbD.="
		<tr>
			<td  align=center >No</td>
			<td  align=center >Jenis Barang</td>
			<td  align=center >In/Out</td>
			<td  align=center >Jml Brg</td>
			<td  align=center >Satuan</td>
			<td  align=center >Jml Brg/DOSS</td>
			<td  align=center >Harga/KG</td>
			<td  align=center >Subtotal</td>
		</tr>
		";
	$br=1;
	foreach ($adt as $dt) {
		$rd=$dt;
		$io=($rd['jlh_terima']>=0?"In":"Out");

		$isiTbD.="
			<tr>
			<td align=center >$br</td>
			<td align=center >$rd[nmbarang]</td>
			<td align=center >$io</td>
			<td align=center  >".maskRp($rd['jlhpkg'],0,0)."</td>
			<td align=center >$rd[satuan]</td>
			<td align=center >".maskRp($rd['jlhppkg'],0,0)."</td>
			<td align=center >".maskRp($rd['hrg'],0,0)."</td>
			<td align=center >".maskRp($rd['subtot'],0,0)."</td>
			</tr>			
			";
		$br++;
	}
	echo $isiTbD;
	
	?>
	
	</tbody>
	<tfoot>
		<tr>
<td class='' colspan=7 align=center >BALANCE</td>
<td class='' style='text-align:center'><?=maskRp($r['bal'],0,0)?></td>
</tr>

		
	</tfoot> 
</table>
</div>
<?php
if (strlen($r['catatan'])>2) echo '<br><br>Catatan : '."<span><i>$r[catatan]</i></span>";
 

echo "
<br>

<table border='0' class='tbform2xx tbcetaktanpagaris ' width=100% >
<tr>
	<td valign=top>
	&nbsp;</td>
	<td>
		<div style='float:right'>
			<div style='width:200px;text-align:center'>
			Penanggung Jawab,
			<br>
			<br>
			<br>
			( ________________ )
			</div>
		</div>	
	</td>
</tr>
</table>
";


$clspage="A5";
include $toroot."css-lx300.php";

?>
</div>
</div>
</div > 