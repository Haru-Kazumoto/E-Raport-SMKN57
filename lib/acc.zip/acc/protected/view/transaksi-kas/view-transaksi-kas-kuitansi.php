<?php
$jud="KUITANSI PEMBAYARAN";
	
if (($stat==1)||($stat==3)) {
	cekvar("op2");
	
	if ($op2!="preview") {
		echo "op2 $op2";
		echo um412_falr('Transaksi yang belum atau tidak di-ACC oleh manajer tidak bisa dicetak ');
		exit;
	} else {
		echo "Preview....";
	}
	$jud="CEKKING KUITANSI";
} else {
	
	echo "<div class='' style=' 0 10px 0;text-align:right' >
			<button class='btn btn-success btn-sm' onclick=\"printDiv('tview_$rnd')\">Cetak</button>
		</div>";

} 

?>

<div class='tout tview' id='tview_<?=$rnd?>'>
<link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
<?php
$clspage="A5";
include $um_path."css-lx300.php";
?>
	<div class=page>
	<div id='tampilan_<?=$rnd?>'>

	<div class=jdlfaktur><?=$jud?></div>
	<?php //echo tampilKop('Pembayaran Iuran Sekolah');
	
	echo $headPsh;
	
	$nokui="KU-".$r["notrans"];
	$wCap=100;
	$guna=$r["catatan"];
//.rowView('Dibayar Kepada',$kepada)
		
	echo "
	<br>
		<table border='0' class='tbkepada tbcetaktanpagaris' width=100% >"
		.rowView('No. Kuitansi',''.$nokui.' </td><td align=right>Tanggal : '.tglindo($r['tgl'])."&nbsp;&nbsp;&nbsp;")
		.rowView('Jumlah Uang',maskrp($r["jlhuang"],1,0).' ')
		.rowView('Guna Membayar',$guna)
		."</table>";
	//.rowView('Rincian Pembayaran','&nbsp;')
		
		//if ($r['catatan']!='') echo rowView('Catatan',$r['catatan']);
		
$arrColumn=array();
$arrColumn[]='$br';
//$arrColumn[]='$rd["kdprk"]';
$arrColumn[]='$rd["nmprk"]';
//$arrColumn[]='tglindo($rd["tgltrans"])';
$arrColumn[]='maskRp($rd["jlhuang"],1,0)';
$arrColumn[]='$rd["catatan"]';
$aAlignFldD[0]="center";
$aAlignFldD[1]="center";
$aAlignFldD[2]="center";
$aAlignFldD[3]="center";
$aAlignFldD[4]="center";			
/*		
$sqTabelD="select d.*,$nmTabelAlias.tgl as tgltrans  from 
($nmTabelD d inner join $nmTabel $nmTabelAlias on d.$fldKeyForeign=$nmTabelAlias.$fldKeyM)
where $nmTabelAlias.$nmFieldID='$id' ";
	*/		
$isiTbD="";
$brd=0;
$hd=mysql_query2($sqTabelD);
$jlhD=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
$arrTabel=array();
while ($rd=mysql_fetch_array($hd)) {
	$br=$brd+1;
	$isiTbD.="<tr>";
	$i=0;
	$jlhD[0]+=$rd['jlhuang'];
	foreach ($arrColumn as $cl) {
		eval("$"."xx=".$cl.";");
		
		$isiTbD.="<td align=$aAlignFldD[$i] style='text-align:$aAlignFldD[$i] '>$xx</td>"; 
		$i++;
	}
	$isiTbD.="</tr>";
	$brd++;
}
 
$terbilang=ucwords(terbilang($r['jlhuang'])." Rupiah");

/*
$tdet="";
$tdet.="
	<div style='margin-top:5px'>
			<table style='width:100%' align=center border=1 class=' tbcetakbergaris '    >
				<tr>
					<td class='tdjudulx' align=center >No.</td>
					<td class='tdjudulx' align=center >Akun</td>
					<td class='tdjudulx' align=center >Jumlah</td>
					<!--td class='tdjudulx' align=center >Keterangan</td-->
				</tr>";
$tdet.=$isiTbD;
$tdet.="		<tr><td colspan='3' align=center >JUMLAH</td><td align=center style='text-align:center'>".maskRp($jlhD[0],1,0)."</td><td>&nbsp;</td>
			</table>
	</div>";

echo $tdet;
*/
?>

<div class=terbilang style='text-decoration:italic;margin-top:10px'>
<i>Terbilang : <?=$terbilang?></i>
<?php

echo "
<table border='0' class='tbform2xx tbcetaktanpagaris ' width=100% style='margin-top:12px' >
<tr>
	<td width='30%' align='center' valign=top>
	<br>Penerima
	<br><br><br><br>
	(_____________________)	
	</td>
	<td width='30%' align='center'>
	&nbsp;</td>
	<td width='30%' align='center' valign=top>
	$defKota,
	 ".tglIndo($r['tgl'])."<br>
	Admin
	<br><br><br><br>
	(_____________________)	
	</td>


</tr>
</table>
";
?>
</div>
</div>