<?php 
echo "===
		<div id=tsfrmfltrpelanggan ></div>
		<div id=tinputdialog2_362286></div>
		<form id='frmfltrpelanggan' action='index.php?det=pelanggan&op=showtable' method='Post'  style='padding:0px;margin:0 0 5px 0;' > 
		<div style='max-height:400px;overflow:auto;padding:0px 10px'>
		
		<dl id='tritb[0]' ><dt >ID</dt> 
			<dd ><input type=text name=ftl_id id=id_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[1]' ><dt >NAMA</dt> 
			<dd ><input type=text name=ftl_nama id=nama_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[2]' ><dt >ALAMAT</dt> 
			<dd ><input type=text name=ftl_alamat id=alamat_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[3]' ><dt >ALAMAT2</dt> 
			<dd ><input type=text name=ftl_alamat2 id=alamat2_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[4]' ><dt >KOTA</dt> 
			<dd ><input type=text name=ftl_kota id=kota_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[5]' ><dt >PROVINSI</dt> 
			<dd ><input type=text name=ftl_provinsi id=provinsi_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[6]' ><dt >TELP</dt> 
			<dd ><input type=text name=ftl_telp id=telp_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[7]' ><dt >FAX</dt> 
			<dd ><input type=text name=ftl_fax id=fax_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[8]' ><dt >CP</dt> 
			<dd ><input type=text name=ftl_cp id=cp_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[9]' ><dt >HP</dt> 
			<dd ><input type=text name=ftl_hp id=hp_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[10]' ><dt >EMAIL</dt> 
			<dd ><input type=text name=ftl_email id=email_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[11]' ><dt >TERM</dt> 
			<dd ><input type=text name=ftl_term id=term_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[12]' ><dt >NPWP</dt> 
			<dd ><input type=text name=ftl_npwp id=npwp_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[13]' ><dt >CATATAN</dt> 
			<dd ><input type=text name=ftl_catatan id=catatan_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[14]' ><dt >INACTIVE</dt> 
			<dd ><input type=text name=ftl_inactive id=inactive_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[15]' ><dt >WWW</dt> 
			<dd ><input type=text name=ftl_www id=www_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[16]' ><dt >FB</dt> 
			<dd ><input type=text name=ftl_fb id=fb_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[17]' ><dt >TWITTER</dt> 
			<dd ><input type=text name=ftl_twitter id=twitter_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[18]' ><dt >PINBB</dt> 
			<dd ><input type=text name=ftl_pinbb id=pinbb_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[19]' ><dt >JPEMBANTU</dt> 
			<dd ><input type=text name=ftl_jpembantu id=jpembantu_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[20]' ><dt >KDWIL</dt> 
			<dd ><input type=text name=ftl_kdwil id=kdwil_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[21]' ><dt >CREDITLIMIT</dt> 
			<dd ><input type=text name=ftl_creditlimit id=creditlimit_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[22]' ><dt >DEFPPN</dt> 
			<dd ><input type=text name=ftl_defppn id=defppn_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[23]' ><dt >KDPJ</dt> 
			<dd ><input type=text name=ftl_kdpj id=kdpj_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[24]' ><dt >JPEMBANTU2</dt> 
			<dd ><input type=text name=ftl_jpembantu2 id=jpembantu2_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[25]' ><dt >DEPOSIT</dt> 
			<dd ><input type=text name=ftl_deposit id=deposit_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[26]' ><dt >SAWAL</dt> 
			<dd ><input type=text name=ftl_sawal id=sawal_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[27]' ><dt >MODIFIED_DATE</dt> 
			<dd ><input type=text name=ftl_modified_date id=modified_date_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[28]' ><dt >KDBRANCH</dt> 
			<dd ><input type=text name=ftl_kdbranch id=kdbranch_$rnd></dd>
		</dl>: 
		
		
		<dl id='tritb[29]' ><dt >IDSALES</dt> 
			<dd ><input type=text name=ftl_idsales id=idsales_$rnd></dd>
		</dl>: 
		
		

		</div>
		
		<!--div align=right style='margin:10px 0px;0px 10px;background:#D2D2D2;padding:10px'>
			<input type=submit class='btn btn-sm btn-primary' value='Filter'>
		</div-->
		===
	</form>
";

?>
