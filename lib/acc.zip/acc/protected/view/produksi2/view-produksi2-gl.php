<link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
<div class='tview' id='tview_<?=$rnd?>'><div class=page>
<h2 class=titleview>
<?=$nmCaptionTabel?>
</h2>
<div class='tbviewatas noprint' style='margin:-35px 0 10px 0;text-align:right' ><button class='btn btn-success btn-sm' onclick="printDiv('tview_<?=$rnd?>')">Cetak</button></div>
<?php
//bersihkan gl kosong
clearEmptyGL();

$notrans=$kdproduksi=$r['kdproduksi'];
echo showGL($notrans);
 

//mencari di bahan baku
echo "<br><b>Penggunaan Bahan Baku</b>";
$anotrans=getString("select notrans from tbpbeli where kdproduksi='$kdproduksi' and jtrans='BB'","array");
foreach ($anotrans as $notrans) {
	echo showGL($notrans);
}
//mencari di bahan baku
//mencari di bahan baku
echo "<br><b>BDB Menjadi Bahan Jadi</b>";

$anotrans=getString("select notrans from tbpbeli where kdproduksi='$kdproduksi' and jtrans='BJ'","array");
foreach ($anotrans as $notrans) {
	echo showGL($notrans);
}
 
?>
</div>
</div></div>