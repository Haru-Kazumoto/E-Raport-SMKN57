<div class='' style=' 0 10px 0;text-align:right' >
	<button class='btn btn-success btn-sm' onclick="printDiv('tview_<?=$rnd?>')">Cetak</button>
</div>

<div class='tout tview' id='tview_<?=$rnd?>'>
<link rel='stylesheet' type='text/css' href='<?=$js_path?>style-cetak.css' >
<?php
$clspage="A5";
include $um_path."css-lx300.php";
?>
	<div class=page>
	<div id='tampilan_<?=$rnd?>'>

	<div class=jdlfaktur>KUITANSI PEMBAYARAN</div>
	<?php //echo tampilKop('Pembayaran Iuran Sekolah');
	
	echo $headPsh;
	
	$nokui="KU-".$r["kdbayar"];
	$wCap=100;
	if ($r['jtrans']=='PH') {
		$guna="Pembayaran Nota Pembelian/Pelunasan hutang";
		$dari="";
		$kepada=$r['namapb'];
	} else {
		$guna=$r["catatan"];
		$dari=$r['namapb'];;
		$kepada=$namaPsh;
		
	}
	echo "
	<br>
		<table border='0' class='tbkepada tbcetaktanpagaris' width=100% >"
//		.rowView('No. Kuitansi',''.$nokui.' </td><td align=right>Tanggal : '.tglindo($r['tgl'])."&nbsp;&nbsp;&nbsp;")
		.rowView('No. Kuitansi',$nokui)
		.rowView('Dibayar Kepada',$kepada)
		.rowView('Jumlah Uang',maskrp($r["jlhbayar"],1,0).' ')
		.rowView('Guna Membayar',$guna)
		.rowView('Rincian Pembayaran','&nbsp;')
		."</table>";
	//if ($r['catatan']!='') echo rowView('Catatan',$r['catatan']);
		
$arrColumn=array();

$arrColumn[]='$rd["notrans"]';
$arrColumn[]='tglindo($rd["tglnota"])';
$arrColumn[]='maskRp($rd["jlhbayar"],1,0)';
$arrColumn[]='$rd["catatan"]';
$aAlignFldD[0]="center";
$aAlignFldD[1]="center";
$aAlignFldD[2]="center";
$aAlignFldD[3]="center";
$aAlignFldD[4]="center";			
		
$sqTabelD="select d.*,b.tgl as tglnota, h.tgl as tgltrans 
from (tbpbayard d inner join tbpbayar h on d.kdbayar=h.kdbayar)
left join tbpbeli b on d.notrans=b.notrans
where h.id='$id' ";
		
$isiTbD="";
$brd=0;
$hd=mysql_query2($sqTabelD);
$jlhD=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
$arrTabel=array();
while ($rd=mysql_fetch_array($hd)) {
	$br=$brd+1;
	$isiTbD.="<tr>";
	$i=0;
	$jlhD[0]+=$rd['jlhbayar'];
	foreach ($arrColumn as $cl) {
		eval("$"."xx=".$cl.";");
		
		$isiTbD.="<td align='$aAlignFldD[$i]' style='text-align:$aAlignFldD[$i] '>$xx</td>"; 
		$i++;
	}
	$isiTbD.="</tr>";
	$brd++;
}


$terbilang=ucwords(terbilang($jlhD[0])." Rupiah");
$tdet="";
$tdet.="
	<div style='margin-top:5px'>
			<table style='width:100%' align=center border=1 class=' tbcetakbergaris '    >
				<tr>
					<td class='tdjudulx' align=center >Nomor Nota</td>
					<td class='tdjudulx' align=center >Tgl Nota</td>
					<td class='tdjudulx' align=center >Jumlah</td>
					<td class='tdjudulx' align=center >Keterangan</td>
				</tr>";
$tdet.=$isiTbD;
$tdet.="		<tr><td colspan='2' align=center >JUMLAH</td><td align=center style='text-align:center'>".maskRp($jlhD[0],1,0)."</td>
			</table>
	</div>";

echo $tdet;

?>

<div class=terbilang style='text-decoration:italic;margin-top:10px'>
<i>Terbilang : <?=$terbilang?></i>
<?php

echo "
<table border='0' class='tbform2xx tbcetaktanpagaris ' width=100% style='margin-top:12px' >
<tr>
	<td width='30%' align='center' valign=top>
	<br>Penerima
	<br><br><br><br>
	(_____________________)	
	</td>
	<td width='30%' align='center'>
	&nbsp;</td>
	<td width='30%' align='center' valign=top>
	 ".tglIndo2($r['tgl'],'w, d M Y')."<br>
	Admin
	<br><br><br><br>
	(_____________________)	
	</td>


</tr>
</table>
";
?>
</div>
</div>