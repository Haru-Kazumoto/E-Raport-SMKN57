<?php

echo showGL($r['kdbayar'],1);
