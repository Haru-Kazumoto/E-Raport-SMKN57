<?php
//digunakan untuk update hpp seluruh transaksi penjualan (sl,je)
$useJS=2;
include_once "conf.php";
$isTest=true;
$ssq="";
$lim="limit 0,3000000";
querysql("delete from tbpbelid_terpakai;");
$dt2=$db->query("select notrans,kdlokasi,jtrans from tbpbeli where 
(jtrans='JE' or jtrans='SL' or jtrans='DS' ) 
order by id asc $lim")->fetch();
foreach($dt2 as $r2) {
	$kdlokasi=$r2['kdlokasi'];
	$notrans=$r2['notrans'];
	$jtrans=$r2['jtrans'];
	$sq="select kdbrg,0 as jlhlama,0 as hpplama,(jlh_terima-jlh_retur) as jlhbaru,id as idbj from tbpbelid where notrans='$r2[notrans]' ";
	$arrdd=$db->query($sq)->fetch();
	$i=0;
	foreach($arrdd as $r) {
		$idbj=$r['idbj'];
		$kdbrg=$r['kdbrg'];
		$hpplama=$r['hpplama'];
		$jlhlama=$r['jlhlama'];
		$jlhdibutuhkan=$r['jlhbaru'];		
		$hpp=cekHrgPokok($kdbrg, $kdlokasi, $jlhdibutuhkan, $notrans, $jtrans,$idbj, $hpplama, $jlhlama,1 );
		$ssq.="update tbpbelid set hpp='$hpp' where id='$idbj';";
		$i++;
	}
	//update gltrans
}
echo $ssq;
querysql($ssq);
foreach($dt2 as $r2) {
	$notrans=$r2['notrans'];
	$jtrans=$r2['jtrans'];
	//updateStockTrans($skdbrg,$kdlokasi,$jtrans);	
    updateGLTransBeli($notrans,$jtrans);
}
$ssq.="\n\n\n\n\n";
echo $loghpp;
