<?php

include "conf.php";
// konveris distribusi ke tbpbeli dari program lama/desktop
// digunakan di ganesha

$sflddist1="notrans,tgl,kdlokasi,kdlokasi2,kdpj,catatan,opr,jtrans,tglentri,modified_date,kdbranch";
$sflddist2="notrans,tgl,kdlokasi1,kdlokasi2,kdpj,catatan,opr,jtrans,tglentri,modified_date,kdbranch";

$sflddistd1="notrans,kdbrg,jlh_terima,cek,hrg,subtot,modified_date";
$sflddistd2="notrans,kdbrg,jlh,cek,hrg,subtot,modified_date";
	/*
	drop table if exists tbpbeli_tmp1;
	drop table if exists tbpbelid_tmp1;
	CREATE TABLE tbpbeli_tmp1 LIKE tbpbeli;
	CREATE TABLE tbpbelid_tmp1 LIKE tbpbelid;
	
	*/
	$ssq="
	update tbpdistribusid set cek=1 where cek=0;
	
	insert into tbpbeli  ($sflddist1)
	select $sflddist2 from tbpdistribusi where jtrans='DS';
	insert into tbpbelid ($sflddistd1)
	select $sflddistd2 from tbpdistribusid where cek=1;
	
	update tbpdistribusi set jtrans='xDS';
	update tbpdistribusid set cek='3';
	

";

querysql($ssq);
?>
