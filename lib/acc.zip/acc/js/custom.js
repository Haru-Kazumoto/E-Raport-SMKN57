
//ready function
prevSelectValue="";
$(document).ready(function(){
	$("select").on('focus', function () {
        // Store the current value on focus and on change
        prevSelectValue = this.value;
    })

}); 

//penggunaan api
var intervalNotif=3*1000;//
var pauseNotif=false;
function cekNotif(){
	if (pauseNotif) return "";
	//console.log('ceknotif-'+curDet);
	myurl="api.php?op=ceknotif";
	
	$.ajax({
		url: myurl,
		method:"post",
		data:{'curdet':curDet},
	}).done(function(response) {
		//console.log(response);
		data=JSON.parse(response);
		//console.log(data);
		//alert(data.jlhnotif);
		if (data.jlhNotif>0) {
			$('#ballon1').html(data.jlhNotif);
			$('#ballon1').show();
			$('#tballon1').hide();
			
		} else {
			$('#ballon1').hide();
			$('#tballon1').show();
			//alert(data);
		}
		//cekrefresh
		if (curDet!='') {
			if (rndDet<data.rndDet) {
				pauseNotif=true;
				alert('silahkan Refresh');
				rndDet=data.rndDet;
				pauseNotif=false;
			}
		}
		
	
	});
}

if (isL!='') {
	var inotif = setInterval('cekNotif()',intervalNotif); // 0.3 minute
}


function bukaLap(tkd,rnd){
	//$("#tprov_"+rnd).html();
	$("#tview_"+rnd).html('');
	url="content1.php?det=pendonor&op=view&custom=perwilayah&newrnd="+rnd
	if (tkd=="prov"){
		kdprov=$("#kdprov_"+rnd).val();
		$("#tkab_"+rnd).html('-');
		$("#tkec_"+rnd).html('-');
		$("#tkel_"+rnd).html('-');
		bukaAjax("tkab_"+rnd,url+"&op2="+tkd+"&kdprov="+kdprov); 
	}
	else if (tkd=="kab"){
		kdkab=$("#kdkab_"+rnd).val();
		$("#tkec_"+rnd).html('');
		$("#tkel_"+rnd).html('');
		bukaAjax("tkec_"+rnd,url+"&op2="+tkd+"&kdkab="+kdkab); 
	}
	else if (tkd=="kec"){
		kdkec=$("#kdkec_"+rnd).val();
		//$("#tkec_"+rnd).html('');
		$("#tkel_"+rnd).html('-');
		bukaAjax("tkel_"+rnd,url+"&op2="+tkd+"&kdkec="+kdkec); 
	}
	else {
		kdkec=$("#kdkec_"+rnd).val();
		kdkel=$("#kdkel_"+rnd).val();	
		bukaAjax("tview_"+rnd,url+"&kdkel="+kdkel+"&kdkec="+kdkec); 
	}
}



$(document).ready(function() {

});

//khusus penjualan
function evalTransPelunasan(rnd){
	//alert(rnd);
	
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	jlh=0;
	for (i=0;i<	jlhno;i++) {
		ident=rnd+"_"+i;
		jlhby=unmaskRp($("#d_jlhbayar_"+ident).val());
		jlh+=jlhby;
	}
	
	$('#jlhbayar_'+rnd).val(maskRp(jlh));  
	$('#xjlhbayar_'+rnd).html(maskRp(jlh));  
	
}

function awalTrans(awal,rnd) {
	if (awal==1) {
		try{ kdp=$('#kdpembantu_'+rnd).val(); 
		getSaldoHP(kdp); } catch(e){}
		console.log("mulai.... ");
		resizeInputTb();

	}
}
function evalJlhTransRJual (rnd){
	evalTransRJual(rnd);
}
function evalTransRJual(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}

	byangkut=	unmaskRp($('#byangkut_'+rnd).val());
	//try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
	netto=brutto*1+byangkut*1;
	
	$('#brutto_'+rnd).val(maskRp(brutto));
	$('#xbrutto_'+rnd).html(maskRp(brutto));
	
	$('#tbrutto_'+rnd).html(maskRp(brutto));
	
	$('#jlhitemfix_'+rnd).html(jlhitemfix);
	
	$('#tjlhnetto_'+rnd).html(maskRp(tjlhterima,0,9));
	
	$('#netto_'+rnd).val(maskRp(netto));
	$('#xnetto_'+rnd).html(maskRp(netto));
	terhutang=netto-paidtoday*1;
	try { 
		$('#kurangbayar_'+rnd).val(maskRp(terhutang,0,0));
		$('#xkurangbayar_'+rnd).html(maskRp(terhutang,0,0));
	
	} catch(e) { }
	
	//alert(brutto);
	
	
}

counterEv=1
function xevalTransJual(rnd,awal){
	awalTrans(awal,rnd);
	
}
 
function evalJlhTransJual (rnd){
	evalTransJual(rnd);
}

 
function evalTransJual(rnd,awal){
	//awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;
	console.log(jlhno);	
	brutto=jlhitemfix=tjlhterima=tbrutto=0;
	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=0;//unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}
	
	byangkut=	unmaskRp($('#byangkut_'+rnd).val());
	//try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
	netto=brutto*1+byangkut*1;
	
	$('#brutto_'+rnd).val(maskRp(brutto));
	$('#xbrutto_'+rnd).html(maskRp(brutto));
	$('#tbrutto_'+rnd).html(maskRp(brutto));
	$('#jlhitemfix_'+rnd).html(jlhitemfix);
	$('#tjlhnetto_'+rnd).html(maskRp(tjlhterima,0,9));
	$('#netto_'+rnd).val(maskRp(netto));
	$('#xnetto_'+rnd).html(maskRp(netto));
	terhutang=netto-paidtoday*1;
	try { 
		$('#kurangbayar_'+rnd).val(maskRp(terhutang,0,0));
		$('#xkurangbayar_'+rnd).html(maskRp(terhutang,0,0));
	
	} catch(e) { }
	
	//alert(brutto);
	
	
}

function cekKdBrgTrBJ(rnd,no){
	//alert(rnd);
		evalTrBJ(rnd);
}

function evalJlhTrBJ (rnd){
	evalTrBJ(rnd);
}
function evalTrBJ(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=0;//unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	//try { byangkut=	unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	//try { bytimbang=	unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	//try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	
	//$('#tjlhbrutto_'+rnd).html(maskRp(vj_jlh0,0,1));
	//$('#tjlhtarra_'+rnd).html(maskRp(vj_jlh1,0,1));
	$('#tjlhnetto_'+rnd).html(maskRp(vj_jlh2,0,9));
	
	
	netto=brutto;//*1+byangkut*1;
	//byangkut*1+bykuli*1;
	 
	$('#brutto_'+rnd).val(brutto);
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#netto_'+rnd).val(maskRp(netto,0,0));
	$('#xnetto_'+rnd).html(maskRp(netto,0,0));
	
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

	
}




function cekKdBrgTransJual(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgjual&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
 
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		$("#d_jlhppkg_"+rnd+"_"+no).val(maskRp(ad[1]*1));
		evalTransJualE(rnd);

	});
	
}

function cekKdBrgTransRJual(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgjual&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
 
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		$("#d_jlhppkg_"+rnd+"_"+no).val(maskRp(ad[1]*1));
		evalTransRJual(rnd);

	});
	
}

function evalFldTrans(jtrans,fld,rnd,fldhasil) {
	fld="carabayar";
	cb=$('#carabayar_'+rnd).val();
	
	if (cb=='K') {
		//kredit
		if (jtrans=='JE'){
			$('#bayar_'+rnd).val(0);
			evalJlhTransJualE(rnd);
		}
		$('#tr'+fldhasil+'_'+rnd).hide();
	} else {
		$('#tr'+fldhasil+'_'+rnd).show();
	}
	
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=defkas&jtrans="+jtrans+"&cb="+cb;
	$.ajax({
		url:myurl
	}).done(function(data) {
		 if (data*1>0) $('#'+fldhasil+'_'+rnd).val(data);
	});
	
}


function evalJlhTransJualE(rnd){
	evalTransJualE(rnd);
}
function evalTransJualE(rnd,awal){
	awalTrans(awal,rnd);
	clstb="cpenjualane";
	idtb=clstb+"-"+rnd;
	//	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	console.log("jlhbr "+jlhno);
	tjlhterima=brutto=netto=0;
	
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		
		tjlhterima+=jlh;
		subtot=Math.round(jlh*hrg);
		xsubtot=maskRp(subtot,0,0);
		console.log("cls : #"+clstb+"-hrg-"+pg+" > jlh "+jlh+",hrg "+hrg+", subtot "+subtot);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;
	}
	//alert(brutto);
	$('#tjlhnetto_'+rnd).html(maskRp(tjlhterima,0,9));
	/*
		
	for (i=0;i<	jlhno;i++) {
		ident=+rnd+"_"+i+"";//pengenal
		/*
		jlhpkg=unmaskRp($("#d_jlhpkg_"+ident).val());
		jlhppkg=unmaskRp($("#d_jlhppkg_"+ident).val());
		jlh=jlhpkg*jlhppkg;
		$("#d_jlh_terima_"+ident).val(maskRp(jlh));
		* /
		jlh=unmaskRp($("#d_jlh_terima_"+ident).val());
		hrg=unmaskRp($("#d_hrg_"+ident).val());
		disc=0;//unmaskRp($("#d_disc_"+ident).val());
		subtot=jlh*(hrg-disc);
		xsubtot=maskRp(subtot);
		tjlhterima+=jlh;
		tbrutto+=subtot;
		
		$("#d_subtot_"+ident).val(xsubtot);
		brutto+=subtot*1;	
		if (jlh>0) jlhitemfix++;
		
	}
	*/
	byangkut=0;//	unmaskRp($('#byangkut_'+rnd).val());
	//try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	try { bayar=	unmaskRp($('#bayar_'+rnd).val());} catch(e) {bayar=0;}
	kembali=bayar-brutto*1;
	//ddbrutto_2950
	$('#brutto_'+rnd).val(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	
	//$('#jlhitemfix_'+rnd).html(jlhitemfix);
	//$('#tjlhnetto_'+rnd).html(maskRp(tjlhterima,0,9));
	
	$('#kembalian_'+rnd).val(maskRp(kembali,0,0));
	$('#xkembalian_'+rnd).html(maskRp(kembali,0,0));
	
}


function cekKdBrgTransJualE(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgjual&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1,0,0));
		$("#d_jlhppkg_"+rnd+"_"+no).val(maskRp(ad[1]*1));
		evalTransJualE(rnd);

	});
	
}

function hitungGaji(rnd){
	masuk=$("#jmasuk_"+rnd).val()*1;
	absen1=$("#jabsen1_"+rnd).val()*1;
	absen2=$("#jabsen2_"+rnd).val()*1;
	
	gapok=$("#g_pokok_"+rnd).val()*1;
	
	tmakan=$("#t_makan_"+rnd).val()*(masuk);
	ttransport=$("#t_transport_"+rnd).val()*(masuk+absen2);
	bonus=$("#bonus_"+rnd).val()*1;
	insentif=$("#g_insentif_"+rnd).val()*1;
	lembur=$("#g_lembur_"+rnd).val()*1;
	//lembur=$("#lembur_"+rnd).val()*1;
	
	cicilan=$("#cicilan_"+rnd).val()*1;
	potlain=$("#editgaji_"+rnd).val()*1;
	
	netto=gapok+tmakan+ttransport+bonus+insentif-cicilan-potlain;
	$("#netto_"+rnd).val(netto)*1;
	t="";
	t+="Peritungan Total Gaji Dibayarkan : <br`>";
	t+="total tunjuangan transport=(jumlah hari masuk + absen 1/2hari) * tunjangan transport perhari<br>";
	t+="total tunjuangan makan=(jumlah hari masuk ) * tunjangan makan perhari<br>";
	t+="netto=gapok+total tunjangan makan+total tunjangan transport+bonus+insentif-cicilan-potlain<br>";
	$("#thitung_"+rnd).html(t);
}

function evalTransBeli_old(rnd){
	//alert(rnd);
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	brutto=0;
	for (i=0;i<	jlhno;i++) {
		ident=+rnd+"_"+i+"";//pengenal
		jlh=unmaskRp($("#d_jlh_terima_"+ident).val());
		//jlhppkg=unmaskRp($("#d_jlhppkg_"+ident).val());
		//jlh=jlhpkg*jlhppkg;
		//$("#d_jlh_terima_"+ident).val(maskRp(jlh));
		hrg=unmaskRp($("#d_hrg_"+ident).val());
		disc=unmaskRp($("#d_disc_"+ident).val());
		subtot=Math.round(jlh*hrg);
		xsubtot=maskRp(subtot);
		$("#d_subtot_"+ident).val(xsubtot);
		brutto+=subtot*1;	
	}
	
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	try { bytimbang=		unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	netto=brutto*1+bytimbang*1;
	//byangkut*1+bykuli*1;
	terhutang=netto-paidtoday*1;
	$('#brutto_'+rnd).val(maskRp(brutto));
	$('#netto_'+rnd).val(maskRp(netto));
	try { $('#kurangbayar_'+rnd).val(maskRp(hutang));} catch(e) { }
	
	//alert(brutto);
	
	
}

function cekKdBrgTransBeli(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	//jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgbeli&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
 
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		//$("#d_jlhppkg_"+rnd+"_"+no).val(maskRp(ad[1]*1));
		evalTransBeli(rnd);

	});
	
}
//khusus retur pembelian
function evalTransRBeli_old(rnd){
	//alert(rnd);
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	brutto=0;
	for (i=0;i<	jlhno;i++) {
		ident=+rnd+"_"+i+"";//pengenal
		jlh=unmaskRp($("#d_jlh_terima_"+ident).val());
		//jlhppkg=unmaskRp($("#d_jlhppkg_"+ident).val());
		//jlh=jlhpkg*jlhppkg;
		//$("#d_jlh_terima_"+ident).val(maskRp(jlh));
		hrg=unmaskRp($("#d_hrg_"+ident).val());
		disc=unmaskRp($("#d_disc_"+ident).val());
		subtot=Math.round(jlh*(hrg-disc));
		xsubtot=maskRp(subtot);
		$("#d_subtot_"+ident).val(xsubtot);
		brutto+=subtot*1;	
	}
	
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	try { bytimbang=		unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	netto=brutto*1+bytimbang*1;
	//byangkut*1+bykuli*1;
	terhutang=netto-paidtoday*1;
	$('#brutto_'+rnd).val(maskRp(brutto));
	$('#netto_'+rnd).val(maskRp(netto));
	try { $('#kurangbayar_'+rnd).val(maskRp(hutang));} catch(e) { }
	
	//alert(brutto);
	
	
}


function cekKdBrgTransRBeli(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	nopo=$("#nopo_"+rnd).val();
	
	//jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgrbeli&kdbrg="+kdbrg+"&nopo="+nopo;
	$.ajax({
		url:myurl
	}).done(function(data) {
 
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		//$("#d_jlhppkg_"+rnd+"_"+no).val(maskRp(ad[1]*1));
		evalTransRBeli(rnd);

	});
	
}

function cekKdBrgTransPacking(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	//jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgbeli&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		evalTransPacking(rnd);
	});
}

//packing
function evalTransPacking(rnd){
	//alert(rnd);
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	brutto=0;
	jlhitemfix=0;
	jlhin=jlhout=0;
	for (i=0;i<	jlhno;i++) {
		ident=+rnd+"_"+i+"";//pengenal
		io=$("#d_io_"+ident).val();
		jlhterima=unmaskRp($("#d_jlh_terima_"+ident).val());
		//jika io kosong, diset ke in atau outerHTML
		if (io=="") {
			io=(jlhterima>=0?"In":"Out");
			$("#d_io_"+ident).val(io);		
		}
		
		jlh=unmaskRp($("#d_jlhpkg_"+ident).val());
		jlhppkg=1;//unmaskRp($("#d_jlhppkg_"+ident).val());
		if (io=="Out")
			jlh=Math.abs(jlh)*-1;
		else
			jlh=Math.abs(jlh);
		 
		$("#d_jlh_terima_"+ident).val(maskRp(jlh,0,1));
		
		if (jlh!=0) {
			jlhitemfix++;
		
			hrg=unmaskRp($("#d_hrg_"+ident).val());		
			subtot=Math.round(jlh*hrg*jlhppkg);
			xsubtot=maskRp(Math.abs(subtot),0,0);
			if (io=="Out")
				jlhout+=Math.abs(subtot);
			else
				jlhin+=Math.abs(subtot);		
		} else {
			harga=subtot=xsubtot=0;
		} 
		
		$("#d_subtot_"+ident).val(xsubtot);
		brutto+=subtot*1;	
	}
	bal=brutto;
	
	
	$('#xballance_'+rnd).val(maskRp(bal),0,0);
	$('#ballance_'+rnd).val(bal);
	//$('#jlhitemfix_'+rnd).html(jlhitemfix);
	
}

//khusus penjualan
function evalTransProd(rnd){
	//alert(rnd);
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	brutto=0;
	for (i=0;i<	jlhno;i++) {
		ident=+rnd+"_"+i+"";//pengenal
		jlh=unmaskRp($("#d_jlh_terima_"+ident).val());
		hrg=unmaskRp($("#d_hrg_"+ident).val());
		disc=unmaskRp($("#d_disc_"+ident).val());
		subtot=Math.round(jlh*(hrg-disc));		
		xsubtot=maskRp(subtot);
		$("#d_subtot_"+ident).val(xsubtot);
		brutto+=subtot*1;	
	}
	
	$('#penyeimbang_'+rnd).val(brutto);
	$('#tpenyeimbang_'+rnd).html(maskRp(brutto));
	//alert(brutto);
}

function cekKdBrgTransProd(rnd,no){
	//alert(rnd);
	ident=rnd+"_"+no;
	kdbrg=$("#d_kdbrg_"+ident).val();
	//jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=hrgbeli&kdbrg="+kdbrg;
	$.ajax({
		url:myurl
	}).done(function(data) {
 
		ad=data.split(",");
		$("#d_hrg_"+rnd+"_"+no).val(maskRp(ad[0]*1));
		evalTransBeli(rnd);
	});
}
//ganti tampilan input
function GTInputJTrans(rnd) {
	jenis=$("#defdk_"+rnd).val();
	/*
	if (jenis=='L') {
		$("#trkdprk2_"+rnd).show();
		$("#trkdprk3_"+rnd).show();
		
	} else {
		$("#trkdprk2_"+rnd).hide();
		$("#kdprk2_"+rnd).val(0);
		$("#trkdprk3_"+rnd).hide();
		$("#kdprk3_"+rnd).val(0);
		
	}
	*/
}

//ganti tampilan input Jurnal Umum
function GTInputJU(rnd) {
	jtrans=$("#jenisju_"+rnd).val();
	myurl= "index.php?contentOnly=1&useJS=2&det=gv&op=prkjtrans&jtrans="+jtrans;
	$.ajax({
		url:myurl
	}).done(function(data) {
		//alert(data);
		prk=data.split(",");
		$("#d_kdprk_"+rnd+"_0").val(prk[0]);
		$("#d_kdprk_"+rnd+"_1").val(prk[1]);
	
	});
}

//ganti tampilan input
function GTInputPrk(rnd) {
	ish=$("#ish_"+rnd).val();
	kdprk=$("#account_code_"+rnd).val()*1;
	$("#tridgrpneraca_"+rnd).hide();
	 
	if (ish=='1') {
		$("#trsawal_"+rnd).hide();
		$("#tridgrpneraca_"+rnd).hide();
		$("#sawal_"+rnd).val(0);
		try { 
			$("#idgrpneraca_"+rnd).val("0");
		} catch(e) {}
		
	} else {
		$("#trsawal_"+rnd).show();
		try {
			if (kdprk<40000) $("#tridgrpneraca_"+rnd).show();
		} catch(e) {}
	}
	
}

function evalTransJU_old(rnd){
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	jlhd=jlhk=brutto=0;
	for (i=0;i<	jlhno;i++) {
		pg=+rnd+"_"+i+"";//pengenal	
		d=unmaskRp($('#d_xxjlhd_'+pg).val())*1;
		k=unmaskRp($('#d_xxjlhk_'+pg).val())*1;
		jlhu=d-k;
		 
		//console.log("$('#d_jlhuang_"+pg+"').val("+jlhu+");");
		$("#d_jlhuang_"+pg).val(jlhu);
		jlhd+=d;
		jlhk+=k;
		//brutto+=jlhu; 
	}
	saldo=jlhd-jlhk;
	$disa="";
	if (saldo!=0) {
		//jika belum seimbang, tombol save mati.
		$disa="disable";
	}
	
	$("#tbsimpan_"+rnd).prop("disabled",$disa);
	$("#tbsimpantambah_"+rnd).prop("disabled",$disa);
	brutto=maskRp(Math.abs(jlhd));
	
	
	$("#jlhuang_"+rnd).val(maskRp(brutto));
	
}

function evalTransJU(rnd){
	try { jtrans=$('#jtrans_'+rnd).val(); } catch(e){ jtrans="JU"};
	$nmtb="tbdet_"+rnd;
	jlhno=$('#jlhrowdet_'+rnd).val()*1;
	jlhd=jlhk=brutto=0;
	$awali=0;
	if ((jtrans=="KM")||(jtrans=="KK")) {
		$awali=1;
	}
	for (i=$awali;i<jlhno;i++) {
		pg=+rnd+"_"+i+"";//pengenal	
		d=unmaskRp($('#d_xxjlhd_'+pg).val())*1;
		k=unmaskRp($('#d_xxjlhk_'+pg).val())*1;
		jlhu=d-k;
		 
		//console.log("$('#d_jlhuang_"+pg+"').val("+jlhu+");");
		$("#d_jlhuang_"+pg).val(jlhu);
		jlhd+=d;
		jlhk+=k;
		//brutto+=jlhu; 
	}
	saldo=jlhd-jlhk;
	disa="";
	if ((jtrans=="KM")||(jtrans=="KK")) {
		
		//baris detail pertama disembunyikan
		pg=+rnd+"_0";//pengenal	
		$("#trdet_"+pg).hide();
		
		ma=Math.abs(saldo);
		kdprkkas=$('#kdprkkas_'+rnd).val();
		kdprk0=$('#d_kdprk_'+pg).val();
		if (kdprkkas!=kdprk0) {
			$('#d_kdprk_'+pg).val(kdprkkas).change();
			try {
				nmprk=$('#d_kdprk_'+pg+' option:selected').text();
				$("#d_kdprk_"+pg).next("span").find("input").val(nmprk);

				//$('#d_kdprk_'+pg).combobox('destroy');
				//$('#d_kdprk_'+pg).combobox();
			} catch(e) {}
		}
		if (jtrans=="KM") {
			$('#d_xxjlhd_'+pg).val(ma);
			$('#d_xxjlhk_'+pg).val(0);
		} else if (jtrans=="KK") {
			$('#d_xxjlhk_'+pg).val(ma);
			$('#d_xxjlhd_'+pg).val(0);
		}	
		
		$("#d_jlhuang_"+pg).val(saldo*-1);
		$("#jlhuang_"+rnd).val(ma);	
		$("#xjlhuang_"+rnd).html(maskRp(ma,0,0));	
		
		
		if (saldo==0) disa="disabled";
	} else {
		brutto=maskRp(Math.abs(jlhd));
		$("#jlhuang_"+rnd).val(brutto);
		if (saldo!=0) {
			//jika belum seimbang, tombol save mati.
			disa="disabled";
		}
	}
	
	$("#tbsimpan_"+rnd).prop("disabled",disa);
	try { $("#tbsimpantambah_"+rnd).prop("disabled",disa); } catch(e) {}

}

//barang
function tampilFrmcariBrg(rnd,no,jenis='beli'){
	func='';	
//	url='index.php?det=gv&op=caribrgpaket&contentOnly=1&useJS=2&showMenu=0&newrnd='+rnd+'&no='+no;
	url='index.php?det=gv&op=caribrg&contentOnly=1&useJS=2&showMenu=0&newrnd='+rnd+'&no='+no;
	url+='&thasil=d_kdbrg_'+rnd+'_'+no;
	bukaAjaxD('tcari3_'+rnd,url,'width:700,height:400',func);
}

/*pembayaran hutang*/
function cariTransTerhutang(rnd,no,jtrans) {
	ident=rnd+"_"+no;
	tempat="thitung_"+rnd;
	thasil="d_notrans_"+ident;
	notrans=$("#d_notrans_"+ident).val();
	kdpembantu=$("#kdpembantu_"+rnd).val()*1;
	if (kdpembantu==0) {
		alert("Pilih Pemasok/Pelanggan terlebih dahulu");
		return false;
	}
	
	
	jlhuang=unmaskRp($("#d_jlhbayar_"+ident).val());
	if (jlhuang>0) {
		if (!confirm('Jumlah bayar sudah terisi, yakin akan melanjutkan?')) return false;
	}
	//jtrans=$("#jenisju_"+rnd).val();
	url= "index.php?det=gv&op=caritransterhutang&kdpembantu="+kdpembantu+"&jtrans="+jtrans+"&thasil="+thasil+"&contentOnly=1&no="+no+"&tdialog="+tempat+"&rndh="+rnd;
	bukaAjaxD(tempat,url,'width:wMax');
}
 
function cekNotransTerhutang(rnd,no,isi) {
	ai=isi.split("|");	
	ident=rnd+"_"+no;
	$("#d_notrans_"+ident).val(ai[0]);
	$("#d_jlhbayar_"+ident).val(maskRp(ai[1],0,0));
	evalTransPelunasan(rnd);
}

function cbBrgByKdJBrg(rnd){
	kdjbarang=$("#kdjbarang_"+rnd).val();
	if (kdjbarang=='')
		$("#tnb_"+rnd).show();
	else
		$("#tnb_"+rnd).hide();

}

function cbNopoByPB(rnd,jtrans) {
	kdpb=$("#kdpembantu_"+rnd).val();
	//$("#tnopo_"+ident).val(maskRp(ai[1],0,0));
	$url="index.php?det=pembelian&op=listnopo&kdpembantu="+kdpb+"&jt="+jtrans;
	//+"&kdlokasi="+kdlokasi
	myurl=coUrl($url,rnd);
	func="$('#nopo_"+rnd+"').combobox();";
	func="";
	bukaAjax("ddnopo_"+rnd,myurl,func);
}

function getSaldoHP(rnd) {
	kdpb=$("#kdpembantu_"+rnd).val()*1;
	if (kdpb==0) {
		$("#tsaldohp_"+rnd).html(" Saldo Hutang/Piutang : Rp. 0 ");
		return false;
	}
	myurl=coUrl("index.php?det=pembelian&op=getsaldohp&kdpembantu="+kdpb,rnd);
	axios.post(myurl, {
		"test":0
	})
	.then(function (response) {
		$("#tsaldohp_"+rnd).html(" Saldo Hutang/Piutang : "+ response.data);
	});
}

function cbBrgByLokasi(rnd){
	$kdlokasi=$('#kdlokasi_'+rnd).val();
	myurl=coUrl('index.php?det=barang&op=cbbrgstock&kdlokasi='+kdlokasi,rnd);
	bukaAjax('tkdbrg_'+rnd,myurl);	
}

function cbProdByBranch(rnd) {
	kdbranch=$("#kdbranch_"+rnd).val();
	myurl=coUrl("index.php?det=produksi2&op=listproduksi&kdbranch="+kdbranch,rnd);
	bukaAjax("ddkdproduksi_"+rnd,myurl);
	cbLokasiByBranch(rnd);
}
function cbLokasiByBranch(rnd) {
	kdbranch=$("#kdbranch_"+rnd).val();
	myurl=coUrl("index.php?det=lokasi&op=listlokasi&kdbranch="+kdbranch,rnd);
	bukaAjax("ddkdlokasi_"+rnd,myurl);
}
function cbLokasiByProduksi(rnd) {
}


function copyPOItem(rnd,jtrans) {
	
	kdpb=$("#kdpembantu_"+rnd).val();
	notrans=$("#nopo_"+rnd).val();
	myurl=coUrl("index.php?det=pembelian&op=listitem&notrans="+notrans+"&jtrans="+jtrans,rnd);
	axios.post(myurl, {
		"test":0
	})
	.then(function (response) {
		//console.log(response);
		var json = response.data;
		var jsonPretty = JSON.stringify(json, null, '\t');
		//console.log(jsonPretty);
		//console.log(myurl);
		//hapus data yang ada
		$('.tbhpdet').attr('confirm','0');
		$('.tbhpdet').click();
		
		clstb=(jtrans=='SR'?'cretur-penjualan':'cretur-pembelian');
		idtb=clstb+"-"+rnd;
		jlhno=0;//$('#jlhrowdet-'+idtb).val()*1;
		kdlokasi=json.kdlokasi;
		$('#kdlokasi_'+rnd).val(kdlokasi);
		dataku=json.data;
		console.log(json.data);
		$(dataku).each(function(dt){
			jlhno++;
			pg=rnd+"-"+jlhno;
			//cretur-penjualan-jlh_terima-3889-1
			kdbrg=this[0];
			nmbarang=this[1];
			hrg=this[2]*1;
			jlh=this[3]*1;
			disc=0;
			subtot=Math.round(hrg*jlh);
			
			v=kdbrg+'|'+nmbarang+'|'+jlh+'|'+hrg+'|'+disc+'|'+subtot;
			//v=kdbrg+'|'+nmbarang+'|'+maskRp(jlh)+'|'+maskRp(hrg)+'|'+maskRp(disc)+'|'+maskRp(subtot);
			$("#thasil-"+idtb).val(v);
			$("#thasil-"+idtb).click();
			
			kdbrg=this[0];
			nmbarang=this[1];
			hrg=this[2]*1;
			jlh=this[3]*1;
			disc=0;
			
			//$("#"+clstb+"-kdbrg-"+pg).val(kdbrg);
			//$("#"+clstb+"-nmbarang-"+pg).val(nmbarang);
			/*
			$("#"+clstb+"-hrg-"+pg).val(hrg);
			$("#"+clstb+"-jlh_terima-"+pg).val(jlh);
			$("#"+clstb+"-subtot_"+pg).val(subtot);
			*/
		});
		$('#jlhrowdet-'+idtb).val(jlhno);
	});
}

function autoAllocatedPayment(rnd,jtrans) {
	
	kdpb=$("#kdpembantu_"+rnd).val()*1;
	kdbayar=$("#kdbayar_"+rnd).val();
	jbb=unmaskRp($("#jlhbayar_"+rnd).val());
	if (kdpb==0) {
		alert("Pilih Supplier/Customer terlebih dahulu");
		return false;
	}
	else if (jbb==0) {
		alert("Isi jumlah pelunasan terlebih dahulu");
		return false;
	}
	myurl=coUrl("index.php?det=gv&op=aap&kdbayar="+kdbayar+"&kdpembantu="+kdpb+"&jtrans="+jtrans,rnd);
 
	axios.post(myurl, {
		"test":0
	})
	.then(function (response) {
		var json = response.data;
		var jsonPretty = JSON.stringify(json, null, '\t');
		//console.log(jsonPretty);
		
		jlhno=0;//$('#jlhrowdet-'+rnd).val()*1;
		jb=0;
		dataku=json.data;
		$(dataku).each(function(dt){
			console.log(this);
			$("#btaddrow_"+rnd).click();
			pg=rnd+"_"+jlhno;
			notrans=this[0];
			hutang=this[1]*1;
			
			sisa=jbb-jb;
			if (sisa<=0) return false;
			if (sisa>=hutang) {
				xh=hutang;
			} else {
				xh=sisa;
			}
			jb+=xh;
			
			$("#d_notrans_"+pg).val(notrans);
			$("#d_jlhbayar_"+pg).val(maskRp(xh,0,0));
			if (sisa<=0) return false;
			jlhno++;
			
		});
		$('#jlhrowdet-'+rnd).val(jlhno);
	});
	return false;	
}

function cetakGrafikPj(tgrafik,tdata,jdl,tipe){
	/*
	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="Chart.min.js"></script>

    <div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>
	

	*/
	if (tgrafik==undefined) tgrafik="tgrafik";
	//if (tdata==undefined) tgrafik="tgrafik";
	if (jdl==undefined) jdl="Grafik Penjualan";
	if (tipe==undefined) tipe="line";
	//kolom: bulan,jumlah
	
	//$.post("data.php",
	//function (data){
		
		/*
			//isi data.php
			$data=[
			['kdbrg'=>1, "bulan"=>'Jan','jumlah'=> 39],
			['kdbrg'=>2, "bulan"=>'Feb','jumlah'=> 89],
				];
			echo json_encode($data);
				
		*/
	xdata=$("#"+tdata).html();
	eval("data="+xdata+";");	
		console.log(data);
		var bulan = [];
		var jumlah = [];

		for (var i in data) {
			bulan.push(data[i][0]);
			jumlah.push(data[i][1]);
		}

		var chartdata = {
			labels: bulan,
			datasets: [
				{
					label: jdl,
					backgroundColor: '#49e2ff',
					borderColor: '#46d5f1',
					hoverBackgroundColor: '#CCCCCC',
					hoverBorderColor: '#666666',
					data: jumlah
				}
			]
		};

		var graphTarget = $("#"+tgrafik);

		var barGraph = new Chart(graphTarget, {
			type: 'line',
			data: chartdata,
			 
		});
	//});
}

function cetakGrafikPj2(tgrafik,tdata,jdl,tipe){
	//perbandingan tahun ini dan tahun sebelumnya
	/*
	<script type="text/javascript" src="../jquery/jquery.min.js"></script>
	<script type="text/javascript" src="Chart.min.js"></script>

    <div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>
	

	*/
	if (tgrafik==undefined) tgrafik="tgrafik";
	//if (tdata==undefined) tgrafik="tgrafik";
	if (jdl==undefined) jdl="Grafik Penjualan";
	if (tipe==undefined) tipe="line";
	//kolom: bulan,jumlah
	
	//$.post("data.php",
	//function (data){
		
		/*
			//isi data.php
			$data=[
			['kdbrg'=>1, "bulan"=>'Jan','jumlah'=> 39],
			['kdbrg'=>2, "bulan"=>'Feb','jumlah'=> 89],
				];
			echo json_encode($data);
				
		*/
	xdata=$("#"+tdata).html();
	eval("data="+xdata+";");	
		console.log(data);
		var bulan = [];
		var jumlah = [];
		var jumlah2 = [];

		for (var i in data) {
			bulan.push(data[i][0]);
			jumlah.push(data[i][1]);
			jumlah2.push(data[i][2]);
		}

		var chartdata = {
			labels: bulan,
			datasets: [
				{
					label: 'Tahun Sebelumnya',
					/*backgroundColor: '#49e2ff',*/
					borderColor: '#46d5f1',
					hoverBackgroundColor: '#CCCCCC',
					hoverBorderColor: '#666666',
					data: jumlah
				},
				{
					label: 'Tahun Ini',
					/*backgroundColor: '#35435',*/
					borderColor: '#453548',
					hoverBackgroundColor: '#CCCCCC',
					hoverBorderColor: '#666666',
					data: jumlah2
				}
			]
		};

		var graphTarget = $("#"+tgrafik);

		var barGraph = new Chart(graphTarget, {
			type: 'line',
			data: chartdata,
			 
		});
	//});
}

function evalJlhTransBeli (rnd){
	evalTransBeli(rnd);
}
function evalTransBeli(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	try { byangkut=	unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	//try { bytimbang=	unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	
	//$('#tjlhbrutto_'+rnd).html(maskRp(vj_jlh0,0,1));
	//$('#tjlhtarra_'+rnd).html(maskRp(vj_jlh1,0,1));
	$('#tjlhnetto_'+rnd).html(maskRp(vj_jlh2,0,9));
	
	
	netto=brutto*1+byangkut*1;
	//byangkut*1+bykuli*1;
	 
	$('#brutto_'+rnd).val(brutto);
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#netto_'+rnd).val(maskRp(netto,0,0));
	$('#xnetto_'+rnd).html(maskRp(netto,0,0));
	
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

	terhutang=netto-paidtoday*1;
	try { 
		$('#kurangbayar_'+rnd).val(maskRp(terhutang,0,0));
		$('#xkurangbayar_'+rnd).html(maskRp(terhutang,0,0));	
	} catch(e) { }
}

function evalJlhTrPack (rnd){
	evalTrPack(rnd);
}
function evalTrPack(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_brutto-"+pg).val());
		io=$("#"+clstb+"-dk-"+pg).val();
		if (io=='k') jlh*=-1;
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=0;
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		$("#"+clstb+"-jlh_terima-"+pg).val(jlh);
		brutto+=subtot*1;	
	}

	bal=brutto;
	
	
	$('#xballance_'+rnd).html(maskRp(bal),0,0);
	$('#ballance_'+rnd).val(bal);
	$('#jlhitemfix_'+rnd).html(jlhitemfix);
}

function evalJlhTrBB (rnd){
	evalTrBB(rnd);
}
function evalTrBB(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=0;
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}

	bal=brutto;
	$('#xballance_'+rnd).html(maskRp(bal),0,0);
	$('#ballance_'+rnd).val(bal);
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

}


function evalJlhTrBJ (rnd){
	evalTrBJ(rnd);
}
function evalTrBJ(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=0;
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}

	bal=brutto;
	$('#xballance_'+rnd).html(maskRp(bal),0,0);
	$('#ballance_'+rnd).val(bal);
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

}

function evalJlhTransDist (rnd){
	evalTransDist(rnd);
}
function evalTransDist(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	try { byangkut=	unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	//try { bytimbang=	unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	
	//$('#tjlhbrutto_'+rnd).html(maskRp(vj_jlh0,0,1));
	//$('#tjlhtarra_'+rnd).html(maskRp(vj_jlh1,0,1));
	$('#tjlhnetto_'+rnd).html(maskRp(vj_jlh2,0,9));
	
	
	netto=brutto*1+byangkut*1;
	//byangkut*1+bykuli*1;
	 
	$('#brutto_'+rnd).val(brutto);
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#netto_'+rnd).val(maskRp(netto,0,0));
	$('#xnetto_'+rnd).html(maskRp(netto,0,0));
	
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

	terhutang=netto-paidtoday*1;
	try { 
		$('#kurangbayar_'+rnd).val(maskRp(terhutang,0,0));
		$('#xkurangbayar_'+rnd).html(maskRp(terhutang,0,0));	
	} catch(e) { }
}


function evalJlhTransRBeli(rnd){
	evalTransRBeli(rnd);
}
function evalTransRBeli(rnd,awal){
	awalTrans(awal,rnd);
	clstb=$('#clstb-'+rnd).val();
	$nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;

	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		jlh=unmaskRp($("#"+clstb+"-jlh_terima-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		disc=unmaskRp($("#"+clstb+"-disc-"+pg).val());
		ident=+rnd+"_"+i+"";//pengenal
		vj_jlh2+=jlh;
		
		if (jlh>0) jlhitemfix++;
		subtot=Math.round(jlh*(hrg-disc));
		//alert(jlh+' '+hrg+' '+disc+' '+subtot+'> '+"#d_hrg_"+ident);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
	}
	//byangkut=	unmaskRp($('#byangkutest_'+rnd).val());
	try { byangkut=	unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	//try { bytimbang=	unmaskRp($('#bytimbang_'+rnd).val()); } catch(e) {bytimbang=0;}
	try { paidtoday=	unmaskRp($('#paidtoday_'+rnd).val());} catch(e) {paidtoday=0;}
/*	try { byangkut=		unmaskRp($('#byangkut_'+rnd).val()); } catch(e) {byangkut=0;}
	try { bykuli=		unmaskRp($('#bykuli_'+rnd).val()); } catch(e) {bykuli=0;}
	*/
	
	//$('#tjlhbrutto_'+rnd).html(maskRp(vj_jlh0,0,1));
	//$('#tjlhtarra_'+rnd).html(maskRp(vj_jlh1,0,1));
	$('#tjlhnetto_'+rnd).html(maskRp(vj_jlh2,0,0));
	
	
	netto=brutto*1+byangkut*1;
	//byangkut*1+bykuli*1;
	 
	$('#brutto_'+rnd).val(brutto);
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#netto_'+rnd).val(maskRp(netto,0,0));
	$('#xnetto_'+rnd).html(maskRp(netto,0,0));
	
	$('#jlhitemfix_'+rnd).html(jlhitemfix);

	terhutang=netto-paidtoday*1;
	try { 
		$('#kurangbayar_'+rnd).val(maskRp(terhutang,0,0));
		$('#xkurangbayar_'+rnd).html(maskRp(terhutang,0,0));	
	} catch(e) { }
}


function evalJlhTransSTO(rnd){
	evalTransSTO(rnd);
}
function evalTransSTO(rnd){
	clstb=$('#clstb-'+rnd).val();
	nmtb="tbdet_"+rnd;
	idtb=clstb+"-"+rnd;
	jlhno=$('#jlhrowdet-'+idtb).val()*1;
	jlhitemfix=tjlhterima=brutto=netto=0;
	vj_jlh0=0;
	vj_jlh1=0;
	vj_jlh2=0;
	for (i=1;i<=jlhno;i++) {
		pg=rnd+"-"+i;//pengenal
		
		stsystem=unmaskRp($("#"+clstb+"-stsystem-"+pg).val());
		stfisik=unmaskRp($("#"+clstb+"-stfisik-"+pg).val());
		hrg=unmaskRp($("#"+clstb+"-hrg-"+pg).val());
		beda=stfisik-stsystem;
		$("#"+clstb+"-jlh_terima-"+pg).val(maskRp(beda));
		console.log("stsy"+stsystem+", stfis"+stfisik);
		jlh=beda;
		subtot=Math.round(jlh*hrg);
		xsubtot=maskRp(subtot,0,0);
		$("#"+clstb+"-subtot-"+pg).val(xsubtot);
		brutto+=subtot*1;	
		jlhitemfix++;
	}
	$('#jlhitemfix_'+rnd).html(jlhitemfix);
	
	//$('#tjlhbrutto_'+rnd).html(maskRp(vj_jlh0,0,1));
	//$('#tjlhtarra_'+rnd).html(maskRp(vj_jlh1,0,1));
	//$('#tjlhnetto_'+rnd).html(maskRp(vj_jlh2,0,0));
	
	
	//netto=brutto*1+byangkut*1;
	//byangkut*1+bykuli*1;
	 
	
	$('#brutto_'+rnd).val(brutto);
	$('#tbrutto_'+rnd).html(maskRp(brutto,0,0));
	$('#xbrutto_'+rnd).html(maskRp(brutto,0,0));
	//$('#netto_'+rnd).val(maskRp(netto,0,0));
	//$('#xnetto_'+rnd).html(maskRp(netto,0,0));
	


}

function cekInpLapStock(inp,rnd) {
	if (inp=='jlap') {
		d=($("#jlap_"+rnd).val()=="nstock"?"none":"");
		$("#tperiode_"+rnd).css({ display:d })

	}
}

//laporan penjualan
function cekJenisLapJual(rnd) {
	b=$("#bentuk_"+rnd).val();	
	//alert(b);
	//bukaAjax("tpbt_"+rnd,"filtercombo.php?op=plg&kdbranch="+kdbranch+"&newrnd="+rnd,rnd," $('#tpbt_"+rnd+"').show();$('#kdpembantu_"+rnd+"').combobox();");
	if (b.indexOf('brg')>0) {
		$("#tfbrg_"+rnd).show();
	} else
		$("#tfbrg_"+rnd).hide();
	
}
//'$parentrnd','$jtrans',#id#,#jumlah#,'#isi#'
datatmp='';
function useTemplate(parentrnd,rnd,br,jtrans){
	//useTemplate('$jtrans',#id#);
	clstb=$('#clstb-'+parentrnd).val();
	sh=$("#h-"+br+"-"+rnd+"").val();
	ah=sh.split("|");
	isi=ah[0];
	datatmp=JSON.parse(isi);
	console.log('datamp');
	console.log(datatmp);
	jlhtmp=datatmp.length;
	br=$("#jlhrowdet-"+clstb+"-"+parentrnd).val();
				
	if ((jtrans=='PG')||(jtrans=='BB')||(jtrans=='BJ')) {
		for (jt=0;jt<jlhtmp;jt++) {
			if (jt==0) {
				//baris pertama daftar field
				temp="#tfldhasil-"+clstb+"-"+parentrnd;
				ha=datatmp[jt];
				$(temp).val(ha);
				
			}else {
				temp="#thasil-"+clstb+"-"+parentrnd;
				ha=datatmp[jt].replaceAll('~','|');
				console.log(ha);
				$(temp).val(ha);
				//alert(ha);
				$(temp).change().click();
				
				br++;
				
					
			}	
			
			

		}
	}

	/*
	jbr=datatmp.kdbrg.length
	console.log(jtrans+' > rnd='+parentrnd+' >'+datatmp.kdbrg);
	param="|";
	
	//if (jtrans=='PG') {
		for (i=1;i<jbr;i++) {
			ha=datatmp.kdbrg[i]+param+datatmp.nmbarang[i]+param+datatmp.jlh_terima[i]+param+datatmp.sat[i]+param+datatmp.hrg[i];
			temp="#thasil-cpacking-"+parentrnd;
			console.log(ha);
			$(temp).val(ha);
			//$(temp).show();
			$(temp).click();
				
		}
	//}
	/*
	temp="#thasil-cpacking-"+parentrnd;
	$(temp).val(h);
	$(temp).click();
	*/
	//alert(hasil);
	
}